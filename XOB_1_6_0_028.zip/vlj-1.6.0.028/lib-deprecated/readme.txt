README.TXT: lib-deprecated folder

This folder contains the following deprecated libraries formerly used in the VistALink RAR:

  -xbean.jar: No longer needed for WebLogic v9/10 because XMLBeans is included as part of the
              core server. The jar is therefore deprecated, but still distributed in case it 
              is needed on a different application server implementation. It was previously
              one of the supporting jars included in the "lib" subfolder in the exploded 
              VistALink RAR.
           