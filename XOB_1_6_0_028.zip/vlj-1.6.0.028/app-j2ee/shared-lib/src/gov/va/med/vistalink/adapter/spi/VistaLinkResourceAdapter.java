package gov.va.med.vistalink.adapter.spi;

import java.io.Serializable;

import javax.resource.NotSupportedException;
import javax.resource.ResourceException;
import javax.resource.spi.ActivationSpec;
import javax.resource.spi.BootstrapContext;
import javax.resource.spi.ResourceAdapterInternalException;
import javax.resource.spi.endpoint.MessageEndpointFactory;
import javax.transaction.xa.XAResource;

import org.apache.log4j.Logger;

/**
 * The VistaLink resource adapter.
 * 
 * TODO: evaluate whether this class can be used to replace functionality currently present in
 * gov.va.med.vistalink.management.VistaLinkConnectorNotificationListener, which listens for appserver deploy/undeploy
 * events for connectors. Not clear if enough information/context is provided to this class to be able to do anything
 * meaningful.
 * 
 */
public class VistaLinkResourceAdapter implements javax.resource.spi.ResourceAdapter, Serializable {

	private static final long serialVersionUID = 6546711036673974565L;

	/**
	 * The logger used by this class
	 */
	private static final Logger logger = Logger.getLogger(VistaLinkResourceAdapter.class);

	/*
	 * This is called when a resource adapter instance is bootstrapped. This may be during resource adapter deployment
	 * or application server startup. This is a startup notification from the application server, and this method is
	 * called by an application server thread. The application server thread executes in an unspecified context.
	 * 
	 * During this method call a ResourceAdapter JavaBean is responsible for initializing the resource adapter instance.
	 * Any exception thrown during this method call causes the application server to abort the bootstrap procedure for
	 * this specific resource adapter instance.
	 * 
	 * (non-Javadoc)
	 * @see javax.resource.spi.ResourceAdapter#start(javax.resource.spi.BootstrapContext)
	 */
	public void start(BootstrapContext bootstrapContext) throws ResourceAdapterInternalException {
		logger.debug("VistaLinkResourceAdapter started");
	}

	/*
	 * This is called when a resource adapter instance is undeployed or during application server shutdown. This is a
	 * shutdown notification from the application server, and this method is called by an application server thread. The
	 * application server thread executes in an unspecified context.
	 * 
	 * During this method call, a ResourceAdapter JavaBean is responsible for performing an orderly shutdown of the
	 * resource adapter instance. Any exception thrown by this method call does not alter the processing of the
	 * application server shutdown or resource adapter undeployment that caused this method call. The application server
	 * may log the exception information for error reporting purposes.
	 * 
	 * (non-Javadoc)
	 * @see javax.resource.spi.ResourceAdapter#stop()
	 */
	public void stop() {
		logger.debug("VistaLinkResourceAdapter stopped");
	}

	/*
	 * This is called during the activation of a message endpoint. This causes the resource adapter instance to do the
	 * necessary setup (ie., setup message delivery for the message endpoint with a message provider). Note that message
	 * delivery to the message endpoint might start even before this method returns.
	 * 
	 * Endpoint activation is deemed successful only when this method completes successfully without throwing any
	 * exceptions.
	 * 
	 * (non-Javadoc)
	 * @see javax.resource.spi.ResourceAdapter#endpointActivation(javax.resource.spi.endpoint.MessageEndpointFactory,
	 *      javax.resource.spi.ActivationSpec)
	 */
	public void endpointActivation(MessageEndpointFactory messageEndpointFactory, ActivationSpec activationSpec)
			throws ResourceException {
		logger.debug("VistaLinkResourceAdapter endpoint activation executed");
		// we're not a bi-directional adapter
		throw new NotSupportedException();
	}

	/*
	 * This is called when a message endpoint is deactivated. The instances passed as arguments to this method call
	 * should be identical to those passed in for the corresponding endpointActivation call. This causes the resource
	 * adapter to stop delivering messages to the message endpoint.
	 * 
	 * Any exception thrown by this method is ignored. After this method call, the endpoint is deemed inactive.
	 * 
	 * (non-Javadoc)
	 * @see javax.resource.spi.ResourceAdapter#endpointDeactivation(javax.resource.spi.endpoint.MessageEndpointFactory,
	 *      javax.resource.spi.ActivationSpec)
	 */
	public void endpointDeactivation(MessageEndpointFactory messageEndpointFactory, ActivationSpec activationSpec) {
		logger.debug("VistaLinkResourceAdapter endpoint deactivation executed");
	}

	/*
	 * This method is called by the application server during crash recovery. This method takes in an array of
	 * ActivationSpec JavaBeans and returns an array of XAResource objects each of which represents a unique resource
	 * manager. The resource adapter may return null if it does not implement the XAResource interface. Otherwise, it
	 * must return an array of XAResource objects, each of which represents a unique resource manager that was used by
	 * the endpoint applications. The application server uses the XAResource objects to query each resource manager for
	 * a list of in-doubt transactions. It then completes each pending transaction by sending the commit decision to the
	 * participating resource managers.
	 * 
	 * (non-Javadoc)
	 * @see javax.resource.spi.ResourceAdapter#getXAResources(javax.resource.spi.ActivationSpec[])
	 */
	public XAResource[] getXAResources(ActivationSpec[] activationSpecArray) throws ResourceException {
		logger.debug("VistaLinkResourceAdapter get xa resources executed");
		throw new NotSupportedException();
	}

}