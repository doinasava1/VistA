package gov.va.med.vistalink.adapter.heartbeat;

import gov.va.med.vistalink.adapter.spi.EMAdapterEnvironment;
import gov.va.med.vistalink.adapter.spi.VistaLinkManagedConnection;

import java.util.Timer;

import org.apache.log4j.Logger;

/**
 * Manages the VistaHeartBeatTimerTask to synchronize all access to the Timer and the TimerTask. All public methods are
 * synchronized(this) If the environment is J2EE this class disables the heartbeat.
 * 
 */
public class VistaHeartBeatTimerManager {

	/**
	 * The timer task used to run the scheduled heart beats
	 */
	private VistaHeartbeatTimerTask timerTask;

	/**
	 * The timer used to schedule the heart beats
	 */
	private Timer heartBeatTimer;

	/**
	 * The rate at which the heart beat will be scheduled in milliseconds. Initially set to 10 seconds before call to M
	 * server is made.
	 * <p>
	 * Note: This initial default is needed for socket timeout purposes.
	 */
	private long heartBeatRate = 10000;

	/**
	 * Identifies whether or not the heart beat timer is active
	 */
	private boolean heartBeatActive;

	private boolean retrievedHeartBeatRate;

	private boolean constructedTimerTask;

	private EMAdapterEnvironment adapterEnvironment;

	/**
	 * The logger used for this class
	 */
	private static final Logger logger = Logger.getLogger(VistaHeartBeatTimerManager.class);

	/**
	 * Constructor for VistaHeartBeatTimerManager. Creates a new VistaHeartBeatTimerTask, and Timer
	 */
	public VistaHeartBeatTimerManager() {
		super();
		setHeartBeatActive(false);
		setRetrievedHeartBeatRate(false);
		setConstructedTimerTask(false);
	}

	/**
	 * J2SE: Adds a managed connection to perform heartbeat on. This method will activate the timer if it has not
	 * already been started.
	 * <p>
	 * J2EE: Does not activate the Timer as no timer is used in J2EE implementation. Gets the heartbeat rate from M.
	 * 
	 * @param mc - the managed connection to add
	 * @throws HeartBeatInitializationFailedException
	 */
	public void addManagedConnection(VistaLinkManagedConnection mc, long heartBeatRate)
			throws HeartBeatInitializationFailedException {

		synchronized (this) {

			if (!hasConstructedTimerTask()) {
				if (logger.isDebugEnabled()) {
					logger.debug("Constructing timer task");
				}

				constructTimerTask();

			}

			if (!hasRetrievedHeartBeatRate()) {
				if (logger.isDebugEnabled()) {
					logger.debug("setting heartbeat rate");
				}
				setHeartBeatRate(heartBeatRate);

			}

			if (getAdapterEnvironment().equals(EMAdapterEnvironment.J2EE)) {

				return;

			}

			timerTask.addManagedConnection(mc);

			if (logger.isDebugEnabled()) {
				logger.debug("Managed connection added for J2SE");
			}

			if (!isHeartBeatActive()) {
				startTimer();
			}

		}
	}

	/**
	 * Executes the interaction with M to retrieve the rate at which the timer executes the heart beat. The timer is
	 * started with the retrieved rate.
	 * 
	 * @param mc - the managed connection to perform the interaction with
	 * @throws HeartBeatInitializationFailedException
	 */

	// commented out this method 9/1/06. Appears to be dead code, not used anywhere. Leaving just in case
	// it should be kept.
	// private void executeHeartBeatInteraction(VistaLinkManagedConnection mc)
	// throws HeartBeatInitializationFailedException {
	//
	// try {
	//
	// if (logger.isDebugEnabled()) {
	// logger.debug("Executing heartBeat interaction");
	// }
	// VistaHeartBeatTimerRequest req = new VistaHeartBeatTimerRequest(adapterEnvironment);
	//
	// VistaHeartBeatTimerResponseFactory resFactory = new VistaHeartBeatTimerResponseFactory();
	//
	// VistaHeartBeatTimerResponse resp = (VistaHeartBeatTimerResponse) mc.executeInteraction(req, resFactory);
	//
	// setHeartBeatRate(resp.getHeartBeatRateMillis());
	//
	// } catch (VistaLinkFaultException e) {
	// throw new HeartBeatInitializationFailedException("VistaLinkFaultException in executeHeartBeatInteraction.",
	// e);
	// } catch (FoundationsException e) {
	// throw new HeartBeatInitializationFailedException("FoundationsException in executeHeartBeatInteraction.", e);
	// }
	//
	// }
	/**
	 * J2SE: Removes a managed connection from the heart beat task. The timer is cancelled if there are no managed
	 * connections in the list.
	 * <p>
	 * J2EE: This method returns immediately as no managed connection have been added.
	 * 
	 * @param mc -the managed connection to be removed from the list
	 */
	public void removeManagedConnection(VistaLinkManagedConnection mc) {

		if (getAdapterEnvironment().equals(EMAdapterEnvironment.J2EE)) {
			return;
		}

		synchronized (this) {

			if (timerTask != null) {
				timerTask.removeManagedConnection(mc);
				logger.debug("Removed managed connection");
				if (timerTask.isManagedConnectionListEmpty()) {
					logger.debug("cancelling timer");
					cancelTimer();
				}
			}

		}
	}

	/**
	 * Starts the timer with the specified rate
	 * 
	 */
	private void startTimer() {
		if (!isHeartBeatActive()) {
			heartBeatTimer = null;

			heartBeatTimer = new Timer(true);

			heartBeatTimer.schedule(timerTask, getHeartBeatRate(), getHeartBeatRate());
			setHeartBeatActive(true);

			if (logger.isDebugEnabled()) {
				logger.debug("Timer started");
			}
		} else {
			if (logger.isDebugEnabled()) {
				logger.debug("Timer is already running");
			}
		}
	}

	/**
	 * Cancels the timer.
	 */
	private void cancelTimer() {
		heartBeatTimer.cancel();
		setHeartBeatActive(false);
		if (logger.isDebugEnabled()) {
			logger.debug("Timer cancelled");
		}
	}

	/**
	 * Returns the heartBeatActive.
	 * 
	 * @return boolean
	 */
	public boolean isHeartBeatActive() {
		synchronized (this) {
			return heartBeatActive;
		}
	}

	/**
	 * Returns the heartBeatRate.
	 * 
	 * @return long
	 */
	public long getHeartBeatRate() {
		synchronized (this) {
			return heartBeatRate;
		}
	}

	/**
	 * Sets the heartBeatActive.
	 * 
	 * @param heartBeatActive The heartBeatActive to set
	 */
	private void setHeartBeatActive(boolean heartBeatActive) {
		this.heartBeatActive = heartBeatActive;
	}

	/**
	 * Sets the heartBeatRate.
	 * 
	 * @param heartBeatRate The heartBeatRate to set
	 */
	private void setHeartBeatRate(long heartBeatRate) {
		this.heartBeatRate = heartBeatRate;
		setRetrievedHeartBeatRate(true);

	}

	public EMAdapterEnvironment getAdapterEnvironment() {
		return adapterEnvironment;
	}

	/**
	 * @param environment
	 */
	public void setAdapterEnvironment(EMAdapterEnvironment environment) {
		adapterEnvironment = environment;
	}

	/**
	 * @return
	 */
	private boolean hasRetrievedHeartBeatRate() {
		return retrievedHeartBeatRate;
	}

	/**
	 * @param b
	 */
	private void setRetrievedHeartBeatRate(boolean b) {
		retrievedHeartBeatRate = b;
	}

	private void constructTimerTask() {
		timerTask = new VistaHeartbeatTimerTask(adapterEnvironment);
		setConstructedTimerTask(true);
	}

	public boolean hasConstructedTimerTask() {
		return constructedTimerTask;
	}

	/**
	 * @param b
	 */
	public final void setConstructedTimerTask(boolean b) {
		constructedTimerTask = b;
	}

}