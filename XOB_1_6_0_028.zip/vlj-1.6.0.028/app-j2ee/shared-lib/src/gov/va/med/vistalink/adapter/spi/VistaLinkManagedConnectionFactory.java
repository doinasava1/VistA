package gov.va.med.vistalink.adapter.spi;

import gov.va.med.environment.Environment;
import gov.va.med.environment.ServerType;
import gov.va.med.exception.ExceptionUtils;
import gov.va.med.exception.FoundationsException;
import gov.va.med.vistalink.adapter.cci.VistaLinkConnectionFactory;
import gov.va.med.vistalink.adapter.cci.VistaLinkResourceException;
import gov.va.med.vistalink.adapter.heartbeat.VistaHeartBeatTimerManager;
import gov.va.med.vistalink.adapter.heartbeat.VistaHeartBeatTimerRequest;
import gov.va.med.vistalink.adapter.heartbeat.VistaHeartBeatTimerResponse;
import gov.va.med.vistalink.adapter.heartbeat.VistaHeartBeatTimerResponseFactory;
import gov.va.med.vistalink.institution.InstitutionMapping;
import gov.va.med.vistalink.institution.InstitutionMappingFactory;
import gov.va.med.vistalink.jmx.IJmxHelper;
import gov.va.med.vistalink.jmx.JmxHelperException;
import gov.va.med.vistalink.jmx.JmxHelperFactory;
import gov.va.med.vistalink.management.VistaLinkConnectorNotificationListener;
import gov.va.med.vistalink.management.VistaLinkInstitutionMapping;

import java.io.PrintWriter;
import java.io.Serializable;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.management.InstanceAlreadyExistsException;
import javax.management.InstanceNotFoundException;
import javax.management.MBeanRegistrationException;
import javax.management.MBeanServer;
import javax.management.MalformedObjectNameException;
import javax.management.NotCompliantMBeanException;
import javax.management.ObjectName;
import javax.resource.ResourceException;
import javax.resource.spi.ConnectionManager;
import javax.resource.spi.ConnectionRequestInfo;
import javax.resource.spi.ManagedConnection;
import javax.resource.spi.ManagedConnectionFactory;
import javax.resource.spi.ValidatingManagedConnectionFactory;
import javax.security.auth.Subject;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

/**
 * Factory for both ManagedConnection and connection factory instances. This class supports connection pooling by
 * defining methods for matching and creating connections.
 * 
 */
public class VistaLinkManagedConnectionFactory implements ManagedConnectionFactory, Serializable,
		ValidatingManagedConnectionFactory {

	public static final String ADAPTER_VERSION = "1.6";

	public static final String ADAPTER_FULL_VERSION = "1.6.0.028";

	public static final String CONNECTOR_PROPERTY_NAME = "connectorJndiName";
	
	private static final String JMX_OBJECT_NAME_STRING_TYPE = "Type";
	private static final String JMX_OBJECT_NAME_STRING_NAME = "Name";

	/**
	 * Cache the classes' hashcode
	 */
	private int hashCode;

	/**
	 * constant for socket timeout used for J2EE
	 */
	private static final long J2EE_DEFAULT_SOCKET_TIMEOUT = 10000;

	/**
	 * constant for socket timeout used for J2SE
	 */
	private static final long J2SE_DEFAULT_SOCKET_TIMEOUT = 10000;

	/**
	 * The logger for this class
	 */
	private static final Logger logger = Logger.getLogger(VistaLinkManagedConnectionFactory.class);

	/**
	 * The minimum value allowed for the J2EE timeout
	 */
	private long defaultJ2EETimeOut = J2EE_DEFAULT_SOCKET_TIMEOUT;

	/**
	 * The minimum value allowed for the J2SE timeout
	 */
	private static long defaultJ2SETimeOut = J2SE_DEFAULT_SOCKET_TIMEOUT;

	/**
	 * The socket timeout multipler for reads
	 */
	private static int socketTimeOutMultipler = 1;

	/**
	 * A flag wheter to use the default minimum value or not
	 */
	private boolean alwaysUseDefaultAsMin = true;

	/**
	 * The raw (unresolved) ip address of the Host M Server this factory will create connections to.
	 */
	private String hostIpAddress;

	/**
	 * The primaryStation attribute assigned from the config file for institution mapping purposes.
	 */
	private String primaryStation = "";

	/**
	 * The resolved ip address of the Host M Server this factory will create connections to.
	 */
	// v1.6 commented out to remove 'resolved' ip address cache
	// private InetAddress hostIpAddressResolved = null;
	/**
	 * The port of the Host M Server this factory will create connections to
	 */
	private int hostPort;

	/**
	 * The access code used to perform initial authentication
	 */
	private String accessCode;

	/**
	 * The verify code used to perform initial authentication
	 */
	private String verifyCode;

	/**
	 * The connector name index to retrieve the connector params from the config file
	 */
	private String connectorJndiName = "";

	/**
	 * retains connection factory created by CreateConnectionFactory()
	 */
	private VistaLinkConnectionFactory cf;

	/**
	 * connector enabled or disabled -- config file setting
	 */
	private boolean connectorEnabled = false;

	/**
	 * The maximum number of connection handles that this factory's managed connections will be able to allocate
	 */
	private int maxConnectionHandles = 1;

	/**
	 * The log writer that will be set by the application server
	 */
	private transient PrintWriter printWriter;

	/**
	 * The timer manager for this factory and its created managed connections
	 */
	private transient VistaHeartBeatTimerManager timerManager;

	/**
	 * Identifies the environment that this adapter is running in
	 */
	private EMAdapterEnvironment adapterEnvironment = EMAdapterEnvironment.J2SE;

	private long managedConnectionCount = 0;

	private Object mcCountSyncObj = new Object();

	private static long managedFactoryCount = 0;

	private static Object mfCountSyncObj = new Object();

	private long distinguishedIdentifier = 0;

	// health monitoring fields
	private long connectionFailureCount = 0;

	private long connectionAuthFailureCount = 0;

	private long divisionMismatchCount = 0;

	private long identityFailureCount = 0;

	private long productionMismatchCount = 0;

	private Object healthSyncObj = new Object();

	// perf stat fields
	private long createConnectionHandleCount = 0;

	private long createConnectionHandleTotalMillis = 0;

	private Object createConnectionHandleAvgSyncObj = new Object();

	private long matchManagedConnectionCount = 0;

	private long matchManagedConnectionTotalMillis = 0;

	private Object matchManagedConnectionAvgSyncObj = new Object();

	private String parseConfigFailureMessage = null;

	private HashSet mcSet = new HashSet();

	// static initializer
	static {

		String INST_MBEAN_COULD_NOT_REG_MSG = "Could not register institution mapping MBean: ";

		logger.info("running static initializer, VistALink adapter version " + ADAPTER_FULL_VERSION + ".");
		ServerType serverType = Environment.getServerType();
		// if it's a J2EE server...
		if ((!serverType.equals(ServerType.JAVA_SE)) && (!serverType.equals(ServerType.UNKNOWN))) {

			VistaLinkConnectorNotificationListener delegateListener = new VistaLinkConnectorNotificationListener();
			IJmxHelper jmxHelper = JmxHelperFactory.getJmxHelper();
			MBeanServer localMBeanServer = null;

			// get local MBeanServer
			try {
				localMBeanServer = jmxHelper.getLocalMBeanServer();
			} catch (JmxHelperException e) {
				logger.error("Could not retrieve local MBean Server. VistaLinkConnector and Institution MBeans cannot be registered: ", e);
			}

			// register notification listener to register VL MBeans for connectors
			if (localMBeanServer != null) {
				try {
					ObjectName delegate = new ObjectName("JMImplementation:type=MBeanServerDelegate");
					// standard MBean to hook into reg/unreg events in an MBeanServer
					localMBeanServer.addNotificationListener(delegate, delegateListener, null, null);
					logger.debug("registered VistaLinkConnectorNotificationListener!");
					// call one-time method to catch any connectors (mbeans) already created/registered.
					delegateListener.performInitialScan();
				} catch (MalformedObjectNameException e) {
					logger.error("Problem registering notification listener: ", e);
				} catch (InstanceNotFoundException e) {
					logger.error("Problem registering notification listener: ", e);
				}
				// register 'singleton' MBean for institution mapping
				try {
					VistaLinkInstitutionMapping instMapMBean = new VistaLinkInstitutionMapping(); 
					StringBuffer sb = new StringBuffer(jmxHelper.getJmxDomainForHev()).append(":");
					sb.append(JMX_OBJECT_NAME_STRING_NAME).append('=').append(VistaLinkInstitutionMapping.getMBeanName());
					sb.append(',').append(JMX_OBJECT_NAME_STRING_TYPE).append('=').append(VistaLinkInstitutionMapping.getMBeanType());
					String additionalProps = jmxHelper.getServerObjectNamePropertiesForRegistration();
					if (additionalProps.length() > 0) {
						sb.append(',').append(additionalProps);
					}
					ObjectName instMappingObjectName = new ObjectName(sb.toString());
					localMBeanServer.registerMBean(instMapMBean, instMappingObjectName);
					logger.debug("MBean '" + instMappingObjectName + "' registered.");
				} catch (MalformedObjectNameException e) {
					logger.error(INST_MBEAN_COULD_NOT_REG_MSG, e);
				} catch (InstanceAlreadyExistsException e) {
					logger.error(INST_MBEAN_COULD_NOT_REG_MSG, e);
				} catch (MBeanRegistrationException e) {
					logger.error(INST_MBEAN_COULD_NOT_REG_MSG, e);
				} catch (NotCompliantMBeanException e) {
					logger.error(INST_MBEAN_COULD_NOT_REG_MSG, e);
				} catch (NullPointerException e) {
					logger.error(INST_MBEAN_COULD_NOT_REG_MSG, e);
				}
			}

		} else {
			// it's J2SE
			// set timeout multipler
			String property = "gov.va.med.vistalink.socket-timeout-multipler";
			String timeOutMultipler = System.getProperty(property);
			if (timeOutMultipler != null) {
				try {
					setSocketTimeOutMultipler(Integer.parseInt(timeOutMultipler));
				} catch (NumberFormatException e) {
					logger.warn("The value of the JVM property " + property + " [" + timeOutMultipler
							+ "] is not a valid number. Default will be used.");
				}
			}
			logger.debug("J2SE socket time-out multipler set to " + getSocketTimeOutMultipler() + ".");

			// set timeout default
			property = "gov.va.med.vistalink.socket-timeout-default";
			String j2seDefaultSocketTimeout = System.getProperty(property);
			if (j2seDefaultSocketTimeout != null) {
				try {
					setDefaultJ2SETimeOut(Long.parseLong(j2seDefaultSocketTimeout));
				} catch (NumberFormatException e) {
					logger.warn("The value of the JVM property " + property + " [" + j2seDefaultSocketTimeout
							+ "] is not a valid number. Default will be used.");
				}
			}
			logger.debug("J2SE default socket time-out set to " + getDefaultJ2SETimeOut() + " ms.");
		}
	}

	/**
	 * Constructor. Actions include creating a new VistaHeartBeatTimerManager, setting the adapter environment to J2EE,
	 * setting the instance distinguished identifier and incrementing the class distinguished identifier, and
	 * registering the VistaLink MBean for this managed connection factory.
	 */
	public VistaLinkManagedConnectionFactory() {

		// set distinguished id, hashcode first
		synchronized (mfCountSyncObj) {
			distinguishedIdentifier = ++managedFactoryCount;
		}
		setHashCode();

		// v1.6 commented out to remove 'resolved' ip address cache
		// hostIpAddressResolved = null;
		timerManager = new VistaHeartBeatTimerManager();
		timerManager.setAdapterEnvironment(adapterEnvironment);

		// NOTE: ra.xml setter/getter properties are *not* yet set here, in WLS
		// at least

		if (logger.isDebugEnabled()) {
			String debugMsg = getLoggerFormattedString("Constructed");
			logger.debug(debugMsg);
		}
	}

	/**
	 * Creates a connection factory instance. The connection factory instance gets initialized with a default connection
	 * manager provided by the resource adapter.
	 * 
	 * @return VistaLinkConnectionFactory instance
	 * @see javax.resource.spi.ManagedConnectionFactory#createConnectionFactory(javax.resource.spi.ConnectionManager)
	 */
	public Object createConnectionFactory(ConnectionManager mgr) throws ResourceException {

		// NOTE: ra.xml setter/getter properties *are* set when get here, in WLS
		// at least

		if (logger.isDebugEnabled()) {
			String loggerMsg = getLoggerFormattedString("createConnectionFactory->managed");
			logger.debug(loggerMsg);
		}

		cf = new VistaLinkConnectionFactory(this, mgr);
		return cf;
	}

	/**
	 * Creates a connection factory instance with the default connection manager.
	 * 
	 * @see javax.resource.spi.ManagedConnectionFactory#createConnectionFactory()
	 */
	public Object createConnectionFactory() throws ResourceException {

		if (logger.isDebugEnabled()) {
			String loggerMsg = getLoggerFormattedString("createConnectionFactory->unmanaged");
			logger.debug(loggerMsg);
		}
		cf = new VistaLinkConnectionFactory(this, null);
		return cf;
	}

	public VistaLinkSystemInfoVO getSystemInfo() {
		VistaLinkManagedConnection mc = null;
		VistaLinkSystemInfoVO systemInfoVO = null;
		try {
			mc = (VistaLinkManagedConnection) createManagedConnection(null, null);
			systemInfoVO = mc.executeSystemInfoInteraction().getSystemInfoVO();
			mc.destroy();
		} catch (Exception e) {
			logger.error(e);
			systemInfoVO = new VistaLinkSystemInfoVO();
			systemInfoVO.setErrorMessage(e.getClass().getName() + ": " + e.getMessage());
		}
		return systemInfoVO;
	}

	/**
	 * Creates a new physical connection to M.
	 * 
	 * @param subject Caller's security information
	 * @param info Additional resource adapter specific connection request information
	 * @return ManagedConnection instance
	 * @throws VistaLinkResourceException
	 * @see javax.resource.spi.ManagedConnectionFactory#createManagedConnection(javax.security.auth.Subject,
	 *      javax.resource.spi.ConnectionRequestInfo)
	 */
	public ManagedConnection createManagedConnection(Subject subject, ConnectionRequestInfo info)
			throws ResourceException {

		try {

			// if disabled, stop here
			if (!this.connectorEnabled) {
				StringBuffer failureMessage = new StringBuffer("Connection factory for '");
				failureMessage.append(this.connectorJndiName);
				failureMessage
						.append("' did not successfully initialize; cannot create connection. Check log files for errors.");
				if (parseConfigFailureMessage != null) {
					failureMessage.append(" Connection factory initialization failure was: '");
					failureMessage.append(this.parseConfigFailureMessage);
					failureMessage.append("'.");
				}
				failureMessage.append(" Try fixing condition and then redeploy connector.");
				throw new VistaLinkResourceException(failureMessage.toString());
			}

			// resolve IP address (in case it needs name resolution) and set
			// internal hostIpAddressResolved property
			// v1.6 commented out to remove 'resolved' ip address cache
			// setHostIpAddressResolved(this.hostIpAddress);

			// now ready to actually create the connection
			long mcDistinguishedIdentifier = 0;
			synchronized (mcCountSyncObj) {
				mcDistinguishedIdentifier = ++managedConnectionCount;
			}
			if (logger.isDebugEnabled()) {
				String loggerMsg = getLoggerFormattedString((new StringBuffer())
						.append("Creating Managed connection->").append(mcDistinguishedIdentifier).toString());
				logger.debug(loggerMsg);
			}

			// create the connection
			VistaLinkManagedConnection mc = new VistaLinkManagedConnection(this, mcDistinguishedIdentifier);
			if (logger.isDebugEnabled()) {
				String loggerMsg = getLoggerFormattedString((new StringBuffer()).append("Created Managed connection->")
						.append(mcDistinguishedIdentifier).toString());
				logger.debug(loggerMsg);
			}
			mcSet.add(mc);
			return mc;

			// v1.6 commented out to remove 'resolved' ip address cache
			// } catch (UnknownHostException e) {
			// String errMsg = "Unknown Host";
			// if (logger.isEnabledFor(Level.ERROR)) {
			// String loggerMsg = getLoggerFormattedStringWStackTrace(errMsg, e);
			// logger.error(loggerMsg);
			// }
			// throw new VistaLinkResourceException(errMsg, e);

		} catch (VistaLinkResourceException e) {
			if (logger.isEnabledFor(Level.ERROR)) {
				/*
				 * Minimized error logging 9/27/07 Kyle VistaLinkResourceExceptions will already be logged
				 * VistaLinkManagedConnection() depending on log4j config and/or if due to config file failure above,
				 * still don't need full stack trace -- just clutters logs to put full stack trace in twice.
				 */
				// String loggerMsg = getLoggerFormattedStringWStackTrace(
				// "Resource exception occurred in creatingManagedConnection()", e);
				// logger.error(loggerMsg);
				logger.error(e.getMessage());
			}
			throw e;
		} catch (Exception e) {
			if (logger.isEnabledFor(Level.ERROR)) {
				String loggerMsg = getLoggerFormattedStringWStackTrace(
						"Unexpected exception occured in creatingManagedConnection()", e);
				logger.error(loggerMsg);
			}
			throw new VistaLinkResourceException(e);
		}
	}

	/**
	 * Remove managed connection for the set used for lookup in matchedManagedConnections
	 * 
	 * @param mc reference to a managed connection
	 */
	protected void removeMc(VistaLinkManagedConnection mc) {
		mcSet.remove(mc);
	}

	/**
	 * Returns a matched connection from the candidate set of connections. This method returns a ManagedConnection
	 * instance that is the best match for handling the connection allocation request.
	 * <p>
	 * The method iterates through a Set of type VistaLinkManagedConnection determines if the HostIPAddress and HostPort
	 * are the same as those defined for this instance of the VistaLinkManagedConnectionFactory and then determines if
	 * the connection request info is equal to the connection request info associated with the mc.
	 * <p>
	 * <br>
	 * <b>Managed Connection Check Criteria: </b> <br>
	 * 1) If the connection request info passed in is equal to the connection request info associated with the mc, then
	 * this mc is immediately returned. It is the best match.
	 * <p>
	 * 2) The first mc found that is not already associated with a connection request info object (mc.getConnReqInfo() ==
	 * null), is the second best match. This mc is returned if no match for #1 is found.
	 * <p>
	 * 3) The last mc found where the connection request info passed in is not equal to the connection request info
	 * associated with the mc will be returned if no match for either #1 or #2 is found.
	 * <p>
	 * 4) If no match for any of #1, #2, #3 is found then null is returned.
	 * <p>
	 * 
	 * @param connectionSet candidate connection set
	 * @param subject caller's security information
	 * @param info additional resource adapter specific connection request information
	 * @return ManagedConnection if resource adapter finds an acceptable match otherwise null
	 * @throws VistaLinkResourceException
	 * @see javax.resource.spi.ManagedConnectionFactory#matchManagedConnections(java.util.Set,
	 *      javax.security.auth.Subject, javax.resource.spi.ConnectionRequestInfo)
	 */
	public ManagedConnection matchManagedConnections(Set connectionSet, Subject subject, ConnectionRequestInfo info)
			throws ResourceException {
		long beginTimeMillis = System.currentTimeMillis();
		String loggerMsg;
		VistaLinkManagedConnection nullConnSpecConnection = null;
		VistaLinkManagedConnection lastConnection = null;
		VistaLinkManagedConnection returnConnection = null;
		boolean foundMatchWithOutConnSpec = false;

		if (logger.isDebugEnabled()) {
			loggerMsg = getLoggerFormattedString("matchManagedConnection: Pool Size: " + connectionSet.size());
			logger.debug(loggerMsg);
		}

		VistaLinkConnectionRequestInfo vlConReqInfo = (VistaLinkConnectionRequestInfo) info;
		if (info != null) {
			if (logger.isDebugEnabled()) {
				loggerMsg = getLoggerFormattedString((new StringBuffer()).append("matchManagedConnection->").append(
						info.toString()).toString());
				logger.debug(loggerMsg);
			}
		}

		Iterator it = connectionSet.iterator();
		while (it.hasNext()) {
			Object obj = it.next();
			if (obj instanceof VistaLinkManagedConnection) {
				VistaLinkManagedConnection mc = (VistaLinkManagedConnection) obj;
				if (logger.isDebugEnabled()) {
					loggerMsg = getLoggerFormattedString((new StringBuffer()).append("matchManagedConnection->")
							.append(mc.toString()).append("->").append(mc.getConnReqInfoString()).toString());
					logger.debug(loggerMsg);
				}
				if (mcSet.contains(mc)) {
					lastConnection = mc;
					// is this mc re-authenticated with the same
					// reqinfo/connspec
					if (vlConReqInfo.equals(mc.getConnReqInfo())) {
						if (logger.isDebugEnabled()) {
							loggerMsg = getLoggerFormattedString((new StringBuffer()).append(
									"matchManagedConnection->Found match with matching connection request info->")
									.append(mc.toString()).append("->").append(mc.getConnReqInfoString()).toString());
							logger.debug(loggerMsg);
						}
						// save elapsed time
						long elapsedMillis = System.currentTimeMillis() - beginTimeMillis;
						addMatchManagedConnectionTime(elapsedMillis);
						if (logger.isInfoEnabled()) {
							logger.info(getLoggerFormattedString(new StringBuffer().append(
									"matchManagedConnections(...) processing time [match found] == ").append(
									elapsedMillis).toString()));
						}
						return mc;

					} else if (!foundMatchWithOutConnSpec) {
						if (mc.getConnReqInfo() == null) {
							foundMatchWithOutConnSpec = true;
							nullConnSpecConnection = mc;
						}
						if (logger.isDebugEnabled()) {
							loggerMsg = getLoggerFormattedString((new StringBuffer()).append(
									"matchManagedConnection->no match on request info->").append(mc.toString()).append(
									"->").append(mc.getConnReqInfoString()).toString());
							logger.debug(loggerMsg);
						}
					} // !foundMatchWithOutConnSpec check
				} // mcSet check
			} // instanceof check
		} // while loop

		if (nullConnSpecConnection != null) {
			returnConnection = nullConnSpecConnection;
		} else {
			returnConnection = lastConnection;
		}
		// save end time
		long elapsedMillis = System.currentTimeMillis() - beginTimeMillis;
		addMatchManagedConnectionTime(elapsedMillis);
		if (logger.isInfoEnabled()) {
			logger.info(getLoggerFormattedString(new StringBuffer().append(
					"matchManagedConnections(...) processing time [match not found] == ").append(elapsedMillis)
					.toString()));
		}
		return returnConnection;
	}

	/**
	 * @see javax.resource.spi.ManagedConnectionFactory#getLogWriter()
	 */
	public PrintWriter getLogWriter() throws ResourceException {
		if (printWriter == null) {
			String errMsg = "Log writer is null";
			if (logger.isEnabledFor(Level.ERROR)) {
				String loggerMsg = getLoggerFormattedString(errMsg);
				logger.error(loggerMsg);
			}
			throw new VistaLinkResourceException(errMsg);
		}
		return printWriter;
	}

	/**
	 * @see javax.resource.spi.ManagedConnectionFactory#setLogWriter(java.io.PrintWriter)
	 */
	public void setLogWriter(PrintWriter out) throws ResourceException {
		printWriter = out;
	}

	/**
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object obj) {

		if (obj == this) {
			return true;
		} else if (!(obj instanceof VistaLinkManagedConnectionFactory)) {
			return false;
		} else {
			VistaLinkManagedConnectionFactory objMcf = (VistaLinkManagedConnectionFactory) obj;
			if (objMcf.distinguishedIdentifier == this.distinguishedIdentifier) {
				return true;
			}
			return false;
		}
	}

	/**
	 * Sets the cached hashcode for this object.
	 */
	private void setHashCode() {

		// algorithm taken from "Effective Java" item #8.
		int HASHCODE_SEED = 17;
		int returnVal = HASHCODE_SEED;

		// distinguished identifier contribution to hashcode
		int distIdHashCode = (int) (this.distinguishedIdentifier ^ (this.distinguishedIdentifier >>> 32));
		returnVal = 37 * returnVal + distIdHashCode;

		this.hashCode = returnVal;
	}

	/**
	 * return cached hashcode
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		return hashCode;
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	public final String toString() {
		String adapterEnvironmentString = "";
		if (adapterEnvironment != null) {
			adapterEnvironmentString = adapterEnvironment.toString();
		}
		return ((new StringBuffer()).append(this.getClass().getName()).append("[]").append(hostIpAddress).append("[]")
				.append(hostPort).append("[]").append(maxConnectionHandles).append("[adapterversion]").append(
						ADAPTER_FULL_VERSION).append("[]").append(adapterEnvironmentString).append("[fdi]")
				.append(distinguishedIdentifier)).toString();

	}

	/**
	 * Returns the maxConnectionHandle.
	 * 
	 * @return int
	 */
	public int getMaxConnectionHandles() {
		return maxConnectionHandles;
	}

	/**
	 * Sets the maxConnectionHandle.
	 * 
	 * @param maxConnectionHandles The maximum number of connection handles
	 */
	private void setMaxConnectionHandles(int maxConnectionHandles) {
		this.maxConnectionHandles = maxConnectionHandles;
	}

	/**
	 * Returns the hostPort.
	 * 
	 * @return int
	 */
	public int getHostPort() {
		return hostPort;
	}

	/**
	 * used for non-managed mode only
	 * 
	 * Sets the hostPort.
	 * 
	 * @param hostPort The hostPort to set
	 */
	public void setNonManagedHostPort(int hostPort) {
		this.hostPort = hostPort;
		// additionally this must be a J2SE adapter
		setJ2SEProperties();
	}

	/**
	 * used for non-managed mode only
	 * 
	 * sets the host IP Address
	 * 
	 * @param hostipaddress
	 */
	public void setNonManagedHostIPAddress(String hostipaddress) {
		this.hostIpAddress = hostipaddress;
		// additionally this must be a J2SE adapter
		setJ2SEProperties();
	}

	/**
	 * Gets the host IP Address.
	 * 
	 * @return String
	 */
	private String getHostIPAddress() {
		return hostIpAddress;
	}

	/**
	 * 
	 * @param log
	 * @return String
	 */
	private String getLoggerFormattedString(String log) {
		return (new StringBuffer()).append(this.toString()).append("\n\t").append(log).toString();
	}

	/**
	 * 
	 * @param e
	 * @return String
	 */
	private String getLoggerFormattedStringWStackTrace(Throwable e) {

		return getLoggerFormattedString(ExceptionUtils.getFullStackTrace(e));

	}

	/**
	 * 
	 * @param log
	 * @param e
	 * @return String
	 */
	private String getLoggerFormattedStringWStackTrace(String log, Throwable e) {

		return getLoggerFormattedString((new StringBuffer()).append(log).append("\n\t").append(
				ExceptionUtils.getFullStackTrace(e)).toString());

	}

	/**
	 * gets the timeout value for managed connections
	 * 
	 * @return int
	 */
	protected long getSocketTimeOut() {
		if (this.adapterEnvironment.equals(EMAdapterEnvironment.J2SE)) {
			return getDefaultJ2SETimeOut();
		}
		return getDefaultJ2EETimeOut();
	}

	/**
	 * Returns the timerManager.
	 * 
	 * @return VistaHeartBeatTimerManager
	 */
	protected VistaHeartBeatTimerManager getHeartBeatTimerManager() {
		return timerManager;
	}

	/**
	 * @return access code
	 * @va.exclude
	 */
	public String getAccessCode() {
		return accessCode;
	}

	/**
	 * @return verify code
	 * @va.exclude
	 */
	public String getVerifyCode() {
		return verifyCode;
	}

	/**
	 * used for non-managed mode only
	 * 
	 * @param string
	 */
	public void setNonManagedAccessCode(String string) {
		accessCode = string;
		// additionally this must be a J2SE adapter
		setJ2SEProperties();
	}

	/**
	 * used for non-managed mode only
	 * 
	 * @param string
	 */
	public void setNonManagedVerifyCode(String string) {
		verifyCode = string;
		// additionally this must be a J2SE adapter
		setJ2SEProperties();
	}

	/**
	 * Resolve the IP address each time. By default, JVM caches this value anyway, no sense caching it twice! Kept
	 * mainly for compatibility.
	 * 
	 * @return resolved-by-DNS-lookup IP address
	 */
	public InetAddress getHostIpAddressResolved() {
		// v1.6 commented out to remove 'resolved' ip address cache
		try {
			return InetAddress.getByName(hostIpAddress);
		} catch (UnknownHostException e) {
			logger.error("could not resolve IP address '" + hostIpAddress + "': ", e);
			// (swallow it)
		}
		return null;
	}

	/**
	 * Resolve the IP address each time. By default, JVM caches this value anyway, no sense caching it twice! Throw
	 * exception so caller can know why resolution failed.
	 * 
	 * @return resolved-by-DNS-lookup IP address
	 * @throws VistaLinkResourceException exception encountered if resolution fails
	 */
	protected InetAddress getHostIpAddressResolvedWithException() throws VistaLinkResourceException {
		try {
			InetAddress returnValue = InetAddress.getByName(hostIpAddress);
			logger.debug("resolved DNS address '" + hostIpAddress + "' as IP address '" + returnValue.getHostAddress()
					+ "'.");
			return returnValue;
		} catch (UnknownHostException e) {
			logger.error("could not resolve IP address '" + hostIpAddress + "': ", e);
			throw new VistaLinkResourceException(e);
		}
	}

	/**
	 * 
	 * @return unresolved (original) host ip address setting
	 */
	public String getHostIpAddressUnresolved() {
		return this.hostIpAddress;
	}

	/**
	 * @return adapter environment
	 */
	public EMAdapterEnvironment getAdapterEnvironment() {
		return adapterEnvironment;
	}

	/**
	 * 
	 * @param adapterEnvironment
	 */
	public void setAdapterEnvironment(EMAdapterEnvironment adapterEnvironment) {
		this.adapterEnvironment = adapterEnvironment;
		this.timerManager.setAdapterEnvironment(this.adapterEnvironment);
	}

	/**
	 * @return managed connection count
	 */
	protected long getManagedConnectionCount() {
		return managedConnectionCount;
	}

	/**
	 * @return distinguished identifier
	 * @va.exclude
	 */
	public long getDistinguishedIdentifier() {
		return distinguishedIdentifier;
	}

	/**
	 * Setter used by container when processing custom ra.xml properties
	 * 
	 * @param connectorJndiName Jndi Name of the entry in the configuration file to use for this connector
	 */
	public void setConnectorJndiName(String connectorJndiName) {
		ConnectorConfigurator cc = new ConnectorConfigurator();
		setConnectorJndiNameInternal(connectorJndiName, cc);
	}

	/**
	 * Supports both container and unit test setting of JNDI name property.
	 * 
	 * @param connectorJndiName
	 * @param cc
	 */
	public void setConnectorJndiNameInternal(String connectorJndiName, ConnectorConfigurator cc) {
		logger.debug("in setConnectorJndiName.");
		this.connectorJndiName = connectorJndiName;
		// if this property is being set, this must be a J2EE adapter
		this.setAdapterEnvironment(EMAdapterEnvironment.J2EE);
		this.parseConfigFailureMessage = null;
		try {
			ConfigurationReader.loadConfigForMcf(this, cc);
			if (logger.isDebugEnabled()) {
				StringBuffer sb = new StringBuffer("connector Config JndiName: '");
				sb.append(connectorJndiName);
				sb.append("'; connector Config IP: '");
				sb.append(this.hostIpAddress);
				sb.append("'; connector Config Port: '");
				sb.append(this.hostPort);
				sb.append("; 'connector Config Access code: <masked>;connector Config Verify code: <masked>; connector Config Status: '");
				sb.append(this.connectorEnabled);
				sb.append('\'');
				logger.debug(sb.toString());
			}
		} catch (VistaLinkResourceException e) {
			this.parseConfigFailureMessage = e.getMessage();
			logger.error("Resource exception occurred reading configuration: ", e);
		}
	}

	/**
	 * overload setter method needed for JBoss
	 * 
	 * @param connectorJndiName
	 */
	public void setconnectorJndiName(String connectorJndiName) {
		setConnectorJndiName(connectorJndiName);
	}

	/**
	 * 
	 * @return Jndi name of the entry in the configuration file used for this connector
	 */
	public String getConnectorJndiName() {
		return this.connectorJndiName;
	}

	private void setJ2SEProperties() {
		if (!this.adapterEnvironment.equals(EMAdapterEnvironment.J2SE)) {
			this.setAdapterEnvironment(EMAdapterEnvironment.J2SE);
		}
		this.connectorEnabled = true;
	}

	// "friendly" scope
	void setAlwaysUseDefaultAsMin(boolean value) {
		alwaysUseDefaultAsMin = value;
	}

	/**
	 * 
	 * @return whether to use the default J2EE socket timeout as the minimum floor, even if timeout has been
	 *         programmatically set lower.
	 * 
	 * @va.exclude
	 */
	public boolean isAlwaysUseDefaultAsMin() {
		return alwaysUseDefaultAsMin;
	}

	void setDefaultJ2EETimeOut(long timeOut) {
		if (timeOut > J2EE_DEFAULT_SOCKET_TIMEOUT)
			defaultJ2EETimeOut = timeOut;
		else {
			defaultJ2EETimeOut = J2EE_DEFAULT_SOCKET_TIMEOUT;
			if (logger.isDebugEnabled())
				logger.debug(getLoggerFormattedString(new StringBuffer().append(
						"J2EE timeOut configuration attribute value is too short [").append(timeOut).append(
						"ms]. The following default value is being used instead: ").append(J2EE_DEFAULT_SOCKET_TIMEOUT)
						.append("ms").toString()));
		}
	}

	/**
	 * @return current default J2EE socket timeout
	 * 
	 * @va.exclude
	 */
	public long getDefaultJ2EETimeOut() {
		return defaultJ2EETimeOut;
	}

	private static void setDefaultJ2SETimeOut(long timeOut) {
		if (timeOut > J2SE_DEFAULT_SOCKET_TIMEOUT)
			defaultJ2SETimeOut = timeOut;
		else {
			defaultJ2SETimeOut = J2SE_DEFAULT_SOCKET_TIMEOUT;
			if (logger.isDebugEnabled())
				logger.debug(new StringBuffer().append("J2SE timeOut configuration attribute value is too short [")
						.append(timeOut).append("ms]. The following default value is being used instead: ").append(
								J2SE_DEFAULT_SOCKET_TIMEOUT).append("ms").toString());
		}
	}

	/**
	 * @return current default J2SE socket timeout
	 * 
	 * @va.exclude
	 */
	private static long getDefaultJ2SETimeOut() {
		return defaultJ2SETimeOut;
	}

	private static void setSocketTimeOutMultipler(int socketTimeOutMultipler) {
		if (socketTimeOutMultipler > 0) {
			VistaLinkManagedConnectionFactory.socketTimeOutMultipler = socketTimeOutMultipler;
		}
	}

	static int getSocketTimeOutMultipler() {
		return socketTimeOutMultipler;
	}

	/**
	 * increment the connnection failure count
	 * 
	 */
	protected void incrementConnectionFailureCount() {
		synchronized (healthSyncObj) {
			this.connectionFailureCount++;
		}
	}

	/**
	 * health indicator
	 * 
	 * @return connection failure count
	 */
	public long getConnectionFailureCount() {
		synchronized (healthSyncObj) {
			return this.connectionFailureCount;
		}
	}

	/**
	 * increment the connection authentication failure count
	 * 
	 */
	protected void incrementConnectionAuthFailureCount() {
		synchronized (healthSyncObj) {
			this.connectionAuthFailureCount++;
		}
	}

	/**
	 * health indicator
	 * 
	 * @return the connection authentication failure count
	 */
	public long getConnectionAuthFailureCount() {
		synchronized (healthSyncObj) {
			return this.connectionAuthFailureCount;
		}
	}

	/**
	 * increment the identity failure count
	 * 
	 */
	protected void incrementIdentityFailureCount() {
		synchronized (healthSyncObj) {
			this.identityFailureCount++;
		}
	}

	/**
	 * health indicator
	 * 
	 * @return identity failure count
	 */
	public long getIdentityFailureCount() {
		synchronized (healthSyncObj) {
			return this.identityFailureCount;
		}
	}

	/**
	 * increment the division mismatch count
	 * 
	 */
	protected void incrementdivisionMismatchCount() {
		synchronized (healthSyncObj) {
			this.divisionMismatchCount++;
		}
	}

	/**
	 * health indicator
	 * 
	 * @return division mismatch count
	 */
	public long getDivisionMismatchCount() {
		synchronized (healthSyncObj) {
			return this.divisionMismatchCount;
		}
	}

	/**
	 * increment the production mismatch count
	 * 
	 */
	protected void incrementProductionMismatchCount() {
		synchronized (healthSyncObj) {
			this.productionMismatchCount++;
		}
	}

	/**
	 * @param connectorEnabled The connectorEnabled to set.
	 */
	protected void setConnectorEnabled(boolean connectorEnabled) {
		this.connectorEnabled = connectorEnabled;
	}

	public boolean isConnectorEnabled() {
		return this.connectorEnabled;
	}

	/**
	 * health indicator
	 * 
	 * @return production mismatch count
	 */
	public long getProductionMismatchCount() {
		synchronized (healthSyncObj) {
			return this.productionMismatchCount;
		}
	}

	/**
	 * Add a new time for creating another connection handle
	 * 
	 * @param elapsedMillis time to create connection handle, in milliseconds
	 */
	protected void addCreateConnectionHandleTime(long elapsedMillis) {
		synchronized (createConnectionHandleAvgSyncObj) {
			if (logger.isDebugEnabled()) {
				logger.debug("elapsedMillis to add: " + Long.toString(elapsedMillis));
			}
			// TODO set some kind of flag for console if reach MAX_VALUE limit?
			// reset?
			if (elapsedMillis < (Long.MAX_VALUE - this.createConnectionHandleTotalMillis)) {
				this.createConnectionHandleCount++;
				this.createConnectionHandleTotalMillis = this.createConnectionHandleTotalMillis + elapsedMillis;
			} else {
				logger.error("CreateConnectionHandle time total exceeded LONG MAX_VALUE");
			}
		}
	}

	/**
	 * health indicator
	 * 
	 * @return average time to create connection handle, in milliseconds
	 */
	public double getCreateConnectionHandleAvgMillis() {
		synchronized (createConnectionHandleAvgSyncObj) {
			if (this.createConnectionHandleCount > 0) {
				return ((double)(createConnectionHandleTotalMillis) / ((double)this.createConnectionHandleCount));
			} else {
				return 0.0;
			}
		}
	}

	/**
	 * update the match managed connection average time
	 * 
	 * @param elapsedMillis new match managed connection time, in milliseconds
	 */
	private void addMatchManagedConnectionTime(long elapsedMillis) {
		synchronized (this.matchManagedConnectionAvgSyncObj) {
			// TODO set some kind of flag for console if reach MAX_VALUE limit?
			// reset?
			if (elapsedMillis < (Long.MAX_VALUE - this.matchManagedConnectionTotalMillis)) {
				this.matchManagedConnectionCount++;
				this.matchManagedConnectionTotalMillis = this.matchManagedConnectionTotalMillis + elapsedMillis;
			} else {
				logger.error("MatchManagedConnection time total exceeded LONG MAX_VALUE");
			}
		}
	}

	/**
	 * health indicator
	 * 
	 * @return match managed connection average time in milliseconds
	 */
	public double getMatchManagedConnectionAvgMillis() {
		synchronized (this.matchManagedConnectionAvgSyncObj) {
			if (this.matchManagedConnectionCount > 0) {
				return (((double) this.matchManagedConnectionTotalMillis) / ((double) this.matchManagedConnectionCount));
			} else {
				return 0.0;
			}
		}
	}

	/**
	 * @return Returns the primaryStation.
	 */
	public String getPrimaryStation() {
		return primaryStation;
	}

	/**
	 * @param accessCode The accessCode to set.
	 */
	protected void setAccessCode(String accessCode) {
		this.accessCode = accessCode;
	}

	/**
	 * @param hostIpAddress The hostIpAddress to set.
	 */
	protected void setHostIpAddress(String hostIpAddress) {
		this.hostIpAddress = hostIpAddress;
	}

	/**
	 * @param hostPort The hostPort to set.
	 */
	protected void setHostPort(int hostPort) {
		this.hostPort = hostPort;
	}

	/**
	 * @param primaryStation The primaryStation to set.
	 */
	protected void setPrimaryStation(String primaryStation) {
		this.primaryStation = primaryStation;
	}

	/**
	 * @param verifyCode The verifyCode to set.
	 */
	protected void setVerifyCode(String verifyCode) {
		this.verifyCode = verifyCode;
	}

	public Set getInvalidConnections(Set managedConnections) throws ResourceException {
		if (logger.isDebugEnabled()) {
			logger.debug("Executing connection test for " + getConnectorJndiName());
		}
		VistaHeartBeatTimerRequest req = null;
		VistaHeartBeatTimerResponse resp = null;
		VistaHeartBeatTimerResponseFactory resFactory = null;
		VistaLinkManagedConnection mc = null;
		Iterator iter = managedConnections.iterator();
		boolean success = false;

		try {
			req = new VistaHeartBeatTimerRequest(adapterEnvironment);
			resFactory = new VistaHeartBeatTimerResponseFactory();
			while (iter.hasNext()) {
				success = false;
				mc = (VistaLinkManagedConnection) iter.next();
				resp = (VistaHeartBeatTimerResponse) mc.executeInteraction(req, resFactory);
				if (resp.isHeartBeatSuccessful()) {
					iter.remove();
					success = true;
				}
				if (logger.isDebugEnabled()) {
					logger.debug(buildTestLoggerMessage(mc, success));
				}
			}
		} catch (FoundationsException e) {
			// used 'debug' level and not 'error' because a failure should spawn
			// other 'error' type activity in app server cleanup process
			if (logger.isDebugEnabled()) {
				logger.debug(buildTestLoggerMessage(mc, false));
			}
		}
		return managedConnections; // if all managed connections pass, the set
		// will be empty
	}

	private String buildTestLoggerMessage(VistaLinkManagedConnection mc, boolean success) {
		return new StringBuffer().append("Managed connection ").append(success ? "passed" : "failed").append(" test.")
				.append("  Connector Information >>> JNDI Name:").append(getConnectorJndiName()).append("  Host:")
				.append(getHostIPAddress()).append("  Port:").append(getHostPort()).append(
						"  Connection Information >>> MJob:").append(mc.getMJob()).append("  Distinguisheded ID:")
				.append(mc.getDistinguishedIdentifier()).toString();
	}

	/**
	 * Finalizer to unmap institution mappings at some point after connector is undeployed by container.
	 */
	protected void finalize() throws Throwable {
		try {
			if (this.adapterEnvironment == EMAdapterEnvironment.J2EE) {
					if (logger.isDebugEnabled()) {
						logger.debug("considering removing mappings for JNDI Name '" + connectorJndiName
								+ "', distinguished identifier '" + distinguishedIdentifier + ".");
					}
					InstitutionMapping instMap = InstitutionMappingFactory.getInstitutionMapping();
					instMap.removeMappingsForJndiName(connectorJndiName, new String[] { primaryStation },
							distinguishedIdentifier);
			}
		} finally {
			super.finalize();
		}
	}

}