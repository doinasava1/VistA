package gov.va.med.vistalink.adapter.cci;

import gov.va.med.exception.ExceptionUtils;
import gov.va.med.exception.FoundationsExceptionInterface;

import java.io.PrintStream;
import java.io.PrintWriter;

import javax.resource.ResourceException;

/**
 * Represents a ResourceException thrown by the VistaLink adapter. 
 * <p>
 * Upgraded to support J2CA 1.5 ResourceException that uses JDK 1.4+ nested exception functionality
 * rather than old J2CA 1.0 linked exception functionality.
 * 
 */
public class VistaLinkResourceException extends ResourceException implements FoundationsExceptionInterface {

	/*
	 * See http://svn.apache.org/viewvc/geronimo/specs/trunk/geronimo-j2ee-connector_1.5_spec/src/main/java/javax/resource/ 
	 * for source code implementation example of the parent class in a JEE 5 server.
	 */
	
	/**
	 * Constructor.
	 * 
	 * @param reason
	 *            application level reason why this exception occurred
	 * @va.exclude
	 */
	public VistaLinkResourceException(String reason) {
		super(reason);
	}

	/**
	 * Constructor.
	 * 
	 * @param e
	 *            exception to nest in new VistaLinkResourceException
	 * @va.exclude
	 */
	public VistaLinkResourceException(Exception e) {
		super(e);
	}

	/**
	 * Constructor. Parameters are required by the parent class.
	 * 
	 * @param reason
	 *            application level reason why this exception occurred
	 * @param errorCode
	 *            application level code reason why this exception occurred
	 * @va.exclude
	 */
	public VistaLinkResourceException(String reason, String errorCode) {
		super(reason);
		this.setErrorCode(errorCode);
	}

	/**
	 * Constructor. Parameters are required by the parent class.
	 * 
	 * @param reason
	 *            application level reason why this exception occurred
	 * @param errorCode
	 *            application level code reason why this exception occurred
	 * @param e
	 *            exception to nest in new VistaLinkResourceException
	 * @va.exclude
	 */
	public VistaLinkResourceException(String reason, String errorCode, Exception e) {
		super(reason, e);
		this.setErrorCode(errorCode);
	}

	/**
	 * Constructor.
	 * 
	 * @param reason
	 *            application level reason why this exception occurred
	 * @param e
	 *            exception to nest in new VistaLinkResourceException
	 * @va.exclude
	 */
	public VistaLinkResourceException(String reason, Exception e) {
		super(reason, e);
	}

	/**
	 * Return nested exception, if any.
	 * 
	 * @see gov.va.med.exception.FoundationsExceptionInterface#getNestedException()
	 * @deprecated Use getCause() instead.
	 */
	public Throwable getNestedException() {
		return this.getCause();
	}

	/**
	 * Returns the detail message, including nested messages from the nested
	 * exceptions.
	 * 
	 * @see java.lang.Throwable#getMessage()
	 */
	public String getMessage() {
		String retMessage = super.getMessage();
		if (retMessage == null) {
			retMessage = "";
		}

		if (getErrorCode() != null) {
			retMessage += "; Code: " + getErrorCode();
		}

		if (getNestedException() == null) {
			return retMessage;
		} else {
			return retMessage + "; \n\tRoot cause exception: \n\t" + getNestedException().toString();
		}
	}

	/**
	 * Prints the composite message and full embedded stack trace to the
	 * specified stream <code>ps</code>.
	 * 
	 * @see java.lang.Throwable#printStackTrace(java.io.PrintStream)
	 * @param ps
	 *            the print stream
	 */
	public void printStackTrace(PrintStream ps) {
		super.printStackTrace(ps);
	}

	/**
	 * Prints the composite message and full embedded stack trace to the
	 * specified print writer <code>pw</code>.
	 * 
	 * @see java.lang.Throwable#printStackTrace(java.io.PrintWriter)
	 * @param pw
	 *            the print writer
	 */
	public void printStackTrace(PrintWriter pw) {
		super.printStackTrace(pw);
	}

	/**
	 * Prints the composite message and full embedded stack trace to
	 * <code>System.err</code>.
	 * 
	 * @see java.lang.Throwable#printStackTrace()
	 */
	public void printStackTrace() {
		printStackTrace(System.err);

	}

	/**
	 * Returns the composite message and full embedded stack trace stack trace
	 * 
	 * @see gov.va.med.exception.FoundationsExceptionInterface#getFullStackTrace()
	 * @deprecated Use Throwable.getStackTrace() instead.
	 */
	public String getFullStackTrace() {
		return ExceptionUtils.getFullStackTrace(this);
	}
}