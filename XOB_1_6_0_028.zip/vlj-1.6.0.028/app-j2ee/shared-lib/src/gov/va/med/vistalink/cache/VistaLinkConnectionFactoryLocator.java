package gov.va.med.vistalink.cache;

import gov.va.med.vistalink.adapter.cci.VistaLinkConnectionFactory;
import gov.va.med.vistalink.institution.InstitutionMappingDelegate;
import gov.va.med.vistalink.institution.InstitutionMapNotInitializedException;
import gov.va.med.vistalink.institution.InstitutionMappingNotFoundException;

import java.util.Collections;
import java.util.Map;

import javax.naming.InitialContext;
import javax.naming.Context;
import javax.naming.NamingException;

import org.apache.log4j.Logger;
/**
 * The instance of this class is used to hold cache the in-memory mapping of VistaLinkConnectionFactory
 * to their perspective JNDI names.
 * <p>
 * The singleton instance of this class is initialized during class initialization.
 * <p>
 * This class is thread-safe.
 * 
 */
public class VistaLinkConnectionFactoryLocator{

  private static VistaLinkConnectionFactoryLocator me = null;
  Context context;
  Map map = Collections.synchronizedMap(new WeakValueMap());
  private static final Logger logger = Logger.getLogger(VistaLinkConnectionFactoryLocator.class); 
    
  private VistaLinkConnectionFactoryLocator() throws VistaLinkCacheException {
    try{
      setContext(new InitialContext());
    }
    catch(Exception e){ // we are not letting any exception out for now
      logger.error("Unable to create InitialContext: "+ e.getMessage());
    }
  }  
  
  
  /**
   * This method should be used to obtain a singleton reference to an instance
   * 
   */
  public static synchronized VistaLinkConnectionFactoryLocator getInstance() throws VistaLinkCacheException {
    if (me == null) {
      me = new VistaLinkConnectionFactoryLocator();
    }
    return me;
  }  
  /**
   * This method should be used to obtain a reference to a VistaLinkConnectionFactory, using
   * a previosly retrieved JNDI name of the factory
   * 
   * @param jndiName
   * 
   * @return VistaLinkConnectionFactory
   * 
   * @throws VistaLinkConnectionFactoryNotFoundException, VistaLinkCacheException
   * 
   */
  public VistaLinkConnectionFactory getFactory(String jndiName) 
                                    throws VistaLinkConnectionFactoryNotFoundException,
                                           VistaLinkCacheException { 
    VistaLinkConnectionFactory result = (VistaLinkConnectionFactory)map.get(jndiName);
    if(result == null)
      try {
        if (context == null) 
          throw new VistaLinkCacheException("Context is uninitialized, look in the logger [ERROR] output file for reasons.");
        
        result = (VistaLinkConnectionFactory)context.lookup(jndiName);
        if(result != null)
          map.put(jndiName, result);
        else
          throw new VistaLinkConnectionFactoryNotFoundException("Unable to find ConnectionFactory, based on the jndiName provided - " + jndiName);
      }
      catch(NamingException e){
        throw new VistaLinkCacheException("Could not complete the lookup: " + e.getMessage());
      }
    return result;
  }
  /**
   * This method should be used to obtain a reference to a VistaLinkConnectionFactory, using
   * a division number (Institution), the method does the actual lookup of the division number to an
   * appropriate JNDI name
   * 
   *  @param division
   * 
   *  @return VistaLinkConnectionFactory
   * 
   *  @throws VistaLinkConnectionFactoryNotFoundException, VistaLinkCacheException,
   *          InstitutionMapNotInitializedException, InstitutionMappingNotFoundException         
   * 
   */  
  public VistaLinkConnectionFactory getFactoryByDivision(String division)
                                    throws VistaLinkConnectionFactoryNotFoundException,
                                           VistaLinkCacheException,
                                           InstitutionMapNotInitializedException,
                                           InstitutionMappingNotFoundException {
    String jndiName = InstitutionMappingDelegate.getJndiConnectorNameForInstitution(division);   
    VistaLinkConnectionFactory result = getFactory(jndiName);
    return result;
  }
  
  /**
   * @va.exclude
   */
  public void setContext(Context ctx){ //Used for Cactus testing so far
    context = ctx;
  }
}
