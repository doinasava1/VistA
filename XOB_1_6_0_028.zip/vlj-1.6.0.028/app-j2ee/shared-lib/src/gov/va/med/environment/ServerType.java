package gov.va.med.environment;

/**
 * Enumerated J2EE server types.
 * 
 */
public class ServerType extends ServerTypeEnum {
	
	protected static final String WEBLOGIC_STR = "weblogic";
	protected static final String ORACLE_STR = "oracle";
	protected static final String JBOSS_STR = "jboss";
	protected static final String WEBSPHERE_STR = "websphere";
	protected static final String SUN_RI_13_STR = "sun-ri-1.3";
	protected static final String JAVA_SE_STR = "javase";
	protected static final String TOMCAT_STR = "tomcat";
	protected static final String UNKNOWN_STR = "unknown";

	public static final ServerType WEBLOGIC = new ServerType(WEBLOGIC_STR);

	public static final ServerType ORACLE = new ServerType(ORACLE_STR);

	public static final ServerType JBOSS = new ServerType(JBOSS_STR);

	public static final ServerType WEBSPHERE = new ServerType(WEBSPHERE_STR);
	
	public static final ServerType SUN_RI_13 = new ServerType(SUN_RI_13_STR);
	
	public static final ServerType JAVA_SE = new ServerType(JAVA_SE_STR);
	
	public static final ServerType TOMCAT = new ServerType(TOMCAT_STR);
	
	public static final ServerType UNKNOWN = new ServerType(UNKNOWN_STR);

	private ServerType(String keyValue) {
		super(keyValue);
	}

	static final ServerType getServerTypeObject(String keyValue) {
		return (ServerType) getObject(keyValue);
	}
}
