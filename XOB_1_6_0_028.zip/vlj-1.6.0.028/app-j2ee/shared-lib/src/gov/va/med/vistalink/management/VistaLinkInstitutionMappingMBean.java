package gov.va.med.vistalink.management;

import java.util.Map;

/**
 * MBean interface for managing the VistALink institution mapping singleton instance on this server.
 * 
 */
public interface VistaLinkInstitutionMappingMBean {
	
	/**
	 * 
	 * @return a Map containing string keys (station numbers) and string values (JNDI names) representing the current institution mapping associations on this JVM.
	 */
	Map getInstitutionMappings();

}
