package gov.va.med.net;

import gov.va.med.exception.ExceptionUtils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Serializable;
import java.net.Socket;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

/**
 * Represents a socket that can be used to communicate with IP end points
 * 
 */
public class SocketManager implements Serializable {

	/**
	 * The logger used by this class
	 */
	private static final Logger logger = Logger.getLogger(SocketManager.class);

	/**
	 * The socket
	 */
	private transient Socket soc;

	/**
	 * An identifier for the socket
	 */
	private String matchingIdentifier;

	/**
	 * The buffersize used for recieve operations, the socket will read this many chars at a time.
	 */
	private int bufferSize = 512;

	/**
	 * Represents an End of Transmission
	 */
	private static final char EOT = '\u0004';

	/**
	 * Represents UTF8 encoding
	 */
	// not used; saving as documentation
	// private static final String ENCODE_OUTF8 = "UTF8";

	/**
	 * Represents ASCII encoding
	 */
	// not used; saving as documentation
	// private static final String ENCODE_ASCII = "US-ASCII";

	/**
	 * Represents standard Windows encoding
	 */
	private static final String ENCODE_CP1252 = "Cp1252";
	
	/**
	 * Default constructor
	 */
	public SocketManager() {
	}

	/**
	 * Constructs this SocketManager with the specified socket.
	 * 
	 * @param soc
	 */
	public SocketManager(Socket soc) {
		setSoc(soc);
	}

	/**
	 * Returns the buffer size.
	 * 
	 * @return int
	 */
	public int getBufferSize() {
		return bufferSize;
	}

	/**
	 * Sets the buffer size.
	 * 
	 * @param value
	 */
	public void setBufferSize(int value) {
		bufferSize = value;
	}

	/**
	 * Gets the socket associated with this SocketManager.
	 * 
	 * @return Socket
	 */
	public Socket getSoc() {
		return soc;
	}

	/**
	 * Sets the socket associated with this SocketManager.
	 * 
	 * @param value
	 */
	public final void setSoc(Socket value) {
		this.soc = value;
	}

	/**
	 * Writes the xmlRequest param to the open socket.
	 * 
	 * @param xmlRequest
	 * @throws VistaSocketException
	 */
	public void sendData(String xmlRequest) throws VistaSocketException {
		BufferedWriter out;
		// commented out -- don't want to log user data
		//		if(logger.isDebugEnabled()){
		//			logger.debug(getLoggerFormattedString((new StringBuffer())
		//			.append("[]sending data ->")
		//			.append(xmlRequest).toString()));
		//		}
		try {
			out = new BufferedWriter(new OutputStreamWriter(soc.getOutputStream(), ENCODE_CP1252), soc
					.getSendBufferSize());
			out.write(xmlRequest + EOT);
			out.flush();
		} catch (Exception e) {
			throw new VistaSocketException("Error occurred writing to socket.", e);
		}
	}

	/**
	 * Reads the socket for a response and writes to String.
	 * 
	 * @return String
	 * @throws VistaSocketException
	 * @throws VistaSocketTimeOutException
	 */
	public String receiveData() throws VistaSocketException, VistaSocketTimeOutException {
		StringBuffer sb = new StringBuffer();
		char[] buffer = new char[bufferSize];
		boolean moreData = true;
		int dataRead = 0;
		BufferedReader in;

		try {

			in = new BufferedReader(new InputStreamReader(soc.getInputStream(), ENCODE_CP1252), soc
					.getReceiveBufferSize());

			while (moreData) {
				dataRead = in.read(buffer);

				if (logger.isDebugEnabled()) {

					logger.debug(getLoggerFormattedString((new StringBuffer()).append("read data->").append(dataRead)
							.toString()));

				}

				if (dataRead > 0) {
					if (buffer[dataRead - 1] == EOT) {

						if (logger.isDebugEnabled()) {

							logger.debug(getLoggerFormattedString((new StringBuffer()).append("read data->Got EOT->")
									.append(dataRead).toString()));

						}
						moreData = false;
						sb.append(buffer, 0, dataRead - 1);
					} else {
						sb.append(buffer, 0, dataRead);
					}
				} else if (dataRead == -1) {
					moreData = false;
					throw new VistaSocketException("End of stream encountered unexpectedly.");
				} else {
					moreData = false;
					throw new VistaSocketException("BufferedReader.read() returned " + dataRead);
				}

			}
			// Can not catch a specific exception since jdk 1.3 and 1.4 throws
			// different exceptions
		} catch (Exception e) {

			if (logger.isEnabledFor(Level.ERROR)) {
				if (dataRead > (buffer.length - 1) | (dataRead < 1)) {
					logger.error(getLoggerFormattedStringWStackTrace(new StringBuffer().append(
							"receiving data exception-> dataRead value: ").append(dataRead).toString(), e));
				} else {
					logger.error(getLoggerFormattedStringWStackTrace(new StringBuffer().append(
							"receiving data exception->").append(buffer, 0, dataRead).toString(), e));

				}

			}

			String timeoutStr = null;
			try {
				timeoutStr = "Socket Timeout occured. Timeout setting was: '"
						+ Integer.toString(this.soc.getSoTimeout()) + " ms'. ";
			} catch (Exception e1) {
				timeoutStr = "Socket Timeout occured. Unable to determine timeout setting. ";
			}
			String SOCKET_TIMEOUT_EXCEPTION_CLASS_1_3_1 = "java.io.InterruptedIOException";
			String SOCKET_TIMEOUT_EXCEPTION_CLASS_1_4_1 = "java.net.SocketTimeoutException";
			if (e.getClass().getName().equals(SOCKET_TIMEOUT_EXCEPTION_CLASS_1_4_1)) {
				throw new VistaSocketTimeOutException(timeoutStr, e);
			} else if (e.getClass().getName().equals(SOCKET_TIMEOUT_EXCEPTION_CLASS_1_3_1)) {
				throw new VistaSocketTimeOutException(timeoutStr, e);
			} else {
				throw new VistaSocketException("Error occurred reading from socket. ", e);
			}
		}
		// commented out -- don't want to log user data
		//		if(logger.isDebugEnabled()){
		//			logger.debug(getLoggerFormattedString(
		//				(new StringBuffer())
		//				.append(("recieving data ->"))
		//				.append(sb.toString()).toString()));
		//		}
		return sb.toString();
	}

	/**
	 * Gets the socket's identifier (if any).
	 * @return Matching identifier
	 */
	public String getMatchingIdentifier() {
		return matchingIdentifier;
	}

	/**
	 * Sets an identifier to identify the socket
	 * @param string matching identifier
	 */
	public void setMatchingIdentifier(String string) {
		matchingIdentifier = string;
	}

	/**
	 * @return String representation of this object.
	 */
	public String toString() {

		return (new StringBuffer()).append(this.getClass().getName()).append("[mdi]").append(getMatchingIdentifier()).toString();

	}

	/**
	 * @param log
	 * @return String
	 */
	private String getLoggerFormattedString(String log) {
		return (new StringBuffer()).append(this.toString()).append("\n\t").append(log).toString();
	}

	/**
	 * @param e
	 * @return String
	 */
	private String getLoggerFormattedStringWStackTrace(Throwable e) {

		return getLoggerFormattedString(ExceptionUtils.getFullStackTrace(e));

	}

	/**
	 * @param log
	 * @param e
	 * @return String
	 */
	private String getLoggerFormattedStringWStackTrace(String log, Throwable e) {

		return getLoggerFormattedString((new StringBuffer()).append(log).append("\n\t").append(
				ExceptionUtils.getFullStackTrace(e)).toString());

	}

}