package gov.va.med.vistalink.adapter.heartbeat;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import gov.va.med.vistalink.adapter.record.VistaLinkRequestVO;
import gov.va.med.vistalink.adapter.record.VistaLinkResponseFactoryImpl;
import gov.va.med.vistalink.adapter.record.VistaLinkResponseVO;
import gov.va.med.exception.ExceptionUtils;
import gov.va.med.exception.FoundationsException;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * This class represents the Response Factory used to create the
 * VistaHeartBeatTimerResponse value object
 * 
 */
public class VistaHeartBeatTimerResponseFactory extends VistaLinkResponseFactoryImpl {

	/**
	 * The logger used for this class
	 */
	private static final Logger logger = Logger.getLogger(VistaHeartBeatTimerResponseFactory.class);

	/**
	 * Constructor for VistaHeartBeatTimerResponseFactory.
	 */
	public VistaHeartBeatTimerResponseFactory() {
		super();
	}

	/**
	 * Evaluates the response from M and determines if the heart beat was
	 * successful and gets the heart beat rate in millis. Constructs a new
	 * VistaHeartBeatTimerResponse object.
	 * 
	 * @see gov.va.med.vistalink.adapter.record.VistaLinkResponseFactoryImpl#parseMessageBody(java.lang.String,
	 *      java.lang.String, org.w3c.dom.Document, java.lang.String,
	 *      gov.va.med.vistalink.adapter.record.VistaLinkRequestVO)
	 */
	protected VistaLinkResponseVO parseMessageBody(String rawXml, String filteredXml, Document doc, String messageType,
			VistaLinkRequestVO requestVO) throws FoundationsException {

		try {

			boolean heartBeatSuccessful;
			long heartBeatRateMillis = 0;

			XPath xpath = XPathFactory.newInstance().newXPath();
			NodeList resultsNodeList = (NodeList) xpath.evaluate("/VistaLink/Response/.", doc, XPathConstants.NODESET);
			Node resultsNode = (resultsNodeList.getLength() > 0) ? resultsNodeList.item(0) : null; 

			// JAXEN-based parsing, now replaced by J2SE built-in XPath
//			XPath xpath = new DOMXPath("/VistaLink/Response/.");
//			Node resultsNode = (Node) xpath.selectSingleNode(doc);

			//			// get result type
			NamedNodeMap attrs = resultsNode.getAttributes();

			if (logger.isDebugEnabled()) {
				logger.debug("got response attributes");

			}

			heartBeatSuccessful = (((Attr) attrs.getNamedItem("type")).getValue().equals("heartbeat"))
					&& (((Attr) attrs.getNamedItem("status")).getValue().equals("success"));

			if (logger.isDebugEnabled()) {
				logger.debug("got heart beat success");

			}

			heartBeatRateMillis = 1000 * Long.parseLong(((Attr) attrs.getNamedItem("rate")).getValue());

			if (logger.isDebugEnabled()) {
				logger.debug("got heart beat rate millis");

			}

			return new VistaHeartBeatTimerResponse(rawXml, filteredXml, doc, messageType, heartBeatSuccessful,
					heartBeatRateMillis);

		} catch (XPathExpressionException e) {

			String errStr = "could not parse xml";

			if (logger.isEnabledFor(Level.ERROR)) {

				String errMsg = (new StringBuffer()).append(errStr).append("\n\t").append(
						ExceptionUtils.getFullStackTrace(e)).toString();

				logger.error(errMsg);
			}

			throw new FoundationsException(errStr, e);
		}

	}

}