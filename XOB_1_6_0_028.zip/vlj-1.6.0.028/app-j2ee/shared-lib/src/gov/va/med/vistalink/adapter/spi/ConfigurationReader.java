package gov.va.med.vistalink.adapter.spi;

import gov.va.med.vistalink.adapter.cci.VistaLinkResourceException;
import gov.va.med.vistalink.adapter.config.Connector;
import gov.va.med.vistalink.institution.InstitutionMappingBadStationNumberException;
import gov.va.med.vistalink.institution.InstitutionMappingFactory;
import gov.va.med.vistalink.institution.InstitutionMapping;

import org.apache.log4j.Logger;

/**
 * Reads in managed connection factory configuration from vistalink configuration file. Isolates J2SE mode's use of MCF
 * from any XML Beans dependencies as a result of J2EE mode's use of XML Beans.
 * 
 * NOTE: the 'scoped' feature for a/v encryption/decryption is present but commented out in this class.
 * 
 */
public class ConfigurationReader {

	private static final Logger logger = Logger.getLogger(ConfigurationReader.class);

	/**
	 * utility class, should not be instantiated
	 */
	private ConfigurationReader() {
	}

	/**
	 * Scan config file, find entry that uniquely corresponds to a given primaryStation.
	 * 
	 * @param stationNumber station# (including suffix if looking for connector for station# w/suffix)
	 * @return jndiName that uniquely matches stationNumber
	 * @throws Exception thrown if problem parsing config file, or if multiple matches found.
	 */
	public static String getJndiNameForStationNumber(String stationNumber) throws Exception {
		return getJndiNameForStationNumber(stationNumber, new ConnectorConfigurator());
	}

	/**
	 * 'internal' call allowing ConnectorConfigurator to be passed in externally; mainly used for unit testing.
	 * 
	 * @param stationNumber
	 * @param cc
	 * @return JNDI name uniquely associated with a station number, based on data in config file. Null if no matches fond.
	 * @throws Exception thrown if multiple matches found, or if a problem reading the config file.
	 */
	public static String getJndiNameForStationNumber(String stationNumber, ConnectorConfigurator cc) throws Exception {

		String matchingJndiName = null;

		if ((stationNumber == null) || (stationNumber.trim().length() < 1)) {
			throw new IllegalArgumentException("Station Number argument '" + stationNumber + "' is invalid.'");
		}
		try {

			Connector[] connectors = cc.getConnectorArray();
			int matchCount = 0;

			// check all configuration entries
			for (int i = 0; i < connectors.length; i++) {
				// only process enabled ones
				if (connectors[i].getEnabled()) {
					// String primaryStation = Integer.toString(connectors[i].getPrimaryStation());
					String primaryStation = connectors[i].getPrimaryStation();
					// append suffix if present
					// commented out v1.6 -- eliminate primaryStationSuffix field
					// if (connectors[i].getPrimaryStationSuffix() != null) {
					// primaryStation = primaryStation + connectors[i].getPrimaryStationSuffix();
					// }
					// skip if primaryStation not the target station#
					if ((!stationNumber.equals(primaryStation)) || (primaryStation.length() < 1)) {
						continue;
					}
					String connectorJndiName = connectors[i].getJndiName();
					// skip null JNDI name
					if ((connectorJndiName == null) || (connectorJndiName.length() < 1)) {
						continue;
					}
					// It's a match... but keep looping in case there's duplicates which would invalidate the match
					matchCount++;
					if (matchCount > 1) {
						throw new Exception("Multiple enabled connector matches found for station# '" + stationNumber
								+ "'; cannot resolve.");
					}
					matchingJndiName = connectorJndiName;
				}
			}

		} catch (Exception e) {
			String error = "Problem parsing config file: ";
			logger.error(error, e);
			throw new Exception(error, e);
		}
		return matchingJndiName;
	}

	/**
	 * Parse config file, find matching entry for the MCF, and set its properties from the configuration.
	 * 
	 * @param mcf ManagedConnectionFactory to retrieve/set properties for
	 * @param cc pre-configured ConnectorConfigurator
	 * @throws ResourceException
	 */
	public static void loadConfigForMcf(VistaLinkManagedConnectionFactory mcf, ConnectorConfigurator cc)
			throws VistaLinkResourceException {

		String connectorJndiName = mcf.getConnectorJndiName();
		if (connectorJndiName == null) {
			String error = "Connector descriptor is not configured with connectorJndiName to be retrieved from configuration file.";
			throw new VistaLinkResourceException(error);
		}

		boolean saveFile = false;
		logger.debug("Looking for connectorJndiName index: " + connectorJndiName);
		int matchEnabledCount = 0;
		String matchFailureMessage = null;

		try {

			Connector[] connectors = cc.getConnectorArray(); // method includes whole-file validation
			for (int i = 0; i < connectors.length; i++) { // begin connector loop

				if (connectorJndiName.equals(connectors[i].getJndiName())) { // begin jndiMatch
					if (!connectors[i].getEnabled()) {
						logger.debug("Skipping disabled connector '" + connectorJndiName + "'.");
					} else { // begin if enabled

						logger.debug("found enabled jndiName match.");

						mcf.setHostIpAddress(connectors[i].getIp());
						mcf.setHostPort(connectors[i].getPort());
						mcf.setDefaultJ2EETimeOut(connectors[i].getTimeout() * 1000);
						mcf.setAlwaysUseDefaultAsMin(connectors[i].getAlwaysUseDefaultAsMin());

						String primaryStation = connectors[i].getPrimaryStation();
						// load/reload station #s for this connector
						if (primaryStation.length() > 0) {
							mcf.setPrimaryStation(primaryStation);
							InstitutionMapping instMap = InstitutionMappingFactory.getInstitutionMapping();
							String[] stationNumbersToMap = new String[] { primaryStation };
							try {
								instMap.loadMappingsForJndiName(connectorJndiName, stationNumbersToMap, mcf
										.getDistinguishedIdentifier());
							} catch (InstitutionMappingBadStationNumberException e1) {
								matchFailureMessage = (matchFailureMessage == null ? "" : "; ")
										+ "skipping configuration '" + connectorJndiName
										+ "', could not load institution mapping due to bad station number(s): '"
										+ e1.getMessage() + "'";
								logger.error(matchFailureMessage, e1);
								continue; // keep trying
							}
						} else {
							matchFailureMessage = (matchFailureMessage == null ? "" : "; "
									+ "Skipping configuration for '" + connectorJndiName
									+ "' because required primary Station attribute not found.");
							logger.error(matchFailureMessage);
							continue; // keep trying
						}

						// get a/v codes, encrypt entry if necessary
						if (connectors[i].getEncrypted()) {
							// two modes of encryption can be encountered - based on the stored seed and based on the
							// domain name - scoped
							boolean isGlobalScoped = cc.isEncryptionScoped();
							mcf.setAccessCode(cc.getDecryptedValue(connectors[i].getAccessCode(), isGlobalScoped));
							mcf.setVerifyCode(cc.getDecryptedValue(connectors[i].getVerifyCode(), isGlobalScoped));
						} else {
							mcf.setAccessCode(connectors[i].getAccessCode());
							mcf.setVerifyCode(connectors[i].getVerifyCode());
							logger.warn("encrypting unencrypted entry in the config file! - " + connectorJndiName);
							saveFile = cc.updateEncryptionIfNeeded(connectors[i]) || saveFile;
						}

						// do this last -- only enable if we successfully parse the entire config entry, then break loop
						mcf.setConnectorEnabled(true);
						matchEnabledCount++;
						break;

					} // end if enabled
				}// end jndiMatch
			} // end connector loop
			if (saveFile) {
				cc.save();
				logger.info("ConfigurationFile saved.");
			}
		} catch (Exception e) {
			String error = "Problem loading connector configuration for jndiName '" + connectorJndiName + "': ";
			throw new VistaLinkResourceException(error, e);
		}

		// if no match is found, matchEnabledCound will be 0, and/or (but should be both) mcf's isConnectorEnabled will
		// be false
		if ((matchEnabledCount == 0) || (!mcf.isConnectorEnabled())) {
			throw new VistaLinkResourceException(
					"Could not find matching, enabled, valid configuration for connectorJndiName '" + connectorJndiName
							+ "'" + (matchFailureMessage == null ? "." : matchFailureMessage));
		}
	}
	// TODO -- reinstate more detailed XML exception message? access point is now inside ConfigurationReader.

	// private static String getXMLExceptionMessage(Collection errors) {
	// StringBuffer result = new StringBuffer();
	// for (Iterator i = errors.iterator(); i.hasNext();) {
	// XmlError error = (XmlError) i.next();
	//
	// result.append("\n");
	// result.append("Message: " + error.getMessage() + "\n");
	// result.append("Location of invalid XML: " + error.getCursorLocation().xmlText() + "\n");
	// }
	// return result.toString();
	// }

}