package gov.va.med.vistalink.security.m;

import gov.va.med.vistalink.adapter.record.VistaLinkResponseVOImpl;

/**
 * Base class for response objects to receive and handle AVSecurity module
 * responses from an M Vista server.
 * 
 * @see SecurityResponseFactory
 */
public class SecurityResponse extends VistaLinkResponseVOImpl {

	// constants used to extract result type
	/**
	 * resulttype representing success.
	 */
	// public static final int RESULT_SUCCESS = 1;

	/**
	 * resulttype representing failure.
	 */
	// public static final int RESULT_FAILURE = 0;

	/**
	 * resulttype representing partial success.
	 */
	// public static final int RESULT_PARTIAL = 2;

	private int resultType;

	private String resultMessage;

	//	private String rawXml;

	/**
	 * Copy constructor
	 * 
	 * @param responseData
	 *            the response to process
	 */
	SecurityResponse(SecurityResponse responseData) {
		super();
		this.resultType = responseData.getResultType();
		this.resultMessage = responseData.getResultMessage();
		this.rawXml = responseData.getRawResponse();
	}

	/**
	 * 
	 * @param resultType
	 *            type of result -- success, failure or partialsuccess.
	 * @param resultMessage
	 *            string returned with result if partialsuccess or failure
	 * @param rawXml
	 *            raw XML of the response
	 */
	SecurityResponse(int resultType, String resultMessage, String rawXml) {
		super();
		this.resultType = resultType;
		this.resultMessage = resultMessage;
		this.rawXml = rawXml;
	}

	/**
	 * 
	 * @return int
	 */
	public int getResultType() {
		return resultType;
	}

	/**
	 * 
	 * @return String
	 */
	public String getResultMessage() {
		return resultMessage;
	}

}