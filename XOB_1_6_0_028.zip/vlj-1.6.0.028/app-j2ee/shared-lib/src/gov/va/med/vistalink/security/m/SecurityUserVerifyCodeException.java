package gov.va.med.vistalink.security.m;

import gov.va.med.vistalink.adapter.record.VistaLinkFaultException;

/**
 * Represents a failure during a re-authentication attempt, where the user's verify code is expired or
 * requires changing.
 * 
 */
public class SecurityUserVerifyCodeException extends SecurityFaultException {

	/**
	 * @param vistaLinkFaultException
	 * @va.exclude
	 */
	public SecurityUserVerifyCodeException(VistaLinkFaultException vistaLinkFaultException) {
		super(vistaLinkFaultException);
	}

}
