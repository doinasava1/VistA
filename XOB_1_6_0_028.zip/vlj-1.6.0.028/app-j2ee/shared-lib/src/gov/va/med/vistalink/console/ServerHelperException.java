package gov.va.med.vistalink.console;

/**
 * Represents an exception encountered while executing IServerHelper functionality.
 * 
 */
public class ServerHelperException extends Exception {

	public ServerHelperException() {
		super();
	}

	public ServerHelperException(String message) {
		super(message);
	}

	public ServerHelperException(Exception e) {
		super(e);
	}

	public ServerHelperException(String message, Exception e) {
		super(message, e);
	}
}
