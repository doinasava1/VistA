package gov.va.med.vistalink.adapter.cci;

import gov.va.med.vistalink.adapter.spi.VistaLinkManagedConnectionFactory;

/**
 * Interface for verifying that the VistaLink-specific custom JNDI property in the J2CA deployment descriptors matches
 * the name the deployed connector is bound to in JNDI.
 * 
 */
public interface JndiVerificationStrategy {

	boolean checkJndiMismatch(VistaLinkManagedConnectionFactory mcf, VistaLinkConnectionFactory cf);
}
