package gov.va.med.vistalink.security.m;

import gov.va.med.vistalink.adapter.record.VistaLinkFaultException;

/**
 * This exception fault is returned from M, and signifies that there was a mismatch between the client
 * and the server in the designation of each side as production or non-production.
 */
public final class SecurityProductionMismatchException extends SecurityFaultException {

	/**
	 * Constructor
	 * @param vistaLinkFaultException the exception to copy into a new exception type
	 * @va.exclude
	 */
	public SecurityProductionMismatchException(VistaLinkFaultException vistaLinkFaultException) {
		super(vistaLinkFaultException);
	}

}
