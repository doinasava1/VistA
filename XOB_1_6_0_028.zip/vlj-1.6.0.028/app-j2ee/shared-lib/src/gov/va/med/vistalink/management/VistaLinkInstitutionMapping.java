package gov.va.med.vistalink.management;

import gov.va.med.vistalink.institution.InstitutionMapping;
import gov.va.med.vistalink.institution.InstitutionMappingFactory;
import gov.va.med.vistalink.institution.InstitutionMappingVO;

import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

import org.apache.log4j.Logger;

/**
 * MBean implementation for managing the VistALink institution mapping singleton instance on this server. Thread-safe.
 * 
 */
public class VistaLinkInstitutionMapping implements VistaLinkInstitutionMappingMBean {

	private static final Logger logger = Logger.getLogger(VistaLinkInstitutionMapping.class);

	/**
	 * return Name value for ObjectNames for MBeans of this type. Since there's only a single MBean, using the same
	 * value for "Name=" as for "Type="
	 * @return
	 */
	public static String getMBeanName() {
		return "VistaLinkInstitutionMapping";
	}

	/**
	 * return Type value for ObjectNames for MBeans of this type
	 * @return
    	 */
	public static String getMBeanType() {
		return "VistaLinkInstitutionMapping";
	}

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.management.VistaLinkInstitutionMappingMBean#getInstitutionMappings()
	 */
	public Map getInstitutionMappings() {

		// return value must be serializable for remote MBean use
		Map returnVal = new TreeMap();
		Map mappings = null;
		try {
			InstitutionMapping me = (InstitutionMapping) InstitutionMappingFactory.getInstitutionMapping();
			if (me != null) {
				mappings = me.getMappingClone();
				// get rid of InstitutionMappingVO in original Map, return as pure strings.
				Iterator iter = mappings.keySet().iterator();
				while (iter.hasNext()) {
					Object key = iter.next();
					InstitutionMappingVO vo = (InstitutionMappingVO) mappings.get(key);
					returnVal.put(key, vo.getJndiName());
				}
			}
		} catch (Exception e) {
			logger.error("getInstitutionMappings failed: ", e);
		}
		return returnVal;
	}

}
