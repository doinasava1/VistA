package gov.va.med.vistalink.adapter.heartbeat;

import gov.va.med.vistalink.adapter.record.VistaLinkRequestVOImpl;
import gov.va.med.vistalink.adapter.spi.EMAdapterEnvironment;
import gov.va.med.vistalink.adapter.spi.VistaLinkManagedConnectionFactory;
import gov.va.med.xml.XmlUtilities;
import gov.va.med.exception.ExceptionUtils;
import gov.va.med.exception.FoundationsException;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.w3c.dom.Attr;
import org.w3c.dom.Node;

/**
 * This class represents a heart beat request.
 * 
 */
public class VistaHeartBeatTimerRequest extends VistaLinkRequestVOImpl {

	/**
	 * The logger used for this class
	 */
	private static final Logger logger =
		Logger.getLogger(VistaHeartBeatTimerRequest.class);

	/**
	 * The xml request used for a heart beat
	 */
	private static final String HEARTBEAT_REQUEST =
		"<?xml version='1.0' encoding='utf-8' ?><VistaLink messageType='gov.va.med.foundations.vistalink.system.request' version='" + VistaLinkManagedConnectionFactory.ADAPTER_VERSION + "' mode='singleton' xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' xsi:noNamespaceSchemaLocation='vlSimpleRequest.xsd'><Request type='heartbeat' environment='' /></VistaLink>";


	/**
	 * Constructor for VistaHeartBeatTimerRequest.
	 * @param adapterEnvironment
	 */
	public VistaHeartBeatTimerRequest(EMAdapterEnvironment adapterEnvironment) throws FoundationsException {
		super();
		try {
			this.requestDoc =
				XmlUtilities.getDocumentForXmlString(HEARTBEAT_REQUEST);

			Node reqNode =
				XmlUtilities.getNode("/VistaLink/Request", this.requestDoc);

			Attr reqAdapterEnvironment = 
					XmlUtilities.getAttr(reqNode, "environment");
			if (adapterEnvironment != null) {
				reqAdapterEnvironment.setValue(adapterEnvironment.toString());
			}else{
				throw new FoundationsException("The adapter Environment is specified as null.");				
			}


		} catch (FoundationsException e) {

			if(logger.isEnabledFor(Level.ERROR)){
				
				String errMsg = (new StringBuffer())
					.append(
					"Could not construct xml document")
					.append("\n\t")
					.append(ExceptionUtils
							.getFullStackTrace(e))
					.toString();
						
				logger.error(errMsg);
			}
			throw e;
		}
	}

}
