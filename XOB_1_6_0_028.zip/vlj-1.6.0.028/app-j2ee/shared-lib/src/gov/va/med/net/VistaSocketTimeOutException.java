package gov.va.med.net;

/**
 * Represents an exception identifying a timeout has occurred during read/write
 * operations.
 * 
 */
public class VistaSocketTimeOutException extends VistaSocketException {

	/**
	 * Constructor for VistaSocketTimeOutException.
	 * 
	 * @va.exclude
	 */
	public VistaSocketTimeOutException() {
		super();
	}

	/**
	 * Constructor for VistaSocketTimeOutException.
	 * 
	 * @param msg
	 *            Message
	 * @va.exclude
	 */
	public VistaSocketTimeOutException(String msg) {
		super(msg);
	}

	/**
	 * Constructor for VistaSocketTimeOutException.
	 * 
	 * @param nestedException
	 *            Exception
	 * @va.exclude
	 */
	public VistaSocketTimeOutException(Exception nestedException) {
		super(nestedException);
	}

	/**
	 * Constructor for VistaSocketTimeOutException.
	 * 
	 * @param msg
	 *            Message
	 * @param nestedException
	 *            Exception
	 * @va.exclude
	 */
	public VistaSocketTimeOutException(String msg, Exception nestedException) {
		super(msg, nestedException);
	}

}