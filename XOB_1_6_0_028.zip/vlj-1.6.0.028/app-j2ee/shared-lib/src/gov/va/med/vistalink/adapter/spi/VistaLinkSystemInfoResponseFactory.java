/*
 * Created on Oct 20, 2003
 *
 */
package gov.va.med.vistalink.adapter.spi;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import gov.va.med.exception.ExceptionUtils;
import gov.va.med.exception.FoundationsException;
import gov.va.med.vistalink.adapter.record.VistaLinkRequestVO;
import gov.va.med.vistalink.adapter.record.VistaLinkResponseFactoryImpl;
import gov.va.med.vistalink.adapter.record.VistaLinkResponseVO;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * 
 */
public class VistaLinkSystemInfoResponseFactory extends VistaLinkResponseFactoryImpl {

	/**
	 * The logger used for this class
	 */
	private static final Logger logger = Logger.getLogger(VistaLinkSystemInfoResponseFactory.class);

	/**
	 * 
	 */
	public VistaLinkSystemInfoResponseFactory() {
		super();
	}

	/**
	 * Evaluates the response from M and gets the heart beat rate in millis. Constructs a new
	 * VistaLinkSystemInfoResponse object.
	 * 
	 * @see gov.va.med.vistalink.adapter.record.VistaLinkResponseFactoryImpl#parseMessageBody(java.lang.String,
	 *      java.lang.String, org.w3c.dom.Document, java.lang.String,
	 *      gov.va.med.vistalink.adapter.record.VistaLinkRequestVO)
	 */
	protected VistaLinkResponseVO parseMessageBody(String rawXml, String filteredXml, Document doc, String messageType,
			VistaLinkRequestVO requestVO) throws FoundationsException {

		try {
			XPath xpath = XPathFactory.newInstance().newXPath();
			NodeList resultsNodeList = (NodeList) xpath.evaluate("/VistaLink/Response/SystemInfo/.", doc, XPathConstants.NODESET);
			Node resultsNode = (resultsNodeList.getLength() > 0) ? resultsNodeList.item(0) : null; 

			// JAXEN-based parsing, now replaced by J2SE built-in XPath
//			XPath xpath = new DOMXPath("/VistaLink/Response/SystemInfo/.");
//			Node resultsNode = (Node) xpath.selectSingleNode(doc);
			// get attribute map
			NamedNodeMap attrs = resultsNode.getAttributes();
			final String deflt = "unknown";
			// get individual attribute values
			VistaLinkSystemInfoVO systemInfoVO = new VistaLinkSystemInfoVO();
			systemInfoVO.setVistalinkVersion(getAttributeValue(attrs, "vistalinkVersion", deflt));
			systemInfoVO.setVistalinkBuild(getAttributeValue(attrs, "vistalinkBuild", deflt));
			systemInfoVO.setAppServerTimeout(Long.parseLong(getAttributeValue(attrs, "appServerTimeout", "0")));
			systemInfoVO.setReAuthSessionTimeout(Long.parseLong(getAttributeValue(attrs, "reAuthSessionTimeout", "0")));
			systemInfoVO.setUci(getAttributeValue(attrs, "uci", deflt));
			systemInfoVO.setVol(getAttributeValue(attrs, "vol", deflt));
			systemInfoVO.setBoxVolume(getAttributeValue(attrs, "boxVolume", deflt));
			systemInfoVO.setMVersion(getAttributeValue(attrs, "mVersion", deflt));
			systemInfoVO.setOperatingSystem(getAttributeValue(attrs, "operatingSystem", deflt));
			systemInfoVO.setDomainName(getAttributeValue(attrs, "domainName", deflt));
			systemInfoVO.setVistaProduction(getAttributeValue(attrs, "vistaProduction", deflt));
			systemInfoVO.setDefaultInstitution(getAttributeValue(attrs, "defaultInstitution", deflt));
			systemInfoVO.setCpName(getAttributeValue(attrs, "cpName", deflt));

			NodeList introNodeList = doc.getDocumentElement().getElementsByTagName("IntroText");
			if (introNodeList.getLength() == 1) {
				NodeList cdataNodeList = introNodeList.item(0).getChildNodes();
				if ((cdataNodeList.getLength() == 1)
						&& (cdataNodeList.item(0).getNodeType() == Node.CDATA_SECTION_NODE)) {
					systemInfoVO.setIntroText(cdataNodeList.item(0).getNodeValue());
				}
			}

			if (logger.isDebugEnabled()) {
				logger.debug("Retrieved system information response attributes");
			}
			// create response object
			return new VistaLinkSystemInfoResponse(rawXml, filteredXml, doc, messageType, systemInfoVO.toMap());
		} catch (XPathExpressionException e) {
			String errStr = "could not parse xml";
			if (logger.isEnabledFor(Level.ERROR)) {
				String errMsg = (new StringBuffer()).append(errStr).append("\n\t").append(
						ExceptionUtils.getFullStackTrace(e)).toString();
				logger.error(errMsg);
			}
			throw new FoundationsException(errStr, e);
		}
	}

	private String getAttributeValue(NamedNodeMap attrs, String attrName, String deflt) {
		Attr attr = null;
		attr = (Attr) attrs.getNamedItem(attrName);
		return (attr != null) ? attr.getValue() : deflt;
	}
}