package gov.va.med.vistalink.adapter.cci;

import gov.va.med.vistalink.adapter.spi.EMReAuthState;
import gov.va.med.xml.XmlUtilities;

import org.apache.log4j.Logger;
import org.w3c.dom.Attr;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * This is the base implementation class for VistaLinkConnectionSpec
 * 
 */
public abstract class VistaLinkConnectionSpecImpl implements VistaLinkConnectionSpec {
	/**
	 * The string used to identify the type attribute
	 */
	protected static final String ATTRIBUTE_SECURITY_TYPE = "type";

	/**
	 * The string used to identify the state attribute
	 */
	protected static final String ATTRIBUTE_SECURITY_STATE = "state";

	/**
	 * The string used to identify the division attribute
	 */
	protected static final String ATTRIBUTE_SECURITY_DIVISION = "division";

	/**
	 * The Division
	 */
	private String division;

	/**
	 * Reauthentication state
	 */
	private EMReAuthState reAuthState;

	/**
	 * The Logger used by this class
	 */
	private static final Logger logger = Logger.getLogger(VistaLinkConnectionSpecImpl.class);

	/**
	 * Note that division is required to be set into a connection spec before it can be used.
	 * 
	 * @va.exclude
	 * @deprecated
	 */
	public VistaLinkConnectionSpecImpl() {
		// argumentless constructor still used by VistaLinkJ2SEConnSpec 
		super();
	}

	/**
	 * @param division
	 *            The station number (e.g., "523", "523BZ", etc.) requested as the division under which logon/actions
	 *            should be conducted for this user on the target Kernel/M system.
	 *            <p>
	 *            The division parameter for connection specs is mandatory. This ensures that division requested for a
	 *            connection on behalf of an end-user matches the division actually accessed on the M side of the
	 *            connection.
	 *            <p>
	 *            The value to pass for the division parameter is the division station number, e.g., "523", "523BZ",
	 *            etc. This is the value found in field 99 ('Station Number') of the corresponding entry in the
	 *            Institution File on the M system.
	 *            <p>
	 *            On the M side, if a user doesn't have one or more "divisions" specified in the DIVISION (#200.02)
	 *            multiple of their New Person file entry, the division passed in with the connection spec must be the
	 *            station number of the division set into the DEFAULT INSTITUTION (#217) field of the KERNEL SYSTEM
	 *            PARAMETERS (#8989.3) file entry for the site. This value is set by Kernel into DUZ(2).
	 *            <p>
	 *            On the M side, if a user has one or more "divisions" specified in the DIVISION (#200.02) multiple of
	 *            their New Person file entry, the division passed in with the connection spec must be the station
	 *            number for one of those divisions present in that multiple. This value will be set by Kernel into
	 *            DUZ(2).
	 */
	public VistaLinkConnectionSpecImpl(String division) {
		super();
		this.division = division;
	}

	/**
	 * @return Current Station # setting
	 */
	public String getDivision() {
		return division;
	}

	/**
	 * @param string
	 *            Station #
	 */
	public void setDivision(String string) {
		division = string;
	}

	/**
	 * Sets the security state in the securityNode to identify the re-authentication state
	 * 
	 * @param reAuthState
	 *            reauthentication state to set
	 * @va.exclude
	 */
	public void setSecurityState(EMReAuthState reAuthState) {
		this.reAuthState = reAuthState;
	}

	/**
	 * returns the state of re-authentication
	 * 
	 * @return Security state
	 * @va.exclude
	 */
	public EMReAuthState getSecurityState() {
		return reAuthState;
	}

	/**
	 * Sets the division in the security Xml
	 * 
	 * @param securityNode
	 *            Security Node
	 * @va.exclude
	 */
	public void setSecurityDivisionAttr(Node securityNode) {
		Attr attrSecurityDivision = XmlUtilities.getAttr(securityNode, ATTRIBUTE_SECURITY_DIVISION);
		attrSecurityDivision.setValue(this.division);
	}

	/**
	 * Sets the security state in the securityNode to identify the re-authentication state
	 * 
	 * @param securityNode
	 *            Security node
	 * @va.exclude
	 */
	public void setSecurityStateAttr(Node securityNode) {
		Attr attrSecurityState = XmlUtilities.getAttr(securityNode, ATTRIBUTE_SECURITY_STATE);
		attrSecurityState.setValue(this.reAuthState.toString());
	}

	/**
	 * Sets the security type in the security xml
	 * 
	 * @param securityNode
	 *            Security node
	 * @va.exclude
	 */
	public void setSecurityTypeAttr(Node securityNode) {
		Attr attrSecurityType = XmlUtilities.getAttr(securityNode, ATTRIBUTE_SECURITY_TYPE);
		attrSecurityType.setValue(this.getSecurityType());
	}

	/**
	 * clears the information in the security node
	 * 
	 * @param securityNode
	 *            the node to clear
	 * @see gov.va.med.vistalink.adapter.cci.VistaLinkConnectionSpec#clearSecurityNode(org.w3c.dom.Node)
	 * @va.exclude
	 */
	public void clearSecurityNode(Node securityNode) {
		//remove all the child nodes
		NodeList nl = securityNode.getChildNodes();
		int nodeListCnt = nl.getLength();
		for (int i = 0; i < nodeListCnt; i++) {
			Node childNode = nl.item(i);
			securityNode.removeChild(childNode);
		}
		Attr attrSecurityDivision = XmlUtilities.getAttr(securityNode, ATTRIBUTE_SECURITY_DIVISION);
		attrSecurityDivision.setValue("");
		Attr attrSecurityType = XmlUtilities.getAttr(securityNode, ATTRIBUTE_SECURITY_TYPE);
		attrSecurityType.setValue("");
		if (logger.isDebugEnabled()) {
			logger.debug("cleared securityNode");
		}
	}

}