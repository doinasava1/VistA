package gov.va.med.vistalink.security.m;

/**
 * Logon-related value object for "Select Division" results.
 * 
 */
public class SecurityVOSelectDivision extends SecurityVO {

	/**
	 * Constructor.
	 * @param resultType Success, Failure or Partial Success (types defined in parent class) 
	 * @param resultMessage optional explanatory description for the result, usually used for failure and partial success only
	 */
	public SecurityVOSelectDivision(int resultType, String resultMessage) {
		super(resultType, resultMessage);
	}

}
