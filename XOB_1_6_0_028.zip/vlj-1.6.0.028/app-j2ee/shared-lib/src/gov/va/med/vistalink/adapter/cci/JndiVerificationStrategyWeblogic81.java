package gov.va.med.vistalink.adapter.cci;

import gov.va.med.vistalink.adapter.spi.VistaLinkManagedConnectionFactory;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.log4j.Logger;

/**
 * Pluggable strategy for verifying if the actual deployed JNDI name for a connector matches the JNDI it was configured
 * with via the gov.va.med.vistalink.ConnectorConfiguration.xml file. Pluggable because implementations may require
 * vendor-specific calls or lifecycle sequencing.
 * 
 */
public class JndiVerificationStrategyWeblogic81 implements JndiVerificationStrategy {

	private static final Logger logger = Logger.getLogger(JndiVerificationStrategyWeblogic81.class);

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.adapter.cci.JndiVerificationStrategy#checkJndiMismatch(gov.va.med.vistalink.adapter.cci.VistaLinkConnectionFactory)
	 */
	public boolean checkJndiMismatch(VistaLinkManagedConnectionFactory mcf, VistaLinkConnectionFactory cf) {

		boolean returnVal = false;
		VistaLinkConnectionFactory retrievedCf = null;
		try {
			if (mcf == null) {
				logger.error("ManagedConnectionFactory is null, can't check JNDI mismatch.");
				// returnVal will be false
			} else {
				InitialContext ctx = new InitialContext();
				String cfgJndiName = mcf.getConnectorJndiName();
				retrievedCf = (VistaLinkConnectionFactory) ctx.lookup(cfgJndiName);
				logger.debug("completed CF lookup.");
				// explicitly want to confirm that both references refer to the same CF object, hence ==
				returnVal = (cf == retrievedCf);
				logger.debug("CF retrieved under JNDI name '" + cfgJndiName + "' is "
						+ ((returnVal ? "equal" : "not equal")) + " to MCF's stored CF, for connectorJndiName: "
						+ mcf.getConnectorJndiName());
			}
		} catch (NamingException e) {
			logger.error(e);
			// returnVal will be false
		}
		logger.debug("Returning '" + returnVal + "' from JndiVerificationStrategyWeblogic81.");
		return returnVal;

	}
}