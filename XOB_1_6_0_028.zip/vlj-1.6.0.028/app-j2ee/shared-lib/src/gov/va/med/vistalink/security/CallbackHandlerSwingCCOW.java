package gov.va.med.vistalink.security;

import java.awt.Frame;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import gov.va.med.hds.cd.ccow.ContextItemNameFactory;
import gov.va.med.hds.cd.ccow.IClinicalContextBroker;
import gov.va.med.hds.cd.ccow.IContextItemName;
import gov.va.med.hds.cd.ccow.IContextModule;
import gov.va.med.hds.cd.ccow.internal.ContextModule;

/**
 * Implements the JAAS CallbackHandler interface. Use with the <code>VistaLoginModule</code> to invoke a Swing-based
 * interactive logon, using the CCOW-enabled features of the VistaLink login module. If user authentication is required
 * (if a valid user context does not exist that can be leveraged for single signon), input values (access code, verify
 * code, division selection, and other "user input") are collected via a set of Swing GUI dialogs by this callback
 * handler.
 * <p>
 * To login:
 * <ol>
 * <li>Create a CCOW context module and broker. Must be securely bound to the context with a secure application
 * passcode.
 * <li>Create an instance of CallbackHandlerSwing, passing the Frame window parent, the context module and broker.
 * <li>Create the JAAS <code>LoginContext</code> instance, passing the instance of the callback handler as one of the
 * parameters.
 * <li>Invoke the JAAS login context's <code>login</code> method. The callback handler will invoke Swing dialogs to
 * collect user input wherever required for login.
 * </ol>
 * For example:
 * <p>
 * <code>
 * // use HDS classes to create context broker, module <br>
 * private IClinicalContextBroker ccowContextBroker; <br>
 * private ContextModule ccowContextModule; <br>
 * // create new Context Module with HDS library call <br>
 * ccowContextModule = new ContextModule(CCOW_APPLICATION_NAME, CCOW_APPLICATION_PASSCODE); <br>
 * // create context participant (a class that implements HDS IContextObserver, <br>
 * //  IContextParticipant interfaces) <br>
 * sampleAppContextParticipant = new SampleAppContextParticipant();
 * <p>
 * try {
 * 	// connect to CCOW context <br>
 * 	if (ccowContextModule != null) { <br>
 * 		ccowContextBroker = ccowContextModule.getBroker(this, sampleAppContextParticipant); <br>
 * 	} <br>
 * 	// create the callback handler <br>
 * 	CallbackHandlerSwingCCOW cbhSwing = new CallbackHandlerSwingCCOW(this.topFrame, this.ccowContextModule, <br>
 * 			this.ccowContextBroker); <br>
 * 	// create the LoginContext <br>
 * 	loginContext = new LoginContext(jaasConfigName, cbhSwing); <br>
 * 	// login to server <br>
 * 	loginContext.login(); <br>
 * 	// get principal <br>
 * 	userPrincipal = VistaKernelPrincipalImpl.getKernelPrincipal(loginContext.getSubject()); <br>
 * 	// set the app's VistaLink 'connected' status to connected. <br>
 * 	if ((ccowContextBroker != null) &amp;&amp; (ccowContextBroker.isConnected())) { <br>
 * 		storeUserContextState(); <br>
 * 	} <br>
 * } catch (Exception e) { <br>
 * 	JOptionPane.showMessageDialog(topFrame, e.getMessage(), &quot;Login error&quot;, JOptionPane.ERROR_MESSAGE); <br>
 * 	statusLabel.setText(STATUS_LABEL_DISCONNECTED_TEXT); <br>
 * 	gracefulLogout(-1); <br>
 * }<p>
 * </code>
 * 
 * @see VistaLoginModule
 */
public class CallbackHandlerSwingCCOW extends CallbackHandlerSwing {

	private static final Logger logger = Logger.getLogger(CallbackHandlerSwingCCOW.class);

	private IClinicalContextBroker applicationCcowContextBroker;

	// private IContextModule applicationCcowContextModule;

	static final String CCOW_BROKER_KEY = "CCOW_BROKER_KEY";

	static final String CCOW_CONTEXT_MODULE_KEY = "CCOW_CONTEXT_MODULE_KEY";

	/**
	 * The user context location under which the Kernel token is stored.
	 */
	public static final String VHA_CCOW_LOGON_TOKEN = "user.id.logon.vistatoken";

	/**
	 * The user context location under which the user name is stored.
	 */
	public static final String VHA_CCOW_LOGON_NAME = "user.id.logon.vistaname";

	/**
	 * The non-VA-specific generic user context location under which the user name is stored.
	 */
	public static final String VHA_CCOW_LOGON_NAME_GENERIC = "user.co.name";

	/**
	 * The user context location under which the VPID is stored.
	 */

	public static final String VHA_CCOW_LOGON_VPID = "user.id.logon.vpid";

	/**
	 * The VistA Domain.
	 */
	public static final String VHA_CCOW_LOGON_DOMAIN = "user.id.logon.vistalogon";

	/**
	 * Array containing the complete set of VHA user context keys. VPID key not yet supported.
	 */
	public static final String[] VHA_CCOW_USER_CONTEXT_KEYS = { VHA_CCOW_LOGON_TOKEN, VHA_CCOW_LOGON_NAME,
			VHA_CCOW_LOGON_NAME_GENERIC, VHA_CCOW_LOGON_VPID, VHA_CCOW_LOGON_DOMAIN };

	/**
	 * The CCOW application name for this login module
	 */
	private static final String CCOW_APPLICATION_NAME = "VistaLinkLoginModule";

	// other ccow fields
	private IClinicalContextBroker loginModuleContextBroker;

	private ContextModule loginModuleContextModule;

	private static final int RPC_RESULT_DELIMITER = 10;

	/**
	 * Creates a callback handler for VistaLink logins, using a SWING interface, and using the CCOW-enabled features of
	 * VistaLink to provide a CCOW-enabled login.
	 * 
	 * @param windowParent Allows login dialogs to be centered over a parent frame (a top-level window with a title and
	 *            border). If null is passed, login dialogs are centered based on the screen itself.
	 * @param applicationCcowContextModule NOT USED: pass null for now. PREVIOUSLY WAS: the application's CCOW context
	 *            module the login module should use to read the CCOW context
	 * @param applicationCcowContextBroker the application's CCOW context broker the login module should use to read the
	 *            CCOW context
	 */
	public CallbackHandlerSwingCCOW(Frame windowParent, IContextModule applicationCcowContextModule,
			IClinicalContextBroker applicationCcowContextBroker) {

		super(windowParent);
		// NOT USED... this.applicationCcowContextModule = applicationCcowContextModule;
		this.applicationCcowContextBroker = applicationCcowContextBroker;

	}

	/**
	 * override's the parent class's logon method for CCOW-enabled logon
	 * 
	 * @param logonCallback
	 */
	void doCallbackLogon(CallbackLogon logonCallback) {

		logger.debug("starting CallbackLogon.");

		String user = null;
		String token = null;

		// inform the login module that a CCOW-enabled callback handler is in
		// use.
		logonCallback.setCcowLogonModeEnabled(true);

		// if we have a context broker, and it's connected, use it to see
		// if we have a user context already set. If so, get the Kernel
		// logon token from that context.
		// if retry count is greater than 1, then don't try CCOW again
		if ((applicationCcowContextBroker != null) && (logonCallback.getTryCount() < 2)) {
			if (applicationCcowContextBroker.isConnected()) {
				// get the context
				Map contextItems = applicationCcowContextBroker.getContextItems();
				// check user/token
				IContextItemName tokenKey = ContextItemNameFactory.getName(VHA_CCOW_LOGON_TOKEN);
				IContextItemName nameKey = ContextItemNameFactory.getName(VHA_CCOW_LOGON_NAME);
				token = (String) contextItems.get(tokenKey);
				user = (String) contextItems.get(nameKey);
			}
		}

		if (((user == null) || (user.length() < 1)) || ((token == null) || (token.length() < 1))) {

			// challenge the user to interactively collect access/verify code
			DialogLogon.showVistaAVSwingGetAV(this.getWindowParent(), logonCallback);

		} else {

			// set token as the access code
			logonCallback.setToken(token);
			logonCallback.setSelectedOption(CallbackLogon.KEYPRESS_OK);
		}
	}

	/**
	 * Overrides the parent class's commit callback for CCOW-enabled post-logon processing
	 * 
	 * @param commitCallback
	 */
	void doCallbackCommit(CallbackCommit commitCallback) {

		logger.debug("starting CallbackCommit.");

		// if CCOW, and context not set, then set context for user
		if (this.applicationCcowContextBroker != null) {

			if (!applicationCcowContextBroker.isConnected()) {

				// could throw exception -- BUT we want app to continue
				logger.info("context Broker is not connected.");

			} else {

				// try to get the expected VISTA ccow context
				Map contextItems = applicationCcowContextBroker.getContextItems();
				IContextItemName tokenKey = ContextItemNameFactory.getName(VHA_CCOW_LOGON_TOKEN);
				IContextItemName nameKey = ContextItemNameFactory.getName(VHA_CCOW_LOGON_NAME);
				String ccowToken = (String) contextItems.get(tokenKey);
				String ccowName = (String) contextItems.get(nameKey);

				// Find out if there is an existing user context, Vista
				// "expected" format or not.

				if (((ccowToken == null) || (ccowToken.length() < 1))
						|| ((ccowName == null) || (ccowName.length() < 1))) {

					// only want to write new context if no existing VHA user
					// context -- otherwise we leave
					// it alone.

					// create the context if it's null and there's no other user
					// context items present (therefore, presumably we're the first app)
					String kernelTokenAndId = commitCallback.getKernelCcowToken();
					int newlineFirst = kernelTokenAndId.indexOf(RPC_RESULT_DELIMITER);
					int newlineSecond = kernelTokenAndId.indexOf(RPC_RESULT_DELIMITER, newlineFirst + 1);
					String kernelToken = kernelTokenAndId.substring(0, newlineFirst);
					String kernelDomain = kernelTokenAndId.substring(newlineFirst + 1, newlineSecond);

					HashMap newContext = new HashMap();

					// add new items to new context
					newContext.put(VHA_CCOW_LOGON_NAME, commitCallback.getNameNewPerson01());
					newContext.put(VHA_CCOW_LOGON_NAME_GENERIC, commitCallback.getNameNewPerson01());
					newContext.put(VHA_CCOW_LOGON_TOKEN, kernelToken);
					newContext.put(VHA_CCOW_LOGON_VPID, commitCallback.getVpid());
					newContext.put(VHA_CCOW_LOGON_DOMAIN, kernelDomain);

					// create login module CCOW context broker
					loginModuleContextModule = new ContextModule(CCOW_APPLICATION_NAME, commitCallback
							.getCcowSecurePasscode());

					try {

						// request the context change w/ new context, using Login
						// Module context broker
						logger.debug("about to write user context.");
						loginModuleContextBroker = loginModuleContextModule.getBroker(this, null);

						if (!loginModuleContextBroker.isConnected()) {

							String errorMessage = "Login module context broker could not connect to CCOW context, so could not write new user context.";
							logger.error(errorMessage);
							commitCallback.setErrorMessageToReport(errorMessage);

						} else {

							Object requestToken = loginModuleContextBroker.requestChange(newContext.keySet());
							if (requestToken != null) {
								if (!loginModuleContextBroker.changeContext(requestToken, newContext)) {
									String errorMessage = "ContextBroker 'changeContext' request failed, could not write new user context.";
									logger.error(errorMessage);
									commitCallback.setErrorMessageToReport(errorMessage);
								}
							} else {
								String errorMessage = "requestToken returned by ContextBroker 'requestChange' method is null, could not write new user context.";
								logger.error(errorMessage);
								commitCallback.setErrorMessageToReport(errorMessage);
							}
						}

					} catch (Throwable t) {

						String errorMessage = t.getMessage();
						logger.error("Error encountered contacting CCOW context broker: " + t.getMessage());
						commitCallback.setErrorMessageToReport(errorMessage);

					} finally {

						doCcowShutdown();
					}
				}
			}
		}
		logger.debug("End CallbackCommit.");
	}

	/**
	 * shut down the ccow contex broker & module.
	 */
	private void doCcowShutdown() {
		logger.debug("shutting down login CCOW module");
		// CCOW logout
		if (loginModuleContextBroker != null) {
			if (loginModuleContextBroker.isConnected()) {
				logger.debug("login CCOW context broker breaking external link.");
				loginModuleContextBroker.breakExternalLink();
			}
		}
		if (loginModuleContextModule != null) {
			logger.debug("login CCOW module shutdown()");
			loginModuleContextModule.shutdown();
		}
		loginModuleContextBroker = null;
		loginModuleContextModule = null;
	}

	/**
	 * returns whether the context contains at least one user context item.
	 * 
	 * @param contextItems Map of context items representing a context
	 * @return true if the context has at least one non-null user context key/value pair
	 */
	public static boolean hasNonNullUserContext(Map contextItems) {
		boolean returnVal = false;
		// examine context, see if it possesses user context
		if (contextItems != null) {
			Set keySet = contextItems.keySet();
			Iterator it = keySet.iterator();
			while (it.hasNext()) {
				IContextItemName key = (IContextItemName) it.next();
				if ("user.id.logon".equals(key.getName().substring(0, 13))) {
					String value = (String) contextItems.get(key);
					if ((value != null) && (value.length() > 0)) {
						returnVal = true;
						break;
					}
				}
			}
		}
		return returnVal;
	}

}
