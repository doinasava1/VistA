package gov.va.med.vistalink.security.m;

import gov.va.med.vistalink.adapter.record.VistaLinkRequestVOImpl;

import org.w3c.dom.Document;

/**
 * Represents a security request, to be sent to an M system for processing and response.
 * @see SecurityRequestFactory
 */
final class SecurityRequest extends VistaLinkRequestVOImpl {

	/**
	 * Constructor
	 * @param requestDoc Document representing the request
	 */
	SecurityRequest(Document requestDoc) {
		super(requestDoc);
	}

}
