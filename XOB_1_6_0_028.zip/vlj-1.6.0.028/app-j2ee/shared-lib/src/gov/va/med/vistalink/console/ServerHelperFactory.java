package gov.va.med.vistalink.console;

import gov.va.med.environment.Environment;
import gov.va.med.environment.ServerType;

/**
 * Constructs IServerHelper objects representing particular J2EE servers.
 * 
 */
public class ServerHelperFactory {

	private static ServerType serverType = null;

	static {
		serverType = Environment.getServerType();
	}

	/**
	 * private constructor to prevent instantiation
	 *
	 */
	private ServerHelperFactory() {
		// private constructor to prevent instantiation
	}
	
	/**
	 * Returns an IServerHelper object representing the specified J2EE server. The key information used to instantiate
	 * an IServerHelper object for specific server is the vendor-specific ObjectName fragment used by the vendor to
	 * filter MBean queries to retrieve MBeans from that single server.
	 * <p>
	 * Typically you would obtain this information for a given server you want to perform MBean operations on, by
	 * <ol>
	 * <li>Use the IJmxHelper getSortedDomainServers method to return a complete set of IServerHelpers for each server
	 * in the domain.
	 * <li>Prompt the user to select a single server from the set of servers (for example in a web page UI). The web
	 * page UI would include, as a state key between requests, the object name fragment from each IServerHelpers'
	 * getServerObjectNamePropertiesForMBeanServer() method, e.g., submitted as a form parameter.
	 * <li>When the user has selected a server, re-instantiate an IServerHelper object for the selected server by using
	 * the state key saved between requests.
	 * <li>Use other methods on the selected IServerHelper as necessary to perform MBean operations on the selected
	 * server.
	 * </ol>
	 * 
	 * @param platformSpecificServerIdentifier
	 *            Implementation-specific location identifier (an ObjectName fragment) identifying the server to get a
	 *            helper for.
	 * @return IServerHelper object for the identified server.
	 */
	public static IServerHelper getServerHelper(String platformSpecificServerIdentifier) {

		if (serverType.equals(ServerType.WEBLOGIC)) {
			return new ServerHelperWebLogic(platformSpecificServerIdentifier);
//		} else if (serverType.equals(ServerType.WEBSPHERE_BASE)) {
//			return new ServerHelperWebSphere(platformSpecificServerIdentifier);
//		} else if (serverType.equals(ServerType.WEBSPHERE_ND)) {
//			return new ServerHelperWebSphere(platformSpecificServerIdentifier);
		} else {
			throw new UnsupportedOperationException("IServerHelper objects not supported on server type: " + serverType);
		}
	}

	/**
	 * Returns an IServerHelper object representing the current JVM (local) J2EE server.
	 * 
	 * @return IServerHelper object representing local server.
	 */
	public static IServerHelper getLocalServerHelper() {
		if (serverType.equals(ServerType.WEBLOGIC)) {
			return new ServerHelperWebLogic();
//		} else if (serverType.equals(ServerType.WEBSPHERE_BASE)) {
//			return new ServerHelperWebSphere();
//		} else if (serverType.equals(ServerType.WEBSPHERE_ND)) {
//			return new ServerHelperWebSphere();
		} else {
			throw new UnsupportedOperationException("IServerHelper objects not supported on server type: " + serverType);
		}
	}

}
