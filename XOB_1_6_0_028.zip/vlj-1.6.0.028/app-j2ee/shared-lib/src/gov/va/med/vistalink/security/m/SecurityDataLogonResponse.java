package gov.va.med.vistalink.security.m;

import java.util.Map;

/**
 * Implements response-specific fields for an AV.Logon security message 
 * @see SecurityResponse
 * @see SecurityResponseFactory
 */
public final class SecurityDataLogonResponse extends SecurityResponse {

	private SecurityVOLogon responseVO;

	/**
	 * @see gov.va.med.vistalink.security.m.SecuriytResponse#SecuriytResponse(int, String)
	 */
	SecurityDataLogonResponse(
		boolean needNewVerifyCode,
		boolean needDivisionSelection,
		Map divisionList,
		String postSignInText,
		String cvcHelpText,
		SecurityResponse responseData) {

		super(responseData);
		responseVO = new SecurityVOLogon(responseData.getResultType(), responseData.getResultMessage());
		responseVO.setCvcHelpText(cvcHelpText);
		responseVO.setDivisionList(divisionList);
		responseVO.setNeedDivisionSelection(needDivisionSelection);
		responseVO.setNeedNewVerifyCode(needNewVerifyCode);
		responseVO.setPostSignInText(postSignInText);
		
	}

	/**
	 * 
	 * @return Value Object with results of logon attempt.
	 */
	public SecurityVOLogon getSecurityVOLogon() {
		return this.responseVO;
	}
}
