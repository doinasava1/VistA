package gov.va.med.vistalink.rpc;

import gov.va.med.xml.XmlUtilities;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

/**
 * Represents the collection of parameters associated with an RPC.
 * <p>
 * J2SE Example:
 * <p>
 * <code>
 *     // request  and response objects <br>
 *     RpcRequest vReq = null; <br>
 *     RpcResponse vResp = null;
 * <p>    
 *     //The Rpc Context<br>
 *     String rpcContext = &quot;XOBV VISTALINK TESTER&quot;;
 * <p>    
 *     //The Rpc to call<br>
 *     String rpcName = &quot;XOBV TEST STRING&quot;;
 * <p>    
 *      //Construct the request object<br>
 *     vReq = RpcRequestFactory.getRpcRequest(rpcContext, rpcName);
 * <p>    
 *     //clear the params 	<br>
 *     vReq.clearParams();
 * <p>    
 *     //Set the params<br>
 *     vReq.getParams(). setParam(1, &quot;string&quot;, &quot;This is a test string!&quot;);
 * <p>    
 *     //Execute the Rpc and get the response<br>
 *     vResp = myConnection.executeRPC(vReq);
 * <p>    
 *     //Work with the response ...
 * </code>
 * 
 */
class RpcXmlRequestParams {

	/**
	 * The DOM document representing the RpcRequest
	 */
	private Document requestDoc = null;

	/**
	 * The node representing the params for the RpcRequest
	 */
	private Node params = null;

	/**
	 * Constructs the Rpc Params.
	 * 
	 * @param requestDoc
	 */
	RpcXmlRequestParams(Document requestDoc) {
		this.requestDoc = requestDoc;
		this.params = XmlUtilities.getNode("/VistaLink/Request/Params", requestDoc);
	}

	/**
	 * Returns the params node.
	 * 
	 * @return Node
	 */
	Node getParams() {
		return params;
	}

	/**
	 * Sets a parameter needed by for a M RPC call.
	 * <p>
	 * The position argument is the parameter list position where the RPC
	 * expects to see this argument.
	 * <p>
	 * The type argument indicates to VistALink how the argument should be
	 * processed on the M VistA server.
	 * <p>
	 * Possible values are the following: 
	 * <ul>
	 * <li>string (corresponds to 'Literal' in VA RPC Broker)
	 * <li>array (corresponds to 'List' in VA RPC Broker)
	 * <li>ref (corresponds to 'Reference' in VA RPC Broker)
	 * </ul>
	 * 
	 * @param position
	 *            parameter position the M RPC expects this parameter
	 * @param type
	 *            type of parameter corresponding to valid M RPC types
	 * @param value
	 *            value of parameter
	 */
	void setParam(int position, String type, Object value) {
		Element param, indices, index, indexName, indexValue;
		Node node = XmlUtilities.getNode("//Param[@position='" + position + "']", params);
		// if param exists at position then remove so it can be re-set
		if (node != null) {
			params.removeChild(node);
			node = null;
		}
		if (value instanceof Map) {
			param = requestDoc.createElement("Param");
			setType(param, "array");
			setPosition(param, Integer.toString(position));
			indices = requestDoc.createElement("Indices");
			Map map = (Map) value;
			Iterator it = map.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry me = (Map.Entry) it.next();
				index = requestDoc.createElement("Index");
				indexName = requestDoc.createElement("Name");
				indexValue = requestDoc.createElement("Value");
				indexName.appendChild(requestDoc.createTextNode(me.getKey().toString()));
				indexValue.appendChild(requestDoc.createTextNode(me.getValue().toString()));
				index.appendChild(indexName);
				index.appendChild(indexValue);
				indices.appendChild(index);
			}
			param.appendChild(indices);
			params.appendChild(param);
		} else if (value instanceof List) {
			List list = (List) value;
			setIndices(position, list.iterator());
		} else if (value instanceof Set) {
			Set set = (Set) value;
			setIndices(position, set.iterator());
		} else {
			param = requestDoc.createElement("Param");
			setType(param, type);
			setPosition(param, Integer.toString(position));

			param.appendChild(requestDoc.createTextNode(value.toString()));
			params.appendChild(param);
		}
	}

	/**
	 * Sets the name, value attributes for a given List's Iterator
	 * 
	 * @param position
	 * @param it
	 */
	private void setIndices(int position, Iterator it) {
		Element param, indices, index, indexName, indexValue;
		param = requestDoc.createElement("Param");
		setType(param, "array");
		setPosition(param, Integer.toString(position));
		int item = 0;
		indices = requestDoc.createElement("Indices");
		while (it.hasNext()) {
			index = requestDoc.createElement("Index");
			indexName = requestDoc.createElement("Name");
			indexValue = requestDoc.createElement("Value");
			indexName.appendChild(requestDoc.createTextNode(String.valueOf(++item)));
			indexValue.appendChild(requestDoc.createTextNode(it.next().toString()));
			index.appendChild(indexName);
			index.appendChild(indexValue);
			indices.appendChild(index);
		}
		param.appendChild(indices);
		params.appendChild(param);
	}

	/**
	 * Sets the type on the specified element.
	 * 
	 * @param param
	 * @param value
	 */
	private void setType(Element param, String value) {
		Attr attr = requestDoc.createAttribute("type");
		attr.setValue(value);
		param.setAttributeNode(attr);
	}

	/**
	 * Sets the RPC parameter position of the specified element param at value.
	 * 
	 * @param param
	 * @param value
	 */
	private void setPosition(Element param, String value) {
		Attr attr = requestDoc.createAttribute("position");
		attr.setValue(value);
		param.setAttributeNode(attr);
	}

}
