package gov.va.med.crypto;

import gov.va.med.exception.FoundationsException;

/**
 * Represents an exception identifying that the Hash Count Limit (for a call to the VistaKernelHash
 * <code>encrypt</code> method) has been exceeded. In this case, the hash algorithm could not return an encrypted hash
 * within a certain number of tries, that was free of CDATA boundary character strings ("&lt;![CDATA[" and "]]&gt;").
 * @see VistaKernelHash
 */
public class VistaKernelHashCountLimitExceededException
	extends FoundationsException {

	/**
	 * Constructor for VistaKernelHashCountLimitExceededException.
	 * @va.exclude
	 */
	public VistaKernelHashCountLimitExceededException() {
		super();
	}

	/**
	 * Constructor for VistaKernelHashCountLimitExceededException.
	 * @param msg error message
	 * @va.exclude
	 */
	public VistaKernelHashCountLimitExceededException(String msg) {
		super(msg);
	}

	/**
	 * Constructor for VistaKernelHashCountLimitExceededException.
	 * @param nestedException an exception to nest
	 * @va.exclude
	 */
	public VistaKernelHashCountLimitExceededException(Exception nestedException) {
		super(nestedException);
	}

	/**
	 * Constructor for VistaKernelHashCountLimitExceededException.
	 * @param msg error message
	 * @param nestedException an exception to nest
	 * @va.exclude
	 */
	public VistaKernelHashCountLimitExceededException(
		String msg,
		Exception nestedException) {
		super(msg, nestedException);
	}

}
