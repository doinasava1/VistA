package gov.va.med.vistalink.adapter.heartbeat;

import gov.va.med.vistalink.adapter.cci.VistaLinkResourceException;

/**
 * This exception class is used to notify the managed connection and its event
 * listeners that a scheduled heart beat has failed.
 * 
 */
public class HeartBeatFailedException extends VistaLinkResourceException {

	/**
	 * Constructor for HeartBeatFailedException.
	 * 
	 * @param reason
	 *            Reason
	 * @va.exclude
	 */
	public HeartBeatFailedException(String reason) {
		super(reason);
	}

	/**
	 * Constructor for HeartBeatFailedException.
	 * 
	 * @param e
	 *            Exception
	 * @va.exclude
	 */
	public HeartBeatFailedException(Exception e) {
		super(e);
	}

	/**
	 * Constructor for HeartBeatFailedException.
	 * 
	 * @param reason
	 *            Reason
	 * @param errorCode
	 *            Error code
	 * @va.exclude
	 */
	public HeartBeatFailedException(String reason, String errorCode) {
		super(reason, errorCode);
	}

	/**
	 * Constructor for HeartBeatFailedException.
	 * 
	 * @param reason
	 *            Reason
	 * @param errorCode
	 *            Error Code
	 * @param e
	 *            Exception
	 * @va.exclude
	 */
	public HeartBeatFailedException(String reason, String errorCode, Exception e) {
		super(reason, errorCode, e);
	}

	/**
	 * Constructor for HeartBeatFailedException.
	 * 
	 * @param reason
	 *            Reason
	 * @param e
	 *            Exception
	 * @va.exclude
	 */
	public HeartBeatFailedException(String reason, Exception e) {
		super(reason, e);
	}

}