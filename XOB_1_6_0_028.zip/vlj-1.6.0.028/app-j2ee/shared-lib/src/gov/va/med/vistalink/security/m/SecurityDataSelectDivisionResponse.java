package gov.va.med.vistalink.security.m;

/**
 * Implements response-specific fields for an AV.SelectDivision security message 
 * @see SecurityResponse
 * @see SecurityResponseFactory
 */
public final class SecurityDataSelectDivisionResponse extends SecurityResponse {

	private SecurityVOSelectDivision responseVO;
	
	/**
	 * 
	 * @see gov.va.med.vistalink.security.m.SecuriytResponse#SecuriytResponse(int, String)
	 */
	SecurityDataSelectDivisionResponse(SecurityResponse responseData) {
		super(responseData);
		responseVO = new SecurityVOSelectDivision(responseData.getResultType(), responseData.getResultMessage());
	}
	
	/**
	 * 
	 * @return Value Object with results of select division attempt.
	 */
	public SecurityVOSelectDivision getSecurityVOSelectDivision() {
		return this.responseVO;
	}

}
