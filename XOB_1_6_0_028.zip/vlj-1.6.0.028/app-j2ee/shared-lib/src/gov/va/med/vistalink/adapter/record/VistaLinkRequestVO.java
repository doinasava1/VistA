package gov.va.med.vistalink.adapter.record;

import gov.va.med.exception.FoundationsException;

/**
 * Base request interface
 * 
 */
public interface VistaLinkRequestVO {

	/**
	 * Returns request string that is written to the socket sent to MUMPS.
	 * 
	 * @return String represents the request to M
	 * @throws FoundationsException
	 * @va.exclude
	 */
	String getRequestString() throws FoundationsException;

	/**
	 * Returns time out value used for communications to M RPC server.
	 * 
	 * @return int time out value in milli-seconds
	 */
	int getTimeOut();

	/**
	 * Enables application to set a request-specific time out for read operations on the connection, 
	 * for the request.
	 * <p>
	 * A timeout value of 0 (zero) indicates that no specific time out for the
	 * request is specified, and that the time out value associated with the socket
	 * should be used during socket read operations.
	 * 
	 * @param timeOut
	 *            Time out value to set in milli-seconds. This timeout value is
	 *            compared to the default value usually used for the connection.
	 *            The greater of the two values will be used.
	 */
	void setTimeOut(int timeOut);
	
	/**
	 * Returns current retry strategy reference.
	 * 
	 * @return VistaLinkRequestRetryStrategy instance reference
	 */
	VistaLinkRequestRetryStrategy getRetryStrategy();
	
	/**
	 * Enables application to set retry strategy for request, to be used if request execution
	 * failed because of socket failure or other system type problems. The strategy determines 
	 * if the retry should be attempted.
	 * 
	 * @param strategy the VistaLinkRequestRetryStrategy instance representing the strategy the application wants implemented.
	 */
	void setRetryStrategy(VistaLinkRequestRetryStrategy strategy);

}