package gov.va.med.vistalink.management;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import gov.va.med.environment.Environment;
import gov.va.med.environment.ServerType;
import gov.va.med.vistalink.jmx.IJmxHelper;
import gov.va.med.vistalink.jmx.JmxHelperException;
import gov.va.med.vistalink.jmx.JmxHelperFactory;

import javax.management.AttributeNotFoundException;
import javax.management.InstanceAlreadyExistsException;
import javax.management.InstanceNotFoundException;
import javax.management.MBeanException;
import javax.management.MBeanRegistrationException;
import javax.management.MBeanServer;
import javax.management.MBeanServerNotification;
import javax.management.MalformedObjectNameException;
import javax.management.NotCompliantMBeanException;
import javax.management.Notification;
import javax.management.NotificationListener;
import javax.management.ObjectName;
import javax.management.ReflectionException;

import org.apache.log4j.Logger;

/**
 * Notification listener for the per-connection-factory VistALink management bean.
 * 
 * Listens for outbound connection pool MBean registration events, and synchronizes the creation and deletion of
 * matching VistaLinkConnector MBeans, based on changes detected in outbound connection pool MBean state.
 * 
 * Note: this class currently contains some WebLogic-specific code. Would need to test/modify to work on other
 * application servers.
 * 
 */
public class VistaLinkConnectorNotificationListener implements NotificationListener {

	private static final Logger logger = Logger.getLogger(VistaLinkConnectorNotificationListener.class);

	// WEBLOGIC-specific MBean type
	private static final String WEBLOGIC_OUTBOUND_CONNECTION_POOL_MBEAN_TYPE = "ConnectorConnectionPoolRuntime";

	// WEBLOGIC-specific MBean attributes
	private static final String WEBLOGIC_JNDINAME_ATTRIBUTE = "JNDIName";
	private static final String WEBLOGIC_EISTYPE_ATTRIBUTE = "ConnectorEisType";
	// Note: ConnectorConnectionPoolRuntimeMBean "JNDIName" is no longer deprecated in the latest (10.3) WebLogic MBean reference.
	
	private static final String WEBLOGIC_JNDINAME_BACKUP_PROP = "Name";

	private static final String JMX_ONAME_NAME_ATTR = "Name";
	private static final String JMX_ONAME_TYPE_ATTR = "Type";

	// map w/synchronized wrapper containing system connector ObjectName keys with corresponding VL MBean ObjectName
	// values
	private Map connectorMBeanMap = Collections.synchronizedMap(new HashMap());

	// text strings
	private static final String TEXT_PROB_REG = "Problem registering VL MBean ";
	private static final String TEXT_BACKUP_ATTR = "Could not retrieve " + WEBLOGIC_OUTBOUND_CONNECTION_POOL_MBEAN_TYPE
			+ " jndiName attribute, using " + WEBLOGIC_JNDINAME_BACKUP_PROP + " attribute";

	// helper objects
	private static IJmxHelper jmxHelper;
	private static MBeanServer localMBeanServer;

	/**
	 * threadsafe instantiation of some private objects in static initializer.
	 */
	static {
		try {
			jmxHelper = JmxHelperFactory.getJmxHelper();
			localMBeanServer = jmxHelper.getLocalMBeanServer();
		} catch (JmxHelperException e) {
			logger.error("Could not get reference to local MBeanServer.", e);
		}
	}

	/**
	 * process notifications of MBean registrations/unregistrations from the local JVM MBean server.
	 */
	public void handleNotification(Notification notification, Object obj) {

		if (!ServerType.WEBLOGIC.equals(Environment.getServerType())) {
			logger.warn("cannot currently create VistaLinkConnector MBeans on non-WebLogic servers");
			return;
		}
		if (notification instanceof MBeanServerNotification) {
			MBeanServerNotification mbsNotification = (MBeanServerNotification) notification;
			ObjectName notificationObjectName = mbsNotification.getMBeanName();
			String mBeanType = notificationObjectName.getKeyProperty("Type");
			if (WEBLOGIC_OUTBOUND_CONNECTION_POOL_MBEAN_TYPE.equals(mBeanType)) {
				// log the notification found.
				logger.debug("MBean type '" + mBeanType + "' was '" + mbsNotification.getType() + "': "
						+ notificationObjectName);
				logger.debug("Event type: '" + mbsNotification.getType() + "', seq: '"
						+ mbsNotification.getSequenceNumber() + "', tstamp: '" + mbsNotification.getTimeStamp()
						+ "', class: '" + mbsNotification.getClass() + "', source: '" + mbsNotification.getSource()
						+ "', message: '" + mbsNotification.getMessage() + "', userdata: '"
						+ mbsNotification.getUserData());
				// process it
				if (MBeanServerNotification.REGISTRATION_NOTIFICATION.equals(mbsNotification.getType())) {
					processCandidateMBean(notificationObjectName);
				} else if (MBeanServerNotification.UNREGISTRATION_NOTIFICATION.equals(mbsNotification.getType())) {
					removeMBean(notificationObjectName);
				} else {
					logger.warn("Received unknown MBeanServerNotification type: " + mbsNotification.getType());
				}
			}
		}
	}

	/**
	 * Catch any connectors whose system MBean(s) were created prior to registration of this notification listener.
	 */
	public void performInitialScan() {

		if (!ServerType.WEBLOGIC.equals(Environment.getServerType())) {
			logger.warn("cannot currently create VistaLinkConnector MBeans on non-WebLogic servers");
			return;
		}

		try {
			ObjectName connectorQueryName = new ObjectName(jmxHelper.getJmxDomainForPlatform() + ":"
					+ JMX_ONAME_TYPE_ATTR + "=" + WEBLOGIC_OUTBOUND_CONNECTION_POOL_MBEAN_TYPE + ",*");
			Set connectorMBeanSet = localMBeanServer.queryNames(connectorQueryName, null);
			if (logger.isDebugEnabled()) {
				logger.debug("found " + connectorMBeanSet.size() + " " + WEBLOGIC_OUTBOUND_CONNECTION_POOL_MBEAN_TYPE
						+ " mbeans");
			}

			// loop through outbound connection pool mbeans
			for (Iterator connectorIter = connectorMBeanSet.iterator(); connectorIter.hasNext();) {
				processCandidateMBean((ObjectName) connectorIter.next());
			}
		} catch (MalformedObjectNameException e) {
			logger.error("Error doing notification initial scan.", e);
		} catch (NullPointerException e) {
			logger.error("Error doing notification initial scan.", e);
		}
	}

	/**
	 * Set up VL MBean for 'found' connectors
	 * @param connectorObjectName system-specific ObjectName of connector found on local JVM
	 */
	private void processCandidateMBean(ObjectName connectorObjectName) {

		if (connectorMBeanMap.containsKey(connectorObjectName)) {
			logger.warn("connector Map already contains connector name '" + connectorObjectName + "'. Skipping.");
		} else {

			ObjectName vlcObjectName = null;
			try {
				if ("VistA".equals(localMBeanServer.getAttribute(connectorObjectName, WEBLOGIC_EISTYPE_ATTRIBUTE))) {

					// 1. create/register new VL MBean
					StringBuffer sb = new StringBuffer(jmxHelper.getJmxDomainForHev()).append(":");
					// if any "/" in this name, replace with "_"
					String connObjectName = connectorObjectName.getKeyProperty("Name").replace("/", "_");
					sb.append(JMX_ONAME_NAME_ATTR).append("=VistaLink_").append(connObjectName);
					sb.append(',').append(JMX_ONAME_TYPE_ATTR).append('=').append(VistaLinkConnector.getMBeanType());
					String additionalProps = jmxHelper.getServerObjectNamePropertiesForRegistration();
					if (additionalProps.length() > 0) {
						sb.append(',').append(additionalProps);
					}
					vlcObjectName = new ObjectName(sb.toString());

					// get JNDI name
					String jndiName = "";
					try {
						jndiName = (String) localMBeanServer.getAttribute(connectorObjectName,
								WEBLOGIC_JNDINAME_ATTRIBUTE);
						if ((jndiName == null) || (jndiName.length() < 1)) {
							logger.warn(TEXT_BACKUP_ATTR);
							jndiName = connectorObjectName.getKeyProperty(WEBLOGIC_JNDINAME_BACKUP_PROP);
						}
					} catch (AttributeNotFoundException e) {
						logger.warn(TEXT_BACKUP_ATTR);
						jndiName = connectorObjectName.getKeyProperty(WEBLOGIC_JNDINAME_BACKUP_PROP);
					} catch (InstanceNotFoundException e) {
						logger.warn(TEXT_BACKUP_ATTR);
						jndiName = connectorObjectName.getKeyProperty(WEBLOGIC_JNDINAME_BACKUP_PROP);
					} catch (MBeanException e) {
						logger.warn(TEXT_BACKUP_ATTR);
						jndiName = connectorObjectName.getKeyProperty(WEBLOGIC_JNDINAME_BACKUP_PROP);
					} catch (ReflectionException e) {
						logger.warn(TEXT_BACKUP_ATTR);
						jndiName = connectorObjectName.getKeyProperty(WEBLOGIC_JNDINAME_BACKUP_PROP);
					}
					logger.debug("got JNDI name: '" + jndiName + "'.");

					VistaLinkConnector vlMBean = new VistaLinkConnector(jndiName, connectorObjectName, localMBeanServer);
					localMBeanServer.registerMBean(vlMBean, vlcObjectName);
					logger.debug("new VL MBean '" + vlcObjectName.getCanonicalName() + "' registered.");

					// 2. update list
					connectorMBeanMap.put(connectorObjectName, vlcObjectName);
				}

			} catch (MalformedObjectNameException e) {
				logger.error(TEXT_PROB_REG + vlcObjectName, e);
			} catch (InstanceAlreadyExistsException e) {
				logger.error(TEXT_PROB_REG + vlcObjectName, e);
			} catch (MBeanRegistrationException e) {
				logger.error(TEXT_PROB_REG + vlcObjectName, e);
			} catch (NotCompliantMBeanException e) {
				logger.error(TEXT_PROB_REG + vlcObjectName, e);
			} catch (NullPointerException e) {
				logger.error(TEXT_PROB_REG + vlcObjectName, e);
			} catch (Exception e) {
				logger.error(TEXT_PROB_REG + vlcObjectName, e);
			}
		}
	}

	/**
	 * remove VL MBean when MBeanServer notifies that a connector MBean is being unregistered
	 * @param notificationObjectName
	 */
	private void removeMBean(ObjectName notificationObjectName) {

		if (connectorMBeanMap.containsKey(notificationObjectName)) {
			ObjectName vlObjectName = (ObjectName) connectorMBeanMap.get(notificationObjectName);
			logger.debug("removing from container MBean list: " + notificationObjectName.getCanonicalName());
			connectorMBeanMap.remove(notificationObjectName);
			try {
				localMBeanServer.unregisterMBean(vlObjectName);
				logger.debug("unregistered VL MBean " + vlObjectName);
			} catch (InstanceNotFoundException e) {
				logger.error("Could not unregister VL MBean " + vlObjectName, e);
			} catch (MBeanRegistrationException e) {
				logger.error("Could not unregister VL MBean " + vlObjectName, e);
			}
		} else {
			logger.warn("could not match MBean unregistration with list item: "
					+ notificationObjectName.getCanonicalName());
		}
	}
}
