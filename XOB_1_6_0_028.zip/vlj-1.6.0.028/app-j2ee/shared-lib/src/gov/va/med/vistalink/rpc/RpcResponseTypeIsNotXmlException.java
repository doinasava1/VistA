package gov.va.med.vistalink.rpc;

import gov.va.med.exception.FoundationsException;

/**
 * Represents an exception indicating the RpcResponse type if not XML
 * 
 */
public class RpcResponseTypeIsNotXmlException extends FoundationsException {

	/**
	 * Constructor for RpcResponseTypeIsNotXmlException.
	 * @va.exclude
	 */
	public RpcResponseTypeIsNotXmlException() {
		super();
	}

	/**
	 * Constructor for RpcResponseTypeIsNotXmlException.
	 * @param s message value
	 * @va.exclude
	 */
	public RpcResponseTypeIsNotXmlException(String s) {
		super(s);
	}

	/**
	 * Constructor for VistaLinkFaultException.
	 * @param nestedException
	 * @va.exclude
	 */
	public RpcResponseTypeIsNotXmlException(Exception nestedException) {
		super(nestedException);
	}

	/**
	 * Constructor for VistaLinkFaultException.
	 * @param msg
	 * @param nestedException
	 * @va.exclude
	 */
	public RpcResponseTypeIsNotXmlException(
		String msg,
		Exception nestedException) {
		super(msg, nestedException);
	}

}