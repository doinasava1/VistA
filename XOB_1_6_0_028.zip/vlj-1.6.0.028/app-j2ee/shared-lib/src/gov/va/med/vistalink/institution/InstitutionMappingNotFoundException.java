package gov.va.med.vistalink.institution;

import gov.va.med.exception.FoundationsException;

/**
 * Represents a failure to retrieve an institution mapping based on station
 * number, due to requested station number not being found in the list of 
 * instituion mappings maintained by the InstitutionMapping instance.
 * 
 */
public class InstitutionMappingNotFoundException extends FoundationsException {

	/**
	 * Exception constructor.
	 * @va.exclude
	 */
	public InstitutionMappingNotFoundException()
	{
		super();
	}
	
	/**
	 * Exception constructor.
	 * @param message Exception message.
	 * @va.exclude
	 */
	public InstitutionMappingNotFoundException(String message) {
		super(message);
	}
	
	/**
	 * Exception constructor.
	 * @param nestedException A nested exception.
	 * @va.exclude
	 */
	public InstitutionMappingNotFoundException(Exception nestedException) {
		super(nestedException);
	}
	
	/**
	 * Exception constructor.
	 * @param message Exception message.
	 * @param nestedException A nested exception.
	 * @va.exclude
	 */
	public InstitutionMappingNotFoundException(String message, Exception nestedException) {
		super(message, nestedException);
	}
}
