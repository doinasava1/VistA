/*
 * Created on Apr 8, 2005
 *
 */
package gov.va.med.crypto;

//CIPHER / GENERATORS
import javax.crypto.Cipher;

// KEY SPECIFICATIONS
import java.security.spec.KeySpec;
import java.security.spec.AlgorithmParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEParameterSpec;

// EXCEPTIONS
import java.security.InvalidAlgorithmParameterException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.InvalidKeyException;
import java.security.spec.InvalidKeySpecException;
import javax.crypto.NoSuchPaddingException;


/**
 * Provides basic implementation for a base class of Cipher algorithms, PassPhrase based.
 * To implement a particular algorithm/encoding, specify the algorithmName, encodingFormat in the overriding class.
 * 
 */

public class PassPhraseEncrypter extends KeyEncrypter{
  // 8-byte salt
  byte[] salt = {
      (byte)0x8E, (byte)0x50, (byte)0x43, (byte)0xE4,
      (byte)0x48, (byte)0xF3, (byte)0xEC, (byte)0xF2
  };
  
  int iCount = 21;
  protected String passPhrase = null;
  
  protected Key generateKey(){
    try{
      KeySpec keySpec = new PBEKeySpec(passPhrase.toCharArray(), salt, iCount);
      return SecretKeyFactory.getInstance(algorithmName).generateSecret(keySpec);
    }
    catch (NoSuchAlgorithmException e){handleException(e, "aquireKey() - NoSuchAlgorithmException!");}
    catch (InvalidKeySpecException e) {handleException(e, "aquireKey() - InvalidKeySpecException!");}
    return null;
  }

  protected Cipher getCipher(int opmode){
    try{
      AlgorithmParameterSpec pSpec = new PBEParameterSpec(salt, iCount);
      
      Cipher result = Cipher.getInstance(algorithmName);
      result.init(opmode, getKey(), pSpec);
      return result;
    }
    catch (InvalidKeyException e) {handleException(e, "getCipher() - InvalidKeyException!");}
    catch (NoSuchPaddingException e) {handleException(e, "getCipher() - NoSuchPaddingException!");}
    catch (NoSuchAlgorithmException e) {handleException(e, "getCipher() - NoSuchAlgorithmException!");}
    catch (InvalidAlgorithmParameterException e) {handleException(e, "getCipher() - InvalidAlgorithmParameterException!");}
    return null;        
  }  
}
