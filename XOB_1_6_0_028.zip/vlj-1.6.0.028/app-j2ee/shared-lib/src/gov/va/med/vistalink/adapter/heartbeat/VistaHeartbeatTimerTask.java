package gov.va.med.vistalink.adapter.heartbeat;

import gov.va.med.vistalink.adapter.record.VistaLinkFaultException;
import gov.va.med.vistalink.adapter.record.VistaLinkResponseVO;
import gov.va.med.vistalink.adapter.spi.EMAdapterEnvironment;
import gov.va.med.vistalink.adapter.spi.VistaLinkManagedConnection;
import gov.va.med.exception.ExceptionUtils;
import gov.va.med.exception.FoundationsException;

import java.util.ArrayList;
import java.util.TimerTask;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

/**
 * This class represents the TimerTask used to run the heart beat tasks on a
 * schedule. The Timer object schedules this object at a rate set by the
 * HeartBeatTimerManager.
 * 
 */
public class VistaHeartbeatTimerTask extends TimerTask {

	/**
	 * An array list to hold the managed connections that this TimerTask will
	 * execute heart beats on
	 */
	private ArrayList managedConnections;

	/**
	 * The rate at which the heart beat is scheduled
	 */
	private long heartBeatRate;

	/**
	 * The logger used for this class
	 */
	private static final Logger logger = Logger.getLogger(VistaHeartbeatTimerTask.class);

	private EMAdapterEnvironment adapterEnvironment;

	/**
	 * Constructor for VistaHeartbeatTimerTask.
	 */
	public VistaHeartbeatTimerTask(EMAdapterEnvironment adapterEnvironment) {
		super();
		managedConnections = new ArrayList();
		this.adapterEnvironment = adapterEnvironment;
	}

	/**
	 * Iterates through a list of managed Connections and executes a heart beat
	 * on them.
	 * <p>
	 * If the heart beat fails on a managed connection, this method notifies
	 * that managed connection and its event listeners that an error has
	 * occurred
	 * 
	 * @see java.lang.Runnable#run()
	 */
	public void run() {

		if (logger.isDebugEnabled()) {
			logger.debug("Run");
		}

		Object[] array;

		synchronized (managedConnections) {
			array = managedConnections.toArray();
		}

		VistaHeartBeatTimerRequest req;
		try {
			req = new VistaHeartBeatTimerRequest(adapterEnvironment);
		} catch (FoundationsException e) {

			if (logger.isEnabledFor(Level.ERROR)) {
				String errMsg = (new StringBuffer()).append("could not create VistaHeartBeatTimerRequest").append(
						"\n\t").append(ExceptionUtils.getFullStackTrace(e)).toString();

				logger.error(errMsg);

			}
			return;
		}

		VistaHeartBeatTimerResponseFactory resFactory = new VistaHeartBeatTimerResponseFactory();

		for (int i = 0; i < array.length; i++) {
			try {
				VistaLinkManagedConnection mc = (VistaLinkManagedConnection) array[i];

				if ((mc.isValid())
						&& ((System.currentTimeMillis() - mc.getLastInteractionTimeMillis()) > (getHeartBeatRate()))) {

					if (logger.isDebugEnabled()) {
						logger.debug((new StringBuffer()).append("sending heartbeat->").append(mc.toString()));
					}

					if (isHeartBeatSuccessful(mc.executeInteraction(req, resFactory))) {

						if (logger.isDebugEnabled()) {
							logger.debug((new StringBuffer()).append("HeartBeat successful->").append(mc.toString())
									.append("->").append(System.currentTimeMillis()));
						}

					} else {
						String errMsg = (new StringBuffer()).append("heartbeat failed->").append(mc.toString()).append(
								"->").append(System.currentTimeMillis()).toString();

						HeartBeatFailedException e = new HeartBeatFailedException(errMsg);

						if (logger.isEnabledFor(Level.ERROR)) {

							errMsg = (new StringBuffer()).append("could not execute heart beat").append("\n\t").append(
									ExceptionUtils.getFullStackTrace(e)).toString();

							logger.error(errMsg);
						}
						mc.notifyErrorOccurred(e);
					}

				}
			} catch (VistaLinkFaultException e) {

				if (logger.isEnabledFor(Level.ERROR)) {
					String errMsg = (new StringBuffer()).append("VistaLinkFaultException occured during heartbeat.")
							.append("\n\t").append(ExceptionUtils.getFullStackTrace(e)).toString();

					logger.error(errMsg);
				}

			} catch (FoundationsException e) {

				if (logger.isEnabledFor(Level.ERROR)) {
					String errMsg = (new StringBuffer()).append("FoundationsException occured during heartbeat.")
							.append("\n\t").append(ExceptionUtils.getFullStackTrace(e)).toString();

					logger.error(errMsg);
				}
			}
		}
	}

	/**
	 * Adds a VistaLinkManagedConnection to managedConnections List. This method
	 * is synchronized on the managedConnections List.
	 * 
	 * @param mc -
	 *            the managed connection to add
	 */
	public void addManagedConnection(VistaLinkManagedConnection mc) {
		if (logger.isDebugEnabled()) {
			logger.debug("adding managed connection");
		}
		synchronized (managedConnections) {
			managedConnections.add(mc);
		}
	}

	/**
	 * Removes a VistaLinkManagedConnection from the managedConnections List.
	 * This method is synchronized on the managedConnections List.
	 * 
	 * @param mc
	 */
	public void removeManagedConnection(VistaLinkManagedConnection mc) {
		if (logger.isDebugEnabled()) {
			logger.debug("remove managed connection");
		}
		synchronized (managedConnections) {
			managedConnections.remove(mc);
		}
	}

	/**
	 * Returns whether or not the managedConnections List isEmpty(). This method
	 * is synchronized on the managedConnections List.
	 * 
	 * @return boolean
	 */
	public boolean isManagedConnectionListEmpty() {
		synchronized (managedConnections) {
			return managedConnections.isEmpty();
		}
	}

	/**
	 * Returns whether the heartbeat request was successful or not.
	 * 
	 * @param res
	 * @return boolean
	 */
	private static boolean isHeartBeatSuccessful(VistaLinkResponseVO res) {

		return ((VistaHeartBeatTimerResponse) res).isHeartBeatSuccessful();

	}

	/**
	 * Returns the heartBeatRate.
	 * 
	 * @return long
	 */
	public long getHeartBeatRate() {
		return heartBeatRate;
	}

	/**
	 * Sets the heartBeatRate.
	 * 
	 * @param heartBeatRate
	 *            The heartBeatRate to set
	 */
	public void setHeartBeatRate(long heartBeatRate) {
		this.heartBeatRate = heartBeatRate;
	}

}