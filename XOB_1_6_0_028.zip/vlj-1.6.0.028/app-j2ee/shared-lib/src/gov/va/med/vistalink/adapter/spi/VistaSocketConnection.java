package gov.va.med.vistalink.adapter.spi;

import gov.va.med.exception.ExceptionUtils;
import gov.va.med.monitor.time.AuditTimer;
import gov.va.med.net.SocketManager;
import gov.va.med.net.VistaSocketException;
import gov.va.med.net.VistaSocketTimeOutException;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketException;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

/**
 * This class represents a raw socket connection to a M-Server
 * 
 */
public class VistaSocketConnection extends SocketManager {

	/**
	 * The logger used by this class
	 */
	private static final Logger logger = Logger.getLogger(VistaSocketConnection.class);

	/**
	 * Audit logger used by this class
	 */
	private static final Logger auditLogger = Logger.getLogger(VistaSocketConnection.class.getName() + ".AuditLog");

	/**
	 * The xml request used to send a close request to M
	 */
	protected static final String CLOSE_SOCKET_REQUEST = "<VistaLink messageType='gov.va.med.foundations.vistalink.system.request'"
			+ " version='"
			+ VistaLinkManagedConnectionFactory.ADAPTER_VERSION
			+ "'"
			+ " mode='single call'"
			+ " xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance'"
			+ " xsi:noNamespaceSchemaLocation='vlSimpleRequest.xsd'"
			//+ " xmlns='http://med.va.gov/Foundations'"
			+ ">" + "<Request type='closeSocket'/>" + "</VistaLink>";

	/**
	 * The port this socket is connected to
	 */
	private int port;

	/**
	 * The ip address this socket is connected to
	 */
	private InetAddress address;

	/**
	 * @param address
	 * @param port
	 * @throws VistaSocketException
	 */
	protected VistaSocketConnection(InetAddress address, int port, String mcIdentifier) throws VistaSocketException {
		super();

		this.address = address;
		this.port = port;
		setMatchingIdentifier(mcIdentifier);

		try {
			setSoc(new Socket(this.address, this.port));
		} catch (IOException e) {

			String errStr = "Can not create TCP/IP socket.";
			if (logger.isEnabledFor(Level.ERROR)) {

				String loggerMsg = getLoggerFormattedStringWStackTrace(errStr, e);

				logger.error(loggerMsg);
			}

			throw new VistaSocketException(errStr, e);
		}
	}

	/**
	 * Sends the request to M and returns the response. Also audits time it
	 * takes to make both transfers.
	 * 
	 * @param request
	 * @return String
	 * @throws VistaSocketTimeOutException
	 * @throws VistaSocketException
	 */
	public String transfer(String request) throws VistaSocketTimeOutException, VistaSocketException {

		boolean isAuditTimerEnabled = AuditTimer.isAuditTimerEnabled(auditLogger);

		AuditTimer auditTimer = null;

		if (isAuditTimerEnabled) {
			auditTimer = new AuditTimer(auditLogger);
			auditTimer.start();
		}
		//send data
		this.sendData(request);

		//read response
		String response = this.receiveData();

		if (isAuditTimerEnabled) {
			auditTimer.stop();
			auditTimer.log("Socket xfer (milli-secs):");
		}

		auditTimer = null;

		return response;
	}

	/**
	 * Sends a close request to M. Closes the socket. Sets the socket to null.
	 * 
	 * @throws VistaSocketException
	 */
	public void close() throws VistaSocketException {
		close(true);
	}

	/**
	 * Closes the socket. Sets the socket to null. Does NOT send a close request
	 * to M.
	 * 
	 * @throws VistaSocketException
	 */
	public void closeDontNotify() throws VistaSocketException {
		close(false);
	}

	/**
	 * Closes the socket. Sets the socket to null. Does NOT send a close request
	 * to M if notifyM parameter is set to false.
	 * 
	 * @param notifyM -
	 *            indicates where the M server should be notified if that the
	 *            socket is closing
	 * @throws VistaSocketException
	 */
	public void close(boolean notifyM) throws VistaSocketException {
		if (getSoc() != null) {
			if (notifyM) {
				try {
					this.sendData(CLOSE_SOCKET_REQUEST);
				} catch (VistaSocketException e) {
					// execute path to this catch block should be very rare...if
					// at all.
					String errStr = "'Close Socket request failed. M/VistA has most likely terminated this connection";
					if (logger.isEnabledFor(Level.ERROR)) {
						String loggerMsg = getLoggerFormattedStringWStackTrace(errStr, e);
						logger.error(loggerMsg);
					}
				}
			}
			try {
				getSoc().close();
			} catch (IOException e) {
				String errStr = "Can not close socket connection.";
				if (logger.isEnabledFor(Level.ERROR)) {
					String loggerMsg = getLoggerFormattedStringWStackTrace(errStr, e);
					logger.error(loggerMsg);
				}
				throw new VistaSocketException(errStr, e);
			}
			setSoc(null);
		}
	}

	/**
	 * @return InetAddress
	 */
	public InetAddress getAddress() {
		return address;
	}

	/**
	 * @return int
	 */
	public int getPort() {
		return port;
	}

	/**
	 * Sets the time out for socket send/read operations.
	 * 
	 * @param timeout
	 * @throws VistaSocketException
	 */
	public void setTransferTimeOut(int timeout) throws VistaSocketException {
		try {
			getSoc().setSoTimeout(timeout);
		} catch (SocketException e) {
			String errStr = "Can not set socket timeout.";
			if (logger.isEnabledFor(Level.ERROR)) {

				String loggerMsg = getLoggerFormattedStringWStackTrace(errStr, e);

				logger.error(loggerMsg);
			}
			throw new VistaSocketException(errStr, e);
		}
	}

	/**
	 * Precautionary code to clean-up socket connections in J2SE environment.
	 * <p>
	 * In application server spi.ManagedConnection:destroy() will be called to
	 * clean-up connections, hence this method will not be performing socket
	 * clean-up.
	 * 
	 * @see java.lang.Object#finalize()
	 */
	protected void finalize() throws Throwable {
		this.closeDontNotify();
		super.finalize();
	}

	public final String toString() {

		return (new StringBuffer()).append(this.getClass().getName()).append("[mdi]").append(getMatchingIdentifier())
				.toString();
	}

	/**
	 * @param log
	 * @return String
	 */
	private String getLoggerFormattedString(String log) {
		return (new StringBuffer()).append(this.toString()).append("\n\t").append(log).toString();
	}

	/**
	 * @param e
	 * @return String
	 */
	private String getLoggerFormattedStringWStackTrace(Throwable e) {

		return getLoggerFormattedString(ExceptionUtils.getFullStackTrace(e));

	}

	/**
	 * @param log
	 * @param e
	 * @return String
	 */
	private String getLoggerFormattedStringWStackTrace(String log, Throwable e) {

		return getLoggerFormattedString((new StringBuffer()).append(log).append("\n\t").append(
				ExceptionUtils.getFullStackTrace(e)).toString());

	}
}