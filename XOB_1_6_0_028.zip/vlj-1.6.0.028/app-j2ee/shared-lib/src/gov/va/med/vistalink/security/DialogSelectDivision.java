package gov.va.med.vistalink.security;
import gov.va.med.vistalink.security.m.VistaInstitutionVO;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Iterator;
import java.util.TreeMap;
import java.util.Vector;
import java.util.Map.Entry;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.Timer;

/**
 * Swing Dialog to collect user input for a "select division" event
 * @see VistaLoginModule
 * @see CallbackHandlerSwing
 */
final class DialogSelectDivision extends JDialog {

	private static final String DEFAULT_TITLE = "Select Division";

	private static final String OK_BUTTON_LABEL = "OK";
	private static final char OK_BUTTON_MNEMONIC = KeyEvent.VK_O;
	private static final String OK_BUTTON_TOOLTIP = "Submit your division choice to the server";

	private static final String HELP_BUTTON_LABEL = "Help";
	private static final char HELP_BUTTON_MNEMONIC = KeyEvent.VK_H;
	private static final String HELP_BUTTON_TOOLTIP = "Ask for help on this dialog";
	
	private static final String CANCEL_BUTTON_LABEL = "Cancel";
	private static final char CANCEL_BUTTON_MNEMONIC = KeyEvent.VK_C;
	private static final String CANCEL_BUTTON_TOOLTIP = "Cancel the login";

	private static final String DEFAULT_LABEL = "Must Select Division to Continue Sign On!";
	private static final String DEFAULT_LABEL_TOOLTIP = "You must select a division for this sign on";

	private static final String LIST_TOOLTIP = "List of Valid Divisions to select for Sign On";
	private static final char LIST_MNEMONIC = KeyEvent.VK_D;
	
	private static final String HELP_MSG_1 = "Select a division from the list and click OK.";
	private static final String HELP_MSG_2 = "To abort the logon click Cancel, but sign on will not be completed.";

	private JList jListDivisions;
	private Frame parentFrame;
	private CallbackSelectDivision divCbh;

	/**
	 * Create a modal Swing dialog to display a list of divisions for user to select 1 from.
	 * @param parent parent frame
	 * @param divCbh callback to retrieve information from and place result in
	 */
	static void showVistaAVSwingSelectDivision(Frame parent, CallbackSelectDivision divCbh) {

		DialogSelectDivision dialog = new DialogSelectDivision(parent, divCbh);
		if ((parent != null) && (!"".equals(parent.getTitle()))) {
			dialog.setTitle(parent.getTitle() + ": " + DialogLogon.SIGNON_STRING + " " + DEFAULT_TITLE);
		} else {
			dialog.setTitle(DialogLogon.DEFAULT_TITLE + ": " + DEFAULT_TITLE);
		}
		VistaLoginSwingUtilities.goldenMeanCenterDialog(parent, dialog);
		dialog.setVisible(true);
	}

	private DialogSelectDivision(Frame parentFrame, CallbackSelectDivision divCbh) {
		super(parentFrame, DEFAULT_TITLE, true);
		this.divCbh = divCbh;
		this.parentFrame = parentFrame;
		Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());
		contentPane.add(createLabelAndListPane(), BorderLayout.CENTER);
		contentPane.add(createButtonPane(), BorderLayout.SOUTH);

		pack();
		VistaLoginSwingUtilities.goldenMeanCenterDialog(parentFrame, this);

		//set up event for timeout
		int timeout = 1000 * this.divCbh.getTimeoutInSeconds();
		ActionListener taskPerformer = new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				doTimeout();
			}
		};
		getAccessibleContext().setAccessibleDescription(DEFAULT_LABEL_TOOLTIP);

		new Timer(timeout, taskPerformer).start();
		jListDivisions.requestFocusInWindow();
	}

	private JComponent createLabelAndListPane() {
		JPanel listPane = new JPanel();
		listPane.setLayout(new BoxLayout(listPane, BoxLayout.Y_AXIS));
		
		// descriptive label
		JLabel label = new JLabel(DEFAULT_LABEL);
		label.setToolTipText(DEFAULT_LABEL_TOOLTIP);
		listPane.add(label);

		listPane.add(Box.createRigidArea(new Dimension(0, 5)));
		listPane.add(createListScrollPane());

		label.setDisplayedMnemonic(LIST_MNEMONIC);
		label.setLabelFor(this.jListDivisions);

		listPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		return listPane;
	}

	private JComponent createButtonPane() {
		JPanel myPanel = new JPanel();
		GridLayout myGridLayout = new GridLayout(1, 3);
		myPanel.setLayout(myGridLayout);

		myPanel.add(createOkButtonPane());
		myPanel.add(createCancelButtonPane());
		myPanel.add(createHelpButtonPane());

		return myPanel;
	}

	private JScrollPane createListScrollPane() {
		JScrollPane listScroller = new JScrollPane(createDivisionJList());
		listScroller.setAlignmentX(LEFT_ALIGNMENT);
		listScroller.setToolTipText(LIST_TOOLTIP);
		return listScroller;
	}

	private JComponent createHelpButtonPane() {

		JPanel p = new JPanel();
		FlowLayout myFlowLayout = new FlowLayout();
		myFlowLayout.setAlignment(FlowLayout.LEFT);
		p.add(createHelpButton());
		return p;
	}

	private JComponent createOkButtonPane() {

		JPanel p = new JPanel();
		FlowLayout myFlowLayout = new FlowLayout();
		myFlowLayout.setAlignment(FlowLayout.LEFT);
		p.add(createOkButton());
		return p;
	}

	private JComponent createCancelButtonPane() {

		JPanel p = new JPanel();
		FlowLayout myFlowLayout = new FlowLayout();
		myFlowLayout.setAlignment(FlowLayout.CENTER);
		p.add(createCancelButton());
		return p;
	}

	private JButton createHelpButton() {

		JButton help = new JButton(HELP_BUTTON_LABEL);
		help.setMnemonic(HELP_BUTTON_MNEMONIC);
		help.setToolTipText(HELP_BUTTON_TOOLTIP);
		help.setFont(help.getFont().deriveFont(Font.BOLD));
		help.addActionListener(new HelpButtonActionListener());
		return help;
	}

	private JButton createOkButton() {
		JButton ok = new JButton(OK_BUTTON_LABEL);
		ok.setMnemonic(OK_BUTTON_MNEMONIC);
		ok.setToolTipText(OK_BUTTON_TOOLTIP);
		ok.setFont(ok.getFont().deriveFont(Font.BOLD));
		this.getRootPane().setDefaultButton(ok);
		ok.setAlignmentX(RIGHT_ALIGNMENT);

		// handle events for button presses
		ok.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				okActionPerformed();
			}
		});
		return ok;
	}

	private JButton createCancelButton() {
		JButton cancel = new JButton(CANCEL_BUTTON_LABEL);
		cancel.setMnemonic(CANCEL_BUTTON_MNEMONIC);
		cancel.setToolTipText(CANCEL_BUTTON_TOOLTIP);
		cancel.setFont(cancel.getFont().deriveFont(Font.BOLD));
		cancel.setAlignmentX(RIGHT_ALIGNMENT);

		// handle events for button presses
		cancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cancelActionPerformed();
			}
		});
		return cancel;
	}

	private JComponent createDivisionJList() {

		TreeMap divisionList = (TreeMap) this.divCbh.getDivisionList();
		Vector divisionListData = new Vector();
		String defaultListString = "";

		for (Iterator it = divisionList.entrySet().iterator(); it.hasNext();) {
			Entry entry = (Entry) it.next();
			VistaInstitutionVO myDivision = (VistaInstitutionVO) entry.getValue();
			String listString = "(" + myDivision.getNumber() + ") " + myDivision.getName();
			divisionListData.add(listString);
			// Store off the element that matches the default division
			if (myDivision.getIsDefaultLogonDivision()) {
				defaultListString = listString;
			}
		}

		jListDivisions = new JList();
		jListDivisions.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		jListDivisions.setListData(divisionListData);
		jListDivisions.setToolTipText(LIST_TOOLTIP);

		// Handle double-click processing
		MouseListener mouseListener = new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if (e.getClickCount() == 2) {
					// check that the current selected item matches the double-click; if not, don't process
					if (jListDivisions.locationToIndex(e.getPoint()) == jListDivisions.getSelectedIndex()) {
						storeSelectedDivision(jListDivisions.getSelectedIndex(), jListDivisions.getSelectedValue());
						divCbh.setSelectedOption(CallbackSelectDivision.KEYPRESS_OK);
						setVisible(false);
						dispose();
					}
				}
			}
		};
		jListDivisions.addMouseListener(mouseListener);

		for (int i = 0; i < jListDivisions.getModel().getSize(); i++) {
			if (((String) jListDivisions.getModel().getElementAt(i)).equalsIgnoreCase(defaultListString)) {
				jListDivisions.setSelectedIndex(i);
				break;
			}
		}

		return jListDivisions;
	}

	private void okActionPerformed() {
		storeSelectedDivision(jListDivisions.getSelectedIndex(), jListDivisions.getSelectedValue());
		this.divCbh.setSelectedOption(CallbackSelectDivision.KEYPRESS_OK);
		this.setVisible(false);
		this.dispose();
	}

	/**
	 * Parse the selected value, match it with division value passed in the callback handler
	 * @param selectedIndex currently selected index in listbox
	 * @param selectedValue currently selected value in listbox
	 * @return boolean true if matched a division in the callback handler, false if not
	 */
	private boolean storeSelectedDivision(int selectedIndex, Object selectedValue) {
		boolean returnVal = false;
		TreeMap divisionList = (TreeMap) this.divCbh.getDivisionList();
		this.divCbh.setSelectedDivisionIen("-1");
		int index = -1;
		for (Iterator it = divisionList.entrySet().iterator(); it.hasNext();) {
			Entry entry = (Entry) it.next();
			index++;
			VistaInstitutionVO myDivision = (VistaInstitutionVO) entry.getValue();
			if ((selectedIndex == index)
				&& (selectedValue.equals("(" + myDivision.getNumber() + ") " + myDivision.getName()))) {
				this.divCbh.setSelectedDivisionIen(myDivision.getIen());
				returnVal = true;
			}
		}
		return returnVal;
	}

	private void cancelActionPerformed() {
		this.divCbh.setSelectedDivisionIen("-1");
		this.divCbh.setSelectedOption(CallbackSelectDivision.KEYPRESS_CANCEL);
		this.setVisible(false);
		this.dispose();
	}

	/**
	 * if we timeout, set the action that closed the dialog to TIMEOUT and return
	 */
	private void doTimeout() {
		this.divCbh.setSelectedDivisionIen("-1");
		this.divCbh.setSelectedOption(CallbackSelectDivision.KEYPRESS_TIMEOUT);
		this.setVisible(false);
		this.dispose();
	}

	/**
	 * Handle event processing for the help button -- launch a separate dialog for help
	 */
	class HelpButtonActionListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {

			StringBuffer sb = new StringBuffer(HELP_MSG_1);
			sb.append('\n');
			sb.append(HELP_MSG_2);
			int returnVal = DialogConfirm.showDialogConfirm(
				parentFrame,
				sb.toString(),
				DialogLogon.SIGNON_STRING + " Select Division Help",
				DialogConfirm.MODE_HELP_MESSAGE,
				divCbh.getTimeoutInSeconds());
			if (returnVal == DialogConfirm.TIMEOUT_OPTION) {
				doTimeout();
			} else {
				jListDivisions.requestFocusInWindow();				
			}
		}
	}

}
