package gov.va.med.vistalink.institution;

/**
 * Returns instantiations for IPrimaryStationRules interface.
 * 
 */
public class PrimaryStationRulesFactory {

	public static final String PRIMARY_STATION_RULES_KEY = "gov.va.med.vistalink.primary-station-rules-class";

	/**
	 * Get an IPrimaryStationRules instance. Defaults to PrimaryStationRulesVHA unless
	 * gov.va.med.vistalink.primary-station-rules-class JVM argument specifies another class.
	 * 
	 * @return IPrimaryStationRules instance
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @throws ClassNotFoundException
	 */
	public static IPrimaryStationRules getPrimaryStationRulesImplementation() throws InstantiationException,
			IllegalAccessException, ClassNotFoundException {

		IPrimaryStationRules returnVal = null;

		String rulesClass = System.getProperty(PRIMARY_STATION_RULES_KEY);
		if (rulesClass == null) {
			returnVal = new PrimaryStationRulesVHA();
		} else {
			returnVal = (IPrimaryStationRules) Class.forName(rulesClass).newInstance();
		}
		return returnVal;
	}
}
