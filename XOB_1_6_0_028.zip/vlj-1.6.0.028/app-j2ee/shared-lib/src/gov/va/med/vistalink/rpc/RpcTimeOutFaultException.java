package gov.va.med.vistalink.rpc;

import gov.va.med.vistalink.adapter.record.VistaLinkFaultException;

/**
 * This exception represents the case where the RPC execution took too long on the server and
 * the application gracefully stopped the RPC's processing.
 * 
 */
public class RpcTimeOutFaultException extends RpcFaultException {

	/**
	 * Constructor for RpcTimeOutFaultException.
	 * @see gov.va.med.vistalink.adapter.record.VistaLinkFaultException#VistaLinkFaultException(VistaLinkFaultException)
	 * @param vistaLinkFaultException the exception to copy into a new exception type
	 * @va.exclude
	 */
	public RpcTimeOutFaultException(VistaLinkFaultException vistaLinkFaultException) {
		super(vistaLinkFaultException);
	}

}
