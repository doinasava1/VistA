package gov.va.med.vistalink.security;

import gov.va.med.vistalink.security.m.SecurityVO;
import gov.va.med.vistalink.security.m.SecurityVOChangeVc;
import gov.va.med.vistalink.security.m.SecurityVOLogon;
import gov.va.med.vistalink.security.m.SecurityVOSelectDivision;
import gov.va.med.vistalink.security.m.SecurityVOUserDemographics;
import gov.va.med.vistalink.security.m.VistaKernelPrincipal;
import gov.va.med.vistalink.security.m.SecurityVOSetupAndIntroText;

import java.util.Hashtable;
import java.util.Map;

/**
 * Mock implementation of teh <code>VistaLoginModuleSPI</code> interface,
 * supports log in without any back-end security provider at all.
 * 
 * @see VistaLoginModuleSPI
 * @see VistaLoginModule
 */
class VistaLoginModuleSPIUnitTest implements VistaLoginModuleSPI {

	private boolean initializeVistaLoginModuleException = false;
	public String initializeVistaLoginModuleExceptionKey = "initializeVistaLoginModuleException";
	private boolean initializeVistaLoginModuleLoginsDisabledException = false;
	public String initializeVistaLoginModuleLoginsDisabledExceptionKey = "initializeVistaLoginModuleLoginsDisabledException";
	private boolean initializeVistaLoginModuleNoJobSlotsAvailable = false;
	public String initializeVistaLoginModuleNoJobSlotsAvailableKey = "initializeVistaLoginModuleNoJobSlotsAvailable";
	private boolean initializeVistaLoginModuleNoPathToListenerException = false;
	public String initializeVistaLoginModuleNoPathToListenerExceptionKey = "initializeVistaLoginModuleNoPathToListenerException";

	private boolean setupVistaLoginModuleException = false;
	public String setupVistaLoginModuleExceptionKey = "setupVistaLoginModuleException";

	private boolean logonVistaLoginModuleException = false;
	public String logonVistaLoginModuleExceptionKey = "logonVistaLoginModuleException";
	private boolean logonVistaLoginModuleTooManyInvalidAttemptsException = false;
	public String logonVistaLoginModuleTooManyInvalidAttemptsExceptionKey = "logonVistaLoginModuleTooManyInvalidAttemptsException";

	private boolean verifyVistaLoginModuleException = false;
	public String verifyVistaLoginModuleExceptionKey = "verifyVistaLoginModuleException";

	private boolean divisionVistaLoginModuleException = false;
	public String divisionVistaLoginModuleExceptionKey = "divisionVistaLoginModuleException";

	private boolean demographicsVistaLoginModuleException = false;
	public String demographicsVistaLoginModuleExceptionKey = "demographicsVistaLoginModuleException";

	private boolean kernelCcowTokenVistaLoginModuleException = false;
	public String kernelCcowTokenVistaLoginModuleExceptionKey = "kernelCcowTokenVistaLoginModuleException";

	private boolean secureCcowPasscodeVistaLoginModuleException = false;
	public String secureCcowPasscodeVistaLoginModuleExceptionKey = "secureCcowPasscodeVistaLoginModuleException";

	private boolean logoutVistaLoginModuleException = false;
	public String logoutVistaLoginModuleExceptionKey = "logoutVistaLoginModuleException";

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.va.med.vistalink.security.VistaLoginModuleSPI#initialize(java.util.Map)
	 */
	public void initialize(Map jaasOptions, Map jaasSharedState) throws Exception {
		
		this.initializeVistaLoginModuleException = "true".equalsIgnoreCase((String) jaasOptions
				.get(this.initializeVistaLoginModuleExceptionKey));
		this.initializeVistaLoginModuleLoginsDisabledException = "true".equalsIgnoreCase((String) jaasOptions
				.get(this.initializeVistaLoginModuleLoginsDisabledExceptionKey));
		this.initializeVistaLoginModuleNoJobSlotsAvailable = "true".equalsIgnoreCase((String) jaasOptions
				.get(this.initializeVistaLoginModuleNoJobSlotsAvailableKey));
		this.initializeVistaLoginModuleNoPathToListenerException = "true".equalsIgnoreCase((String) jaasOptions
				.get(this.initializeVistaLoginModuleNoPathToListenerExceptionKey));
		this.setupVistaLoginModuleException = "true".equalsIgnoreCase((String) jaasOptions
				.get(this.setupVistaLoginModuleExceptionKey));
		this.logonVistaLoginModuleException = "true".equalsIgnoreCase((String) jaasOptions
				.get(this.logonVistaLoginModuleExceptionKey));
		this.logonVistaLoginModuleTooManyInvalidAttemptsException = "true".equalsIgnoreCase((String) jaasOptions
				.get(this.logonVistaLoginModuleTooManyInvalidAttemptsExceptionKey));
		this.verifyVistaLoginModuleException = "true".equalsIgnoreCase((String) jaasOptions
				.get(this.verifyVistaLoginModuleExceptionKey));
		this.divisionVistaLoginModuleException = "true".equalsIgnoreCase((String) jaasOptions
				.get(this.divisionVistaLoginModuleExceptionKey));
		this.demographicsVistaLoginModuleException = "true".equalsIgnoreCase((String) jaasOptions
				.get(this.demographicsVistaLoginModuleExceptionKey));
		this.kernelCcowTokenVistaLoginModuleException = "true".equalsIgnoreCase((String) jaasOptions
				.get(this.kernelCcowTokenVistaLoginModuleExceptionKey));
		this.secureCcowPasscodeVistaLoginModuleException = "true".equalsIgnoreCase((String) jaasOptions
				.get(this.secureCcowPasscodeVistaLoginModuleExceptionKey));
		this.logoutVistaLoginModuleException = "true".equalsIgnoreCase((String) jaasOptions
				.get(this.logoutVistaLoginModuleExceptionKey));

		if (this.initializeVistaLoginModuleException) {
			throw new VistaLoginModuleException(this.initializeVistaLoginModuleExceptionKey);
		} else if (this.initializeVistaLoginModuleLoginsDisabledException) {
			throw new VistaLoginModuleLoginsDisabledException(this.initializeVistaLoginModuleLoginsDisabledExceptionKey);
		} else if (this.initializeVistaLoginModuleNoJobSlotsAvailable) {
			throw new VistaLoginModuleNoJobSlotsAvailableException(this.initializeVistaLoginModuleNoJobSlotsAvailableKey);
		} else if (this.initializeVistaLoginModuleNoPathToListenerException) {
			throw new VistaLoginModuleNoPathToListenerException(this.initializeVistaLoginModuleNoPathToListenerExceptionKey);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.va.med.vistalink.security.VistaLoginModuleSPI#getSetupAndIntroTextInfo()
	 */
	public Object getSetupAndIntroTextInfo() throws Exception {

		if (this.setupVistaLoginModuleException) {
			throw new VistaLoginModuleException(this.setupVistaLoginModuleExceptionKey);
		}
		/*
		 * SecurityVOSetupAndIntroText setupAndIntroTextInfo, SecurityResponse
		 * responseData
		 */
		SecurityVOSetupAndIntroText infoVO = new SecurityVOSetupAndIntroText(SecurityVO.RESULT_SUCCESS, "");
		infoVO.setDevice("x");
		infoVO
				.setIntroductoryText("yadda yadda hello\nyadda yadda hello\nyadda yadda hello\nyadda yadda hello\nyadda yadda hello\nyadda yadda hello\nyadda yadda hello\nyadda yadda hello\nyadda yadda hello\nyadda yadda hello\nyadda yadda hello\nyadda yadda hello\nyadda yadda hello\nyadda yadda hello\nyadda yadda hello\nyadda yadda hello\nyadda yadda hello\nyadda yadda hello\nyadda yadda hello\nyadda yadda hello\n");
		infoVO.setLogonRetryCount(5);
		infoVO.setPort(0);
		infoVO.setServerName("Server0");
		infoVO.setTimeout(150);
		infoVO.setUci("UCI0");
		infoVO.setVolume("Vol0");
		return infoVO;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.va.med.vistalink.security.VistaLoginModuleSPI#doKernelLogon(java.lang.String)
	 */
	public SecurityVOLogon doKernelLogon(String kernelCcowLogonToken) throws Exception {

		if (this.logonVistaLoginModuleException) {
			throw new VistaLoginModuleException(this.logonVistaLoginModuleExceptionKey);
		} else if (this.logonVistaLoginModuleTooManyInvalidAttemptsException) {
			throw new VistaLoginModuleTooManyInvalidAttemptsException(this.logonVistaLoginModuleTooManyInvalidAttemptsExceptionKey);
		}
		SecurityVOLogon myResponse = new SecurityVOLogon(SecurityVO.RESULT_SUCCESS, "");
		myResponse.setNeedDivisionSelection(false);
		myResponse.setNeedNewVerifyCode(false);
		myResponse.setPostSignInText("");
		return myResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.va.med.vistalink.security.VistaLoginModuleSPI#doKernelLogon(java.lang.String,
	 *      java.lang.String, boolean)
	 */
	public SecurityVOLogon doKernelLogon(String accessCode, String verifyCode, boolean requestCvc) throws Exception {

		if (this.logonVistaLoginModuleException) {
			throw new VistaLoginModuleException(this.logonVistaLoginModuleExceptionKey);
		} else if (this.logonVistaLoginModuleTooManyInvalidAttemptsException) {
			throw new VistaLoginModuleTooManyInvalidAttemptsException(this.logonVistaLoginModuleTooManyInvalidAttemptsExceptionKey);
		}
		SecurityVOLogon myResponse = new SecurityVOLogon(SecurityVO.RESULT_SUCCESS, "");
		myResponse.setNeedDivisionSelection(false);
		myResponse.setNeedNewVerifyCode(false);
		myResponse.setPostSignInText("");
		if (requestCvc) {
			myResponse.setNeedNewVerifyCode(true);
			myResponse.setResultType(SecurityVO.RESULT_PARTIAL);
		} else if (this.verifyVistaLoginModuleException) {
			myResponse.setNeedNewVerifyCode(true);
			myResponse.setResultType(SecurityVO.RESULT_PARTIAL);
		} else if (this.divisionVistaLoginModuleException) {
			myResponse.setNeedDivisionSelection(true);
			myResponse.setResultType(SecurityVO.RESULT_PARTIAL);
		}
		return myResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.va.med.vistalink.security.VistaLoginModuleSPI#changeVerifyCode(java.lang.String,
	 *      java.lang.String, java.lang.String)
	 */
	public SecurityVOChangeVc changeVerifyCode(String oldVerifyCode, String newVerifyCode, String newVerifyCodeCheck)
			throws Exception {

		if (this.verifyVistaLoginModuleException) {
			throw new VistaLoginModuleException(this.verifyVistaLoginModuleExceptionKey);
		}
		SecurityVOChangeVc myResponse = new SecurityVOChangeVc(SecurityVO.RESULT_SUCCESS, "");
		myResponse.setNeedDivisionSelection(false);
		return myResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.va.med.vistalink.security.VistaLoginModuleSPI#selectDivision(java.lang.String)
	 */
	public SecurityVOSelectDivision selectDivision(String selectedDivisionIen) throws Exception {
		/*
		 * SecurityResponse responseData
		 */
		if (this.divisionVistaLoginModuleException) {
			throw new VistaLoginModuleException(this.divisionVistaLoginModuleExceptionKey);
		}
		SecurityVOSelectDivision myResponse = new SecurityVOSelectDivision(SecurityVO.RESULT_SUCCESS, "");
		return myResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.va.med.vistalink.security.VistaLoginModuleSPI#getUserDemographicsData()
	 */
	public SecurityVOUserDemographics getUserDemographicsData() throws Exception {

		if (this.demographicsVistaLoginModuleException) {
			throw new VistaLoginModuleException(this.demographicsVistaLoginModuleExceptionKey);
		}
		Hashtable userDemographicsHashtable = new Hashtable();

		// name info
		userDemographicsHashtable.put(VistaKernelPrincipal.KEY_NAME_NEWPERSON01, "TestUser");
		userDemographicsHashtable.put(VistaKernelPrincipal.KEY_NAME_DISPLAY, "TestUser");
		userDemographicsHashtable.put(VistaKernelPrincipal.KEY_NAME_FAMILYLAST, "User");
		userDemographicsHashtable.put(VistaKernelPrincipal.KEY_NAME_GIVENFIRST, "Test");
		userDemographicsHashtable.put(VistaKernelPrincipal.KEY_NAME_MIDDLE, "");
		userDemographicsHashtable.put(VistaKernelPrincipal.KEY_NAME_PREFIX, "");
		userDemographicsHashtable.put(VistaKernelPrincipal.KEY_NAME_SUFFIX, "");
		userDemographicsHashtable.put(VistaKernelPrincipal.KEY_NAME_DEGREE, "");

		//userinfo node
		userDemographicsHashtable.put(VistaKernelPrincipal.KEY_DUZ, "1");
		userDemographicsHashtable.put(VistaKernelPrincipal.KEY_DTIME, "150");
		userDemographicsHashtable.put(VistaKernelPrincipal.KEY_TITLE, "Tester");
		userDemographicsHashtable.put(VistaKernelPrincipal.KEY_SERVICE_SECTION, "SQA");
		userDemographicsHashtable.put(VistaKernelPrincipal.KEY_LANGUAGE, "");
		userDemographicsHashtable.put(VistaKernelPrincipal.KEY_VPID, "");

		//divisioninfo node
		userDemographicsHashtable.put(VistaKernelPrincipal.KEY_DIVISION_IEN, "-1");
		userDemographicsHashtable.put(VistaKernelPrincipal.KEY_DIVISION_STATION_NAME, "Oakland");
		userDemographicsHashtable.put(VistaKernelPrincipal.KEY_DIVISION_STATION_NUMBER, "999ZZ");

		SecurityVOUserDemographics myResponse = new SecurityVOUserDemographics(SecurityVO.RESULT_SUCCESS, "");
		myResponse.setUserDemographicsHashtable(userDemographicsHashtable);
		return myResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.va.med.vistalink.security.VistaLoginModuleSPI#getSecureCcowPasscode()
	 */
	public String getSecureCcowPasscode() throws Exception {
		if (this.secureCcowPasscodeVistaLoginModuleException) {
			throw new VistaLoginModuleException(this.secureCcowPasscodeVistaLoginModuleExceptionKey);
		}
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.va.med.vistalink.security.VistaLoginModuleSPI#getKernelCcowToken()
	 */
	public String getKernelCcowToken() throws Exception {
		if (this.kernelCcowTokenVistaLoginModuleException) {
			throw new VistaLoginModuleException(this.kernelCcowTokenVistaLoginModuleExceptionKey);
		}
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.va.med.vistalink.security.VistaLoginModuleSPI#addSPISpecificInformationToPrincipal(gov.va.med.vistalink.security.VistaKernelPrincipalImpl)
	 */
	public void addSPISpecificInformationToPrincipal(VistaKernelPrincipalImpl principal) throws Exception {
		// do nothing -- no connection to add
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.va.med.vistalink.security.VistaLoginModuleSPI#logout()
	 */
	public void logout() throws Exception {
		if (this.logoutVistaLoginModuleException) {
			throw new VistaLoginModuleException(this.logoutVistaLoginModuleExceptionKey);
		}
		// do nothing -- nothing to log out of.
	}

}