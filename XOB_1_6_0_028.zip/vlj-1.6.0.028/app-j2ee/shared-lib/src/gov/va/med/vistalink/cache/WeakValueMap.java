/*
 * Created on May 18, 2005
 *
 */
package gov.va.med.vistalink.cache;

import java.util.AbstractMap;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;

import java.lang.ref.ReferenceQueue;
import java.lang.ref.Reference;
import java.lang.ref.WeakReference;

import org.apache.log4j.Logger;

/**
 * Utility class for caching connection factory weak references.
 *
 */
public class WeakValueMap extends AbstractMap{
  
  private static final Logger logger = Logger.getLogger(WeakValueMap.class); 
  /*internal storage object*/
  private final Map map = new HashMap();
  /* hard storage list - FIFO queue*/
  //private final LinkedList strongRef = new LinkedList();
  //private final int STRONG_SIZE;
  
  private final ReferenceQueue queue = new ReferenceQueue();
  
  public WeakValueMap(){
    // this(1);
  }
  
  //public WeakValueMap(int strongSize){
  //  STRONG_SIZE = strongSize;
  //}
  
  public Object get(Object key){
    Object result = null;
    Reference ref = (Reference)map.get(key);
     if(ref != null) {
       result = ref.get();
       if(result == null){ //either not in the map or was removed by the processQueue()
          logger.debug("map element <"+ map.remove(key)+"> has been removed for the key: " + key);
       }
     /*else {
        // Adding this object to the beginning of the strong
        // reference queue.  One reference can occur more than
        // once, because lookups of the FIFO queue are quite slow, so
        // we don't want to search through it each time to remove
        // duplicates.
         strongRef.addFirst(result);
         
         if(strongRef.size() > STRONG_SIZE) {
           strongRef.removeLast(); // Remove the last entry if the list longer than STRONG_SIZE
           logger.debug("Bumped up the object <" +result+"> in the strong reference cache");
         }
      }*/
     }
    return result;
  }  
  
  public Set entrySet(){
    processQueue();
    return map.entrySet();
  }
  
  public String toString(){
    processQueue();
    return super.toString();
  }
  
  /*
   *  We define our own subclass of WeakReference which contains
   *  not only the value but also the key to make it easier to find
   *  the entry in the HashMap after it's been garbage collected.
   */
  
  private static class WeakValue extends WeakReference {
    private final Object key; 
    private WeakValue(Object referent, Object key, ReferenceQueue q) {
      super(referent, q);
      this.key = key;
    }
   
    public String toString(){
      return ("Key: "+key+", Value: "+get());
    }
  }
 
  /* 
   * We go through the ReferenceQueue and remove garbage
   * collected WeakValue objects from the Map, by looking them
   * up using the WeakValue.key data member. 
   *  
   */
 
  private void processQueue() {
    WeakValue sv = null;
    logger.debug("Processing the queue ...");
    while ((sv = (WeakValue)queue.poll()) != null) {
      map.remove(sv.key); // we CAN access private data.
      logger.debug("Removed WeakValue: " + sv);
    }
  }
  
  public Object put(Object key, Object value) {
    processQueue();
    WeakValue sv =  new WeakValue(value, key, queue);
    logger.debug("Putting a WeakValue: " + sv);
    return map.put(key, sv);
  }
  
  public Object remove(Object key) {
    processQueue();
    logger.debug("Removing WeakValue, based on key: " + key);
    return map.remove(key);
  }
  
  public void clear() {
    // strongRef.clear();
    processQueue();
    map.clear();
  }
  
  public int size() {
    processQueue();
    return map.size();
  }
}
