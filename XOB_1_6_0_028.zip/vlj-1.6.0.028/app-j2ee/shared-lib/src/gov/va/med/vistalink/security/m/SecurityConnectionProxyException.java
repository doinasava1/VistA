package gov.va.med.vistalink.security.m;

import gov.va.med.vistalink.adapter.record.VistaLinkFaultException;

/**
 * This exception fault is returned from M, and signifies that the connection proxy used to create the connection was
 * invalid in some way, and a connection could not be established to the EIS.
 */
public final class SecurityConnectionProxyException extends SecurityFaultException {

	/**
	 * Constructor
	 * @param vistaLinkFaultException the exception to copy into a new exception type
	 * @va.exclude
	 */
	public SecurityConnectionProxyException(VistaLinkFaultException vistaLinkFaultException) {
		super(vistaLinkFaultException);
	}

}