/*
 * Created on Dec 18, 2003
 *
 */
package gov.va.med.vistalink.adapter.spi;

import gov.va.med.net.VistaSocketException;

/**
 * Represents a situation where, when attempting to close a socket, the socket is already closed.
 * 
 */
public class VistaLinkSocketAlreadyClosedException
	extends VistaSocketException {

	/**
	 * 
	 * @va.exclude
	 */
	public VistaLinkSocketAlreadyClosedException() {
		super();
	}

	/**
	 * @param msg
	 * @va.exclude
	 */
	public VistaLinkSocketAlreadyClosedException(String msg) {
		super(msg);
	}

	/**
	 * @param nestedException
	 * @va.exclude
	 */
	public VistaLinkSocketAlreadyClosedException(Exception nestedException) {
		super(nestedException);
	}

	/**
	 * @param msg
	 * @param nestedException
	 * @va.exclude
	 */
	public VistaLinkSocketAlreadyClosedException(
		String msg,
		Exception nestedException) {
		super(msg, nestedException);
	}

}
