package gov.va.med.vistalink.jmx;

/**
 * Represents an exception encountered performing JMX-related operations.
 * 
 */
public class JmxHelperException extends Exception {

	public JmxHelperException() {
		super();
	}
	
	public JmxHelperException(String message) {
		super(message);
	}

	public JmxHelperException(Exception e) {
		super(e);
	}

	public JmxHelperException(String message, Exception e) {
		super(message, e);
	}
}
