package gov.va.med.vistalink.rpc;

import gov.va.med.vistalink.adapter.record.VistaLinkFaultException;

/**
 * This exception represents the case where the request RPC context does not exist or the current
 * user does not have access to the B-option representing the context.
 * 
 */
public class NoRpcContextFaultException extends RpcFaultException {

	/**
	 * Constructor for NoRpcContextFaultException.
	 * @see gov.va.med.vistalink.adapter.record.VistaLinkFaultException#VistaLinkFaultException(VistaLinkFaultException)
	 * @param vistaLinkFaultException the exception to copy into a new exception type
	 * @va.exclude
	 */
	public NoRpcContextFaultException(VistaLinkFaultException vistaLinkFaultException) {
		super(vistaLinkFaultException);
	}

}
