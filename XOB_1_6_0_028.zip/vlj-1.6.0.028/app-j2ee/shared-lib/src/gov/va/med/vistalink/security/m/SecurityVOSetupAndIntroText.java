package gov.va.med.vistalink.security.m;

/**
 * Logon-related value object to hold results gathered from a
 * SetupAndGetIntroText call.
 * 
 */
public final class SecurityVOSetupAndIntroText extends SecurityVO {
	private String introductoryText = "";
	private String serverName = "";
	private String volume = "";
	private String uci = "";
	private String device = "";
	private int logonRetryCount = 5;
	private int timeout = 0;
	private int port = 0;

	/**
	 * Constructor.
	 * 
	 * @param resultType
	 *            Success, Failure or Partial Success (types defined in parent
	 *            class)
	 * @param resultMessage
	 *            optional explanatory description for the result, usually used
	 *            for failure and partial success only
	 */
	public SecurityVOSetupAndIntroText(int resultType, String resultMessage) {
		super(resultType, resultMessage);
	}

	/**
	 * No-parameter constructor. Sets the result type to FAILURE, and the result
	 * message string to "".
	 */
	public SecurityVOSetupAndIntroText() {
		super(SecurityVO.RESULT_FAILURE, "");
	}

	/**
	 * Constructor based on the (VistaLink-internal) setup/intro text response
	 * object.
	 * 
	 * @param setupAndIntroResponseObj
	 *            internal VistaLink object representing all setup and intro
	 *            text information returned from an M system
	 */
	public SecurityVOSetupAndIntroText(SecurityDataSetupAndIntroTextResponse setupAndIntroResponseObj) {
		super(setupAndIntroResponseObj.getResultType(), setupAndIntroResponseObj.getResultMessage());
		this.introductoryText = setupAndIntroResponseObj.getSetupAndIntroTextInfo().getIntroductoryText();
		this.serverName = setupAndIntroResponseObj.getSetupAndIntroTextInfo().getServerName();
		this.volume = setupAndIntroResponseObj.getSetupAndIntroTextInfo().getVolume();
		this.uci = setupAndIntroResponseObj.getSetupAndIntroTextInfo().getUci();
		this.device = setupAndIntroResponseObj.getSetupAndIntroTextInfo().getDevice();
		this.logonRetryCount = setupAndIntroResponseObj.getSetupAndIntroTextInfo().getLogonRetryCount();
		this.timeout = setupAndIntroResponseObj.getSetupAndIntroTextInfo().getTimeout();
		this.port = setupAndIntroResponseObj.getSetupAndIntroTextInfo().getPort();
	}

	/**
	 * Sets the raw Introductory Text string returned from M. This is expected
	 * to be many actual display lines concatenated into one string separated by
	 * &lt;BR&gt;'s.
	 * 
	 * @param value
	 *            the introductory text string to set
	 */
	public void setIntroductoryText(String value) {
		this.introductoryText = addLineBreaksToIntroductoryText(value);
	}

	/**
	 * Gets the raw Introductory Text string returned from M. This is typically
	 * many actual display lines concatenated into one string separated by
	 * &lt;BR&gt;'s.
	 * 
	 * @return String the introductory text as a string
	 */
	public String getIntroductoryText() {
		return introductoryText;
	}

	/**
	 * Sets the server name representing the M system active partition, expected
	 * to be as returned from M.
	 * 
	 * @param value
	 *            the server name
	 */
	public void setServerName(String value) {
		serverName = value;
	}

	/**
	 * Gets the server name representing the M system active partition, expected
	 * to be as returned from M.
	 * 
	 * @return String the server name
	 */
	public String getServerName() {
		return serverName;
	}

	/**
	 * Sets the volume name representing the M system active partition, expected
	 * to be as returned from M.
	 * 
	 * @param value
	 *            the M partition's volume
	 */
	public void setVolume(String value) {
		volume = value;
	}

	/**
	 * Gets the volume name representing the M system active partition, expected
	 * to be as returned from M.
	 * 
	 * @return String the M partition's volume
	 */
	public String getVolume() {
		return volume;
	}

	/**
	 * sets the number of logon retries allowed by Kernel, expected to be as
	 * returned from M.
	 * 
	 * @param count
	 *            the # of logon retries
	 */
	public void setLogonRetryCount(int count) {
		logonRetryCount = count;
	}

	/**
	 * returns the number of logon retries allowed by Kernel, expected to be as
	 * returned from M.
	 * 
	 * @return int the # of logon retries
	 */
	public int getLogonRetryCount() {
		return logonRetryCount;
	}

	/**
	 * Sets the UCI name representing the M system active partition, expected to
	 * be as returned from M.
	 * 
	 * @param value
	 *            the M partition UCI name
	 */
	public void setUci(String value) {
		uci = value;
	}

	/**
	 * Gets the UCI name representing the M system active partition, expected to
	 * be as returned from M.
	 * 
	 * @return String the M partition UCI name
	 */
	public String getUci() {
		return uci;
	}

	/**
	 * Sets the Device name representing the M system active partition, expected
	 * to be as returned from M.
	 * 
	 * @param value
	 *            the device name for the M partition
	 */
	public void setDevice(String value) {
		device = value;
	}

	/**
	 * Gets the Device name representing the M system active partition, expected
	 * to be as returned from M.
	 * 
	 * @return String the device name for the M partition
	 */
	public String getDevice() {
		return device;
	}

	/**
	 * Sets the timeout, expected to be as returned from the M server
	 * 
	 * @param value
	 *            timeout in seconds
	 */
	public void setTimeout(int value) {
		timeout = value;
	}

	/**
	 * Gets the timeout from the M system active partition prior to logon,
	 * expected to be as returned from M.
	 * 
	 * @return int
	 */
	public int getTimeout() {
		return timeout;
	}

	/**
	 * Sets the port, expected to be the port to which the connection is being
	 * made
	 * 
	 * @param value
	 *            port of the current connection
	 */
	public void setPort(int value) {
		port = value;
	}

	/**
	 * returns the port value for the server connection
	 * 
	 * @return int port for the server connection
	 */
	public int getPort() {
		return port;
	}

	/**
	 * Returns a crude "toString" representation of the data held in the object.
	 * 
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return "Server: " + serverName + " Volume: " + volume + " UCI: " + uci + " Device: " + device
				+ " Intro Text Length: " + introductoryText.length() + " Timeout: " + timeout;
	}

	private String addLineBreaksToIntroductoryText(String introText) {

		String lineBreakString = "<BR>";
		int lineBreakStringLength = lineBreakString.length();

		StringBuffer sb = new StringBuffer();

		int lineStartPos = 0;
		int posNextBreak = introText.indexOf(lineBreakString, lineStartPos);

		if (posNextBreak < 0) {
			// no <br> tokens in string
			return introText;
		}

		while (posNextBreak > -1) {
			sb.append(introText.substring(lineStartPos, posNextBreak));
			sb.append("\n");
			lineStartPos = posNextBreak + lineBreakStringLength;
			posNextBreak = introText.indexOf(lineBreakString, posNextBreak + 1);
		}

		return sb.toString();
	}
}