package gov.va.med.vistalink.adapter.cci;

import gov.va.med.vistalink.adapter.record.VistaLinkFaultException;
import gov.va.med.vistalink.adapter.record.VistaLinkRequestVO;
import gov.va.med.vistalink.adapter.record.VistaLinkResponseFactory;
import gov.va.med.vistalink.adapter.record.VistaLinkResponseVO;
import gov.va.med.vistalink.adapter.spi.VistaLinkServerInfo;
import gov.va.med.vistalink.rpc.RpcRequest;
import gov.va.med.vistalink.rpc.RpcResponse;
import gov.va.med.exception.FoundationsException;

import javax.resource.cci.Connection;

/**
 * This interface represents an application level connection handle that is used
 * by a component to access an EIS instance.
 * <p>
 * J2SE Example:
 * <p>
 * <code>
 * // login to server<br>
 * loginContext.login(); 
 * <p>
 * //Gets the principal that contains the VistaLinkConnection<br>
 * VistaKernelPrincipalImpl myPrincipal = VistaKernelPrincipalImpl.<br>
 * 			getKernelPrincipal(loginContext.getSubject());
 * <p>
 * //Get the VistaLinkConnection<br>
 * VistaLinkConnection myConnection = myPrincipal.getAuthenticatedConnection();
 * <p>
 *  //request  and response objects <br>
 * RpcRequest vReq = null; <br>
 * RpcResponse vResp = null;
 * <p>
 * //The Rpc Context<br>
 * String rpcContext = &quot;XOBV VISTALINK TESTER&quot;;
 * <p>
 * //The Rpc to call<br>
 * String rpcName = &quot;XOBV TEST PING&quot;;
 * <p>
 *  //Construct the request object<br>
 * vReq = RpcRequestFactory.getRpcRequest(rpcContext, rpcName);
 * <p>
 * //Execute the Rpc and get the response <br>
 * vResp = myConnection.executeRPC(vReq);<br>
 * <p>
 *  //Work with the response ...<br>
 * </code>
 * 
 */
public interface VistaLinkConnection extends Connection {

	/**
	 * Executes an interaction with M.
	 * 
	 * @param requestVO -
	 *            the request being made
	 * @param responseFactory -
	 *            the factory which will construct the response
	 * @return VistaLinkResponseVO the response from M
	 * @throws VistaLinkFaultException -
	 *             thrown if an error occurred on M while processing the request
	 * @throws FoundationsException -
	 *             thrown if an internal adapter exception has occurred
	 * @va.exclude
	 */
	VistaLinkResponseVO executeInteraction(VistaLinkRequestVO requestVO, VistaLinkResponseFactory responseFactory)
			throws VistaLinkFaultException, FoundationsException;

	/**
	 * Executes an interaction with M using the RpcResponseFactory to construct
	 * a response.
	 * 
	 * @param request -
	 *            The request being made
	 * @return RpcResponse the response that is returned
	 * @throws VistaLinkFaultException -
	 *             thrown if an error occurred on M while processing the request
	 * @throws FoundationsException -
	 *             thrown if an internal adapter exception has occurred
	 */
	RpcResponse executeRPC(RpcRequest request) throws VistaLinkFaultException, FoundationsException;

	/**
	 * Returns connection information about the host. The return value
	 * represents M VistA information for the connection, like address and port.
	 * For developer debugging.
	 * 
	 * @return VistaLinkServerInfo the value object that contains connection
	 *         information
	 */
	VistaLinkServerInfo getConnectionInfo();

	/**
	 * Returns current connection time out value
	 * 
	 * @return int time out value in milli-seconds
	 */
	int getTimeOut();

	/**
	 * Enables application to set time out for read operations on connections.
	 * 
	 * @param timeOut
	 *            time out value to set in milli-seconds. This timeout value is
	 *            compared to the default value usually used for the connection.
	 *            The greater of the two values will be used.
	 */
	void setTimeOut(int timeOut);

}