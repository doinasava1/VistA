package gov.va.med.vistalink.security;

import gov.va.med.vistalink.security.m.SecurityVOChangeVc;
import gov.va.med.vistalink.security.m.SecurityVOLogon;
import gov.va.med.vistalink.security.m.SecurityVOSelectDivision;
import gov.va.med.vistalink.security.m.SecurityVOUserDemographics;

import java.util.Map;

/**
 * A service provider interface (SPI) definition for implementing back-end
 * services for Kernel/M-based logins. The class defines all the methods
 * necessary to provide back-end Kernel services for the
 * <code>VistaLoginModule</code>.
 * 
 * @see VistaLoginModule
 */
public interface VistaLoginModuleSPI {

	/**
	 * Perform any initialization needed for this class. Ideally all input
	 * information needed for initialization would be provided via options in
	 * the JAAS configuration.
	 * 
	 * @param jaasOptions
	 *            Map of JAAS options
	 * @throws Exception thrown for initialization errors
	 */
	void initialize(Map jaasOptions, Map jaasSharedState) throws Exception;

	/**
	 * Performs setup, retrieves setup-related information and system
	 * introductory test.
	 * 
	 * @return can return either SecurityVOSetupAndIntroText (normal operation) or
	 *         SecurityDataLogonResponse (if Kernel Auto-Signon is invoked). 
	 * 
	 * @throws Exception
	 *             if error encountered
	 */
	Object getSetupAndIntroTextInfo() throws Exception;

	/**
	 * Performs the credential submission/verification portion of login
	 * 
	 * @param kernelCcowLogonToken
	 *            Kernel CCOW login token (in lieu of access/verify code)
	 * @return @throws
	 *         Exception if an error encountered
	 */
	SecurityVOLogon doKernelLogon(String kernelCcowLogonToken) throws Exception;

	/**
	 * Performs the credential submission/verification portion of login
	 * 
	 * @param accessCode
	 *            access code
	 * @param verifyCode
	 *            verify code
	 * @param requestCvc
	 *            true if user wants to change verify code, false if not
	 * @return @throws
	 *         Exception if an error encountered
	 */
	SecurityVOLogon doKernelLogon(String accessCode, String verifyCode, boolean requestCvc) throws Exception;

	/**
	 * Performs the change verify code portion of login
	 * 
	 * @param oldVerifyCode
	 *            old verify code
	 * @param newVerifyCode
	 *            new verify code
	 * @param newVerifyCodeCheck
	 *            new verify code check
	 * @return @throws
	 *         VistaLoginModuleException if error encountered
	 */
	SecurityVOChangeVc changeVerifyCode(String oldVerifyCode, String newVerifyCode, String newVerifyCodeCheck)
			throws Exception;

	/**
	 * Performs the select division portion of login
	 * 
	 * @param selectedDivisionIen
	 *            IEN of division selected by user
	 * @return @throws
	 *         VistaLoginModuleException if an error encountered
	 */
	SecurityVOSelectDivision selectDivision(String selectedDivisionIen)
			throws Exception;

	/**
	 * retrieves user demographics from the Kernel system
	 * 
	 * @return @throws
	 *         VistaLoginModuleException if an error encountered
	 */
	SecurityVOUserDemographics getUserDemographicsData() throws Exception;

	/**
	 * retrieves the CCOW login passcode from the M system
	 * 
	 * @return @throws
	 *         VistaLoginModuleException if an error encountered
	 */
	String getSecureCcowPasscode() throws Exception;

	/**
	 * retrieves a Kernel login token for a particular user to place in the CCOW
	 * user context
	 * 
	 * @return @throws
	 *         VistaLoginModuleException if an error encountered
	 */
	String getKernelCcowToken() throws Exception;

	/**
	 * Adds any SPI-specific information to the JAAS / Kernel user principal.
	 * 
	 * @param principal
	 *            JAAS principal
	 */
	void addSPISpecificInformationToPrincipal(VistaKernelPrincipalImpl principal) throws Exception;

	/**
	 * Performs a logout, including any actions needed on the Kernel/M system
	 * necessary to log the user out.
	 */
	void logout() throws Exception;
}