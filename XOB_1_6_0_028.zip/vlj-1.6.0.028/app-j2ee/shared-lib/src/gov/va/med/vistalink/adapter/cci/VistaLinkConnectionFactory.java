package gov.va.med.vistalink.adapter.cci;

import gov.va.med.vistalink.adapter.spi.ConnectorInfoVO;
import gov.va.med.vistalink.adapter.spi.EMAdapterEnvironment;
import gov.va.med.vistalink.adapter.spi.VistaLinkConnectionManager;
import gov.va.med.vistalink.adapter.spi.VistaLinkConnectionRequestInfo;
import gov.va.med.vistalink.adapter.spi.VistaLinkManagedConnectionFactory;
import gov.va.med.vistalink.adapter.spi.VistaLinkSystemInfoVO;
import gov.va.med.environment.Environment;
import gov.va.med.environment.ServerType;
import gov.va.med.exception.ExceptionUtils;

import java.io.PrintWriter;
import java.io.Serializable;

import javax.naming.Reference;
import javax.resource.NotSupportedException;
import javax.resource.Referenceable;
import javax.resource.ResourceException;
import javax.resource.cci.Connection;
import javax.resource.cci.ConnectionFactory;
import javax.resource.cci.ConnectionSpec;
import javax.resource.cci.RecordFactory;
import javax.resource.cci.ResourceAdapterMetaData;
import javax.resource.spi.ConnectionManager;
import javax.resource.spi.ConnectionRequestInfo;
import javax.resource.spi.ManagedConnectionFactory;
import javax.resource.spi.ResourceAdapterInternalException;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

/**
 * This implementation class provides an interface for getting connection to an EIS instance. Adapters derived from
 * ConnectionFactory overide/implement getConnection() to provide adapter-specific connections.
 * 
 */
public class VistaLinkConnectionFactory implements ConnectionFactory, Serializable, Referenceable {

	/**
	 * The logger used by this class
	 */
	private static final Logger logger = Logger.getLogger(VistaLinkConnectionFactory.class);

	/**
	 * strategy implementation to do JNDI mismatch checking. thread safety not an issue as this object only updated in
	 * static initializer.
	 */
	private static JndiVerificationStrategy jndiVerificationStrategy = null;

	/**
	 * The managed connection factory used to allocate managed connections. thread safety not an issue as this object
	 * only updated in constructor.
	 */
	private transient ManagedConnectionFactory managedFactory;

	/**
	 * The connection manager used to allocate connection handles. thread safety not an issue as this object only
	 * updated in constructor.
	 */
	private transient ConnectionManager connectionManager;

	/**
	 * The reference.
	 */
	private Reference reference;

	/**
	 * The PrintWriter used for logging to app server
	 */
	private transient PrintWriter printWriter;

	/**
	 * Stores result of per-connection JNDI mismatch checking
	 */
	private boolean passedJndiMismatchCheck = false;

	/**
	 * keeps track of the number of invocations of the J2SE getConnection method in a J2EE environment.
	 */
	private int connectionWrongModeInvocationCount = 0;

	/**
	 * thread safety not an issue as only modified in constructor.
	 */
	private EMAdapterEnvironment adapterEnvironment;

	static {
		logger.debug("in VistaLinkConectionFactory static initializer.");
		/**
		 * Set jndi verifications strategy based on server type
		 */
		if (Environment.getServerType().equals(ServerType.WEBLOGIC)) {
			jndiVerificationStrategy = new JndiVerificationStrategyWeblogic81();
		} else {
			jndiVerificationStrategy = new JndiVerificationStrategyAlwaysPass();
		}
	}

	/**
	 * @param managedFactory the factory that the connection manager will use to construct managed connections
	 * @param connectionManager the connection manager that will allocate new VistaLinkConnections. This value is null
	 *            in an unmanaged environment and defaults to VistaLinkConnectionManager this value is specified by the
	 *            application server in a managed environment
	 * @va.exclude
	 */
	public VistaLinkConnectionFactory(VistaLinkManagedConnectionFactory managedFactory,
			ConnectionManager connectionManager) {
		logger.debug("in VistaLinkConectionFactory constructor.");
		this.managedFactory = managedFactory;
		this.adapterEnvironment = managedFactory.getAdapterEnvironment();
		logger.debug("VistaLinkConnectionFactory constructor called!");

		if (connectionManager == null) {
			this.connectionManager = new VistaLinkConnectionManager();
		} else {
			this.connectionManager = connectionManager;
		}
		reference = null;
		printWriter = null;
	}

	/**
	 * Allocates a VistaLinkConnection Connection Handle using the specified connection manager
	 * 
	 * @return Connection The connection handle that may be used to interact with M.
	 * @throws ResourceException
	 */
	private Connection allocateConnection() throws ResourceException {
		if (managedFactory == null) {
			throw new ResourceAdapterInternalException("managedConnectionFactory is not set for this connectionFactory");
		}
		return (Connection) connectionManager.allocateConnection(managedFactory, null);
	}

	/**
	 * Allocates a VistaLinkConnection Connection Handle using the specified connection manager.
	 * 
	 * @param cri ConnectionRequestInfo object
	 * @return Connection The connection handle that may be used to interact with M.
	 * @throws ResourceException
	 */
	private Connection allocateConnection(ConnectionRequestInfo cri) throws ResourceException {
		if (managedFactory == null) {
			throw new ResourceAdapterInternalException("managedConnectionFactory is not set for this connectionFactory");
		}

		return (Connection) connectionManager.allocateConnection(managedFactory, cri);
	}

	/**
	 * @return PrintWriter
	 * @throws ResourceException
	 * @va.exclude
	 * @deprecated unused method, not part of JCA spec, left to help preserve compatibility with previous versions
	 */
	public synchronized PrintWriter getLogWriter() throws ResourceException {
		return printWriter;
	}

	/**
	 * @param printWriter
	 * @throws ResourceException
	 * @deprecated unused method, not part of JCA spec, left to help preserve compatibility with previous versions
	 * @va.exclude
	 */
	public synchronized void setLogWriter(PrintWriter printWriter) throws ResourceException {
		this.printWriter = printWriter;
	}

	/**
	 * Returns the meta data information associated with this adapter.
	 * 
	 * @see javax.resource.cci.ConnectionFactory#getMetaData()
	 * @va.exclude
	 */
	public ResourceAdapterMetaData getMetaData() throws ResourceException {
		return new VistaLinkResourceAdapterMetaData();
	}

	/**
	 * Referenceable interface.
	 * 
	 * @see javax.naming.Referenceable#getReference()
	 * @va.exclude
	 */
	public synchronized Reference getReference() {
		return reference;
	}

	/**
	 * Referenceable interface.
	 * 
	 * @param reference reference
	 * @see javax.resource.Referenceable#setReference(javax.naming.Reference)
	 * @va.exclude
	 */
	public synchronized void setReference(Reference reference) {
		this.reference = reference;
	}

	/*
	 * (non-Javadoc)
	 * @see javax.resource.cci.ConnectionFactory#getConnection(javax.resource.cci.ConnectionSpec)
	 */
	public Connection getConnection(ConnectionSpec connectionSpec) throws ResourceException {

		try {
			if (adapterEnvironment.equals(EMAdapterEnvironment.J2SE)) {
				throw new VistaLinkResourceException(
						"Use of this method is not allowed in a J2SE environment, please use getConnection() instead");
			}

			// Reject JNDI mismatches (connectorConfig.xml JNDI vs. ra.xml JDNI)
			if (adapterEnvironment.equals(EMAdapterEnvironment.J2EE) && (!isPassedJndiMismatchCheck())) {
				if (!jndiVerificationStrategy.checkJndiMismatch(
						(VistaLinkManagedConnectionFactory) this.managedFactory, this)) {
					String errorMessage = "JNDI Mismatch found for connector configured with JNDI Name: '"
							+ ((this.managedFactory == null) ? "[not defined]"
									: ((VistaLinkManagedConnectionFactory) this.managedFactory).getConnectorJndiName())
							+ "'. Rejecting connection request.";
					logger.error(errorMessage);
					throw new VistaLinkResourceException(errorMessage);
				} else {
					setPassedJndiMismatchCheck(true);
				}
			}
			return allocateConnection(new VistaLinkConnectionRequestInfo(connectionSpec));

		} catch (ResourceException e) {

			if (logger.isEnabledFor(Level.ERROR)) {

				String errMsg = (new StringBuffer()).append("Can not allocate VistaLinkConnection.").append("\n\t")
						.append(ExceptionUtils.getFullStackTrace(e)).toString();

				logger.error(errMsg);
			}

			throw e;
		}
	}

	/**
	 * Gets a VistaLinkConnection connection handle; calls allocateConnection(). This gets connections for J2SE mode.
	 * 
	 * @see javax.resource.cci.ConnectionFactory#getConnection()
	 */
	public Connection getConnection() throws ResourceException {

		if (adapterEnvironment.equals(EMAdapterEnvironment.J2EE)) {

			String errMsg = "Use of this method is not allowed in a J2EE environment, please use getConnection(ConnectionSpec) instead. NOTE: IF this is exception is logged during connector deployment or startup on BEA WebLogic, one instance of this exception per connector module is always thrown. This is normal and can be ignored in those cases.";
			incrementConnectionWrongModeInvocationCount();
			// Note: WebLogic 8.1 called this method once on deployment. WebLogic v9 no longer appears to do this.
			if ((Environment.getServerType().equals(ServerType.WEBLOGIC))
					&& (getConnectionWrongModeInvocationCount() < 2)) {
				logger.debug(errMsg);
			} else {
				logger.error(errMsg);
			}
			throw new VistaLinkResourceException(errMsg);
		}

		try {

			return allocateConnection();

		} catch (ResourceException e) {

			if (logger.isEnabledFor(Level.ERROR)) {

				String errMsg = (new StringBuffer()).append("Can not allocate VistaLinkConnection.").append("\n\t")
						.append(ExceptionUtils.getFullStackTrace(e)).toString();

				logger.error(errMsg);
			}

			throw e;
		}
	}

	/**
	 * Empty method.
	 * 
	 * @throws NotSupportedException
	 * @see javax.resource.cci.ConnectionFactory#getRecordFactory()
	 * @va.exclude
	 */
	public RecordFactory getRecordFactory() throws ResourceException {
		throw new NotSupportedException("getRecordFactory() is not supported at this time.");
	}

	/**
	 * Creates VistaLinkConnectionFactory to be used in non-managed environment (J2SE).
	 * <p>
	 * This method should never be called in managed environment (J2EE) as application server is responsible for
	 * creating ConnectionFactories. J2EE code should use JNDI lookup to get a reference to the ConnectionFactory.
	 *  
	 * @param hostIPAddress - the IP address to connect to
	 * @param hostPort - the port to open
	 * @return VistaLinkConnectionFactory The connection factory that will return Connections for the specified
	 *         IPAddress and port
	 * @va.exclude
	 * @throws ResourceException
	 */
	public static final VistaLinkConnectionFactory getVistaLinkConnectionFactory(String hostIPAddress, Integer hostPort)
			throws ResourceException {
		try {
			VistaLinkManagedConnectionFactory mcf = new VistaLinkManagedConnectionFactory();
			mcf.setNonManagedHostIPAddress(hostIPAddress);
			mcf.setNonManagedHostPort(hostPort.intValue());
			mcf.setAdapterEnvironment(EMAdapterEnvironment.J2SE);

			return (VistaLinkConnectionFactory) mcf.createConnectionFactory();
		} catch (ResourceException e) {
			if (logger.isEnabledFor(Level.ERROR)) {

				String errMsg = (new StringBuffer()).append("Can not create VistaLinkConnectionFactory.")
						.append("\n\t").append(ExceptionUtils.getFullStackTrace(e)).toString();
				logger.error(errMsg);
			}
			throw e;
		}
	}

	/**
	 * @return Returns the passedJndiMismatchCheck.
	 */
	private synchronized boolean isPassedJndiMismatchCheck() {
		return passedJndiMismatchCheck;
	}

	/**
	 * @param passedJndiMismatchCheck The passedJndiMismatchCheck to set.
	 */
	private synchronized void setPassedJndiMismatchCheck(boolean passedJndiMismatchCheck) {
		this.passedJndiMismatchCheck = passedJndiMismatchCheck;
	}

	/**
	 * Populate a ConnectorInfoVO object with information from the stored VistaLinkManagedConnectionFactory instance.
	 * Note: This method is unused and could be removed, except for compatibility concerns with previous version.
	 * 
	 * @param connectorInfoVO object to populate
	 * @param getDetailInfo populate with less detail if false, more detail if true
	 * @va.exclude
	 * @deprecated Unused method; not removing to help preserve compatibility.
	 */
	public void getMCFInfo(ConnectorInfoVO connectorInfoVO, boolean getDetailInfo) {
		if (this.managedFactory != null) {
			VistaLinkManagedConnectionFactory mcf = (VistaLinkManagedConnectionFactory) this.managedFactory;

			connectorInfoVO.setCfgIpAddress(mcf.getHostIpAddressUnresolved());
			connectorInfoVO.setCfgPort(mcf.getHostPort());
			connectorInfoVO.setCfgTimeout(mcf.getDefaultJ2EETimeOut() / 1000L);
			connectorInfoVO.setCfgTimeoutAlwaysUseDefaultAsMin(mcf.isAlwaysUseDefaultAsMin());
			connectorInfoVO.setCfgJndiName(mcf.getConnectorJndiName());

			connectorInfoVO.setHlthConnectionAuthFailureCount(mcf.getConnectionAuthFailureCount());
			connectorInfoVO.setHlthConnectionFailureCount(mcf.getConnectionFailureCount());
			connectorInfoVO.setHlthDivisionMismatchCount(mcf.getDivisionMismatchCount());
			connectorInfoVO.setHlthIdentityFailureCount(mcf.getIdentityFailureCount());
			connectorInfoVO.setHlthProductionMismatchCount(mcf.getProductionMismatchCount());

			if (getDetailInfo) {
				connectorInfoVO.setPerfCreateConnectionHandleAvgMillis(mcf.getCreateConnectionHandleAvgMillis());
				connectorInfoVO.setPerfMatchManagedConnectionAvgMillis(mcf.getMatchManagedConnectionAvgMillis());
				connectorInfoVO.setVljDistinguishedIdentifier(mcf.getDistinguishedIdentifier());
				connectorInfoVO.setMumpsSystemInfo(mcf.getSystemInfo());
			}
		}
	}

	/**
	 * Retrieve configuration file setting for this connection factory.
	 * @return IP address from configuration file.
	 * @va.exclude
	 */
	public String getCfgIpAddress() {
		return ((VistaLinkManagedConnectionFactory) this.managedFactory).getHostIpAddressUnresolved();
	}

	/**
	 * Retrieve configuration file setting for this connection factory.
	 * @return port from configuration file.
	 * @va.exclude
	 */
	public int getCfgPort() {
		return ((VistaLinkManagedConnectionFactory) this.managedFactory).getHostPort();
	}

	/**
	 * Retrieve configuration file setting for this connection factory.
	 * @return default timeout, from configuration file
	 * @va.exclude
	 */
	public long getCfgTimeout() {
		return ((VistaLinkManagedConnectionFactory) this.managedFactory).getDefaultJ2EETimeOut();
	}

	/**
	 * Retrieve configuration file setting for this connection factory.
	 * @return setting for whether to use default timeout as minimum timeout, from configuration file
	 * @va.exclude
	 */
	public boolean isCfgTimeoutAlwaysUseDefaultAsMin() {
		return ((VistaLinkManagedConnectionFactory) this.managedFactory).isAlwaysUseDefaultAsMin();
	}

	/**
	 * Retrieve information for this connection factory.
	 * @return distinguished (internal) identifier associated with this connection factory
	 * @va.exclude
	 */
	public long getDistinguishedIdentifier() {
		return ((VistaLinkManagedConnectionFactory) this.managedFactory).getDistinguishedIdentifier();
	}

	/**
	 * Retrieve health counter for this connection factory.
	 * @return health counter for authentication failures
	 * @va.exclude
	 */
	public long getHlthConnectionAuthFailureCount() {
		return ((VistaLinkManagedConnectionFactory) this.managedFactory).getConnectionAuthFailureCount();
	}

	/**
	 * Retrieve health counter for this connection factory.
	 * @return health counter for connection failures
	 * @va.exclude
	 */
	public long getHlthConnectionFailureCount() {
		return ((VistaLinkManagedConnectionFactory) this.managedFactory).getConnectionFailureCount();
	}

	/**
	 * Retrieve health counter for this connection factory.
	 * @return health counter for division mismatches
	 * @va.exclude
	 */
	public long getHlthDivisionMismatchCount() {
		return ((VistaLinkManagedConnectionFactory) this.managedFactory).getDivisionMismatchCount();
	}

	/**
	 * Retrieve health counter for this connection factory.
	 * @return health counter for "reauthentication" second-level light authentication failures
	 * @va.exclude
	 */
	public long getHlthIdentityFailureCount() {
		return ((VistaLinkManagedConnectionFactory) this.managedFactory).getIdentityFailureCount();
	}

	/**
	 * Retrieve health counter for this connection factory.
	 * @return health counter for production-test mismatches
	 * @va.exclude
	 */
	public long getHlthProductionMismatchCount() {
		return ((VistaLinkManagedConnectionFactory) this.managedFactory).getProductionMismatchCount();
	}

	/**
	 * Retrieve performance tracker for this connection factory.
	 * @return performance tracker for "create connection handle" average in milliseconds
	 * @va.exclude
	 */
	public double getPerfCreateConnectionHandleAvgMillis() {
		return ((VistaLinkManagedConnectionFactory) this.managedFactory).getCreateConnectionHandleAvgMillis();
	}

	/**
	 * Retrieve performance tracker for this connection factory.
	 * @return performance tracker for "match managed connection" function in milliseconds
	 * @va.exclude
	 */
	public double getPerfMatchManagedConnectionAvgMillis() {
		return ((VistaLinkManagedConnectionFactory) this.managedFactory).getMatchManagedConnectionAvgMillis();
	}

	/**
	 * query the M system reached by this connector for general system information.
	 * 
	 * @return M System Info object.
	 * @va.exclude
	 */
	public VistaLinkSystemInfoVO queryMSystem() {
		return ((VistaLinkManagedConnectionFactory) this.managedFactory).getSystemInfo();
	}

	/**
	 * Retrieve configuration file setting for this connection factory.
	 * 
	 * @return JNDI name retrieved from VistALink configuration file and associated with this connection factory
	 * @va.exclude
	 */
	public String getConnectorJndiName() {
		return ((VistaLinkManagedConnectionFactory) this.managedFactory).getConnectorJndiName();
	}

	private synchronized void incrementConnectionWrongModeInvocationCount() {
		connectionWrongModeInvocationCount++;
	}

	private synchronized int getConnectionWrongModeInvocationCount() {
		return connectionWrongModeInvocationCount;
	}

}