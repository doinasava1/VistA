package gov.va.med.vistalink.console;

import gov.va.med.vistalink.jmx.IJmxHelper;
import gov.va.med.vistalink.jmx.JmxHelperException;
import gov.va.med.vistalink.jmx.JmxHelperFactory;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Hashtable;
import java.util.Set;

import javax.management.AttributeNotFoundException;
import javax.management.InstanceNotFoundException;
import javax.management.MBeanException;
import javax.management.MBeanServer;
import javax.management.MBeanServerConnection;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.management.ReflectionException;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;

import org.apache.log4j.Logger;

import weblogic.management.NoAccessRuntimeException;

/**
 * WebLogic-specific implementation of IServerHelper.
 * 
 * Encapsulates app-server-specific mechanism for specifying server/JVM locations in domain-wide ObjectNames. Useful for
 * app servers that support domain-wide MBean queries -- allows filtering of query based on server location, allowing
 * queries to be targeted to a specific server location.
 * 
 * This class is thread safe.
 * 
 */
public final class ServerHelperWebLogic extends ServerHelperAbstract implements Comparable, IServerHelper {

	private static final Logger logger = Logger.getLogger(ServerHelperWebLogic.class);

	private static final String OBJECT_NAME_STRING_TYPE = "Type";
	private static final String OBJECT_NAME_STRING_NAME = "Name";
	private static final String JMX_REMOTE_PROTOCOL = "t3"; // t3, t3s, http, https, iiop, iiops are legal values
	private static final String JMX_JNDI_ROOT = "/jndi/";
	private static final String JMX_DOMAIN_RUNTIME_MBEANSERVER = "weblogic.management.mbeanservers.domainruntime";
	private static final String DOMAIN_RUNTIME_SERVICE_MBEAN_ONAME = "com.bea:Name=DomainRuntimeService,Type=weblogic.management.mbeanservers.domainruntime.DomainRuntimeServiceMBean";
	private static final String JMX_PROTOCOL_PREFIX = "service:jmx:";
	private static final String JMX_CONNECTOR_PACKAGE = "weblogic.management.remote";

	// text literals
	private static final String TXT_EXPECT_1_RESULT = "Expected 1 result for local server query, got: ";
	private static final String TXT_NO_RETR_LOC_SRV = "Could not retrieve local server name: ";
	private static final String TXT_NO_RETR_JMX_URL = "Could not retrieve JMX URL for server ";

	// instance variables, used must be synchronized for thread safety
	private String serverName = null;
	private String locationDisplayName = "";
	private boolean isLocalServer = false;
	private boolean isLocalServerChecked = false;
	private String jmxUrl = null; // URL for JMX connections
	private boolean isJmxUrlServerRuntimeValidated = false; // is config-based JMX URL value validated by server runtime

	// value

	/**
	 * no-arg constructor used for local server helper only.
	 * 
	 */
	protected ServerHelperWebLogic() {
		super();
		init(true);
		logger.debug("Constructed WebLogic Server Helper: " + toString());
	}

	/**
	 * arg constructor may or may not be for local server
	 */
	protected ServerHelperWebLogic(String objectNameFragment) {
		super(objectNameFragment);
		init(false);
		logger.debug("Constructed WebLogic Server Helper: " + toString());
	}

	/**
	 * called from constructors only, don't need to synchronize var access for thread safety
	 * 
	 * @param localServerNoArgConstructor
	 */
	private void init(boolean localServerNoArgConstructor) {
		// 1. initialize serverName
		if (localServerNoArgConstructor) {
			isLocalServer = true;
			isLocalServerChecked = true;
			try {
				serverName = getLocalServerName();
			} catch (ServerHelperException e) {
				// swallow, logged below
			}
		} else if (super.keyPropertiesContainKey(OBJECT_NAME_STRING_NAME)) {
			serverName = super.keyPropertiesGetValue(OBJECT_NAME_STRING_NAME);
		} else {
			logger.error("Could not construct IServerHelper for WebLogic, missing '" + OBJECT_NAME_STRING_NAME
					+ "' key.");
		}
		// 2. initialize locationDisplayName
		if (serverName != null) {
			// nothing else besides name needed in WebLogic to uniquely identify a server within the management unit of
			// a domain
			locationDisplayName = serverName;
		}
	}

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.console.IServerHelper#getServerHelperConstructorProperties()
	 */
	public String getServerHelperConstructorProperties() {
		return OBJECT_NAME_STRING_NAME + "=" + getServerName();
	}

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.jmx.IServerHelper#getLocationDisplayName()
	 */
	synchronized public String getDisplayNameFullyLocationQualified() {
		// synchronized accessor for this instance variable
		return locationDisplayName;
	}

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.jmx.IJmxHelper#getJmxConnector(gov.va.med.vistalink.console.IServerHelper)
	 */
	public JMXConnector getJmxConnector() throws ServerHelperNotRunningException, ServerHelperException, IOException {

		logger.debug("Getting JMX Connector for server: " + getServerName());

		JMXConnector returnVal = null;
		try {
			String baseURL = getJmxRemoteUrlBase();
			if (baseURL == null) {
				throw new IOException("Could not determine host address for server '" + getServerName() + "'");
			}
			// set up to contact runtime MBean server on target server
			// JMX service URL includes weblogic-specific JNDI name
			JMXServiceURL serviceURL = new JMXServiceURL(JMX_PROTOCOL_PREFIX + baseURL
					+ "/jndi/weblogic.management.mbeanservers.runtime");
			Hashtable h = new Hashtable();
			// weblogic-specific provider packages
			h.put(JMXConnectorFactory.PROTOCOL_PROVIDER_PACKAGES, JMX_CONNECTOR_PACKAGE);
			returnVal = JMXConnectorFactory.connect(serviceURL, h);
		} catch (MalformedURLException e) {
			logger.error("Could not retrieve JMX Connector: ", e);
			throw new ServerHelperException("Could not retrieve JMX Connector: " + e.getMessage(), e);
		}
		return returnVal;
	}

	/**
	 * 
	 * @return Base url to use to establish a JSR-160 JMX remoting connection to this server (protocol + host + port),
	 *         not terminated with &quot;/&quot;.
	 */
	private String getJmxRemoteUrlBase() throws ServerHelperNotRunningException, ServerHelperException {

		if ((getJmxUrl() == null) || (!isJmxUrlServerRuntimeValidated())) {
			// initialize JMX URL instance variables
			try {
				IJmxHelper jmxHelper = JmxHelperFactory.getJmxHelper();
				MBeanServer localMBeanServer = jmxHelper.getLocalMBeanServer();
				String jmxDomainForPlatform = jmxHelper.getJmxDomainForPlatform();

				// if hasn't been validated by ServerRuntime, re-check every time until it has: gives more accurate
				// host/listen address value (config MBean value can be overridden by launch scripts)
				try {
					if (!isJmxUrlServerRuntimeValidated()) {
						initUrlFromServerRuntimeMBean(localMBeanServer, jmxDomainForPlatform);
					}
					// if ServerRuntime retrieval failed, get from config MBean
					if (!isJmxUrlServerRuntimeValidated()) {
						initUrlFromConfigMBean(localMBeanServer, jmxDomainForPlatform);
					}
				} catch (NoAccessRuntimeException e1) {
					// if don't have rights to make JMX remote call, try to get from config MBean that doesn't require
					// JMX
					// remoting (special second try for MONITOR users)
					logger.warn("No access rights to make JMX call: " + e1.getMessage());
					initUrlFromConfigMBean(localMBeanServer, jmxDomainForPlatform);
				}
			} catch (JmxHelperException e) {
				logger.error(TXT_NO_RETR_JMX_URL + getServerName() + ": ", e);
				throw new ServerHelperException(TXT_NO_RETR_JMX_URL + getServerName() + ": ", e);
			}
		}
		// note: if return val is null, check is in caller and exception is thrown there
		return getJmxUrl();
	}

	/**
	 * Get the most accurate JMX url, based on runtime server MBean (runtime values could be changed vs. the
	 * configuration settings). Also, doesn't depend on ListenAddress being explicitly set in configuration.
	 * 
	 * @param localMBeanServer
	 * @param jmxDomainForPlatform
	 * @throws ServerHelperNotRunningException, ServerHelperException
	 */
	private void initUrlFromServerRuntimeMBean(MBeanServer localMBeanServer, String jmxDomainForPlatform)
			throws ServerHelperNotRunningException, ServerHelperException {

		String adminServerHost = null;
		Integer adminServerListenPort = null;

		try {

			// 1. get AdminServerHost, AdminServerListenPort from local ServerRuntime MBean
			ObjectName oNamePartial = new ObjectName(jmxDomainForPlatform + ":" + OBJECT_NAME_STRING_TYPE
					+ "=ServerRuntime,*");
			Set queryResults = localMBeanServer.queryNames(oNamePartial, null);
			if (queryResults.size() != 1) {
				logger.error(TXT_EXPECT_1_RESULT + queryResults.size());
			} else {
				ObjectName serverObjectName = (ObjectName) queryResults.iterator().next();
				adminServerHost = (String) localMBeanServer.getAttribute(serverObjectName, "AdminServerHost");
				adminServerListenPort = (Integer) localMBeanServer.getAttribute(serverObjectName,
						"AdminServerListenPort");
			}

			// 2. connect remotely to DomainRuntimeMBeanServer on Admin server
			JMXServiceURL serviceURL = new JMXServiceURL(JMX_REMOTE_PROTOCOL, adminServerHost, adminServerListenPort
					.intValue(), JMX_JNDI_ROOT + JMX_DOMAIN_RUNTIME_MBEANSERVER);
			logger.debug("about to make JMX Remote call on URL: " + serviceURL);
			Hashtable h = new Hashtable();
			h.put(JMXConnectorFactory.PROTOCOL_PROVIDER_PACKAGES, JMX_CONNECTOR_PACKAGE);
			JMXConnector adminConnector = JMXConnectorFactory.connect(serviceURL, h);
			MBeanServerConnection adminConnection = adminConnector.getMBeanServerConnection();

			// 3. query ServerRuntime for this server via the DomainRuntimeServiceMBean
			ObjectName drsOName = new ObjectName(DOMAIN_RUNTIME_SERVICE_MBEAN_ONAME);
			logger.debug("checking URL for server: " + getServerName());
			ObjectName serverRuntimeMBean = (ObjectName) adminConnection.invoke(drsOName, "lookupServerRuntime",
					new Object[] { getServerName() }, new String[] { "java.lang.String" });
			if (serverRuntimeMBean != null) {
				String UrlString = (String) adminConnection.invoke(serverRuntimeMBean, "getURL",
						new Object[] { JMX_REMOTE_PROTOCOL }, new String[] { "java.lang.String" });

				// update instance variables
				setJmxUrl(UrlString);
				setJmxUrlServerRuntimeValidated(true);

				logger.debug("set ServerHelper [" + getServerName() + "]'s JMX URL from ServerRuntime MBean, to: "
						+ UrlString);
			} else {
				logger.debug("ServerRuntime MBean was null, but no InstanceNotFoundException was thrown.");
				throw new ServerHelperNotRunningException("Does not appear that server " + getServerName()
						+ " is running.");
			}

		} catch (MalformedObjectNameException e) {
			logger.error(TXT_NO_RETR_JMX_URL + this.getServerName() + ": ", e);
		} catch (NullPointerException e) {
			logger.error(TXT_NO_RETR_JMX_URL + this.getServerName() + ": ", e);
		} catch (InstanceNotFoundException e) {
			// DEBUG not ERROR: not an error if can't get runtime MBean -- so far has always meant server's not running.
			logger.debug(TXT_NO_RETR_JMX_URL + this.getServerName() + ": ", e);
			throw new ServerHelperNotRunningException("Does not appear that server " + getServerName()
					+ " is running: ", e);
		} catch (AttributeNotFoundException e) {
			logger.error(TXT_NO_RETR_JMX_URL + this.getServerName() + ": ", e);
		} catch (MBeanException e) {
			logger.error(TXT_NO_RETR_JMX_URL + this.getServerName() + ": ", e);
		} catch (ReflectionException e) {
			logger.error(TXT_NO_RETR_JMX_URL + this.getServerName() + ": ", e);
		} catch (IOException e) {
			logger.error(TXT_NO_RETR_JMX_URL + this.getServerName() + ": ", e);
		}
	}

	/**
	 * get listen address, port for a given server from Config MBean (depends on whether those have been explicitly set
	 * in the configuration or not.)
	 * 
	 * @param localMBeanServer
	 * @param jmxDomainForPlatform
	 */
	private void initUrlFromConfigMBean(MBeanServer localMBeanServer, String jmxDomainForPlatform)
			throws ServerHelperException {
		try {
			StringBuffer sb = new StringBuffer(jmxDomainForPlatform).append(":");
			sb.append(OBJECT_NAME_STRING_TYPE).append("=Server,");
			sb.append(OBJECT_NAME_STRING_NAME).append("=").append(getServerName());
			sb.append(",*");
			ObjectName serverQuery = new ObjectName(sb.toString());
			Set queryResults = localMBeanServer.queryNames(serverQuery, null);
			if (queryResults.size() != 1) {
				logger.error(TXT_EXPECT_1_RESULT + queryResults.size());
				throw new ServerHelperException("Could not get local server information.");
			} else {
				ObjectName serverObjectName = (ObjectName) queryResults.iterator().next();
				Integer jmxPort = ((Integer) localMBeanServer.getAttribute(serverObjectName, "ListenPort"));
				String jmxHostname = (String) localMBeanServer.getAttribute(serverObjectName, "ListenAddress");
				if ((jmxHostname != null) && (jmxHostname.trim().length() > 0)) {
					String urlVal = JMX_REMOTE_PROTOCOL + "://" + jmxHostname + ":" + jmxPort.toString();
					setJmxUrl(urlVal);
					logger.debug("set ServerHelper [" + getServerName() + "]'s JMX URL from Server Config MBean, to: "
							+ urlVal);
				} else {
					logger.warn("ListenAddress and/or ListenPort not configured for server '" + getServerName() + "'");
					throw new ServerHelperException("ListenAddress and/or ListenPort not configured for server '"
							+ getServerName() + "'");
				}
			}
		} catch (MalformedObjectNameException e) {
			logger.error(TXT_NO_RETR_JMX_URL + getServerName() + ": ", e);
		} catch (AttributeNotFoundException e) {
			logger.error(TXT_NO_RETR_JMX_URL + getServerName() + ": ", e);
		} catch (InstanceNotFoundException e) {
			logger.error(TXT_NO_RETR_JMX_URL + getServerName() + ": ", e);
		} catch (NullPointerException e) {
			logger.error(TXT_NO_RETR_JMX_URL + getServerName() + ": ", e);
		} catch (MBeanException e) {
			logger.error(TXT_NO_RETR_JMX_URL + getServerName() + ": ", e);
		} catch (ReflectionException e) {
			logger.error(TXT_NO_RETR_JMX_URL + getServerName() + ": ", e);
		}
	}

	/**
	 * Gets the local server name. For example, no-arg constructor for the "local server" instantiation uses this method
	 * to get name.
	 * 
	 * @return
	 * @throws ServerHelperException
	 */
	private String getLocalServerName() throws ServerHelperException {
		String returnVal = null;
		try {
			IJmxHelper jmxHelper = JmxHelperFactory.getJmxHelper();
			MBeanServer localMBeanServer = jmxHelper.getLocalMBeanServer();
			ObjectName oNamePartial = new ObjectName(jmxHelper.getJmxDomainForPlatform() + ":"
					+ OBJECT_NAME_STRING_TYPE + "=ServerRuntime,*");
			Set queryResults = localMBeanServer.queryNames(oNamePartial, null);
			if (queryResults.size() != 1) {
				logger.error(TXT_EXPECT_1_RESULT + queryResults.size());
				throw new Exception("Could not get local server information.");
			} else {
				ObjectName serverObjectName = (ObjectName) queryResults.iterator().next();
				returnVal = serverObjectName.getKeyProperty(OBJECT_NAME_STRING_NAME);
			}
		} catch (MalformedObjectNameException e) {
			logger.error(TXT_NO_RETR_LOC_SRV, e);
			throw new ServerHelperException(TXT_NO_RETR_LOC_SRV, e);
		} catch (NullPointerException e) {
			logger.error(TXT_NO_RETR_LOC_SRV, e);
			throw new ServerHelperException(TXT_NO_RETR_LOC_SRV, e);
		} catch (JmxHelperException e) {
			logger.error(TXT_NO_RETR_LOC_SRV, e);
			throw new ServerHelperException(TXT_NO_RETR_LOC_SRV, e);
		} catch (Exception e) {
			logger.error(TXT_NO_RETR_LOC_SRV, e);
			throw new ServerHelperException(TXT_NO_RETR_LOC_SRV, e);
		}
		return returnVal;
	}

	/**
	 * Special WebLogic-only function, not in interface. Saves some steps by checking if it's the admin server only if
	 * it already knows it's the local server (function is targeted for use *on* the admin server by admin consoles).
	 * 
	 * WebLogic-specific clients can cast ServerHelper to ServerHelperWebLogic to access the function.
	 * 
	 * @return true if the Server Object both a) represents both an admin server, and b) is the instantiated on the
	 *         server it represents.
	 * @throws ServerHelperException
	 */
	public boolean isLocalAndAdminServer() throws ServerHelperException {

		Boolean returnVal = Boolean.FALSE;

		// first check if this object represents local server
		if (!isLocalServerChecked()) {
			String localServerName = getLocalServerName();
			boolean isLocal = getServerName().equalsIgnoreCase(localServerName);
			setLocalServerChecked(true);
			setLocalServer(isLocal);
			logger.debug("isLocalServer results for server [" + getServerName() + "]: " + isLocal);
		}

		// now check if also admin server
		if (isLocalServer()) {
			try {
				IJmxHelper jmxHelper = JmxHelperFactory.getJmxHelper();
				MBeanServer localMBeanServer = jmxHelper.getLocalMBeanServer();
				ObjectName oNamePartial = new ObjectName(jmxHelper.getJmxDomainForPlatform() + ":"
						+ OBJECT_NAME_STRING_TYPE + "=ServerRuntime,*");
				Set queryResults = localMBeanServer.queryNames(oNamePartial, null);
				if (queryResults.size() != 1) {
					logger.error(TXT_EXPECT_1_RESULT + queryResults.size());
					throw new Exception("Could not get local server information.");
				} else {
					ObjectName serverObjectName = (ObjectName) queryResults.iterator().next();
					returnVal = (Boolean) localMBeanServer.getAttribute(serverObjectName, "AdminServer");
					// note: could cache "admin" value for future references, as with "local" value, if ever heavily
					// used.
				}
			} catch (MalformedObjectNameException e) {
				logger.error("Could not determine if server is local/current server.", e);
				throw new ServerHelperException("Could not determine if server is local/current server.", e);
			} catch (NullPointerException e) {
				logger.error("Could not determine if server is local/current server.", e);
				throw new ServerHelperException("Could not determine if server is local/current server.", e);
			} catch (JmxHelperException e) {
				logger.error("Could not determine if server is local/current server.", e);
				throw new ServerHelperException("Could not determine if server is local/current server.", e);
			} catch (Exception e) {
				logger.error("Could not determine if server is local/current server.", e);
				throw new ServerHelperException("Could not determine if server is local/current server.", e);
			}
		}
		return returnVal.booleanValue();
	}

	/**
	 * synchronized accessor for this instance variable
	 * @return
	 */
	private synchronized boolean isLocalServer() {
		return isLocalServer;
	}

	/**
	 * synchronized accessor for this instance variable
	 * @param isLocalServer
	 */
	private synchronized void setLocalServer(boolean isLocalServer) {
		this.isLocalServer = isLocalServer;
	}

	/**
	 * synchronized accessor for this instance variable
	 * @return
	 */
	private synchronized String getServerName() {
		return serverName;
	}

	/**
	 * synchronized accessor for this instance variable
	 * @return
	 */
	private synchronized boolean isLocalServerChecked() {
		return isLocalServerChecked;
	}

	/**
	 * synchronized accessor for this instance variable
	 * @param val
	 */
	private synchronized void setLocalServerChecked(boolean val) {
		isLocalServerChecked = val;
	}

	/**
	 * synchronized accessor for this instance variable
	 * @return
	 */
	private synchronized String getJmxUrl() {
		return jmxUrl;
	}

	/**
	 * synchronized accessor for this instance variable
	 * @param val
	 */
	private synchronized void setJmxUrl(String val) {
		jmxUrl = val;
	}

	/**
	 * synchronized accessor for this instance variable
	 * @return
	 */
	private synchronized boolean isJmxUrlServerRuntimeValidated() {
		return isJmxUrlServerRuntimeValidated;
	}

	/**
	 * synchronized accessor for this instance variable
	 * @param val
	 */
	private synchronized void setJmxUrlServerRuntimeValidated(boolean val) {
		isJmxUrlServerRuntimeValidated = val;
	}

}
