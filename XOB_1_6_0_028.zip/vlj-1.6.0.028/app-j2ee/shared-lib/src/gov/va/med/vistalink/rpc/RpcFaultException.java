package gov.va.med.vistalink.rpc;

import gov.va.med.vistalink.adapter.record.VistaLinkFaultException;

/**
 * This fault exception class is used for all rpc-related errors returned from the M system.
 * 
 */
public class RpcFaultException extends VistaLinkFaultException {

	/**
	 * Constructor for NoRpcContextFaultException. 
	 * @see gov.va.med.vistalink.adapter.record.VistaLinkFaultException#VistaLinkFaultException(VistaLinkFaultException)
	 * @param vistaLinkFaultException the exception to copy into a new exception type
	 * @va.exclude
	 */
	public RpcFaultException(VistaLinkFaultException vistaLinkFaultException) {
		super(vistaLinkFaultException);
	}
}
