package gov.va.med.vistalink.security.m;

import gov.va.med.vistalink.adapter.record.VistaLinkFaultException;

/**
 * Represents an authentication failure during a re-authentication attempt, in
 * which an invalid division has been passed for the user on whose behalf
 * re-authentication is being attempted. The user does not have access to the
 * requested division.
 * 
 */
public class SecurityDivisionDeterminationFaultException extends SecurityFaultException {

	/**
	 * @param vistaLinkFaultException Fault Exception
	 * @va.exclude
	 */
	public SecurityDivisionDeterminationFaultException(VistaLinkFaultException vistaLinkFaultException) {
		super(vistaLinkFaultException);
	}

}