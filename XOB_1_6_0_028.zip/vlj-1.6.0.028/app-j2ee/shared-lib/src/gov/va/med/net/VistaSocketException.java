package gov.va.med.net;

import gov.va.med.exception.FoundationsException;

/**
 * Represents an exception thrown during read/write operations on a socket
 * 
 */
public class VistaSocketException extends FoundationsException {
	/**
	 * Constructor for VistaSocketException.
	 * @va.exclude
	 */
	public VistaSocketException() {
		super();
	}

	/**
	 * Constructor for VistaSocketException.
	 * @param msg Message
	 * @va.exclude
	 */
	public VistaSocketException(String msg) {
		super(msg);
	}

	/**
	 * Constructor for VistaSocketException.
	 * @param nestedException Exception
	 * @va.exclude
	 */
	public VistaSocketException(Exception nestedException) {
		super(nestedException);
	}

	/**
	 * Constructor for VistaSocketException.
	 * @param msg Message
	 * @param nestedException Exception
	 * @va.exclude
	 */
	public VistaSocketException(String msg, Exception nestedException) {
		super(msg, nestedException);
	}

}