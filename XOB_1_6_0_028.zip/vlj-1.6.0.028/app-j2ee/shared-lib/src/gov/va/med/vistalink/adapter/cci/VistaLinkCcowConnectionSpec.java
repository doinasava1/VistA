package gov.va.med.vistalink.adapter.cci;

import gov.va.med.crypto.VistaKernelHash;
import gov.va.med.crypto.VistaKernelHashCountLimitExceededException;

import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.w3c.dom.CDATASection;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

/**
 * This is the connection spec class for CCOW-token-based re-authentication (e.g., FatKAAT and KAAJEE).
 * 
 */
public class VistaLinkCcowConnectionSpec extends VistaLinkConnectionSpecImpl {

	/**
	 * Value used to identify type as CCOW connection spec
	 */
	private static final String TYPE_CCOW = "ccow";

	/**
	 * Element name given to CCOW type
	 */
	private static final String ELEMENT_CCOW = "KernelCcowToken";

	/**
	 * The Kernel CCOW Token
	 */
	private String kernelCcowToken;

	/**
	 * The logger used by this class
	 */
	private static final Logger logger = Logger.getLogger(VistaLinkCcowConnectionSpec.class);

	/**
	 * Pass identifying information for an end user.
	 * 
	 * @param encryptedKernelCcowToken
	 *            Kernel CCOW Token for this user, already encrypted with VistaKernelHash.encrypt.
	 */
	public VistaLinkCcowConnectionSpec(String encryptedKernelCcowToken) {
		super(""); // division not needed w/CCOW token, it's stored on M back-end already
		this.kernelCcowToken = "";
		try {
			this.kernelCcowToken = VistaKernelHash.encrypt(encryptedKernelCcowToken, true);
		} catch (VistaKernelHashCountLimitExceededException e) {
			logger.error("Could not encrypt CCOW token", e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.va.med.vistalink.adapter.cci.VistaLinkConnectionSpec#getProprietaryString()
	 */
	public ArrayList getProprietarySecurityInfo() {
		ArrayList values = new ArrayList();
		values.add(this.kernelCcowToken);
		return values;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.va.med.vistalink.adapter.cci.VistaLinkConnectionSpec#setAuthenticationNodes()
	 */
	public void setAuthenticationNodes(Document requestDoc, Node securityNode) {

		if (logger.isDebugEnabled()) {
			logger.debug("setAuthenticationNodes -> Re Auth type is 'ccow'");
		}

		setSecurityDivisionAttr(securityNode);
		setSecurityTypeAttr(securityNode);

		Element elemCCOW = requestDoc.createElement(ELEMENT_CCOW);

		/* add CDATA section for encoded Kernel CCOW Token */
		CDATASection cdata = requestDoc.createCDATASection(this.kernelCcowToken);
		Node currentCcowCdataNode = elemCCOW.getFirstChild();
		if (currentCcowCdataNode != null) {
			elemCCOW.removeChild(currentCcowCdataNode);
		}
		elemCCOW.appendChild(cdata);

		securityNode.appendChild(elemCCOW);

	}

	/**
	 * Compares two objects to see if they are equal
	 * 
	 * @param obj
	 *            the object to compare
	 * @see gov.va.med.vistalink.adapter.cci.VistaLinkConnectionSpec#isConnSpecEqual(java.lang.Object)
	 * @va.exclude
	 * @deprecated Use equals() method.
	 */
	public boolean isConnSpecEqual(Object obj) {
		return equals(obj);
	}

	public boolean equals(Object obj) {
		
		if (obj instanceof VistaLinkCcowConnectionSpec) {
			VistaLinkCcowConnectionSpec connSpec = (VistaLinkCcowConnectionSpec) obj;
			if ((connSpec.getDivision().equals(this.getDivision()))
					&& (connSpec.getKernelCcowToken().equals(this.getKernelCcowToken()))) {
				return true;
			}
		}
		return false;
	}

	public int hashCode() {
		// algorithm taken from "Effective Java" item #8.
		int HASHCODE_SEED = 17;
		int returnVal = HASHCODE_SEED;

		// division contribution to hashcode
		int divisionHashCode = this.getDivision().hashCode();
		returnVal = 37 * returnVal + divisionHashCode; 
		// Kernel Token contribution to hashcode
		int kernelTokenHashCode = this.getKernelCcowToken().hashCode();
		returnVal = 37 * returnVal + kernelTokenHashCode; 
		return returnVal;
	}	
	
	/**
	 * @return Kernel CCOW Token
	 * @va.exclude
	 */
	public String getKernelCcowToken() {
		return kernelCcowToken;
	}

	/**
	 * @param kernelCcowToken The kernelCcowToken to set.
	 */
	protected void setKernelCcowToken(String kernelCcowToken) {
		this.kernelCcowToken = kernelCcowToken;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.va.med.vistalink.adapter.cci.VistaLinkConnectionSpec#getSecurityType()
	 */
	public String getSecurityType() {
		return TYPE_CCOW;
	}
}