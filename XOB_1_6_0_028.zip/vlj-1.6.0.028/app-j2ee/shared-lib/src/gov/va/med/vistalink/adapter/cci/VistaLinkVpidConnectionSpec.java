package gov.va.med.vistalink.adapter.cci;

import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

/**
 * This is the connection spec class for VPID re-authentication.
 * 
 */
public class VistaLinkVpidConnectionSpec extends VistaLinkConnectionSpecImpl {

	/**
	 * Value used to identify type as VPID
	 */
	private static final String TYPE_VPID = "vpid";

	/**
	 * Element name given to VPID type
	 */
	private static final String ELEMENT_VPID = "Vpid";

	/**
	 * Name given to attribute representing VPID value
	 */
	private static final String ATTRIBUTE_VALUE = "value";

	/**
	 * The VPID value
	 */
	private String vpid;

	/**
	 * The logger used by this class
	 */
	private static final Logger logger = Logger.getLogger(VistaLinkVpidConnectionSpec.class);

	/**
	 * @va.exclude
	 */
	public VistaLinkVpidConnectionSpec() {
		super();
	}

	/**
	 * @param vpid
	 *            the VPID identifier for the end-user.
	 * @param division
	 *            The station number (e.g., "523", "523BZ", etc.) requested as
	 *            the division under which logon/actions should be conducted for
	 *            this user on the target Kernel/M system.
	 *            <p>
	 *            The division parameter for connection specs is mandatory. This
	 *            ensures that division requested for a connection on behalf of
	 *            an end-user matches the division actually accessed on the M
	 *            side of the connection.
	 *            <p>
	 *            The value to pass for the division parameter is the division
	 *            station number, e.g., "523", "523BZ", etc. This is the value
	 *            found in field 99 ('Station Number') of the corresponding
	 *            entry in the Institution File on the M system.
	 *            <p>
	 *            On the M side, if a user doesn't have one or more "divisions"
	 *            specified in the DIVISION (#200.02) multiple of their New
	 *            Person file entry, the division passed in with the connection
	 *            spec must be the station number of the division set into the
	 *            DEFAULT INSTITUTION (#217) field of the KERNEL SYSTEM
	 *            PARAMETERS (#8989.3) file entry for the site. This value is
	 *            set by Kernel into DUZ(2).
	 *            <p>
	 *            On the M side, if a user has one or more "divisions" specified
	 *            in the DIVISION (#200.02) multiple of their New Person file
	 *            entry, the division passed in with the connection spec must be
	 *            the station number for one of those divisions present in that
	 *            multiple. This value will be set by Kernel into DUZ(2).
	 */
	public VistaLinkVpidConnectionSpec(String division, String vpid) {
		super(division);
		this.vpid = vpid;
	}

	/**
	 * @return VPID
	 */
	public String getVpid() {
		return vpid;
	}

	/**
	 * @param vpid the VPID to set for this connection spec.
	 */
	public void setVpid(String vpid) {
		this.vpid = vpid;
	}

	/**
	 * Gets the security information as a proprietary string
	 * 
	 * @see gov.va.med.vistalink.adapter.cci.VistaLinkConnectionSpec#getProprietarySecurityInfo()
	 * @va.exclude
	 */
	public ArrayList getProprietarySecurityInfo() {
		ArrayList values = new ArrayList();
		values.add(vpid);
		return values;
	}

	/**
	 * Compares two objects to see if they are equal
	 * 
	 * @param obj
	 *            the object to compare
	 * @see gov.va.med.vistalink.adapter.cci.VistaLinkConnectionSpec#isConnSpecEqual(java.lang.Object)
	 * @va.exclude
	 * @deprecated Use equals() method.
	 */
	public boolean isConnSpecEqual(Object obj) {
		return equals(obj);
	}

	public boolean equals(Object obj) {
		if (obj instanceof VistaLinkVpidConnectionSpec) {
			VistaLinkVpidConnectionSpec connSpec = (VistaLinkVpidConnectionSpec) obj;
			if ((connSpec.getDivision().equals(this.getDivision())) && (connSpec.getVpid().equals(this.getVpid()))) {
				return true;
			}
		}
		return false;
	}

	public int hashCode() {
		// algorithm taken from "Effective Java" item #8.
		int HASHCODE_SEED = 17;
		int returnVal = HASHCODE_SEED;

		// division contribution to hashcode
		int divisionHashCode = this.getDivision().hashCode();
		returnVal = 37 * returnVal + divisionHashCode; 
		// vpid contribution to hashcode
		int vpidHashCode = this.getVpid().hashCode();
		returnVal = 37 * returnVal + vpidHashCode; 
		return returnVal;
	}
	
	/**
	 * creates the xml in the security node
	 * 
	 * @param requestDoc
	 *            the Document object that contains the nodes
	 * @param securityNode
	 *            the node to create the XML under
	 * @see gov.va.med.vistalink.adapter.cci.VistaLinkConnectionSpec#setAuthenticationNodes(org.w3c.dom.Document,
	 *      org.w3c.dom.Node)
	 * @va.exclude
	 */
	public void setAuthenticationNodes(Document requestDoc, Node securityNode) {
		if (logger.isDebugEnabled()) {
			logger.debug("setAuthenticationNodes -> Re Auth type is 'vpid'");
		}

		setSecurityDivisionAttr(securityNode);
		setSecurityTypeAttr(securityNode);

		Element elemVpid = requestDoc.createElement(ELEMENT_VPID);

		elemVpid.setAttribute(ATTRIBUTE_VALUE, this.vpid);

		securityNode.appendChild(elemVpid);

	}

	/**
	 * returns the security mechanism type
	 * 
	 * @see gov.va.med.vistalink.adapter.cci.VistaLinkConnectionSpec#getSecurityType()
	 * @va.exclude
	 */
	public String getSecurityType() {
		return TYPE_VPID;
	}

}