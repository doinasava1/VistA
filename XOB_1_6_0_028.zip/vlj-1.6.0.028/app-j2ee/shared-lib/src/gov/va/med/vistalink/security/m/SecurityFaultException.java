package gov.va.med.vistalink.security.m;

import gov.va.med.vistalink.adapter.record.VistaLinkFaultException;

/**
 * This fault exception class is used for all security-related errors returned from the M system. It represents an error
 * that happened on the M system, that VistaLink does not provide a specific java exception for. It will not be returned
 * directly to an application calling a Vista login. Instead, it would be nested within a
 * <code>VistaLoginModuleException</code> which is directly returned to an application calling a Vista login.
 * <p>Calling <code>getMessage</code> on a <code>VistaLoginModuleException</code> might, for example, reveal nested
 * exceptions. For example:
 * <code>
 * <p>ERROR: gov.va.med.vistalink.security.VistaLoginModuleException: Security fault occured on the M system.;<br>
 * nested  exception is:  gov.va.med.vistalink.security.m.SecurityFaultException:  Fault Code: 'Client'; Fault<br>
 * String: 'Unexpected Message Format'; Fault Actor: '';   Code: '183002'; Type: ''; Message: 'Security message action<br>
 * 'AV.SetupAndIntroText' is an unknown security action.'
 * </code>
 * @see gov.va.med.vistalink.security.VistaLoginModuleException
 */
public class SecurityFaultException extends VistaLinkFaultException {

	/**
	 * Constructs a SecurityFaultException based on a VistaLinkFaultException
	 * @param vistaLinkFaultException Fault Exception
	 * @va.exclude
	 */   
	public SecurityFaultException(VistaLinkFaultException vistaLinkFaultException) {
		super(vistaLinkFaultException);
	}

}
