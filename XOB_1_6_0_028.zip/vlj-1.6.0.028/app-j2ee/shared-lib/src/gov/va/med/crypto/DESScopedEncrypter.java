package gov.va.med.crypto;

import gov.va.med.vistalink.jmx.IJmxHelper;
import gov.va.med.vistalink.jmx.JmxHelperException;
import gov.va.med.vistalink.jmx.JmxHelperFactory;

/**
 * Adds a "scoped" seed to the encryption, restricting use of the decryption to the computing domain a given value was
 * encrypted in.
 * 
 */
public class DESScopedEncrypter extends DESPassPhraseEncrypter {

	DESScopedEncrypter() {
		super();
		try {
			IJmxHelper jmxHelper = JmxHelperFactory.getJmxHelper();
			passPhrase += jmxHelper.getComputingDomainName();
		} catch (JmxHelperException e) {
			logger.error("DESScopedEncrypter: Could not retrieve Domain Name for local server:", e);
		}
	}

}
