package gov.va.med.monitor.time;

import org.apache.log4j.Logger;

/**
 * This class gives an easy way to capture performance statistics and log them
 * to a log file. Internally System.currentTimeMillis() is used.
 * <p>
 * Typical steps for using this class:
 * <ol>
 * <li>Create an instance: auditTimer = new AutitTimer()</li>
 * <li>auditTimer.start()</li>
 * <li>auditTimer.stop()</li>
 * <li>auditTimer.getTimeElapsedMillis()</li>
 * </ol>
 * 
 * auditTimer.start() should be called before auditTimer.stop()is called.
 * 
 */
public class AuditTimer {

	/**
	 * Default log4j logger to be used for outputing time audit messages if no
	 * logger is provided in the constructor. Logger
	 * gov.va.med.foundations.utilities.AuditTimer level info.
	 */
	private static final Logger defaultLogger = Logger.getLogger(AuditTimer.class);

	/**
	 * log4j logger to be used for outputing time audit messages.
	 */
	private Logger logger = null;

	/**
	 * Start time
	 */
	private long startTimeMillis = 0;
	/**
	 * Stop time
	 */
	private long stopTimeMillis = 0;
	/**
	 * Elapsed time
	 */
	private long timeElapsedMillis = 0;

	/**
	 * Default constructor. Default logger
	 * gov.va.med.foundations.utilities.AuditTimer will be used.
	 */
	public AuditTimer() {
		logger = defaultLogger;
	}

	/**
	 * Constructor that accepts logger to be used for output. Application can
	 * pass in their own loggers to have granual control over logging.
	 * 
	 * @param logger
	 */
	public AuditTimer(Logger logger) {
		this.logger = logger;
	}

	/**
	 * Starts the timer.
	 */
	public void start() {
		startTimeMillis = System.currentTimeMillis();
	}

	/**
	 * Stops the timer. If start() was not called at least once before stop() is
	 * called timeElapsedMillis is set to -1.
	 * <p>
	 * This method does not through Exception to keep client code simple.
	 * 
	 * @return long elapsed time since timer start in milliseconds (or -1 if timer not started)
	 */
	public long stop() {
		if (startTimeMillis == 0) {
			// don't want to through exception to keep client coding simple.
			// just return negative timeElapsedMillis
			timeElapsedMillis = -1;
		} else {
			stopTimeMillis = System.currentTimeMillis();
			timeElapsedMillis = stopTimeMillis - startTimeMillis;
		}
		return timeElapsedMillis;
	}

	/**
	 * @return long
	 */
	public long getTimeElapsedMillis() {
		return timeElapsedMillis;
	}

	/**
	 * The same as log(String).
	 */
	public void log() {
		log(null);
	}

	/**
	 * Logs a message to the log4j logger in a following format:
	 * <p>
	 * your_message elapsed_time_milliseconds
	 * 
	 * @param message
	 */
	public void log(String message) {
		StringBuffer logString = new StringBuffer(255);

		if ((message == null) || ("".equals(message))) {
			logString.append("");
		} else {
			logString.append(message).append(' ');
		}
		logString.append(timeElapsedMillis);

		logger.info(logString.toString());
	}

	/**
	 * 
	 * @param logger
	 * @return is info level logging enabled on the specified logger.
	 */
	public static boolean isAuditTimerEnabled(Logger logger) {
		if (logger == null) {
			return false;
		}

		return logger.isInfoEnabled();
	}

	/**
	 * 
	 * @return is info level logging specified on the default logger.
	 */
	public static boolean isAuditTimerEnabled() {

		return isAuditTimerEnabled(defaultLogger);
	}
}