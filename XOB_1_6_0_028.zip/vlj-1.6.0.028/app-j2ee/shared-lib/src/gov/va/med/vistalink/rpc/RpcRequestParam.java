package gov.va.med.vistalink.rpc;

/**
 * Value object representing an RPC parameter.
 * 
 */
public class RpcRequestParam {
    private String type = null;
    
    private Object value = null;
    
    RpcRequestParam(String type, Object value){
        this.type = type;
        this.value = value;
    }
    /**
     * @return Returns the type.
     */
    String getType() {
        return type;
    }
    /**
     * @param type The type to set.
     */
    void setType(String type) {
        this.type = type;
    }
    /**
     * @return Returns the value.
     */
    Object getValue() {
        return value;
    }
    /**
     * @param value The value to set.
     */
    void setValue(Object value) {
        this.value = value;
    }
    
    public String toString() {
        return "Parameter: Type = " + type + " Value = " + this.value.toString();
    }
 }
