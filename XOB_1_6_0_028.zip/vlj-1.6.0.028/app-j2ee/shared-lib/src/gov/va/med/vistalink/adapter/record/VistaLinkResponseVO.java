package gov.va.med.vistalink.adapter.record;

import org.w3c.dom.Document;

/**
 * Base interface for response objects.  
 * 
 */
public interface VistaLinkResponseVO {

	/**
	 * Returns raw xml response string.
	 * 
	 * @return String
	 */
	String getRawResponse();

	/**
	 * Returns response as DOM Document.
	 * 
	 * @return org.w3c.dom.Document
	 */
	Document getDocument();

}
