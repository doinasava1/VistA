package gov.va.med.vistalink.security;

import gov.va.med.vistalink.security.m.VistaInstitutionVO;
import gov.va.med.vistalink.security.m.SecurityVOSetupAndIntroText;

import java.util.Iterator;
import java.util.TreeMap;
import java.util.Map.Entry;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.UnsupportedCallbackException;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

/**
 * Implements the JAAS CallbackHandler interface. Use with the
 * <code>VistaLoginModule</code> to invoke a silent signon. Intended for use
 * in unit testing environments where logins must be called repetitively without
 * user interaction. <b>Not </b> for use in production environments, where users
 * should be interactively prompted for signon credentials.
 * <ol>
 * <li>Pass access code, verify code and division as parameters when you create
 * an instance of this callback handler.
 * <li>Pass the instance of the callback handler to the login context when you
 * create the login context.
 * <li>Then, when <code>VistaLoginModule</code>'s<code>login</code>
 * method (via the indirection of the <code>LoginContext</code>) invokes this
 * callback handler to collect user input for (access code, verify code, select
 * division), these values are already present and are handed back to the login
 * module without any user interation.
 * </ol>
 * For example: <code>
 * <p>
 *     String cfgName = "RpcSampleServer"; <br>
 *     String accessCode = "joe.123"; <br>
 *     String verifyCode = "ebony.23"; <br>
 *     String division = "";
 * <p>
 *     // create the callbackhandler for JAAS login <br>
 *     CallbackHandlerUnitTest cbhSilentSimple =  <br>
 *        new CallbackHandlerUnitTest(accessCode, verifyCode, division);
 * <p>
 *     // create the JAAS LoginContext for login <br>
 *     lc = new LoginContext(cfgName, cbhSilentSimple);
 * <p>
 *     // login to server <br>
 *     lc.login();
 * </code>
 * 
 * @see VistaLoginModule
 */
public final class CallbackHandlerUnitTest extends CallbackHandlerBase {

	private static final Logger logger = Logger.getLogger(CallbackHandlerUnitTest.class);

	private char[] accessCode;
	private char[] verifyCode;
	private String divisionIen = "";
	private char[] newVerifyCode;
	private char[] newVerifyCodeCheck;

	/**
	 * Creates a simple callback handler that handles the callbacks for logon.
	 * 
	 * @param accessCode
	 *            Access Code to use for logon
	 * @param verifyCode
	 *            Verify Code to use for logon
	 * @param divisionIen
	 *            IEN of division to select for multidivisional logins. If not
	 *            needed, pass an empty string.
	 */
	public CallbackHandlerUnitTest(String accessCode, String verifyCode, String divisionIen) {

		super();

		this.accessCode = accessCode.toCharArray();
		this.verifyCode = verifyCode.toCharArray();
		this.divisionIen = divisionIen;

	}

	/**
	 * Creates a simple callback handler that handles the callbacks for logon. Will change verify code as part of login.
	 * 
	 * @param accessCode
	 *            Access Code to use for logon
	 * @param oldVerifyCode
	 *            Verify Code to use for logon
	 * @param divisionIen
	 *            IEN of division to select for multidivisional logins. If not
	 *            needed, pass an empty string.
	 * @param newVerifyCode
	 *            new verify code to change
	 * @param newVerifyCodeCheck
	 *            should be the same as newVerifyCode, to be successful. Used as
	 *            a check.
	 */
	public CallbackHandlerUnitTest(String accessCode, String oldVerifyCode, String divisionIen, String newVerifyCode,
			String newVerifyCodeCheck) {
		super();
		this.accessCode = (accessCode != null) ? accessCode.toCharArray() : "".toCharArray();
		this.verifyCode = (oldVerifyCode != null) ? oldVerifyCode.toCharArray() : "".toCharArray();
		this.divisionIen = divisionIen;
		this.newVerifyCode = (newVerifyCode != null) ? newVerifyCode.toCharArray() : "".toCharArray();
		this.newVerifyCodeCheck = (newVerifyCodeCheck != null) ? newVerifyCodeCheck.toCharArray() : "".toCharArray();
	}

	/**
	 * Does the change verify code callback
	 * 
	 * @param cvcCallback
	 *            change verify code callback
	 */
	void doCallbackChangeVc(CallbackChangeVc cvcCallback) throws UnsupportedCallbackException {
		logger.debug("starting CallbackChangeVc");
		// this.doUnsupportedCallback(cvcCallback);
		cvcCallback.setNewVerifyCode(this.newVerifyCode);
		cvcCallback.setNewVerifyCodeCheck(this.newVerifyCodeCheck);
		cvcCallback.setOldVerifyCode(this.verifyCode);
		cvcCallback.setSelectedOption(CallbackChangeVc.KEYPRESS_OK);
	}

	/**
	 * Does the confirm callback
	 * 
	 * @param confirmCallback confirm callback
	 */
	void doCallbackConfirm(CallbackConfirm confirmCallback) {
		logger.debug("starting CallbackConfirm");
		String messageText = confirmCallback.getDisplayMessage();
		// since it's an error, let's display it for quicker troubleshooting
		// (assuming error priority logging is enabled)
		logger.error(messageText);
		confirmCallback.setSelectedOption(CallbackConfirm.KEYPRESS_OK);
	}

	/**
	 * Does the logon callback
	 * 
	 * @param logonCallback
	 */
	void doCallbackLogon(CallbackLogon logonCallback) {
		logger.debug("starting CallbackLogon");
		SecurityVOSetupAndIntroText setupInfo = logonCallback.getSetupAndIntroTextInfo();
		logger.debug(setupInfo);
		String introText = setupInfo.getIntroductoryText();
		logger.debug(introText);
		logonCallback.setAccessCode(accessCode);
		logonCallback.setVerifyCode(verifyCode);
		logonCallback.setSelectedOption(CallbackLogon.KEYPRESS_OK);
	}

	/**
	 * Does the select division callback
	 * 
	 * @param divisionCallback
	 */
	void doCallbackSelectDivision(CallbackSelectDivision divisionCallback) {
		logger.debug("starting CallbackSelectDivision");
		TreeMap divisionList = (TreeMap) divisionCallback.getDivisionList();
		for (Iterator it = divisionList.entrySet().iterator(); it.hasNext();) {
			Entry entry = (Entry) it.next();
			VistaInstitutionVO myDivision = (VistaInstitutionVO) entry.getValue();
			logger.debug("candidate login division IEN: " + myDivision.getIen() + " Name: " + myDivision.getName() + " Number: "
					+ myDivision.getNumber());
		}
		divisionCallback.setSelectedDivisionIen(divisionIen);
		divisionCallback.setSelectedOption(CallbackSelectDivision.KEYPRESS_OK);

	}

	/**
	 * Does the commit callback
	 * 
	 * @param commitCallback
	 */
	void doCallbackCommit(CallbackCommit commitCallback) {
		logger.debug("starting CallbackCommit");
		// do nothing
	}

	/**
	 * processes unsupported callbacks
	 * 
	 * @param callback
	 *            the unsupported callback
	 * @throws UnsupportedCallbackException
	 *             thrown as part of the processing of an unsupported callback
	 */
	void doUnsupportedCallback(Callback callback) throws UnsupportedCallbackException {

		String errMsg = "Unsupported callback: '" + callback.getClass() + "'";
		UnsupportedCallbackException e = new UnsupportedCallbackException(callback, errMsg);
		if (logger.isEnabledFor(Level.ERROR)) {
			logger.error(errMsg, e);
		}
		throw e;
	}

}