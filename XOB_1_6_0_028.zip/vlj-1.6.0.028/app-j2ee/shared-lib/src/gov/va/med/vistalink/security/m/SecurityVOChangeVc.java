package gov.va.med.vistalink.security.m;

import java.util.Map;

/**
 * Logon-related value object for "change verify code" results.
 * 
 */
public class SecurityVOChangeVc extends SecurityVO {

	private boolean needDivisionSelection = false;
	private Map divisionList;

	/**
	 * Constructor.
	 * @param resultType Success, Failure or Partial Success (types defined in parent class) 
	 * @param resultMessage optional explanatory description for the result, usually used for failure and partial success only
	 */
	public SecurityVOChangeVc(int resultType, String resultMessage) {
		super(resultType, resultMessage);
	}
	
	/**
	 * List of divisions that the user should select a division from, if, after changing verify code,
	 * the user needs to select a division.
	 * @return TreeMap list of divisions
	 */
	public Map getDivisionList() {
		return divisionList;
	}

	/**
	 * Sets the list of divisions a user should select a division from.
	 * @param divisionList TreeMap list of divisions. The key is the division/station number (a string); the
	 * object is a VistaInstitutionVO object.
	 * @see VistaInstitutionVO
	 */
	public void setDivisionList(Map divisionList) {
		this.divisionList = divisionList;
	}

	/**
	 * Returns whether division selection needed after completion of the change verify code?
	 * @return boolean whether division selection is needed
	 */
	public boolean getNeedDivisionSelection() {
		return needDivisionSelection;
	}

	/**
	 * Set whether division selection is needed, given a successful change verify code operation.
	 * @param needDivisionSelection
	 */
	public void setNeedDivisionSelection(boolean needDivisionSelection) {
		this.needDivisionSelection = needDivisionSelection;
	}
}
