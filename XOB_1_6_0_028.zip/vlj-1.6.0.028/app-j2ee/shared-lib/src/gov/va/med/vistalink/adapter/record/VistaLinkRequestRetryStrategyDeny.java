package gov.va.med.vistalink.adapter.record;

import org.apache.log4j.Logger;

/**
 * Simple 'Deny' strategy implementation that indicates request should not be re-executed
 * 
 */
public class VistaLinkRequestRetryStrategyDeny implements VistaLinkRequestRetryStrategy  {
    /**
     * The logger used by this class
     */
    private static final Logger logger = Logger.getLogger(VistaLinkRequestRetryStrategyDeny.class);


	/* 
	 * Simple 'Deny' logic that indicates request should not be re-executed
	 * 
	 * @see gov.va.med.vistalink.adapter.record.VistaLinkRequestRetryStrategy#execute(gov.va.med.vistalink.adapter.record.VistaLinkRequestVO)
	 */
	public boolean execute(VistaLinkRequestVO request){
        if (logger.isDebugEnabled()) {
            logger.debug("Executing 'Deny' retry strategy for request class = " + request.getClass());
        }
		return false;
	}
}
