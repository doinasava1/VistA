package gov.va.med.vistalink.console;

import java.io.IOException;

import javax.management.remote.JMXConnector;

/**
 * Abstracts the concept of a J2EE "server", to support building multi-server-aware admin consoles. Hides
 * vendor-specific implementation details. Provides information needed to identify a given server (for JMX queries, and
 * for end-users), as well support for making JMX remoting calls to the server.
 * <p>
 * The key information used to instantiate IServerHelper objects is the vendor-specific ObjectName fragment used by the
 * vendor to filter MBean queries to retrieve MBeans from a single server.
 * <p>
 * 
 */
public interface IServerHelper {

	/**
	 * Return a display name for the server that includes all of the location qualifiers (e.g., cell/node/server for
	 * WebSphere, server for WebLogic, etc.) in a format appropriate to display to an end-user (e.g., for a web page
	 * list of servers to select from).
	 * 
	 * @return Server display name, including all qualifiers needed to describe the server location appropriately its
	 *         the vendor-specific context, to an end-user.
	 */
	String getDisplayNameFullyLocationQualified();

	/**
	 * 
	 * @return the object name fragment representing the information needed for the ServerHelper object to construct
	 *         itself to represent a particular server on the J2EE platform being used.
	 */
	String getServerHelperConstructorProperties();

	/**
	 * Return a JSR-160 compliant JMX connector to the specified server. Remember to close the connector when you are
	 * done.
	 * 
	 * @return JSR-160 connection to server.
	 * @throws ServerHelperNotRunningException, ServerHelperException, IOException
	 */
	JMXConnector getJmxConnector() throws ServerHelperNotRunningException, ServerHelperException, IOException;
}