package gov.va.med.exception;

import java.io.PrintStream;
import java.io.PrintWriter;

/**
 * FoundationsException provides adds nested exception functionality to standard exceptions. This functionality is no
 * longer necessary starting in Java 1.4, whose java.lang.Throwable class introduces built-in support for nested
 * exceptions. However, for backwards compatibility, VistALink exceptions still inherit from this class.
 * 
 * Implements methods to return nested exception message as part of current exception message.
 * <p>
 * The nested exception, uses throwable so it can encapsulate all types of exceptions even Error exceptions.
 * 
 */
public class FoundationsException extends Exception implements FoundationsExceptionInterface {

	/**
	 * Default constructor.
	 */
	public FoundationsException() {
		super();
	}

	/**
	 * Constructor.
	 * 
	 * @param msg
	 * @see java.lang.Throwable#Throwable(java.lang.String)
	 */
	public FoundationsException(String msg) {
		super(msg);
	}

	/**
	 * Constructor.
	 * 
	 * @param nestedException exception to nest in new FoundationsException
	 */
	public FoundationsException(Throwable nestedException) {
		super(nestedException);
	}

	/**
	 * Constructor.
	 * 
	 * @param msg Exception message
	 * @param nestedException exception to nest in new FoundationsException
	 */
	public FoundationsException(String msg, Throwable nestedException) {
		super(msg, nestedException);
	}

	/**
	 * Return nested exception that is wrapped within this exception.
	 * @return nested exception
	 * @deprecated Use Throwable.getCause() instead.
	 */
	public Throwable getNestedException() {
		return getCause();
	}

	/**
	 * Returns oringal message that was passed into the exception constructor. Does not perform message discovery from
	 * the nested exception. Only to be used by the descendants of this class.
	 * 
	 * @return String
	 */
	protected String getOriginalMessage() {
		return super.getMessage();
	}

	/**
	 * Returns the detail message, including nested messages from the nested exceptions.
	 * 
	 * @see java.lang.Throwable#getMessage()
	 */
	public String getMessage() {
		/*
		 * Note: jdk1.4 getMessage does *not* included nested messages from the nested exceptions, whereas this does.
		 * Guess we just leave this as-is, and it will behave as before for classes derived from FoundationsException.
		 */
		String retMessage = super.getMessage();
		if (retMessage == null) {
			retMessage = "";
		}

		// note that the original (pre-JDK-1.4) version of this call only went down one level.
		if (getCause() == null) {
			return retMessage;
		} else {
			return retMessage + "; \n\tRoot cause exception: \n\t" + getCause().toString();
		}
	}

	/**
	 * Prints the composite message and full embedded stack trace to the
	 * specified stream <code>ps</code>.
	 * 
	 * @see java.lang.Throwable#printStackTrace(java.io.PrintStream)
	 * @param ps
	 *            the print stream
	 */
	public void printStackTrace(PrintStream ps) {
		if (getNestedException() == null) {
			super.printStackTrace(ps);
		} else {
			ps.println(this);
			getNestedException().printStackTrace(ps);
		}
	}

	/**
	 * Prints the composite message and full embedded stack trace to the
	 * specified print writer <code>pw</code>
	 * 
	 * @see java.lang.Throwable#printStackTrace(java.io.PrintWriter)
	 * @param pw
	 *            the print writer
	 */
	public void printStackTrace(PrintWriter pw) {
		if (getNestedException() == null) {
			super.printStackTrace(pw);
		} else {
			pw.println(this);
			getNestedException().printStackTrace(pw);
		}
	}

	/**
	 * Prints the composite message and full embedded stack trace to
	 * <code>System.err</code>.
	 * 
	 * @see java.lang.Throwable#printStackTrace()
	 */
	public void printStackTrace() {
		printStackTrace(System.err);
	}

	/**
	 * Returns the composite message and full embedded stack trace trace
	 * 
	 * @see gov.va.med.exception.FoundationsExceptionInterface#getFullStackTrace()
	 * @deprecated Use Throwable.getStackTrace() instead.
	 */
	public String getFullStackTrace() {
		// no identical substitute for this -- jdk 1.4 getStackTrace returns StackTraceElement[]
		return ExceptionUtils.getFullStackTrace(this);
	}

}