/*
 * Created on Oct 20, 2003
 *
 */
package gov.va.med.vistalink.adapter.spi;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import gov.va.med.vistalink.adapter.record.VistaLinkRequestVO;
import gov.va.med.vistalink.adapter.record.VistaLinkResponseFactoryImpl;
import gov.va.med.vistalink.adapter.record.VistaLinkResponseVO;
import gov.va.med.exception.ExceptionUtils;
import gov.va.med.exception.FoundationsException;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Response Factory for VistaLinkInitSocketResponse.
 * 
 */
public class VistaLinkInitSocketResponseFactory extends VistaLinkResponseFactoryImpl {

    /**
     * The logger used for this class
     */
    private static final Logger logger = Logger.getLogger(VistaLinkInitSocketResponseFactory.class);

    /**
     *  
     */
    protected VistaLinkInitSocketResponseFactory() {
        super();
    }

    /**
     * Evaluates the response from M and gets the heart beat rate in millis. Constructs a new
     * VistaLinkInitSocketResponse object.
     * 
     * @see gov.va.med.vistalink.adapter.record.VistaLinkResponseFactoryImpl#parseMessageBody(java.lang.String,
     *      java.lang.String, org.w3c.dom.Document, java.lang.String,
     *      gov.va.med.vistalink.adapter.record.VistaLinkRequestVO)
     */
    protected VistaLinkResponseVO parseMessageBody(String rawXml, String filteredXml, Document doc, String messageType,
            VistaLinkRequestVO requestVO) throws FoundationsException {

        try {

            Attr attr = null;
            long heartBeatRateMillis = 0;
            String mJob = "";
            long reAuthSessionTimeout = 600;

			XPath xpath = XPathFactory.newInstance().newXPath();
			NodeList resultsNodeList = (NodeList) xpath.evaluate("/VistaLink/Response/.", doc, XPathConstants.NODESET);
			Node resultsNode = (resultsNodeList.getLength() > 0) ? resultsNodeList.item(0) : null; 

			// JAXEN-based parsing, now replaced by J2SE built-in XPath
//			XPath xpath = new DOMXPath("/VistaLink/Response/.");
//            Node resultsNode = (Node) xpath.selectSingleNode(doc);

            //			// get result type
            NamedNodeMap attrs = resultsNode.getAttributes();

            if (logger.isDebugEnabled()) {
                logger.debug("got response attributes");

            }

            heartBeatRateMillis = 1000 * Long.parseLong(((Attr) attrs.getNamedItem("rate")).getValue());
            attr = ((Attr) attrs.getNamedItem("mJob"));
            mJob = (attr != null) ? attr.getValue() : "[$JOB not returned]";
            attr = ((Attr) attrs.getNamedItem("reAuthSessionTimeout"));
            reAuthSessionTimeout = (attr != null) ? 1000 * Long.parseLong(attr.getValue()) : 600000;

            if (logger.isDebugEnabled()) {
                logger.debug(new StringBuffer().append("Retrieved Initial Socket Response: \n\theartbeat rate = ")
                        .append(heartBeatRateMillis).append("\n\tM $JOB = ").append(mJob).append(
                                "\n\tReauth session Timeout = ").append(reAuthSessionTimeout).toString());
            }

            return new VistaLinkInitSocketResponse(rawXml, filteredXml, doc, messageType, heartBeatRateMillis, mJob,
                    reAuthSessionTimeout);

        } catch (XPathExpressionException e) {

            String errStr = "could not parse xml";

            if (logger.isEnabledFor(Level.ERROR)) {

                String errMsg = (new StringBuffer()).append(errStr).append("\n\t").append(
                        ExceptionUtils.getFullStackTrace(e)).toString();

                logger.error(errMsg);
            }

            throw new FoundationsException(errStr, e);
        }

    }

}