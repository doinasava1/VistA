package gov.va.med.vistalink.adapter.spi;

import java.util.Map;

/**
 * JavaBean value object to transfer connector detail for a single connector, i.e. between an struts action and a JSP
 * page.
 * 
 */
public class ConnectorInfoVO {

	// VL configuration value fields -- from VL config file
	private String cfgIpAddress;
	private int cfgPort;
	private String cfgJndiName;
	private long cfgTimeout;
	private boolean cfgTimeoutAlwaysUseDefaultAsMin;
	private String[] cfgStationNumbers;

	// VL mcf fields -- obtain from MCF
	private long hlthConnectionFailureCount;
	private long hlthConnectionAuthFailureCount;
	private long hlthDivisionMismatchCount;
	private long hlthIdentityFailureCount;
	private long hlthProductionMismatchCount;
	private double perfCreateConnectionHandleAvgMillis;
	private double perfMatchManagedConnectionAvgMillis;

	private long vljDistinguishedIdentifier;

	private VistaLinkSystemInfoVO mumpsSystemInfo;

	// JCA-standard item fields
	private String jcaJndiName;
	private String jcaDeploymentStateString;
	private int jcaDeploymentState;

	// generic field
	private String displayName;
	private boolean jndiMismatch;

	// platform-specific field
	private Map platformSpecificItemsMap;

	/**
	 * 
	 * @param wlsJndiActual the confirmed, server-deploymed JNDI name
	 */
	public final void setJcaJndiName(String wlsJndiActual) {
		this.jcaJndiName = wlsJndiActual;
	}

	/**
	 * 
	 * @return the server-deployment JNDI name
	 */
	public String getJcaJndiName() {
		return this.jcaJndiName;
	}

	/**
	 * @param vljIpAddress IP address of the M listener
	 */
	public final void setCfgIpAddress(String vljIpAddress) {
		this.cfgIpAddress = vljIpAddress;
	}

	/**
	 * 
	 * @return IP address of the M listener
	 */
	public String getCfgIpAddress() {
		return this.cfgIpAddress;
	}

	/**
	 * 
	 * @param vljPort Port of the M listener
	 */
	public final void setCfgPort(int vljPort) {
		this.cfgPort = vljPort;
	}

	/**
	 * 
	 * @return Port of the M listener
	 */
	public int getCfgPort() {
		return this.cfgPort;
	}

	/**
	 * 
	 * @param vljJndiConfig JNDI name configured in the VistaLink connectorJndiName property of ra.xml.
	 */
	public final void setCfgJndiName(String vljJndiConfig) {
		this.cfgJndiName = vljJndiConfig;
	}

	/**
	 * 
	 * @return JNDI name configured in the VistaLink connectorJndiName property of ra.xml.
	 */
	public String getCfgJndiName() {
		return this.cfgJndiName;
	}

	/**
	 * 
	 * @param healthConnectionFailureCount The number of socket connection errors for the connector
	 */
	public final void setHlthConnectionFailureCount(long healthConnectionFailureCount) {
		this.hlthConnectionFailureCount = healthConnectionFailureCount;
	}

	/**
	 * 
	 * @return the number of socket connection errors for the connector
	 */
	public long getHlthConnectionFailureCount() {
		return this.hlthConnectionFailureCount;
	}

	/**
	 * 
	 * @param healthConnectionAuthFailureCount The number of connection user authentication failures for the connector.
	 */
	public final void setHlthConnectionAuthFailureCount(long healthConnectionAuthFailureCount) {
		this.hlthConnectionAuthFailureCount = healthConnectionAuthFailureCount;
	}

	/**
	 * @return The number of connection user authentication failures for the connector.
	 */
	public long getHlthConnectionAuthFailureCount() {
		return hlthConnectionAuthFailureCount;
	}

	/**
	 * 
	 * @param healthDivisionMismatchCount The number of re-authentication division mismatches for the connector.
	 */
	public final void setHlthDivisionMismatchCount(long healthDivisionMismatchCount) {
		this.hlthDivisionMismatchCount = healthDivisionMismatchCount;
	}

	/**
	 * 
	 * @return The number of re-authentication division mismatches for the connector.
	 */
	public long getHlthDivisionMismatchCount() {
		return this.hlthDivisionMismatchCount;
	}

	/**
	 * 
	 * @param healthIdentityFailureCount The number of reauthentication identification failures for the connector.
	 */
	public final void setHlthIdentityFailureCount(long healthIdentityFailureCount) {
		this.hlthIdentityFailureCount = healthIdentityFailureCount;
	}

	/**
	 * 
	 * @return The number of reauthentication identification failures for the connector.
	 */
	public long getHlthIdentityFailureCount() {
		return this.hlthIdentityFailureCount;
	}

	/**
	 * @return Returns the number of production/test mismatches for this connector.
	 */
	public long getHlthProductionMismatchCount() {
		return hlthProductionMismatchCount;
	}

	/**
	 * @param hlthProductionMismatchCount The number of production/test mismatches for this connector.
	 */
	public final void setHlthProductionMismatchCount(long hlthProductionMismatchCount) {
		this.hlthProductionMismatchCount = hlthProductionMismatchCount;
	}

	/**
	 * @return Returns the display name for the adapter (JCA 1.0)/connection factory (JCA 1.5). The contents of the
	 *         display name may vary from platform to platform.
	 */
	public String getDisplayName() {
		return displayName;
	}

	/**
	 * @param displayName The display name for the adapter (JCA 1.0)/connection factory (JCA 1.5). The contents of the
	 *            display name may vary from platform to platform.
	 */
	public final void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	/**
	 * @return Returns the WLS Deployment State for the connector.
	 */
	public int getJcaDeploymentState() {
		return jcaDeploymentState;
	}

	/**
	 * @param jcaDeploymentState The WLS Deployment State for the connector.
	 */
	public final void setJcaDeploymentState(int jcaDeploymentState) {
		this.jcaDeploymentState = jcaDeploymentState;
	}

	/**
	 * @return Returns the string representation of the WLS Deployment State for the connector.
	 */
	public String getJcaDeploymentStateString() {
		return jcaDeploymentStateString;
	}

	/**
	 * @param jcaDeploymentStateString The string representation of the WLS Deployment State for the connector.
	 */
	public final void setJcaDeploymentStateString(String jcaDeploymentStateString) {
		this.jcaDeploymentStateString = jcaDeploymentStateString;
	}

	/**
	 * @return Returns the array of mapped station numbers for the connector.
	 */
	public String[] getCfgStationNumbers() {
		if (cfgStationNumbers != null) {
			return cfgStationNumbers.clone();
		} else { 
			return cfgStationNumbers;
		}
	}

	/**
	 * @param cfgStationNumbers The array of mapped station numbers for the connector.
	 */
	public final void setCfgStationNumbers(String[] cfgStationNumbers) {
		if (cfgStationNumbers != null) {
			this.cfgStationNumbers = cfgStationNumbers.clone();
		} else {
			cfgStationNumbers = null;
		}
	}

	/**
	 * @return Returns the mSystemInfo object retrieved using the connector.
	 */
	public VistaLinkSystemInfoVO getMumpsSystemInfo() {
		return mumpsSystemInfo;
	}

	/**
	 * @param systemInfo The mSystemInfo object retrieved using the connector.
	 */
	public final void setMumpsSystemInfo(VistaLinkSystemInfoVO systemInfo) {
		mumpsSystemInfo = systemInfo;
	}

	/**
	 * @return Returns the average CreateConnectionHandle time, in milliseconds.
	 */
	public double getPerfCreateConnectionHandleAvgMillis() {
		return perfCreateConnectionHandleAvgMillis;
	}

	/**
	 * @param perfCreateConnectionHandleAvgMillis The average CreateConnectionHandle time, in milliseconds.
	 */
	public final void setPerfCreateConnectionHandleAvgMillis(double perfCreateConnectionHandleAvgMillis) {
		this.perfCreateConnectionHandleAvgMillis = perfCreateConnectionHandleAvgMillis;
	}

	/**
	 * @return Returns the average MatchManagedConnection time, in milliseconds.
	 */
	public double getPerfMatchManagedConnectionAvgMillis() {
		return perfMatchManagedConnectionAvgMillis;
	}

	/**
	 * @param perfMatchManagedConnectionAvgMillis The average MatchManagedConnection time, in milliseconds.
	 */
	public final void setPerfMatchManagedConnectionAvgMillis(double perfMatchManagedConnectionAvgMillis) {
		this.perfMatchManagedConnectionAvgMillis = perfMatchManagedConnectionAvgMillis;
	}

	/**
	 * @return Returns the VistaLink distinguished identifier of the connector.
	 */
	public long getVljDistinguishedIdentifier() {
		return vljDistinguishedIdentifier;
	}

	/**
	 * @param vljDistinguishedIdentifier The VistaLink distinguished identifier of the connector.
	 */
	public final void setVljDistinguishedIdentifier(long vljDistinguishedIdentifier) {
		this.vljDistinguishedIdentifier = vljDistinguishedIdentifier;
	}

	/**
	 * @return Returns the cfgTimeout.
	 */
	public long getCfgTimeout() {
		return cfgTimeout;
	}

	/**
	 * @param timeout The cfgTimeout to set.
	 */
	public final void setCfgTimeout(long timeout) {
		this.cfgTimeout = timeout;
	}

	/**
	 * @return Returns the cfgTimeoutAlwaysUseDefaultAsMin.
	 */
	public boolean isCfgTimeoutAlwaysUseDefaultAsMin() {
		return cfgTimeoutAlwaysUseDefaultAsMin;
	}

	/**
	 * @param timeoutAlwaysUseDefaultAsMin true if the default timeout should always be enforced as the minimum possible timeout.
	 */
	public final void setCfgTimeoutAlwaysUseDefaultAsMin(boolean timeoutAlwaysUseDefaultAsMin) {
		this.cfgTimeoutAlwaysUseDefaultAsMin = timeoutAlwaysUseDefaultAsMin;
	}

	/**
	 * Human-friendly toString output
	 */
	public String toString() {

		StringBuffer sb = new StringBuffer("Deployed JNDI name: '");
		sb.append(jcaJndiName);
		sb.append("WebLogic Application Name: '");
		sb.append(displayName);
		sb.append("', Config JNDI Name: '");
		sb.append(cfgJndiName);
		sb.append("', M IP: '");
		sb.append(cfgIpAddress);
		sb.append("', M Port: '");
		sb.append(cfgPort);
		sb.append("'.");

		return sb.toString();
	}

	public Map getPlatformSpecificItemsMap() {
		return platformSpecificItemsMap;
	}

	public final void setPlatformSpecificItemsMap(Map platformSpecificItemsMap) {
		this.platformSpecificItemsMap = platformSpecificItemsMap;
	}

	public boolean isJndiMismatch() {
		return jndiMismatch;
	}

	public void setJndiMismatch(boolean jndiMismatch) {
		this.jndiMismatch = jndiMismatch;
	}

	/**
	 * Compares two JNDI names.
	 * @param jndiName1
	 * @param jndiName2
	 * @return Returns true if both are a) non-null AND b) don't match
	 * @va.exclude
	 */
	public static boolean isJndiMismatch(String jndiName1, String jndiName2) {
		boolean returnVal = true;
		// returns true if either one is null -- something is wrong.
		if ((jndiName1 != null) && (jndiName2 != null)) {
			returnVal = (!(jndiName1.trim()).equals(jndiName2.trim()));
		}
		return returnVal;
	}
}