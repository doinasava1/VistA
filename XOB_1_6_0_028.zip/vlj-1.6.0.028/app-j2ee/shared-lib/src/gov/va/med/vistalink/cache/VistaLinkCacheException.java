/*
 * Created on May 18, 2005
 *
 */
package gov.va.med.vistalink.cache;

import gov.va.med.exception.FoundationsException;
;

/**
 * Represents error conditions found while attempting to use the connection factory cache/locator.
 * 
 */
public class VistaLinkCacheException extends FoundationsException{
  /**
   * Exception constructor.
   * @va.exclude
   */
  public VistaLinkCacheException()
  {
    super();
  }
  
  /**
   * Exception constructor.
   * @param message Exception message.
   * @va.exclude
   */
  public VistaLinkCacheException(String message) {
    super(message);
  }
  
  /**
   * Exception constructor.
   * @param nestedException A nested exception.
   * @va.exclude
   */
  public VistaLinkCacheException(Exception nestedException) {
    super(nestedException);
  }
  
  /**
   * Exception constructor.
   * @param message Exception message.
   * @param nestedException A nested exception.
   * @va.exclude
   */
  public VistaLinkCacheException(String message, Exception nestedException) {
    super(message, nestedException);
  }
}
