package gov.va.med.vistalink.security;

import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Window;

/**
 * Contains various Swing-related utilities used by the Security package.
 * 
 */
class VistaLoginSwingUtilities {

	static void goldenMeanCenterDialog(Window parentWindow, Window windowToCenter) {

		Dimension parentWindowSize = null;
		int parentWindowTopLeftCornerX = 0;
		int parentWindowTopLeftCornerY = 0;

		if (parentWindow == null) {
			parentWindowSize = windowToCenter.getToolkit().getScreenSize();
		} else {
			Rectangle rect = parentWindow.getBounds();
			parentWindowSize = new Dimension(rect.width, rect.height);
			parentWindowTopLeftCornerX = rect.x;
			parentWindowTopLeftCornerY = rect.y;
		}

		int x = ((parentWindowSize.width - windowToCenter.getWidth()) / 2) + parentWindowTopLeftCornerX;
		int goldenMeanCenterHeight = (int) (parentWindowSize.getHeight() - (parentWindowSize.getHeight() / 1.618));
		int y = (goldenMeanCenterHeight - (windowToCenter.getHeight() / 2)) + parentWindowTopLeftCornerY;
		// in case dialog is bigger than screen, adjust
		if (y < 0) {
			y = 0;
		}
		if (x < 0) {
			x = 0;
		}
		windowToCenter.setLocation(x, y);
	}
}
