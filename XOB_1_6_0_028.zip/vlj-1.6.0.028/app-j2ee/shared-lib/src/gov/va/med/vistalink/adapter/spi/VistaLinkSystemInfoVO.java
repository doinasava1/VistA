package gov.va.med.vistalink.adapter.spi;

import java.util.HashMap;
import java.util.Map;

/**
 * This class represents a serialized repsonse to the VistaLinkSystemInfoRequest. The VistaLinkSystemInfoResponse class
 * represents the parsed version of the response.
 * <p>
 * The read only properties represent VistaLink system information for a M/VistA server.
 * <p>
 * This value object is needed becuase it must be serializable to go across JVMs for the admin console add-in.
 * 
 */
public class VistaLinkSystemInfoVO {

	//HashMap keys
	private static final String VL_VERSION = "vistalinkVersion";
	private static final String VL_BUILD = "vistalinkBuild";
	private static final String VL_APP_SRV_TIMEOUT = "appServerTimeout";
	private static final String VL_REAUTH_SESS_TIMEOUT = "reAuthSessionTimeout";
	private static final String VL_UCI = "uci";
	private static final String VL_VOL = "vol";
	private static final String VL_BOX_VOL = "boxVolume";
	private static final String VL_M_VERSION = "mVersion";
	private static final String VL_OS = "operatingSystem";
	private static final String VL_DOMAIN_NAME = "domainName";
	private static final String VL_PRODUCTION = "vistaProduction";
	private static final String VL_DEFAULT_INST = "defaultInstitution";
	private static final String VL_INTRO_TEXT = "introductoryText";
	private static final String VL_CP_USERNAME = "cpName";
	private static final String VL_ERROR_MESSAGE = "mErrorMessage";

	/**
	 * The VistaLink version on the M/VistA server
	 */
	private String vistalinkVersion;

	/**
	 * The Vista Kernel setting for whether the account is production or test
	 */
	private String vistaProduction;

	/**
	 * The default institution for the remote system from the Kernel System Parameters file.
	 */
	private String defaultInstitution;

	/**
	 * The VistaLink build number on the M/VistA server
	 */
	private String vistalinkBuild;

	/**
	 * The application server connection timeount (in milliseconds) set on the M/VistA server
	 */
	private long appServerTimeout;

	/**
	 * The application server reauthenticated session timeout (in milliseconds) set on the M/VistA server
	 */
	private long reAuthSessionTimeout;

	/**
	 * The uci name of M/VistA server
	 */
	private String uci;

	/**
	 * The volume name of M/VistA server
	 */
	private String vol;

	/**
	 * The box-volume name of M/VistA server
	 */
	private String boxVolume;

	/**
	 * The M version name of M/VistA server
	 */
	private String mVersion;

	/**
	 * The operating system on which the M/VistA server runs under
	 */
	private String operatingSystem;

	/**
	 * The domain name of M/VistA server
	 */
	private String domainName;

	/**
	 * Location for object user to stash an error message when returning this object
	 */
	private String errorMessage;

	/**
	 * c/p username
	 */
	private String cpName;

	private String introText;

	/**
	 * no-arg constructor
	 */
	public VistaLinkSystemInfoVO() {
		super();
	}

	/**
	 *  
	 */
	public VistaLinkSystemInfoVO(Map mSystemInfoMap) {
		super();

		// populate properties
		this.vistalinkVersion = (String) mSystemInfoMap.get(VL_VERSION);
		this.vistalinkBuild = (String) mSystemInfoMap.get(VL_BUILD);
		this.appServerTimeout = ((Long) mSystemInfoMap.get(VL_APP_SRV_TIMEOUT)).longValue();
		this.reAuthSessionTimeout = ((Long) mSystemInfoMap.get(VL_REAUTH_SESS_TIMEOUT)).longValue();
		this.uci = (String) mSystemInfoMap.get(VL_UCI);
		this.vol = (String) mSystemInfoMap.get(VL_VOL);
		this.boxVolume = (String) mSystemInfoMap.get(VL_BOX_VOL);
		this.mVersion = (String) mSystemInfoMap.get(VL_M_VERSION);
		this.operatingSystem = (String) mSystemInfoMap.get(VL_OS);
		this.domainName = (String) mSystemInfoMap.get(VL_DOMAIN_NAME);
		this.vistaProduction = (String) mSystemInfoMap.get(VL_PRODUCTION);
		this.defaultInstitution = (String) mSystemInfoMap.get(VL_DEFAULT_INST);
		this.introText = (String) mSystemInfoMap.get(VL_INTRO_TEXT);
		this.cpName = (String) mSystemInfoMap.get(VL_CP_USERNAME);
		this.errorMessage = (String) mSystemInfoMap.get(VL_ERROR_MESSAGE);

	}

	public Map toMap() {
	
		HashMap mSystemInfoMap = new HashMap();
		
		mSystemInfoMap.put(VL_VERSION, getVistalinkVersion());
		mSystemInfoMap.put(VL_BUILD, getVistalinkBuild());
		mSystemInfoMap.put(VL_APP_SRV_TIMEOUT, Long.valueOf(getAppServerTimeout()));
		mSystemInfoMap.put(VL_REAUTH_SESS_TIMEOUT, Long.valueOf(getReAuthSessionTimeout()));
		mSystemInfoMap.put(VL_UCI, getUci());
		mSystemInfoMap.put(VL_VOL, getVol());
		mSystemInfoMap.put(VL_BOX_VOL, getBoxVolume());
		mSystemInfoMap.put(VL_M_VERSION, getMumpsVersion());
		mSystemInfoMap.put(VL_OS, getOperatingSystem());
		mSystemInfoMap.put(VL_DOMAIN_NAME, getDomainName());
		mSystemInfoMap.put(VL_PRODUCTION, getVistaProduction());
		mSystemInfoMap.put(VL_DEFAULT_INST, getDefaultInstitution());
		mSystemInfoMap.put(VL_INTRO_TEXT, getIntroText());
		mSystemInfoMap.put(VL_CP_USERNAME, getCpName());
		mSystemInfoMap.put(VL_ERROR_MESSAGE, this.getErrorMessage());

		return mSystemInfoMap;
	}

	/**
	 * @return Returns the vistalinkVersion.
	 */
	public String getVistalinkVersion() {
		return vistalinkVersion;
	}

	/**
	 * @return Returns the vistalinkBuild.
	 */
	public String getVistalinkBuild() {
		return vistalinkBuild;
	}

	/**
	 * @return Returns whether the remote M system is Production (true | false | unknown)
	 */
	public String getVistaProduction() {
		return this.vistaProduction;
	}

	/**
	 * @return Returns the default institution (station#) for the M system.
	 */
	public String getDefaultInstitution() {
		return this.defaultInstitution;
	}

	/**
	 * @return Returns the reauthenticated session time out
	 */
	public long getReAuthSessionTimeout() {
		return reAuthSessionTimeout;
	}

	/**
	 * @return Returns the uci name
	 */
	public String getUci() {
		return uci;
	}

	/**
	 * @return Returns the vol name
	 */
	public String getVol() {
		return vol;
	}

	/**
	 * @return Returns the box-volume name
	 */
	public String getBoxVolume() {
		return boxVolume;
	}

	/**
	 * @return Returns the M version name
	 */
	public String getMumpsVersion() {
		return mVersion;
	}

	/**
	 * Returns the operating system name
	 * 
	 * @return long
	 */
	public String getOperatingSystem() {
		return operatingSystem;
	}

	/**
	 * @return Returns the domainName.
	 */
	public String getDomainName() {
		return domainName;
	}

	/**
	 * @return Returns an errorMessage store in the VO by the user of the VO.
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * @param errorMessage
	 *            The errorMessage to set.
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	/**
	 * @return Returns the introText.
	 */
	public String getIntroText() {
		return introText;
	}

	/**
	 * 
	 * @return Returns the introText but with &lt;BR&gt; characters replaced with line breaks instead
	 */
	public String getIntroTextReplaceBrWithLineBreak() {

		String returnVal = null;
		if (introText != null) {
			String[] splitStr = introText.split("<BR>");
			StringBuffer sb = new StringBuffer();
			for (int i = 0; i < splitStr.length; i++) {
				sb.append(splitStr[i]);
				sb.append('\n');
			}
			returnVal = sb.toString();
		}
		return returnVal;
	}

	/**
	 * @param introText
	 *            The introText to set.
	 */
	public void setIntroText(String introText) {
		this.introText = introText;
	}

	/**
	 * @return connector proxy username
	 */
	public String getCpName() {
		return this.cpName;
	}

	/**
	 * @param cpName
	 *            connector proxy username
	 */
	public void setCpName(String cpName) {
		this.cpName = cpName;
	}

	public String toString() {
		return "VistaLink version: '" + vistalinkVersion + "' build: '" + vistalinkBuild
				+ "' Application Server Timeout: '" + appServerTimeout + "' UCI: '" + uci + "' VOL: '" + vol
				+ "' BOX-VOLUME: '" + boxVolume + "' M Version: ' " + mVersion + "' Operating System: '"
				+ operatingSystem + "' Domain: " + domainName + "' Production: '" + vistaProduction
				+ "' Default Institution Station#: '" + defaultInstitution + "'";
	}

	public void setBoxVolume(String boxVolume) {
		this.boxVolume = boxVolume;
	}

	public void setDefaultInstitution(String defaultInstitution) {
		this.defaultInstitution = defaultInstitution;
	}

	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	public void setMVersion(String version) {
		mVersion = version;
	}

	public void setOperatingSystem(String operatingSystem) {
		this.operatingSystem = operatingSystem;
	}

	public void setReAuthSessionTimeout(long reAuthSessionTimeout) {
		this.reAuthSessionTimeout = reAuthSessionTimeout;
	}

	public void setUci(String uci) {
		this.uci = uci;
	}

	public void setVistalinkBuild(String vistalinkBuild) {
		this.vistalinkBuild = vistalinkBuild;
	}

	public void setVistalinkVersion(String vistalinkVersion) {
		this.vistalinkVersion = vistalinkVersion;
	}

	public void setVistaProduction(String vistaProduction) {
		this.vistaProduction = vistaProduction;
	}

	public void setVol(String vol) {
		this.vol = vol;
	}

	/**
	 * @return Returns the application server connection listener time out
	 */
	public long getAppServerTimeout() {
		return appServerTimeout;
	}

	public void setAppServerTimeout(long appSeverTimeout) {
		this.appServerTimeout = appSeverTimeout;
	}
}