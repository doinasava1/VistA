package gov.va.med.vistalink.security;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.UnsupportedCallbackException;

/**
 * Abstract class that implements the JAAS CallbackHandler interface. It is the base class for all callback
 * handlers used in the VistaLink login module security package. 
  *
 * @see VistaLoginModule
 * @see CallbackHandlerSwing
 * @see CallbackHandlerSwingCCOW
 * @see CallbackHandlerUnitTest
 */
abstract class CallbackHandlerBase implements CallbackHandler {

	/**
	* Instantiates a JAAS callback handler for Swing applications. 
	*/
	CallbackHandlerBase() {
	}

	/**
	 * @see javax.security.auth.callback.CallbackHandler#handle(Callback[] callbacks)
	 */
	public void handle(Callback[] callbacks) throws UnsupportedCallbackException {

		for (int i = 0; i < callbacks.length; i++) {

			if (callbacks[i] instanceof CallbackChangeVc) {

				doCallbackChangeVc((CallbackChangeVc) callbacks[i]);

			} else if (callbacks[i] instanceof CallbackConfirm) {

				doCallbackConfirm((CallbackConfirm) callbacks[i]);

			} else if (callbacks[i] instanceof CallbackLogon) {

				doCallbackLogon((CallbackLogon) callbacks[i]);

			} else if (callbacks[i] instanceof CallbackSelectDivision) {

				doCallbackSelectDivision((CallbackSelectDivision) callbacks[i]);

			} else if (callbacks[i] instanceof CallbackCommit) {

				doCallbackCommit((CallbackCommit) callbacks[i]);

			} else {

				doUnsupportedCallback(callbacks[i]);
			}
		}
	}

	/**
	 * Does the change verify code callback
	 * @param cvcCallback change verify code callback
	 */
	abstract void doCallbackChangeVc(CallbackChangeVc cvcCallback) throws UnsupportedCallbackException;

	/**
	 * Does the confirm callback
	 * @param confirmCallback confirm callback
	 */
	abstract void doCallbackConfirm(CallbackConfirm confirmCallback);
	/**
	 * Does the logon callback
	 * @param logonCallback
	 */
	abstract void doCallbackLogon(CallbackLogon logonCallback);

	/**
	 * Does the select division callback
	 * @param divisionCallback
	 */
	abstract void doCallbackSelectDivision(CallbackSelectDivision divisionCallback);

	/**
	 * Does the commit callback
	 * @param commitCallback
	 */
	abstract void doCallbackCommit(CallbackCommit commitCallback);

	/**
	 * processes unsupported callbacks
	 * @param callback the unsupported callback
	 * @throws UnsupportedCallbackException thrown as part of the processing of an unsupported callback
	 */
	abstract void doUnsupportedCallback(Callback callback) throws UnsupportedCallbackException;

}
