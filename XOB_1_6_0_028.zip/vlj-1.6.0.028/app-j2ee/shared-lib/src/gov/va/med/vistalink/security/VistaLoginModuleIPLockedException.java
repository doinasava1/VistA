package gov.va.med.vistalink.security;

/**
 * If thrown, the user's IP has been locked due to too many times with invalid credentials. When attempting a logon, you
 * can trap for this specific exception, in addition to the more general <code>VistaLoginModuleException</code> and
 * <code>LoginException</code> exceptions.
 * 
 */
public final class VistaLoginModuleIPLockedException extends VistaLoginModuleException {

	/**
	 * @param msg
	 *            Exception message
	 * @see java.lang.Throwable#Throwable(String)
	 */
	VistaLoginModuleIPLockedException(String msg) {
		super(msg);
	}

	/**
	 * @param nestedException
	 *            exception to nest in new VistaLoginModuleException
	 */
	VistaLoginModuleIPLockedException(Throwable nestedException) {
		super(nestedException);
	}

	/**
	 * @param msg
	 *            String exception message
	 * @param nestedException
	 *            exception to nest in new VistaLoginModuleException
	 */
	VistaLoginModuleIPLockedException(String msg, Throwable nestedException) {
		super(msg, nestedException);
	}

}