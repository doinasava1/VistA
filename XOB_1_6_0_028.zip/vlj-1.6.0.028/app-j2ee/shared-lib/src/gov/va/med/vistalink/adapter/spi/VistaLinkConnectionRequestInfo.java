package gov.va.med.vistalink.adapter.spi;

import gov.va.med.vistalink.adapter.cci.VistaLinkConnectionSpec;
import gov.va.med.vistalink.adapter.cci.VistaLinkResourceException;

import javax.resource.cci.ConnectionSpec;
import javax.resource.spi.ConnectionRequestInfo;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

/**
 * The connection request info class that is used internally to encapsulate
 * the various connection spec(re-authentication mechanisms)
 * 
 */
public class VistaLinkConnectionRequestInfo implements ConnectionRequestInfo {

	private static final Logger logger =
		Logger.getLogger(VistaLinkConnectionRequestInfo.class);

	private VistaLinkConnectionSpec connectionSpec;

	public VistaLinkConnectionRequestInfo(ConnectionSpec connectionSpec) throws VistaLinkResourceException {


		if (logger.isDebugEnabled()) {
			logger.debug("Constructing request info");
		}
		
		if (connectionSpec instanceof VistaLinkConnectionSpec){		
			this.connectionSpec =  
				(VistaLinkConnectionSpec) connectionSpec;
		}else{
			String errMsg = "the connection spec is not the right type";
			
			if (logger.isEnabledFor(Level.ERROR)) {
				logger.error(errMsg);
			}						
			
			throw new VistaLinkResourceException(errMsg);						
		}
		
	}

	public VistaLinkConnectionSpec getConnectionSpec() {

		return connectionSpec;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {

		return (new StringBuffer()).append(this.getClass().getName())
			.append("->")
			.append(connectionSpec.getClass().getName())
			.append("->")
			.append(connectionSpec.getSecurityType()).toString();
	}


	/*
	 *  (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object obj) {

		if (obj == null)
			return false;
		if (obj instanceof VistaLinkConnectionRequestInfo) {
			VistaLinkConnectionRequestInfo other = (VistaLinkConnectionRequestInfo) obj;
			
			return this.getConnectionSpec().equals(other.getConnectionSpec());
			
		} else {
			return false;
		}
	}

	/**
	 * return hashcode
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		// algorithm taken from "Effective Java" item #8.
		int HASHCODE_SEED = 17;
		int returnVal = HASHCODE_SEED;

		// connSpec contribution to hashcode
		int connSpecHashCode = this.connectionSpec.hashCode();
		returnVal = 37 * returnVal + connSpecHashCode; 

		return returnVal;
	}

}
