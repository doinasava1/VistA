package gov.va.med.vistalink.security.m;

import gov.va.med.vistalink.adapter.record.VistaLinkFaultException;

/**
 * Represents an authorization failure during a re-authentication attempt, e.g., DISUSER flag is set for
 * the re-authentication user, prohibited times of day is set, etc.
 */
public class SecurityUserAuthorizationException extends SecurityFaultException {

	/**
	 * @param vistaLinkFaultException
	 * @va.exclude
	 */
	public SecurityUserAuthorizationException(VistaLinkFaultException vistaLinkFaultException) {
		super(vistaLinkFaultException);
	}

}