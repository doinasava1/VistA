package gov.va.med.vistalink.adapter.record;

/**
 * This exception represents the case where on the M side 
 * there are no license slots available to start another process.
 * 
 */
public class NoJobSlotsAvailableFaultException
	extends VistaLinkFaultException {

	/**
	 * Constructor for NoJobSlotsAvailableFaultException.
	 * @param vistaLinkFaultException
	 * @va.exclude
	 */
	public NoJobSlotsAvailableFaultException(
		VistaLinkFaultException vistaLinkFaultException) {
		super(vistaLinkFaultException);
	}


}
