package gov.va.med.vistalink.security.m;

/**
 * Abstract base class for Logon-related value objects.
 * 
 */
public abstract class SecurityVO {

	// constants used to extract result type
	/**
	 * resulttype representing success.
	 */
	public static final int RESULT_SUCCESS = 1;
	/**
	 * resulttype representing failure.
	 */
	public static final int RESULT_FAILURE = 0;
	/**
	 * resulttype representing partial success.
	 */
	public static final int RESULT_PARTIAL = 2;
	
	private int resultType;
	private String resultMessage;
	
	/**
	 * Constructor.
	 * @param resultType Success, Failure or Partial Success (types defined in parent class) 
	 * @param resultMessage optional explanatory description for the result, usually used for failure and partial success only
	 */
	public SecurityVO(int resultType, String resultMessage) {
		this.resultType = resultType;
		this.resultMessage = resultMessage;
	}
	/**
	 * Result type -- sucessful, partially successful or failure.
	 * <ul>
	 * <li>RESULT_SUCCESS is returned if operation was successful
	 * <li>RESULT_FAILURE if operation was unsuccessful
	 * <li>RESULT_PARTIAL is returned only for:
	 * <ul><li>logon calls (if logon was successful but user needs to change verify code or select division)
	 * <li>change verify code calls (if the change verify code succeeded but the user needs to select division)
	 * </ul>
	 * </ul>
	 * @return int RESULT_SUCCESS, RESULT_FAILURE or RESULT_PARTIAL.
	 */
	public int getResultType() {
		return this.resultType;
	}
	
	/**
	 * Sets the result type.
	 * @param resultType
	 */
	public void setResultType(int resultType) {
		this.resultType = resultType;
	}
	/**
	 * Gets any message associated with the result type.
	 * @return String
	 */
	public String getResultMessage() {
		return resultMessage;
	}
	/**
	 * Sets any message associated with the result type. Usually only partially succesful and failure result types
	 * have a message associated with them.
	 * @param resultMessage message to associate with/explain the result type.
	 */
	public void setResultMessage(String resultMessage) {
		this.resultMessage = resultMessage;
	}
}
