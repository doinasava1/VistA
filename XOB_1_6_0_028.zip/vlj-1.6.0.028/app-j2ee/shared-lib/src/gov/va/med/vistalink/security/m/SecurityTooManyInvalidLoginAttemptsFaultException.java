package gov.va.med.vistalink.security.m;

import gov.va.med.vistalink.adapter.record.VistaLinkFaultException;

/**
 * This exception fault is returned from M, and signifies that the user's login credentials were invalid too many times,
 * and the M system is rejecting further login attempts as a result. This fault exception will never be returned to an
 * application; instead, the application will be returned a
 * <code>VistaLoginModuleTooManyInvalidAttemptsException</code>.
 * 
 */
public final class SecurityTooManyInvalidLoginAttemptsFaultException extends SecurityFaultException {

	/**
	 * Constructor
	 * @param vistaLinkFaultException the exception to copy into a new exception type
	 * @va.exclude
	 */
	public SecurityTooManyInvalidLoginAttemptsFaultException(VistaLinkFaultException vistaLinkFaultException) {
		super(vistaLinkFaultException);
	}

}
