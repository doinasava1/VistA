package gov.va.med.vistalink.adapter.cci;

import java.util.ArrayList;

import javax.resource.cci.ConnectionSpec;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

/**
 * This interface defined the common properties needed by any connection spec
 * implementation.
 * <p>
 * It identifies the most common property(s): Currently, division.
 * <p>
 * The sub-classes should extend if there are more properties.
 * 
 */
public interface VistaLinkConnectionSpec extends ConnectionSpec {
	/**
	 * Returns the division of this ConnectionSpec.
	 * 
	 * @return the division, in String
	 */
	String getDivision();

	/**
	 * Sets the division
	 * 
	 * @param division
	 *            the division number to be set
	 */
	void setDivision(String division);

	/**
	 * creates the xml in the security node
	 * 
	 * @param requestDoc
	 *            the Document object that contains the nodes
	 * @param securityNode
	 *            the node to create the XML under
	 * @va.exclude
	 */
	void setAuthenticationNodes(Document requestDoc, Node securityNode);

	/**
	 * clears the information in the security node
	 * 
	 * @param securityNode
	 *            the node to clear
	 * @va.exclude
	 */
	void clearSecurityNode(Node securityNode);

	/**
	 * Gets the security information as a proprietary string
	 * 
	 * @return Security info
	 * @va.exclude
	 */
	ArrayList getProprietarySecurityInfo();

	/**
	 * Compares two objects to see if they are equal
	 * @param obj
	 *            the object to compare
	 * @va.exclude
	 * @deprecated Use equals() method.
	 */
	boolean isConnSpecEqual(Object obj);

	/**
	 * returns the security mechanism type
	 * 
	 * @va.exclude
	 */
	String getSecurityType();

}