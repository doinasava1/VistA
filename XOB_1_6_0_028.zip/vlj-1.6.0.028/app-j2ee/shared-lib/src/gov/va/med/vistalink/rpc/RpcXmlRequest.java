package gov.va.med.vistalink.rpc;

import gov.va.med.crypto.VistaKernelHash;
import gov.va.med.exception.ExceptionUtils;
import gov.va.med.exception.FoundationsException;
import gov.va.med.vistalink.adapter.cci.VistaLinkConnectionSpecImpl;
import gov.va.med.vistalink.adapter.spi.EMReAuthState;
import gov.va.med.xml.XmlUtilities;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.w3c.dom.Attr;
import org.w3c.dom.CDATASection;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

/**
 * Used by RpcRequest to generate XML request strings when non-proprietary (XML) communication mode is in use.
 * 
 */
class RpcXmlRequest {
	/**
	 * The logger used by this class
	 */
	private static final Logger logger = Logger.getLogger(RpcXmlRequest.class);

	/**
	 * The message type used for this Request
	 */
	static final String GOV_VA_MED_RPC_REQUEST = "gov.va.med.foundations.rpc.request";

	/**
	 * The parameters associated with the RPC that this request represents
	 */
	private RpcXmlRequestParams params;

	/**
	 * Identifies the name of the RPC to executed on the M server
	 */
	private Attr rpcName;

	/**
	 * Identifies the client time out for the RPC
	 */
	private Attr rpcClientTimeOut;

	/**
	 * Identifies the version of the RPC (USED FOR XOBAPVER)
	 */
	private Attr rpcVersion;

	/**
	 * Identifies the RpcContext
	 */
	private String rpcContext;

	/**
	 * Placeholder for node that identifies the security node
	 */
	private Node rpcSecurityNode;

	private Document requestDoc = null;

	/**
	 * @param requestDoc
	 * @param rpcContext
	 * @param rpcName
	 * @param rpcClientTimeOut
	 * @param params
	 * @throws FoundationsException
	 */
	RpcXmlRequest(Document requestDoc) throws FoundationsException {
		this.requestDoc = requestDoc;
		Node reqNode = XmlUtilities.getNode("/VistaLink/Request", requestDoc);
		// Setup rpcName
		this.rpcName = XmlUtilities.getAttr(reqNode, "rpcName");
		// Setup rpcClientTimeOut
		this.rpcClientTimeOut = XmlUtilities.getAttr(reqNode, "rpcClientTimeOut");
		// Setup rpcVersion
		this.rpcVersion = XmlUtilities.getAttr(reqNode, "rpcVersion");
		// Setup RPC params
		this.params = new RpcXmlRequestParams(requestDoc);
		// Setup security node
		this.rpcSecurityNode = XmlUtilities.getNode("/VistaLink/Request/Security", requestDoc);
	}

	/**
	 * Gets the reference to the {@link RpcRequestParams}object associated with this request.
	 * <p>
	 * This object contains the parameters sent with the call to the RPC during the getResponse() call. Use this object
	 * to set these parameters before calling getResponse().
	 * 
	 * @return RpcRequestParams
	 */
	RpcXmlRequestParams getParams() {
		return params;
	}

	/**
	 * Gets the name of the RPC.
	 * 
	 * @return String
	 */
	String getRpcName() {
		return rpcName.getValue();
	}

	/**
	 * Sets the name of the RPC to be called on the M server. The name must be a valid RPC name as it appears in the
	 * REMOTE PROCEDURE (#8994) file in M VistA.
	 * 
	 * @param value
	 */
	void setRpcName(String value) {
		rpcName.setValue(value);
	}

	/**
	 * Gets the name of the RPC Context.
	 * 
	 * @return String
	 */
	String getRpcContext() {
		return rpcContext;
	}

	/**
	 * Sets the name of the RPC Context to be used. The name must be a valid B- type OPTION name as it appears in the
	 * OPTION (#19) file in M VistA.
	 * 
	 * @param value
	 * @throws FoundationsException
	 */
	void setRpcContext(String value) throws FoundationsException {
		try {
			rpcContext = value;
			Node node = XmlUtilities.getNode("/VistaLink/Request/RpcContext", requestDoc);
			String encryptedRpcContext = VistaKernelHash.encrypt(rpcContext, true);
			CDATASection cdata = requestDoc.createCDATASection(encryptedRpcContext);
			Node currentRpcContextNode = node.getFirstChild();
			if (currentRpcContextNode != null) {
				node.removeChild(currentRpcContextNode);
			}
			node.appendChild(cdata);

		} catch (FoundationsException e) {
			if (logger.isEnabledFor(Level.ERROR)) {
				logger.error((new StringBuffer()).append("Can not set RpcContext.").append("\n\t").append(
						ExceptionUtils.getFullStackTrace(e)).toString());
			}
			throw e;
		}
	}

	/**
	 * Gets the current client time out value. (Value is returned in the number of seconds).
	 * 
	 * @return int
	 */
	int getRpcClientTimeOut() {
		return Integer.parseInt(rpcClientTimeOut.getValue());
	}

	/**
	 * Sets the client time out value. (Value is expected in seconds.)
	 * 
	 * @param value
	 */
	void setRpcClientTimeOut(int value) {
		rpcClientTimeOut.setValue(String.valueOf(value));
	}

	/**
	 * Gets the current RPC version specified by application
	 * 
	 * @return Returns the rpcVersion.
	 */
	Attr getRpcVersion() {
		return rpcVersion;
	}

	/**
	 * Sets the RPC version number
	 * 
	 * Note: Like parameters, it is up to the application code to set this property appropriately for each RPC request
	 * made using the RpcRequest instance.
	 * 
	 * To unset to default, set property to 0 (zero).
	 * 
	 * @param value The rpcVersion to set.
	 */
	void setRpcVersion(double value) {
		rpcVersion.setValue(String.valueOf(value));
	}

	/**
	 * 
	 * @param connSpec
	 * @param reAuthState
	 * @param theAdapterEnvironment
	 * @va.exclude
	 */
	void setReAuthenticateInfo(VistaLinkConnectionSpecImpl connSpec) {
		if (logger.isDebugEnabled()) {
			logger.debug("Setting re-authentication information in request document");
		}
		if (connSpec != null) {
			connSpec.clearSecurityNode(rpcSecurityNode);
			connSpec.setSecurityTypeAttr(rpcSecurityNode);
			connSpec.setSecurityStateAttr(rpcSecurityNode);
			if (!connSpec.getSecurityState().equals(EMReAuthState.AUTHENTICATED)) {
				connSpec.setAuthenticationNodes(requestDoc, rpcSecurityNode);
			}
		} else {
			if (logger.isDebugEnabled()) {
				logger.debug("the conn spec is null!!!");
			}
		}
	}

	/**
	 * Returns request XML data as a String.
	 * 
	 * @see gov.va.med.vistalink.adapter.record.VistaLinkRequestVO#getRequestString()
	 */
	String getRequestString() throws FoundationsException {
		if (requestDoc == null) {
			String errStr = "Can not return request String as requestDoc == null. Make sure to initialize Request appropriately.";
			FoundationsException e = new FoundationsException(errStr);
			if (logger.isEnabledFor(Level.ERROR)) {
				String errMsg = ExceptionUtils.getFullStackTrace(e);
				logger.error(errMsg);
			}
			throw e;
		}
		String xmlString = "";
		try {
			xmlString = XmlUtilities.convertXmlToStr(requestDoc);
		} catch (FoundationsException e) {
			if (logger.isEnabledFor(Level.ERROR)) {
				String errMsg = (new StringBuffer()).append("Converting requestDoc to XML String failed.").append(
						"\n\t").append(ExceptionUtils.getFullStackTrace(e)).toString();
				logger.error(errMsg);
			}
			throw e;
		}
		return xmlString;
	}
}
