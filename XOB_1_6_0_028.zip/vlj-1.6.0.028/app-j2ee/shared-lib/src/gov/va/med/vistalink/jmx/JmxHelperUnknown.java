package gov.va.med.vistalink.jmx;

import javax.management.MBeanServer;

/**
 * Generic (placeholder)-specific JMX object retrieval methods.
 * 
 */
public final class JmxHelperUnknown implements IJmxHelper {

	private static final String NOT_SUPPORTED_STR = "not supported.";
	
	/**
	 * protected constructor enforces direct non-instantiability
	 *
	 */
	protected JmxHelperUnknown() {
		super();
	}
	
	/*
	 *  (non-Javadoc)
	 * @see gov.va.med.vistalink.jmx.IJmxHelper#getLocalServerIdentifierForServerHelper()
	 */
	public String getServerObjectNamePropertiesForRegistration() {
		throw new UnsupportedOperationException(NOT_SUPPORTED_STR);
	}

	/* (non-Javadoc)
	 * @see gov.va.med.vistalink.jmx.IJmxHelper#getLocalMBeanServer()
	 */
	public MBeanServer getLocalMBeanServer() {
		throw new UnsupportedOperationException(NOT_SUPPORTED_STR);
	}

	/*
	 *  (non-Javadoc)
	 * @see gov.va.med.vistalink.jmx.IJmxHelper#getActiveDomainName()
	 */
	public String getJmxDomainForPlatform() {
		throw new UnsupportedOperationException(NOT_SUPPORTED_STR);
	}

	/*
	 *  (non-Javadoc)
	 * @see gov.va.med.vistalink.jmx.IJmxHelper#getJmxDomainForHevMBeans()
	 */
	public String getJmxDomainForHev() {
		return JmxHelperFactory.JMX_DOMAIN_NAME_FOR_HEV_MBEANS;
	}

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.jmx.IJmxHelper#getDomainName()
	 */
	public String getComputingDomainName() throws JmxHelperException {
		throw new UnsupportedOperationException(NOT_SUPPORTED_STR);
	}
}
