package gov.va.med.vistalink.institution;

/**
 * Business rules for primary station# validation and connector lookup by primary station for VHA systems.
 * <ul>
 * <li>RULE #1 (VHA stations) generally can be 3 digits or 5+ digits.
 * <li>RULE #2 (special for AAC) if has alpha suffix, numeric portion must be "200"
 * <li>RULE #3 (nursing homes) if numeric is 4 digits, 4th digit must be "9"
 * </ul>
 * 
 */
public class PrimaryStationRulesVHA implements IPrimaryStationRules {

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.institution.IPrimaryStationRules#getPrimaryStationLookupString(java.lang.String)
	 */
	public String getPrimaryStationLookupString(String division) throws InstitutionMappingBadStationNumberException {

		if (division == null)
			throw new InstitutionMappingBadStationNumberException("input cannot be null");
		if (division.length() < 1)
			throw new InstitutionMappingBadStationNumberException("input cannot be empty string");

		String returnVal = null;

		// get last digit position
		int nextDigitPosToTest = 0;
		while ((nextDigitPosToTest < division.length()) && (Character.isDigit(division.charAt(nextDigitPosToTest)))) {
			nextDigitPosToTest++;
		}
		// nextDigitPosToTest-1 has last digit position for first numeric portion of string
		int lastDigitPos = nextDigitPosToTest - 1;

		if ((lastDigitPos == 3) && (division.charAt(3) == '9')) {
			// RULE #3 (nursing homes) can be 4 digits if 4th digit is "9" -- truncate "9" and return first 3
			returnVal = division.substring(0, 3);
		} else if ((division.charAt(0) == '2') && (lastDigitPos == 2) && (division.length() > lastDigitPos)) {
			// RULE #2 (special for AAC) if numeric portion is "200"-series, can have non-numeric suffix (so don't
			// strip!)
			returnVal = division;
		} else if ((lastDigitPos == 2) || (lastDigitPos >= 4)) {
			// RULE #1 primary station portion of division for VHA stations generally can be 3 digits or 5+ digits.
			returnVal = division.substring(0, nextDigitPosToTest);
		} else {
			throw new InstitutionMappingBadStationNumberException("Invalid station number format: '" + division + "'.");
		}
		return returnVal;
	}

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.institution.IPrimaryStationRules#validatePrimaryStation(java.lang.String)
	 */
	public void validatePrimaryStation(String primaryStation) throws InstitutionMappingBadStationNumberException {

		if (primaryStation == null)
			throw new InstitutionMappingBadStationNumberException("input cannot be null");

		// get last digit position
		int nextDigitPosToTest = 0;
		while ((nextDigitPosToTest < primaryStation.length())
				&& (Character.isDigit(primaryStation.charAt(nextDigitPosToTest)))) {
			nextDigitPosToTest++;
		}
		// nextDigitPosToTest-1 has last successful position
		int lastDigitPos = nextDigitPosToTest - 1;

		// RULE #1 (VHA stations) must be at least 3 digits
		if (lastDigitPos < 2) {
			// i.e., less than 3 digits fails
			throw new InstitutionMappingBadStationNumberException("Station Number '" + primaryStation
					+ "' not valid; numeric portion must be at least 3 digits.");

		}

		// RULE #2 (special for AAC) if has alpha suffix, numeric portion must be "200"
		if ((lastDigitPos + 1) < primaryStation.length()) {
			// i.e., if has non-numeric suffix, has to be 3 digits with first digit == 2
			if (lastDigitPos != 2) {
				throw new InstitutionMappingBadStationNumberException("Station Number '" + primaryStation
						+ "' not valid; only stations in the 200 range can have a non-numeric suffix.");
			} else if (primaryStation.charAt(0) != '2') {
				throw new InstitutionMappingBadStationNumberException("Station Number '" + primaryStation
						+ "' not valid; only stations in the 200 range can have a non-numeric suffix.");
			}
		}

		// RULE #3 (nursing homes) if numeric is 4 digits, 4th digit must be "9"
		if (lastDigitPos == 3) {
			// i.e., if 4 digits, not legal, because 4th digit is regarded as a suffix if '9', or invalid otherwise
			if (primaryStation.charAt(3) == '9') {
				throw new InstitutionMappingBadStationNumberException(
						"Station Number '"
								+ primaryStation
								+ "' not valid; if 4th digit is '9', it is treated as a suffix and cannot be part of primary station #.");
			} else {
				throw new InstitutionMappingBadStationNumberException(
						"Station Number '"
								+ primaryStation
								+ "' not valid; 3 or 5+ digits only for VHA station #s.");
			}
		}
	}

}
