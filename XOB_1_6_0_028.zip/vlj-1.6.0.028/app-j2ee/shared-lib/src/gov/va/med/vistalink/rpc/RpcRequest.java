package gov.va.med.vistalink.rpc;

import gov.va.med.crypto.VistaKernelHash;
import gov.va.med.exception.ExceptionUtils;
import gov.va.med.exception.FoundationsException;
import gov.va.med.vistalink.adapter.cci.VistaLinkConnectionSpecImpl;
import gov.va.med.vistalink.adapter.record.VistaLinkRequestVOImpl;
import gov.va.med.vistalink.adapter.spi.EMAdapterEnvironment;
import gov.va.med.vistalink.adapter.spi.EMReAuthState;
import gov.va.med.vistalink.adapter.spi.VistaLinkManagedConnectionFactory;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

/**
 * Represents a RPC request to an M VistA server.
 * <p>
 * This is the principal class of VLJ used by developers to create and setup requests to the host M server.
 * <p>
 * J2SE Example:
 * <p>
 * <code>
 *      //request  and response objects<br> 
 *         RpcRequest vReq = null; <br>
 *         RpcResponse vResp = null;
 * <p>
 *         //The Rpc Context<br>
 *         String rpcContext = &quot;XOBV VISTALINK TESTER&quot;;
 * <p>        
 *         //The Rpc to call<br>
 *         String rpcName = &quot;XOBV TEST PING&quot;;
 * <p>         
 *          //Construct    the request object <br>
 *         vReq = RpcRequestFactory.getRpcRequest(rpcContext, rpcName);
 * <p>         
 *         //Execute the Rpc and get the response<br>
 *         vResp = myConnection.executeRPC(vReq);
 * <p>         
 *         //Work with the response ...
 * </code>
 * 
 */
public class RpcRequest extends VistaLinkRequestVOImpl {
    /**
     * The logger used by this class
     */
    private static final Logger logger = Logger.getLogger(RpcRequest.class);

    /**
     * Flag used to indicate that the HashMap key represents a multiple M subscript structure
     */
    private static final char MULTIPLE_M_SUBSRCIPT_FLAG = '\r';

    /**
     * The version of the RPC Handler on M
     */
    protected static final String RPC_HANDLER_VERSION = "1.6";

    /**
     * The name of the RPC that acts as a Sink for message sent with the proprietary format
     */
    private static final String SINK_NAME = "XOB RPC";

    /**
     * The padding used to delimit values in the proprietary message format
     */
    private static final String SINK_PAD = "00000";

    /**
     * The length of the SINK_PAD
     */
    private static final int SINK_PAD_LEN = SINK_PAD.length();

    /**
     * Identifies whether the request will be made using the proprietary message format or XML
     */
    private boolean useProprietaryMessageFormat = true;

    /**
     * Identifies whether debugging is on or off
     */
    private boolean debuggingOn = false;

    /**
     * The parameters associated with the RPC that this request represents
     */
    private RpcRequestParams params;

    /**
     * Identifies the name of the RPC to executed on the M server
     */
    private String rpcName;

    /**
     * Identifies the client time out for the RPC
     */
    private int rpcClientTimeOut;

    /**
     * Identifies the version of the RPC (USED FOR XOBAPVER)
     */
    private double rpcVersion = 0;

    /**
     * Identifies the RpcContext
     */
    private String rpcContext;

    /**
     * Identifies whether the response will be XML format
     */
    private boolean xmlResponse = false;

    private VistaLinkConnectionSpecImpl vlConnSpec;

    private EMAdapterEnvironment adapterEnvironment;
    
    /**
     * Comment for <code>requestStrBuf</code>
     * Used to store request string as it is being built
     */
    private StringBuffer requestStrBuf = new StringBuffer(200);

    /**
     * @param rpcContext
     * @param rpcName
     * @throws FoundationsException
     */
    protected RpcRequest(String rpcContext, String rpcName) throws FoundationsException { // leave FoundationsExecption
        // in for backwards
        // compatibility
        super(null);
        this.rpcContext = rpcContext;
        this.rpcName = rpcName;
        this.params = new RpcRequestParams();
    }

    /**
     * Gets the reference to the {@link RpcRequestParams}object associated with this request.
     * <p>
     * This object contains the parameters sent with the call to the RPC during the getResponse() call. Use this object
     * to set these parameters before calling getResponse().
     * 
     * @return RpcRequestParams
     */
    public RpcRequestParams getParams() {
        return params;
    }

    /**
     * Sets all the parameters for a RPC call at once using a List.
     * 
     * @param list
     */
    public void setParams(List list) {
        Object obj;
        for (int item = 0; item < list.size(); item++) {
            obj = list.get(item);
            if (obj instanceof Map || obj instanceof Collection) {
                params.setParam(item + 1, "array", obj);
            } else if (obj instanceof RpcReferenceType) {
                params.setParam(item + 1, "ref", obj);
            } else {
                params.setParam(item + 1, "string", obj);
            }
        }
    }

    /**
     * Builds and returns string that contains the following:
     * <ul>
     * <li>an indicator that the value represents a multiple M subscript structure</li>
     * <li>the actual multiple M subscript structure string value</li>
     * </ul>
     * 
     * @param keyValue
     *            Value representing the multiple M subscript structure
     * @return flagged key value to be used as HashMap key
     */
    public static String buildMultipleMSubscriptKey(String keyValue) {
        return MULTIPLE_M_SUBSRCIPT_FLAG + keyValue;
    }

    /**
     * Clears the params associated with this instance of RpcRequest
     */
    public void clearParams() {
        params.clear();
    }

    /**
     * Gets the name of the RPC.
     * 
     * @return String
     */
    public String getRpcName() {
        return rpcName;
    }

    /**
     * Sets the name of the RPC to be called on the M server. The name must be a valid RPC name as it appears in the
     * REMOTE PROCEDURE (#8994) file in M VistA.
     * 
     * @param value
     */
    public void setRpcName(String value) {
        rpcName = value;
    }

    /**
     * Gets the name of the RPC Context.
     * 
     * @return String
     */
    public String getRpcContext() {
        return rpcContext;
    }

    /**
     * Sets the name of the RPC Context to be used. The name must be a valid B- type OPTION name as it appears in the
     * OPTION (#19) file in M VistA.
     * 
     * @param value
     */
    public void setRpcContext(String value) {
        rpcContext = value;
    }

    /**
     * Gets the current client time out value. (Value is returned in the number of seconds).
     * 
     * @return int
     */
    public int getRpcClientTimeOut() {
        return rpcClientTimeOut;
    }

    /**
     * Sets the client time out value. (Value is expected in seconds.)
     * 
     * @param value
     */
    public void setRpcClientTimeOut(int value) {
        rpcClientTimeOut = value;
    }

    /**
     * Gets the current RPC version specified by application
     * 
     * @return Returns the rpcVersion.
     */
    public double getRpcVersion() {
        return rpcVersion;
    }

    /**
     * Sets the RPC version number
     * 
     * Note: Like parameters, it is up to the application code to set this property appropriately for each RPC request
     * made using the RpcRequest instance.
     * 
     * To unset to default, set property to 0 (zero).
     * 
     * @param value The RPC version to set.
     */
    public void setRpcVersion(double value) {
        rpcVersion = value;
    }

    /**
     * Gets the proprietary or xml (depending on setting) request string to be sent to the M server.
     * 
     * @return String
     * @throws FoundationsException
     */
    /* (non-Javadoc)
     * @see gov.va.med.vistalink.adapter.record.VistaLinkRequestVO#getRequestString()
     */
    public String getRequestString() throws FoundationsException {
        if (!this.isUseProprietaryMessageFormat()){
            return RpcXmlRequestFactory.getRpcXmlRequest(this).getRequestString();
        }
        requestStrBuf.delete(0,requestStrBuf.length());

        // set sink name ; must be in sync with message type on M server
        String lenSinkName = String.valueOf(SINK_NAME.length());
        requestStrBuf.append("00".substring(0, 2 - lenSinkName.length()) + lenSinkName + SINK_NAME);

        // send debugging byte
        if (this.debuggingOn) {
            requestStrBuf.append('1');
        } else {
            requestStrBuf.append('0');
        }

        // send length string size
        requestStrBuf.append(SINK_PAD_LEN);

        // send VistaLink version
        append("VLV", convert(VistaLinkManagedConnectionFactory.ADAPTER_VERSION));

        // send RpcHandler version
        append("RHV", convert(RPC_HANDLER_VERSION));

        // send RPC version
        append("RPV", convert(String.valueOf(rpcVersion)));

        // send RPC name
        append("RPC", convert(rpcName));

        // send RPC Context name
        try {
            append("RCX", convert(VistaKernelHash.encrypt(rpcContext, true)));
        } catch (FoundationsException e) {
            String errStr = "Can not encrypt rpcContext to be set to RCX.";

            if (logger.isEnabledFor(Level.ERROR)) {
                logger.error((new StringBuffer()).append(errStr).append("\n\t").append(
                        ExceptionUtils.getFullStackTrace(e)).toString());
            }

            throw new FoundationsException(errStr, e);
        }

        // send RPC Client Time Out
        append("RTO", convert(rpcClientTimeOut));

        if (this.adapterEnvironment.equals(EMAdapterEnvironment.J2EE)) {

            // ---------------------------- Security Info ------------------------------------------
            // send security type
            append("SEC", convert(vlConnSpec.getSecurityType()));

            // send division
            append("DIV", convert(vlConnSpec.getDivision()));

            // send reauthentication state
            EMReAuthState evaluatedAuthState = vlConnSpec.getSecurityState();
            append("RAS", convert(evaluatedAuthState.toString()));

            // send values need for re-authentication if not authenticated
            if (!evaluatedAuthState.equals(EMReAuthState.AUTHENTICATED)) {
                ArrayList values = vlConnSpec.getProprietarySecurityInfo();
                Iterator valueIter = values.iterator();

                while (valueIter.hasNext()) {
                    append("RAS", convert((String) valueIter.next()));
                }
            }

        } else if (this.adapterEnvironment.equals(EMAdapterEnvironment.J2SE)) {

            // ---------------------------- Security Info -------------------------------------
            // send security type
            append("SEC", convert(vlConnSpec.getSecurityType()));

            // send division
            append("DIV", convert(""));

            // send reauthentication state
            EMReAuthState evaluatedAuthState = EMReAuthState.AUTHENTICATED;
            append("RAS", convert(evaluatedAuthState.toString()));

        }

        int paramCount = params.getParams().size();
        RpcRequestParam param = null;
        String position;
        Object value = null;
        append("PMS", convert(paramCount));

        // send parameters
        for (int i = 0; i < paramCount; i++) {
            position = String.valueOf(i + 1);
            if (params.getParams().containsKey(position)) {
                param = (RpcRequestParam) params.getParams().get(position);
                value = param.getValue();
                if (value instanceof Map) {
                    doMap((Map) value, position);
                } else if (value instanceof Set) {
                    doCollection((Set) value, position);
                } else if (value instanceof List) {
                    doCollection((List) value, position);
                } else {
                    append("TYP", convert(param.getType()));
                    append("POS", convert(position));
                    append("VAL", convert((String) value.toString()));
                }
            }
        }
        return requestStrBuf.toString();
    }

    private void doMap(Map value, String position) {
        append("TYP", convert("array"));
        append("POS", convert(position));
        // indicate how many items in the array
        append("ITS", convert(value.size()));
        Iterator it = value.entrySet().iterator();

        while (it.hasNext()) {
            Map.Entry me = (Map.Entry) it.next();
            append("SUB", convert(me.getKey().toString()));
            append("VAL", convert(me.getValue().toString()));
        }
    }

    private void doCollection(Collection value, String position){
        append("TYP", convert("array"));
        append("POS", convert(position));
        // indicate how many items in the array
        append("ITS", convert(value.size()));
        int item = 0;
        Iterator it = value.iterator();
        while (it.hasNext()) {
            append("SUB", convert(String.valueOf(++item)));
            append("VAL", convert(it.next().toString()));
        }        
    }

    /**
     * Helper method to concatenate strings
     * 
     * @param label
     * @param value
     * @param sb
     */
    private void append(String label, String value) {
        if (this.debuggingOn) {
            requestStrBuf.append(label).append('=').append(value);
        } else {
            requestStrBuf.append(value);
        }
    }

    /**
     * Converts a string to a proprietary formatted string
     * 
     * @param str
     * @return String
     */
    private String convert(String str) {
        String lenStr = String.valueOf(str.length());
        return SINK_PAD.substring(0, SINK_PAD_LEN - lenStr.length()) + lenStr + str;
    }

    /**
     * Converts an int to a proprietary formatted string
     * 
     * @param cnt
     * @return String
     */
    private String convert(int cnt) {
        String lenStr = String.valueOf(String.valueOf(cnt).length());
        return SINK_PAD.substring(0, SINK_PAD_LEN - lenStr.length()) + lenStr + cnt;
    }

    /**
     * Indicates whether the returned value from the RPC call is expected in XML format or not.
     * 
     * @return boolean
     */
    public boolean isXmlResponse() {
        return xmlResponse;
    }

    /**
     * Sets the indicator that the returned value from the RPC call is expected in XML format or not.
     * 
     * @param value
     *            Whether XML is the expected type of result to be returned.
     */
    public void setXmlResponse(boolean value) {
        this.xmlResponse = value;
    }

    /**
     * Indicates whether the RPC request should be sent to the M server in a proprietary format (true) or in XML format
     * (false).
     * 
     * @return boolean
     * @deprecated For internal testing only!
     */
    public boolean isUseProprietaryMessageFormat() {
        return useProprietaryMessageFormat;
    }

    /**
     * Set the indicator that the RPC request should be sent to the M server in a proprietary format (true) or in XML
     * format (false). 
     * 
     * @param useSink
     */
    public void setUseProprietaryMessageFormat(boolean useSink) {
        this.useProprietaryMessageFormat = useSink;
    }

    /**
     * 
     * @param connSpec
     * @param reAuthState
     * @param theAdapterEnvironment
     * @va.exclude
     */
    public void setReAuthenticateInfo(VistaLinkConnectionSpecImpl connSpec, EMReAuthState reAuthState,
            EMAdapterEnvironment theAdapterEnvironment) {
        if (logger.isDebugEnabled()) {
            logger.debug("Setting re-authentication information");
        }
        this.adapterEnvironment = theAdapterEnvironment;
        this.vlConnSpec = null;
        if (connSpec != null) {
            this.vlConnSpec = connSpec;
            this.vlConnSpec.setSecurityState(reAuthState);
        } else {
            if (logger.isDebugEnabled()) {
                logger.debug("the conn spec is null!!!");
            }
        }
    }
    /**
     * @return Returns the adapterEnvironment.
     */
    EMAdapterEnvironment getAdapterEnvironment() {
        return adapterEnvironment;
    }
    /**
     * @return Returns the vlConnSpec.
     */
    VistaLinkConnectionSpecImpl getVlConnSpec() {
        return vlConnSpec;
    }
}