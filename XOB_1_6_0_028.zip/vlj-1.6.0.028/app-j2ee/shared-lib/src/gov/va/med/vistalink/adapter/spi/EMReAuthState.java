package gov.va.med.vistalink.adapter.spi;

/**
 * Enumeration class to enumerate re-authentication states
 * 
 */
public class EMReAuthState {

	/**
	 * the integer value of the re-authentication state
	 */
	private final int reAuthState;

	/**
	 * the string representation of the re-authentication state
	 */
	private final String reAuthStateStringValue;

	/**
	 * Integer value that represents an authenticated re-authenticated state
	 */
	private static final int INT_AUTHENTICATED = 1;

	/**
	 * Integer value that represents a non-authenticated re-authentication state
	 */
	private static final int INT_NOTAUTHENTICATED = 2;

	/**
	 * Integer value that represents a virgin state for re-authentication
	 */
	private static final int INT_VIRGIN = 0;

	/**
	 * String representation of an authenticated re-authentication state
	 */
	private static final String STRING_AUTHENTICATED = "authenticated";

	/**
	 * String representation of a non-authenticated re-authentication state
	 */
	private static final String STRING_NOTAUTHENTICATED = "notauthenticated";

	/**
	 * String representation of a virgin state for re-authentication
	 */
	private static final String STRING_VIRGIN = "virgin";

	/**
	 * represents an authenticated re-authentication state
	 */
	public static final EMReAuthState AUTHENTICATED = new EMReAuthState(INT_AUTHENTICATED);

	/**
	 * represents a non-authenticated re-authentication state
	 */
	public static final EMReAuthState NOTAUTHENTICATED = new EMReAuthState(INT_NOTAUTHENTICATED);

	/**
	 * represents a virgin state for re-authentication
	 */
	public static final EMReAuthState VIRGIN = new EMReAuthState(INT_VIRGIN);

	/**
	 * private Constructor
	 * 
	 * @param reAuthState -
	 *            the authentication state
	 */
	private EMReAuthState(int reAuthState) {
		this.reAuthState = reAuthState;

		String stringReAuthState = null;

		switch (reAuthState) {
		case INT_AUTHENTICATED:
			stringReAuthState = STRING_AUTHENTICATED;
			break;
		case INT_NOTAUTHENTICATED:
			stringReAuthState = STRING_NOTAUTHENTICATED;
			break;
		case INT_VIRGIN:
			stringReAuthState = STRING_VIRGIN;
			break;
		default:
			stringReAuthState = null;
			break;
		}

		reAuthStateStringValue = stringReAuthState;

	}

	/**
	 * Gets the integer value of the authentication state. Used internally for
	 * comparisons.
	 * 
	 * @return integer value
	 */
	private int getValue() {

		return reAuthState;

	}

	/*
	 * (non-Javadoc) returns string representation of re-authentication state
	 * 
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return reAuthStateStringValue;
	}

	/*
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object obj) {
		if (obj instanceof EMReAuthState) {
			return (boolean) ((((EMReAuthState) obj).getValue()) == (this.getValue()));
		} else {
			return false;
		}
	}

	/**
	 * return hashcode
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		// algorithm taken from "Effective Java" item #8.
		int HASHCODE_SEED = 17;
		int returnVal = HASHCODE_SEED;

		// getValue() contribution to hashcode
		int valueHashCode = getValue();
		returnVal = 37 * returnVal + valueHashCode; 

		return returnVal;
	}

}