package gov.va.med.vistalink.adapter.spi;

import javax.resource.ResourceException;
import javax.resource.spi.ManagedConnectionMetaData;

/**
 * This class gives info about a VistaLinkManagedConnection
 * 
 */
public class VistaLinkManagedConnectionMetaData implements ManagedConnectionMetaData {

	/**
	 * The managed connection that this class gives information about
	 */
	private VistaLinkManagedConnection managedConnection;

	/**
	 * This adapters product name
	 */
	private String eisProductName = "VistALink J2M Adapter";

	/**
	 * This adapters version number
	 */
	private String eisProductVersion = "1.6.0";

	/**
	 * Not used
	 */
	private String userName = "";

	/**
	 * Constructor
	 * 
	 * @param mc
	 */
	public VistaLinkManagedConnectionMetaData(VistaLinkManagedConnection mc) {
		managedConnection = mc;
	}

	/**
	 * Returns Product name of the underlying EIS instance connected through the
	 * ManagedConnection
	 * 
	 * @see javax.resource.spi.ManagedConnectionMetaData#getEISProductName()
	 */
	public String getEISProductName() throws ResourceException {
		return eisProductName;
	}

	/**
	 * Returns product version of the underlying EIS instance connected through
	 * the ManagedConnection
	 * 
	 * @see javax.resource.spi.ManagedConnectionMetaData#getEISProductVersion()
	 */
	public String getEISProductVersion() throws ResourceException {
		return eisProductVersion;
	}

	/**
	 * Returns maximum limit on number of active concurrent connections that an
	 * EIS instance can support across client processes
	 * 
	 * @see javax.resource.spi.ManagedConnectionMetaData#getMaxConnections()
	 */
	public int getMaxConnections() throws ResourceException {
		return managedConnection.getMaxConnectionHandles();
	}

	/**
	 * Returns "".
	 * 
	 * @see javax.resource.spi.ManagedConnectionMetaData#getUserName()
	 */
	public String getUserName() throws ResourceException {
		return userName;
	}

}