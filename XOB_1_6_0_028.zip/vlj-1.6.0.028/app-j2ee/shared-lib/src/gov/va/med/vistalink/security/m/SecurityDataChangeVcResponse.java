package gov.va.med.vistalink.security.m;

import java.util.Map;

/**
 * Implements responseVO-specific fields for an AV.UpdateVC security message 
 * @see SecurityResponse
 * @see SecurityResponseFactory
 */
public final class SecurityDataChangeVcResponse extends SecurityResponse {

	private SecurityVOChangeVc responseVO;

	/**
	 * 
	 * @see gov.va.med.vistalink.security.m.SecurityResponse#SecurityResponse(int, String)
	 */
	SecurityDataChangeVcResponse(
		boolean needDivisionSelection,
		Map divisionList,
		SecurityResponse responseData) {

		super(responseData);
		responseVO = new SecurityVOChangeVc(responseData.getResultType(), responseData.getResultMessage());
		responseVO.setDivisionList(divisionList);
		responseVO.setNeedDivisionSelection(needDivisionSelection);
	}

	/**
	 * 
	 * @return Value Object with results of change VC attempt
	 */
	public SecurityVOChangeVc getSecurityVOChangeVc() {
		return this.responseVO;
	}
}
