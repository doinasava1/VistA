package gov.va.med.vistalink.adapter.cci;

import gov.va.med.vistalink.adapter.spi.VistaLinkManagedConnectionFactory;

/**
 * Default strategy always passes; use to allow connector to continue in containers no JNDI verification strategy has
 * been defined for yet.
 * 
 */
public class JndiVerificationStrategyAlwaysPass implements JndiVerificationStrategy {

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.adapter.cci.JndiVerificationStrategy#checkJndiMismatch(gov.va.med.vistalink.adapter.cci.VistaLinkConnectionFactory)
	 */
	public boolean checkJndiMismatch(VistaLinkManagedConnectionFactory mcf, VistaLinkConnectionFactory cf) {

		boolean returnVal = true;
		return returnVal;
	}
}