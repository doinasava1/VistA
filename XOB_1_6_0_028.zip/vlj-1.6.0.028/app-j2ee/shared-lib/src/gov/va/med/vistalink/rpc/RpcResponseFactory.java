package gov.va.med.vistalink.rpc;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import gov.va.med.vistalink.adapter.record.LoginsDisabledFaultException;
import gov.va.med.vistalink.adapter.record.VistaLinkFaultException;
import gov.va.med.vistalink.adapter.record.VistaLinkRequestVO;
import gov.va.med.vistalink.adapter.record.VistaLinkResponseFactoryImpl;
import gov.va.med.vistalink.adapter.record.VistaLinkResponseVO;
import gov.va.med.vistalink.security.m.SecurityAccessVerifyCodePairInvalidException;
import gov.va.med.vistalink.security.m.SecurityDivisionDeterminationFaultException;
import gov.va.med.vistalink.security.m.SecurityIdentityDeterminationFaultException;
import gov.va.med.vistalink.security.m.SecurityFaultException;
import gov.va.med.vistalink.security.m.SecurityTooManyInvalidLoginAttemptsFaultException;
import gov.va.med.vistalink.security.m.SecurityUserAuthorizationException;
import gov.va.med.vistalink.security.m.SecurityUserVerifyCodeException;
import gov.va.med.xml.XmlUtilities;
import gov.va.med.exception.ExceptionUtils;
import gov.va.med.exception.FoundationsException;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Implements RPC specific response parsing logic
 * 
 */
public class RpcResponseFactory extends VistaLinkResponseFactoryImpl {

	/**
	 * The logger used by this class
	 */
	private static final Logger logger = Logger.getLogger(RpcResponseFactory.class);

	/**
	 * The message type used for this response
	 */
	protected static final String GOV_VA_MED_RPC_RESPONSE = "gov.va.med.foundations.rpc.response";

	/**
	 * Represents a rpc fault
	 */
	protected static final String GOV_VA_MED_RPC_FAULT = "gov.va.med.foundations.rpc.fault";

	/**
	 * Represents the strings that identifies if a RPC fault has occurred
	 */
	protected static final String ERROR_MSG_RPC = XmlUtilities.XML_HEADER + "<VistaLink messageType=\""
			+ GOV_VA_MED_RPC_FAULT;

	/**
	 * version string most commonly expected in VL messages from M side
	 */
	protected static final String COMMON_RESPONSE_VERSION = "1.6";
	
	/**
	 * Represents the beginning of the CDATA section
	 */
	protected static final String CDATA_BEG = "<![CDATA[";

	/**
	 * Represents the end of the CDATA section w/ the SUFFIX from
	 * VistaLinkResponseFactoryImpl
	 */
	protected static final String CDATA_END_W_SUFFIX = "]]>" + SUFFIX;

	/**
	 * Represents the end of the CDATA section wo/ the SUFFIX from
	 * VistaLinkResponseFactoryImpl
	 */
	protected static final String CDATA_END_WO_SUFFIX = "]]>";

	protected static final String MOST_COMMON_HEADER = "<?xml version=\"1.0\" encoding=\"utf-8\" ?><VistaLink messageType=\"gov.va.med.foundations.rpc.response\" version=\"" + COMMON_RESPONSE_VERSION + "\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:noNamespaceSchemaLocation=\"rpcResponse.xsd\"><Response type=\"";
	protected static final String MOST_COMMON_MIDDLE = "\" ><![CDATA[";
	protected static final String MOST_COMMON_ENDING = CDATA_END_W_SUFFIX;
	
	/**
	 * Constructor for VistaRPCResponseFactory.
	 */
	public RpcResponseFactory() {
		super();
	}

	public VistaLinkResponseVO handleResponse(String response, VistaLinkRequestVO requestVO)
			throws FoundationsException {
		VistaLinkResponseVO result = handleCommonCase(response, requestVO);
		if (result != null)
			return result;
		else
			return super.handleResponse(response, requestVO);
	}
	
	
	private VistaLinkResponseVO handleCommonCase(String response, VistaLinkRequestVO requestVO) {
		if (!response.startsWith(MOST_COMMON_HEADER)) return null;
		if (!response.endsWith(MOST_COMMON_ENDING)) return null;
		
		int mid = response.indexOf(MOST_COMMON_MIDDLE, MOST_COMMON_HEADER.length());
		if (mid == -1) return null;
		
		String type = response.substring(MOST_COMMON_HEADER.length(), mid);
		
		int resultStart = mid + MOST_COMMON_MIDDLE.length();
		int resultEnd = response.length() - MOST_COMMON_ENDING.length();
		String rpcResult = response.substring(resultStart, resultEnd);
		
		RpcResponse rpcResponse = new RpcResponse(response, response, null, GOV_VA_MED_RPC_RESPONSE, rpcResult, type);

		RpcRequest rpcRequest = (RpcRequest) requestVO;
		if (rpcRequest.isXmlResponse()) {
			rpcResponse.setResultsType("xml");
		}

		return rpcResponse;
	}

	/**
	 * RPC specific method to parse response XML string message body and to
	 * create RpcResponse object with appropriate data.
	 * 
	 * @see gov.va.med.vistalink.adapter.record.VistaLinkResponseFactoryImpl#parseMessageBody(java.lang.String,
	 *      java.lang.String, org.w3c.dom.Document, java.lang.String,
	 *      gov.va.med.vistalink.adapter.record.VistaLinkRequestVO)
	 */
	protected VistaLinkResponseVO parseMessageBody(String rawXml, String filteredXml, Document doc, String messageType,
			VistaLinkRequestVO requestVO) throws FoundationsException {

		String cdataFromXml = getCDATAFromResponseXml(rawXml);
		String resultsType = null;

		if (messageType.equals(GOV_VA_MED_RPC_RESPONSE)) {
			XPath xpath = null;
			Node resultsNode = null;

			try {
				xpath = XPathFactory.newInstance().newXPath();
				NodeList resultsNodeList = (NodeList) xpath.evaluate("/VistaLink/Response/.", doc, XPathConstants.NODESET);
				resultsNode = (resultsNodeList.getLength() > 0) ? resultsNodeList.item(0) : null; 

				// JAXEN-based parsing, now replaced by J2SE built-in XPath
//				xpath = new DOMXPath("/VistaLink/Response/.");
//				resultsNode = (Node) xpath.selectSingleNode(doc);
			} catch (XPathExpressionException e) {

				String errStr = "Exception occured getting Response DOM node from response XML document.";

				if (logger.isEnabledFor(Level.ERROR)) {
					logger.error((new StringBuffer()).append(errStr).append("\n\t").append(
							ExceptionUtils.getFullStackTrace(e)).toString());
				}

				throw new FoundationsException(errStr, e);
			}

			// get result type
			NamedNodeMap attrs = resultsNode.getAttributes();
			Attr attr = (Attr) attrs.getNamedItem("type");
			resultsType = attr.getValue().toLowerCase();
		} else {
			throw new FoundationsException("Illegal Response Format Returned: '" + messageType + "'.");
		}

		RpcResponse rpcResponse = new RpcResponse(rawXml, filteredXml, doc, messageType, cdataFromXml, resultsType);

		RpcRequest rpcRequest = (RpcRequest) requestVO;
		if (rpcRequest.isXmlResponse()) {
			rpcResponse.setResultsType("xml");
		}

		return rpcResponse;
	}

	/**
	 * Performs additional response XML string parsing to check if fault occured
	 * 
	 * @see gov.va.med.vistalink.adapter.record.VistaLinkResponseFactoryImpl#doesResponseIndicateFault(java.lang.String)
	 */
	protected boolean doesResponseIndicateFault(String rawXml) {
		return rawXml.startsWith(ERROR_MSG_RPC);
	}

	/**
	 * Filters response XML string specific to RPC implementation. Removes CDATA
	 * from within the response XML.
	 * 
	 * @see gov.va.med.vistalink.adapter.record.VistaLinkResponseFactoryImpl#filterResponseXmlString(java.lang.String,
	 *      boolean)
	 */
	protected String filterResponseXmlString(String rawXml, boolean isFault) {
		return removeCDATAFromResponseXml(rawXml, isFault);
	}

	/**
	 * Removes the CDATA section from the raw XML
	 * 
	 * @param rawXml
	 * @param isFault
	 * @return String
	 */
	private String removeCDATAFromResponseXml(String rawXml, boolean isFault) {
		int cdataIndex = getCDATAStartIndex(rawXml);

		if ((cdataIndex > -1) && (!isFault)) {
			//			<dontknow>
			//			int cdataEndIndex = rawXml.
			//				lastIndexOf(CDATA_END_WO_SUFFIX)
			//			   + CDATA_END_WO_SUFFIX.length();
			//
			//			xmlNoCData = ((new StringBuffer())
			//				.append(rawXml.substring(0, cdataIndex))
			//				.append(rawXml.substring(cdataEndIndex))).toString();
			//			<dontknow>
			String xmlNoCData = rawXml.substring(0, cdataIndex) + SUFFIX;

			return xmlNoCData;
		} else {
			return rawXml;
		}
	}

	/**
	 * Gets the CDATA section from the raw XML
	 * 
	 * @param rawXml
	 * @return String
	 */
	private String getCDATAFromResponseXml(String rawXml) {
		int cdataStartIndex = getCDATAStartIndex(rawXml);

		String retStr = null;
		if (cdataStartIndex > -1) {
			int cdataEndIndex = getCDATAEndIndex(rawXml);
			retStr = rawXml.substring(cdataStartIndex + CDATA_BEG.length(), cdataEndIndex);
		}
		return retStr;
	}

	/**
	 * Gets the start of the CDATA section
	 * 
	 * @param rawXml
	 * @return int
	 */
	private int getCDATAStartIndex(String rawXml) {
		return rawXml.indexOf(CDATA_BEG);
	}

	/**
	 * Gets the end of the CDATA section
	 * 
	 * @param rawXml
	 * @return int
	 */
	private int getCDATAEndIndex(String rawXml) {
		return rawXml.indexOf(CDATA_END_W_SUFFIX);
	}

	/**
	 * Perform RPC specific fault handling and creation of RPC specific
	 * FaultExceptions.
	 * 
	 * @see gov.va.med.vistalink.adapter.record.VistaLinkResponseFactoryImpl#handleSpecificFault(org.w3c.dom.Document,
	 *      java.lang.String,
	 *      gov.va.med.vistalink.adapter.record.VistaLinkFaultException)
	 */
	protected VistaLinkFaultException handleSpecificFault(Document xdoc, String messageType,
			VistaLinkFaultException faultException) throws VistaLinkFaultException, FoundationsException {

		if ("181004".equals(faultException.getErrorCode())) {

			return new LoginsDisabledFaultException(faultException);

		} else if ("182005".equals(faultException.getErrorCode())) {

			return new RpcNotInContextFaultException(faultException);

		} else if ("182006".equals(faultException.getErrorCode())) {

			return new NoRpcContextFaultException(faultException);

		} else if ("182007".equals(faultException.getErrorCode())) {

			return new RpcTimeOutFaultException(faultException);

		} else if ("182010".equals(faultException.getErrorCode())) {

			return new RpcNotOkForProxyUseException(faultException);

		} else if ("182301".equals(faultException.getErrorCode())) {

			return new SecurityIdentityDeterminationFaultException(faultException);

		} else if ("182302".equals(faultException.getErrorCode())) {

			return new SecurityDivisionDeterminationFaultException(faultException);

		} else if ("182303".equals(faultException.getErrorCode())) {

			return new SecurityUserVerifyCodeException(faultException);

		} else if ("182304".equals(faultException.getErrorCode())) {

			return new SecurityUserAuthorizationException(faultException);

		} else if ("182305".equals(faultException.getErrorCode())) {

			return new SecurityAccessVerifyCodePairInvalidException(faultException);

		} else if ("182306".equals(faultException.getErrorCode())) {

			return new SecurityTooManyInvalidLoginAttemptsFaultException(faultException);

		} else if ("182307".equals(faultException.getErrorCode())) {
			
			// application proxy failure
			return new SecurityIdentityDeterminationFaultException(faultException);

		} else if ("182308".equals(faultException.getErrorCode())) {

			return new SecurityDivisionDeterminationFaultException(faultException);

		} else if ("1823".equals(faultException.getErrorCode().substring(0, 4))) {

			return new SecurityFaultException(faultException);

		} else if ("182".equals(faultException.getErrorCode().substring(0, 3))) {

			return new RpcFaultException(faultException);

		}

		return null;
	}

}