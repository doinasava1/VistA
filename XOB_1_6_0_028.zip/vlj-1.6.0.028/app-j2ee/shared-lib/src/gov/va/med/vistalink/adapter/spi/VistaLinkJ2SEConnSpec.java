/*
 * Created on Jun 17, 2003
 *
 */
package gov.va.med.vistalink.adapter.spi;

import gov.va.med.vistalink.adapter.cci.VistaLinkConnectionSpecImpl;

import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

/**
 * The connection spec used internally for J2SE environments. 
 * This class should never be used by a client application
 * 
 */
public class VistaLinkJ2SEConnSpec extends VistaLinkConnectionSpecImpl {

	/**
	 * Value used to identify type as J2SE
	 */
	private static final String TYPE_J2SE = "j2se";

	/**
	 * The logger used by this class
	 */
	private static final Logger logger = Logger.getLogger(VistaLinkJ2SEConnSpec.class);

	/**
	 *  
	 */
	public VistaLinkJ2SEConnSpec() {
		super();
	}

	/**
	 * @param division
	 */
	public VistaLinkJ2SEConnSpec(String division) {
		super(division);
	}

	/* (non-Javadoc)
	 * @see gov.va.med.vistalink.adapter.cci.VistaLinkConnectionSpec#getProprietarySecurityInfo(org.w3c.dom.Node)
	 */
	public ArrayList getProprietarySecurityInfo() {
		ArrayList values = new ArrayList();
		return values;
	}

	/* (non-Javadoc)
	 * @see gov.va.med.vistalink.adapter.cci.VistaLinkConnectionSpec#isConnSpecEqual(java.lang.Object)
	 * @va.exclude
	 * @deprecated Use equals() method.
	 */
	public boolean isConnSpecEqual(Object obj) {
		return equals(obj);
	}
	
	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.adapter.cci.VistaLinkConnectionSpec#setAuthenticationNodes(org.w3c.dom.Document,
	 *      org.w3c.dom.Node)
	 */
	public void setAuthenticationNodes(Document requestDoc, Node securityNode) {
		if (logger.isDebugEnabled()) {
			logger.debug("setAuthenticationNodes -> Re Auth type is 'J2SE'");
		}

	}

	/* (non-Javadoc)
	 * @see gov.va.med.vistalink.adapter.cci.VistaLinkConnectionSpec#getSecurityType()
	 */
	public String getSecurityType() {
		return TYPE_J2SE;
	}
}