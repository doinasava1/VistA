package gov.va.med.vistalink.institution;

import gov.va.med.environment.Environment;
import gov.va.med.environment.ServerType;
import gov.va.med.vistalink.adapter.cci.VistaLinkConnectionFactory;
import gov.va.med.vistalink.adapter.spi.ConfigurationReader;

import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.naming.InitialContext;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

/**
 * The implementation of the singleton object used to hold the in-memory mapping of institutions to VistaLink connector
 * JNDI names.
 * <p>
 * The singleton instance of this class is initialized during connector startup.
 * <p>
 * This class is thread-safe.
 * 
 * @va.exclude
 */
public class InstitutionMapping {

	private static final Logger logger = Logger.getLogger(InstitutionMapping.class);
	// rules implementations should be threadsafe
	private static IPrimaryStationRules primaryStationRules;

	static {
		// get primaryStationRules implementation
		try {
			primaryStationRules = PrimaryStationRulesFactory.getPrimaryStationRulesImplementation();
		} catch (InstantiationException e) {
			logger.error("Could not get primary station rules implementation: ", e);
		} catch (IllegalAccessException e) {
			logger.error("Could not get primary station rules implementation: ", e);
		} catch (ClassNotFoundException e) {
			logger.error("Could not get primary station rules implementation: ", e);
		}
	}
	
	/*
	 * internal list of institutions, read from config file. Key = station#, value = jndi name.
	 */
	private TreeMap institutionMap;

	/*
	 * synchronize concurrent access to mappings
	 */
	private Object syncObjMapping = new Object();

	/**
	 * constructor
	 */
	public InstitutionMapping() {
		super();
		if (logger.isEnabledFor(Level.DEBUG)) {
			logger.debug("InstitutionMapping :: In constructor.");
		}
		// create internal map of institutions
		institutionMap = new TreeMap();
	}

	/**
	 * Loads one or more station# mappings for a given JNDI name.
	 * 
	 * @param mcfJndiName JNDI name to create mappings for
	 * @param mcfStationNumbers One or more station#s to create mappings for
	 * @param mcfDistinguishedIdentifier MCF distinguished identifier used later during a connector's finalize method --
	 *            allows a connector to know whether it should remove the mapping or not, depending on a match on
	 *            distinguished identifier.
	 * @va.exclude
	 */
	public void loadMappingsForJndiName(String mcfJndiName, String[] mcfStationNumbers, long mcfDistinguishedIdentifier)
			throws InstitutionMappingBadStationNumberException {

		// check station #s first
		for (int i = 0; i < mcfStationNumbers.length; i++) {
//			checkStationNumber(mcfStationNumbers[i]);
			primaryStationRules.validatePrimaryStation(mcfStationNumbers[i]);
		}

		synchronized (this.syncObjMapping) {

			// Remove any existing mappings for this jndi name that aren't part of the incoming station #s set
			Set keySet = this.institutionMap.keySet();
			for (Iterator iter = keySet.iterator(); iter.hasNext();) {
				String mappingStationNumber = (String) iter.next();
				String mappingJndiName = ((InstitutionMappingVO) this.institutionMap.get(mappingStationNumber))
						.getJndiName();
				if (mcfJndiName.equals(mappingJndiName)) {
					boolean stationMatch = false;
					for (int i = 0; i < mcfStationNumbers.length; i++) {
						if (mcfStationNumbers[i].equals(mappingStationNumber)) {
							stationMatch = true;
						}
					}
					if (!stationMatch) {
						if (logger.isDebugEnabled()) {
							logger.debug("removing mapping of station number '" + mappingStationNumber
									+ "' to JNDI name '" + mcfJndiName + "'.");
						}
						// remove the mapping
						iter.remove();
					}
				}
			}

			// Add new mappings:
			for (int i = 0; i < mcfStationNumbers.length; i++) {

				logger.debug("considering station#: " + mcfStationNumbers[i]);

				if (!institutionMap.containsKey(mcfStationNumbers[i])) {

					// If mapping not already present for station#, create new one
					if (logger.isDebugEnabled()) {
						logger.debug("adding mapping for JNDI name '" + mcfJndiName + "' to station number '"
								+ mcfStationNumbers[i] + "'.");
					}
					this.institutionMap.put(mcfStationNumbers[i], new InstitutionMappingVO(mcfJndiName,
							mcfDistinguishedIdentifier));

				} else {

					InstitutionMappingVO foundMapping = (InstitutionMappingVO) institutionMap.get(mcfStationNumbers[i]);
					String mappingJndiName = foundMapping.getJndiName();

					if (mappingJndiName.equals(mcfJndiName)) {

						// If mapping already present for this JNDI, reset MCF DI to new one
						if (logger.isDebugEnabled()) {
							logger
									.debug("Institution mapping contains station number: "
											+ mcfStationNumbers[i]
											+ "and the JNDI names are equal. Updating the last MCF distinguished identifier for mapping.");
						}
						foundMapping.setLastOneInMcfDistinguishedIdentifier(mcfDistinguishedIdentifier);

					} else {

						// If mapping already present for another JNDI, remove and create new one
						if (!mappingJndiName.equals(mcfJndiName)) {
							logger.warn("Existing station mapping found for station '" + mcfStationNumbers[i]
									+ "' mapped to JNDI name '" + mappingJndiName
									+ "'. Replacing with new mapping to JNDI name '" + mcfJndiName + "'.");
						}
						foundMapping.setJndiName(mcfJndiName);
						foundMapping.setLastOneInMcfDistinguishedIdentifier(mcfDistinguishedIdentifier);
					}
				}
			}
		}
	}

	/**
	 * Call to remove mapping
	 * @param mcfJndiName JNDI name of the mapping to remove
	 * @param mcfStationNumbers Station # of the mapping to remove
	 * @param mcfDistinguishedIdentifier Managed Connection Factory (mcf) distinguished identifier to identify owner of
	 *            mapping to be removed.
	 * @va.exclude
	 */
	public void removeMappingsForJndiName(String mcfJndiName, String[] mcfStationNumbers,
			long mcfDistinguishedIdentifier) {

		synchronized (this.syncObjMapping) {

			for (int i = 0; i < mcfStationNumbers.length; i++) {
				logger.debug("considering removing station # " + mcfStationNumbers[i]);
				if (institutionMap.containsKey(mcfStationNumbers[i])) {
					InstitutionMappingVO imVO = (InstitutionMappingVO) institutionMap.get(mcfStationNumbers[i]);
					if (imVO.getJndiName().equals(mcfJndiName)) {
						if (imVO.getLastOneInMcfDistinguishedIdentifier() == mcfDistinguishedIdentifier) {
							institutionMap.remove(mcfStationNumbers[i]);
							if (logger.isDebugEnabled()) {
								logger.debug("Removed mapping for station #'" + mcfStationNumbers[i] + "', JNDI name '"
										+ mcfJndiName + "'.");
							}
						}
					}
				}
			}
		}
	}

	/**
	 * Returns the JNDI connector name (if found) for a division matching the station number passed in.
	 * 
	 * @param stationNumber Station number of the division to retrieve a connector pool for.
	 * @return the JNDI connector name that has been mapped to the station number passed in.
	 * @throws InstitutionMappingNotFoundException if a match is not found, this exception is thrown.
	 * @throws InstitutionMappingBadStationNumberException if a bad station number is passed
	 * @va.exclude
	 */
	String getJndiConnectorNameForInstitution(String stationNumber) throws InstitutionMappingNotFoundException, InstitutionMappingBadStationNumberException {
		InstitutionMappingVO imuVO = null;

		String primaryStationLookupStr = primaryStationRules.getPrimaryStationLookupString(stationNumber);

		synchronized (this.syncObjMapping) {
			imuVO = (InstitutionMappingVO) institutionMap.get(primaryStationLookupStr);
		}
		// 2nd try for WebSphere, which deploys connectors lazily
		if ((imuVO == null) && (ServerType.WEBSPHERE.equals(Environment.getServerType()))) {
			// make a JNDI query to trigger auto-add add of station #s to mapping
			try {
				String jndiName = ConfigurationReader.getJndiNameForStationNumber(primaryStationLookupStr);
				logger.debug("Attempting to force load of connection factory into JNDI for WebSphere, for JNDI name: "
						+ jndiName);
				InitialContext ic = new InitialContext();
				VistaLinkConnectionFactory cf = (VistaLinkConnectionFactory) ic.lookup(jndiName);
				synchronized (this.syncObjMapping) {
					imuVO = (InstitutionMappingVO) institutionMap.get(primaryStationLookupStr);
				}
			} catch (Exception e) {
				// swallow fow now -- if use WebSphere more, determine if some other action appropriate 
			}
		}
		if (imuVO == null) {
			throw new InstitutionMappingNotFoundException("Could not match stationNumber '" + stationNumber
					+ "' to an institution mapping.");
		}
		return imuVO.getJndiName();
	}

	/**
	 * Used by MBean to display connector mapping list
	 * 
	 * @return a cloned copy of the TreeSet of current mappings
	 * @va.exclude
	 */
	public Map getMappingClone() {

		// make shallow copy of TreeMap, should prevent synch errors if real
		// TreeMap is being modified
		TreeMap clone = null;
		synchronized (this.syncObjMapping) {
			clone = (TreeMap) institutionMap.clone();
		}
		return clone;
	}

	/**
	 * Return a Set containing station#s in the current institution mapping.
	 * @return
	 */
	Set getVistaLinkMappedStationNumberSet() {
		return Collections.unmodifiableSet(getMappingClone().keySet());
	}
}