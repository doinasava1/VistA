package gov.va.med.vistalink.jmx;

import org.apache.log4j.Logger;

import gov.va.med.environment.Environment;
import gov.va.med.environment.ServerType;

/**
 * Factory class to return app-server-specific IJmxHelper implementations.
 * 
 */
public final class JmxHelperFactory {

	private static final Logger logger = Logger.getLogger(JmxHelperFactory.class);

	static final String JMX_DOMAIN_NAME_FOR_HEV_MBEANS = "gov.va.med";

	/**
	 * private constructor to prevent instantiation
	 */
	private JmxHelperFactory() {
		// empty constructor to prevent instantiation
	}

	/**
	 * Returns a platform-specific implementation of the IJmxHelper interface.
	 * 
	 * @return an IJmxHelper instance.
	 */
	public static IJmxHelper getJmxHelper() {
		IJmxHelper result = null;
		ServerType currentServerType = Environment.getServerType();
		if (currentServerType.equals(ServerType.WEBLOGIC)) {
			logger.debug("returning WebLogic-type JMX helper");
			result = new JmxHelperWebLogic();
//		} else if (currentServerType.equals(ServerType.WEBSPHERE_BASE)) {
//			logger.debug("returning WebSphere-type JMX helper");
//			result = new JmxHelperWebSphere();
//		} else if (currentServerType.equals(ServerType.WEBSPHERE_ND)) {
//			logger.debug("returning WebSphere-type JMX helper");
//			result = new JmxHelperWebSphere();
		} else {
			logger.debug("returning generic type JMX helper");
			result = new JmxHelperUnknown();
		}
		return result;
	}
}