/*
 * Created on Apr 4, 2005
 *
 */
package gov.va.med.crypto;

/**
 * Key based encrypter, using DES algorithm and "UTF8" encoding.
 * 
 */

public class DESKeyEncrypter extends KeyEncrypter{
  DESKeyEncrypter(){
	super();
    algorithmName = "DES";
    encodingFormat = "UTF8";
  }
}
