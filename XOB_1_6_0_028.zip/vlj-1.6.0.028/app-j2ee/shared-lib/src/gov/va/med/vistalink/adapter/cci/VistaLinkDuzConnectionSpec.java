package gov.va.med.vistalink.adapter.cci;

import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

/**
 * This is the connection spec class for Duz re-authentication
 * 
 */
public class VistaLinkDuzConnectionSpec extends VistaLinkConnectionSpecImpl {

	/**
	 * Value used to identify type as DUZ
	 */
	private static final String TYPE_DUZ = "duz";

	/**
	 * Element name given to DUZ type
	 */
	private static final String ELEMENT_DUZ = "Duz";

	/**
	 * Name given to attribute representing DUZ
	 */
	private static final String ATTRIBUTE_VALUE = "value";

	/**
	 * The DUZ value
	 */
	private String duz;

	/**
	 * The logger used by this class
	 */
	private static final Logger logger = Logger.getLogger(VistaLinkDuzConnectionSpec.class);

	/**
	 * @va.exclude
	 */
	public VistaLinkDuzConnectionSpec() {
		super();
	}

	/**
	 * @param duz
	 *            The DUZ identifier for the end user.
	 * @param division
	 *            The station number (e.g., "523", "523BZ", etc.) requested as
	 *            the division under which logon/actions should be conducted for
	 *            this user on the target Kernel/M system.
	 *            <p>
	 *            The division parameter for connection specs is mandatory. This
	 *            ensures that division requested for a connection on behalf of
	 *            an end-user matches the division actually accessed on the M
	 *            side of the connection.
	 *            <p>
	 *            The value to pass for the division parameter is the division
	 *            station number, e.g., "523", "523BZ", etc. This is the value
	 *            found in field 99 ('Station Number') of the corresponding
	 *            entry in the Institution File on the M system.
	 *            <p>
	 *            On the M side, if a user doesn't have one or more "divisions"
	 *            specified in the DIVISION (#200.02) multiple of their New
	 *            Person file entry, the division passed in with the connection
	 *            spec must be the station number of the division set into the
	 *            DEFAULT INSTITUTION (#217) field of the KERNEL SYSTEM
	 *            PARAMETERS (#8989.3) file entry for the site. This value is
	 *            set by Kernel into DUZ(2).
	 *            <p>
	 *            On the M side, if a user has one or more "divisions" specified
	 *            in the DIVISION (#200.02) multiple of their New Person file
	 *            entry, the division passed in with the connection spec must be
	 *            the station number for one of those divisions present in that
	 *            multiple. This value will be set by Kernel into DUZ(2).
	 */
	public VistaLinkDuzConnectionSpec(String division, String duz) {
		super(division);
		this.duz = duz;
	}

	/**
	 * @return DUZ
	 */
	public String getDuz() {
		return duz;
	}

	/**
	 * Sets the DUZ
	 * 
	 * @param string
	 */
	public void setDuz(final String string) {
		duz = string;
	}

	/**
	 * @return Security info
	 * @see gov.va.med.vistalink.adapter.cci.VistaLinkConnectionSpec#getProprietarySecurityInfo()
	 * @va.exclude
	 */
	public ArrayList getProprietarySecurityInfo() {
		final ArrayList values = new ArrayList();
		values.add(duz);
		return values;
	}

	/**
	 * Compares two objects to see if they are equal
	 * 
	 * @param obj
	 *            the object to compare
	 * @see gov.va.med.vistalink.adapter.cci.VistaLinkConnectionSpec#isConnSpecEqual(java.lang.Object)
	 * @va.exclude
	 * @deprecated Use equals() method.
	 */
	public boolean isConnSpecEqual(final Object obj) {
		return equals(obj);
	}

	public boolean equals(final Object obj) {
		if (obj instanceof VistaLinkDuzConnectionSpec) {
			final VistaLinkDuzConnectionSpec connSpec = (VistaLinkDuzConnectionSpec) obj;
			if ((connSpec.getDivision().equals(this.getDivision())) && (connSpec.getDuz().equals(this.getDuz()))) {
				return true;
			}
		}
		return false;
	}

	public int hashCode() {
		// algorithm taken from "Effective Java" item #8.
		final int HASHCODE_SEED = 17;
		int returnVal = HASHCODE_SEED;

		// division contribution to hashcode
		final int divisionHashCode = this.getDivision().hashCode();
		returnVal = 37 * returnVal + divisionHashCode; 
		// Duz contribution to hashcode
		final int duzHashCode = this.getDuz().hashCode();
		returnVal = 37 * returnVal + duzHashCode; 
		return returnVal;
	}
	
	/**
	 * creates the xml in the security node
	 * 
	 * @param requestDoc
	 *            the Document object that contains the nodes
	 * @param securityNode
	 *            the node to create the XML under
	 * @see gov.va.med.vistalink.adapter.cci.VistaLinkConnectionSpec#setAuthenticationNodes(org.w3c.dom.Document,
	 *      org.w3c.dom.Node)
	 * @va.exclude
	 */
	public void setAuthenticationNodes(final Document requestDoc, final Node securityNode) {
		if (logger.isDebugEnabled()) {
			logger.debug("setAuthenticationNodes -> Re Auth type is 'duz'");
		}

		setSecurityDivisionAttr(securityNode);
		setSecurityTypeAttr(securityNode);

		Element elemDuz = requestDoc.createElement(ELEMENT_DUZ);

		elemDuz.setAttribute(ATTRIBUTE_VALUE, this.getDuz());

		securityNode.appendChild(elemDuz);

	}

	/**
	 * returns the security mechanism type
	 * 
	 * @see gov.va.med.vistalink.adapter.cci.VistaLinkConnectionSpec#getSecurityType()
	 * @va.exclude
	 */
	public String getSecurityType() {
		return TYPE_DUZ;
	}

}