package gov.va.med.vistalink.rpc;

import gov.va.med.vistalink.adapter.record.VistaLinkFaultException;

/**
 * This exception represents the case where the requested RPC is not contained in the current
 * RPC context.
 * 
 */
public class RpcNotInContextFaultException extends RpcFaultException {

	/**
	 * Constructor for RpcNotInContextFaultException.
	 * @see gov.va.med.vistalink.adapter.record.VistaLinkFaultException#VistaLinkFaultException(VistaLinkFaultException)
	 * @param vistaLinkFaultException the exception to copy into a new exception type
	 * @va.exclude
	 */
	public RpcNotInContextFaultException(VistaLinkFaultException vistaLinkFaultException) {
		super(vistaLinkFaultException);
	}

}
