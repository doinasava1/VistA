package gov.va.med.vistalink.console;

import gov.va.med.vistalink.jmx.IJmxHelper;
import gov.va.med.vistalink.jmx.JmxHelperFactory;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

/**
 * Class that encapsulates app-server-specific mechanism for specifying server/JVM locations in domain-wide ObjectNames.
 * Useful for app servers that support domain-wide MBean queries -- allows filtering of query based on server location,
 * allowing queries to be targeted to a specific server location.
 * 
 */
public abstract class ServerHelperAbstract implements Comparable, IServerHelper {

	private static final Logger logger = Logger.getLogger(ServerHelperAbstract.class);

	// instance vars -- use must be synchronized for thread safety
	private final Map keyPropertyHm = new HashMap();

	/**
	 * no-arg constructor used to construct server helper for local server only
	 * 
	 */
	ServerHelperAbstract() {
		IJmxHelper jmxHelper = JmxHelperFactory.getJmxHelper();
		init(jmxHelper.getServerObjectNamePropertiesForRegistration());
	}

	/**
	 * Used to construct object based on server identifier
	 * @param objectNameFragment
	 */
	ServerHelperAbstract(String objectNameFragment) {
		init(objectNameFragment);
	}

	/**
	 * called from constructors only, var access does not need to be synchronized for thread safety
	 * 
	 * @param objectNameFragment object name key-value pairs respresenting the server identity, to store
	 */
	final void init(String objectNameFragment) {

		if (objectNameFragment.trim().length() > 0) {
			// parse out the object name key-value pairs passed in
			logger.debug("processing objectNameFragment: " + objectNameFragment);
			String[] keyValuePairs = objectNameFragment.trim().split(",");
			for (int i = 0; i < keyValuePairs.length; i++) {
				String[] keyValuePair = keyValuePairs[i].trim().split("=");
				logger.debug("found keyValuePair: " + keyValuePair[0] + "=" + keyValuePair[1]);
				if ((keyValuePair.length == 2) && (keyValuePair[0].length() > 0) && (keyValuePair[1].length() > 0)) {
					// store parsed out key-value pairs in keyPropertyHm
					keyPropertyHm.put(keyValuePair[0], keyValuePair[1]);
				}
			}
		}
	}

	/**
	 * implement comparison for sorting, based on displayName value.
	 */
	public final int compareTo(Object o) {
		int returnVal = 0;
		if (o instanceof IServerHelper) {
			String compareDisplayName = ((IServerHelper) o).getDisplayNameFullyLocationQualified();
			String displayName = this.getDisplayNameFullyLocationQualified();
			if ((compareDisplayName == null) && (displayName == null)) {
				returnVal = 0;
			} else if (compareDisplayName == null) {
				returnVal = 1;
			} else if (displayName == null) {
				returnVal = -1;
			} else {
				returnVal = displayName.compareTo(compareDisplayName);
			}
		} else {
			throw new ClassCastException("Expected IServerHelper, found: " + o.getClass().getName());
		}
		return returnVal;
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public final boolean equals(Object obj) {

		boolean returnVal = false;
		if (obj == this) {
			returnVal = true;
		} else if (obj instanceof IServerHelper) {
			// if one, the other or both equal "" return false
			if ("".equals(this.getDisplayNameFullyLocationQualified())
					|| ("".equals(((IServerHelper) obj).getDisplayNameFullyLocationQualified()))) {
				returnVal = false;
			} else {
				returnVal = this.getDisplayNameFullyLocationQualified().equals(
						((IServerHelper) obj).getDisplayNameFullyLocationQualified());
			}
		}
		return returnVal;
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	public final int hashCode() {
		int result = 17;
		int c = 0;
		String objectNameFragment = this.getDisplayNameFullyLocationQualified();
		if (objectNameFragment != null) {
			c = objectNameFragment.hashCode();
		}
		return 37 * result + c;
	}

	public final String toString() {

		String locationDisplayName = getDisplayNameFullyLocationQualified();
		StringBuffer sb = new StringBuffer("DisplayName: '").append((locationDisplayName == null) ? "null"
				: locationDisplayName);
		sb.append("'");
		return sb.toString();

	}

	/**
	 * synchronized wrapper for thread safety, for use by descendants
	 * @param key
	 * @return
	 */
	protected synchronized boolean keyPropertiesContainKey(String key) {
		return keyPropertyHm.containsKey(key);
	}

	/**
	 * synchronized wrapper for thread safety, for use by descendants
	 * @param key
	 * @return
	 */
	protected synchronized String keyPropertiesGetValue(String key) {
		return (String) keyPropertyHm.get(key);
	}
}
