package gov.va.med.vistalink.rpc;

import gov.va.med.exception.FoundationsException;
import gov.va.med.vistalink.adapter.record.VistaLinkRequestFactory;

/**
 * Factory class to creates instances of RpcRequest
 * <p>
 * J2SE Example:
 * <p>
 * <code>
 *    //request  and response objects <br>
 *   RpcRequest vReq = null; <br>
 *   RpcResponse vResp = null;
 * <p>   
 *   //The Rpc Context<br>
 *   String rpcContext = &quot;XOBV VISTALINK TESTER&quot;;
 * <p>   
 *   //The Rpc to call<br>
 *   String rpcName = &quot;XOBV TEST PING&quot;;
 * <p>   
 *   //Construct  the request object <br>
 *   vReq = RpcRequestFactory.getRpcRequest(rpcContext, rpcName);
 * <p>   
 *   //Execute the Rpc and get the response<br>
 *   vResp = myConnection.executeRPC(vReq);
 * <p>   
 *   //Work with the response ...
 * </code>
 * 
 */
public class RpcRequestFactory implements VistaLinkRequestFactory {

    /**
     * Creates a RpcRequest with a null RpcContext and RpcName
     * 
     * @return RpcRequest
     * @throws FoundationsException
     */
    public static RpcRequest getRpcRequest() throws FoundationsException {
        return getRpcRequest(null);
    }

    /**
     * Creates a RpcRequest with the specified RpcContext and a null RpcName.
     * 
     * @param rpcContext
     * @return RpcRequest
     * @throws FoundationsException
     */
    public static RpcRequest getRpcRequest(String rpcContext) throws FoundationsException {
        return getRpcRequest(rpcContext, null);
    }

    /**
     * Creates appropriate rpc request object to be passed into the connection.
     * 
     * @param rpcContext
     * @param rpcName
     * @return RpcRequest
     * @throws FoundationsException
     */
    public static RpcRequest getRpcRequest(String rpcContext, String rpcName) throws FoundationsException {
            return new RpcRequest(rpcContext, rpcName);
    }
}