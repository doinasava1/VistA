package gov.va.med.vistalink.institution;

/**
 * Interface for PrimaryStationRules implementations. All implementations must be threadsafe.
 * 
 */
public interface IPrimaryStationRules {

	/**
	 * Implement a method that validates a particular 'primary station' identifier string as valid. Primary stations are
	 * used in VistALink to look up a connector. Therefore, the format of a valid 'primary station' identifier should be
	 * such that the entity or system it identifies would have one and only one connector associated with it.
	 * 
	 * @param primaryStation identifier for a 'primary station', i.e., 'computing facility'
	 * @throws InstitutionMappingBadStationNumberException thrown if primaryStation param is considered an invalid
	 *             identifier
	 */
	void validatePrimaryStation(String primaryStation) throws InstitutionMappingBadStationNumberException;

	/**
	 * Implement a method that, given a particular 'division' string (i.e., primary station plus optional division
	 * suffix), returns the primary Station derived from that division string. The primary station is used for looking
	 * up connectors, and would be the 'computing facility' for the division in question.
	 * 
	 * @param division
	 * @return the primaryStation value derived from the division parameter, to use for connector lookups.
	 * @throws InstitutionMappingBadStationNumberException thrown if the division passed in is considered invalid.
	 */
	String getPrimaryStationLookupString(String division) throws InstitutionMappingBadStationNumberException;
}
