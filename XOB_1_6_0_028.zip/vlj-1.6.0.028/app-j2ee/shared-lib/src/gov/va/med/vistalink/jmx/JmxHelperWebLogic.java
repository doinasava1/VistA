package gov.va.med.vistalink.jmx;

import java.util.Set;

import javax.management.MBeanServer;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NameNotFoundException;
import javax.naming.NamingException;

import org.apache.log4j.Logger;

/**
 * WebLogic-specific JMX-related methods. Class is designed to be thread-safe.
 * 
 */
public final class JmxHelperWebLogic implements IJmxHelper {

	// static variables
	private static final Logger logger = Logger.getLogger(JmxHelperWebLogic.class);
	private static final String JMX_DOMAIN_FOR_PLATFORM = "com.bea";
	private static final String MBEANSERVER_JNDI_ENV_CONTEXT = "java:comp/env/jmx/runtime";
	private static final String MBEANSERVER_JNDI_CONTEXT = "java:comp/jmx/runtime";
	private static final String OBJECT_NAME_STRING_TYPE = "Type";

	// instance variables (all access must be synchronized for thread safety)
	private MBeanServer localRuntimeMBeanServer = null;

	/**
	 * protected constructor enforces direct non-instantiability
	 * 
	 */
	protected JmxHelperWebLogic() {
		super();
	}

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.jmx.IJmxHelper#getServerObjectNamePropertiesForRegistration()
	 */
	public String getServerObjectNamePropertiesForRegistration() {
		// for wls 9/10, just need Name and Type -- so, no special ObjectName properties --
		// return empty string!
		return "";
	}

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.jmx.IJmxHelper#getLocalMBeanServer()
	 */
	public MBeanServer getLocalMBeanServer() throws JmxHelperException {
		logger.debug("in getLocalMBeanServer");

		// method encapsulates access to localRuntimeMBeanServer instance variable for thread safety

		MBeanServer returnVal = null;
		Context ctx = null;
		try {
			ctx = new InitialContext();
			returnVal = getLocalRuntimeMBeanServer();
			if (returnVal == null) {
				try {
					// if running at EJB-JAR or WAR level
					returnVal = (MBeanServer) ctx.lookup(MBEANSERVER_JNDI_ENV_CONTEXT);
				} catch (NameNotFoundException e) {
					// if running at EAR level
					try {
						returnVal = (MBeanServer) ctx.lookup(MBEANSERVER_JNDI_CONTEXT);
					} catch (NameNotFoundException e1) {
						logger.error("Could not retrieve local MBeanServer: ", e1);
						throw new JmxHelperException("Could not retrieve local MBeanServer from JNDI");
					}
				}
				if (returnVal != null) {
					// store for future accesses
					setLocalRuntimeMBeanServer(returnVal);
				}
			} // end null check

		} catch (NamingException e) {
			logger.error("Could not get initial context: ", e);
			if (ctx != null) {
				try {
					ctx.close();
				} catch (NamingException e1) {
					logger.error("Could not close InitialContext: ", e1);
				}
			}
			throw new JmxHelperException("Could not get initial context: ", e);
		} finally {
			try {
				ctx.close();
			} catch (NamingException e) {
				logger.error("error closing JNDI context", e);
			}
		}
		return returnVal;
	}

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.console.IServerHelper#getScopedEncryptionToken()
	 */
	public String getComputingDomainName() throws JmxHelperException {
		String domainName = null;
		try {
			MBeanServer localMBeanServer = getLocalMBeanServer();
			ObjectName oNamePartial = new ObjectName(getJmxDomainForPlatform() + ":" + OBJECT_NAME_STRING_TYPE
					+ "=Domain,*");
			Set queryResults = localMBeanServer.queryNames(oNamePartial, null);
			if (queryResults.size() != 1) {
				logger.error("Expected 1 result for local server query, got: " + queryResults.size());
				throw new JmxHelperException(
						"Could not get domain name, domain query returned result size other than 1:"
								+ queryResults.size());
			} else {
				ObjectName serverObjectName = (ObjectName) queryResults.iterator().next();
				domainName = serverObjectName.getKeyProperty("Name");
			}
		} catch (MalformedObjectNameException e) {
			throw new JmxHelperException("Could not get domain name: ", e);
		} catch (NullPointerException e) {
			throw new JmxHelperException("Could not get domain name: ", e);
		}
		return domainName;
	}

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.jmx.IJmxHelper#getJMXDomainNameForPlatformMBeans()
	 */
	public String getJmxDomainForPlatform() {
		return JMX_DOMAIN_FOR_PLATFORM;
	}

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.jmx.IJmxHelper#getJmxDomainForHevMBeans()
	 */
	public String getJmxDomainForHev() {
		return JmxHelperFactory.JMX_DOMAIN_NAME_FOR_HEV_MBEANS;
	}

	/**
	 * synchronized accessor
	 * @return
	 */
	private synchronized MBeanServer getLocalRuntimeMBeanServer() {
		return localRuntimeMBeanServer;
	}

	/**
	 * synchronized accessor
	 * @param localRuntimeMBeanServer MBeanServer from local JVM
	 */
	private synchronized void setLocalRuntimeMBeanServer(MBeanServer localRuntimeMBeanServer) {
		this.localRuntimeMBeanServer = localRuntimeMBeanServer;
	}
}