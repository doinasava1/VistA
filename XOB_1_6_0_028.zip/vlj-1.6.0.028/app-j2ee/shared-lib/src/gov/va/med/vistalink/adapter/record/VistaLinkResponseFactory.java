package gov.va.med.vistalink.adapter.record;

import gov.va.med.exception.FoundationsException;

/**
 * 
 * Response factory interface used by the connection to parse response string
 * into the response object.
 * <p>
 * Implementations of this interface need to have a default constructor.
 * 
 */
public interface VistaLinkResponseFactory {

	/**
	 * Performs handling of the M side response message.
	 * <p>
	 * This method is responsible for parsing String message from M side and
	 * generating VistaLinkResponseVO implementation.
	 * 
	 * @param response
	 * @param requestVO
	 * @return @throws
	 *         FoundationsException
	 */
	VistaLinkResponseVO handleResponse(String response, VistaLinkRequestVO requestVO)
			throws FoundationsException;

}