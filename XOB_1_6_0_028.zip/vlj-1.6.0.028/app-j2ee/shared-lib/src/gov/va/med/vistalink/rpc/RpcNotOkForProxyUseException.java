package gov.va.med.vistalink.rpc;

import gov.va.med.vistalink.adapter.record.VistaLinkFaultException;

/**
 * This exception represents the case where the requested RPC is not marked as
 * OK for use by an application proxy user, but has been attempted to be invoked
 * by one.
 * 
 */
public class RpcNotOkForProxyUseException extends RpcFaultException {

	/**
	 * Constructor for RpcNotOkForProxyUseException.
	 * 
	 * @see gov.va.med.vistalink.adapter.record.VistaLinkFaultException#VistaLinkFaultException(VistaLinkFaultException)
	 * @param vistaLinkFaultException
	 *            the exception to copy into a new exception type
	 * @va.exclude
	 */
	public RpcNotOkForProxyUseException(VistaLinkFaultException vistaLinkFaultException) {
		super(vistaLinkFaultException);
	}

}

