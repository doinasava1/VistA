package gov.va.med.vistalink.adapter.record;

/**
 * Request factory interface to be used to construct request objects.
 * 
 */
public interface VistaLinkRequestFactory {

}
