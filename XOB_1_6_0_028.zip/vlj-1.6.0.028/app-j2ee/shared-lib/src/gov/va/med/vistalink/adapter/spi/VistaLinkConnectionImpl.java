package gov.va.med.vistalink.adapter.spi;

import gov.va.med.vistalink.adapter.cci.VistaLinkConnection;
import gov.va.med.vistalink.adapter.cci.VistaLinkResourceException;
import gov.va.med.vistalink.adapter.record.VistaLinkFaultException;
import gov.va.med.vistalink.adapter.record.VistaLinkRequestVO;
import gov.va.med.vistalink.adapter.record.VistaLinkResponseFactory;
import gov.va.med.vistalink.adapter.record.VistaLinkResponseVO;
import gov.va.med.vistalink.rpc.RpcRequest;
import gov.va.med.vistalink.rpc.RpcResponse;
import gov.va.med.exception.ExceptionUtils;
import gov.va.med.exception.FoundationsException;

import javax.resource.NotSupportedException;
import javax.resource.ResourceException;
import javax.resource.cci.ConnectionMetaData;
import javax.resource.cci.Interaction;
import javax.resource.cci.LocalTransaction;
import javax.resource.cci.ResultSetInfo;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

/**
 * This implementation class represents an application level connection handle
 * that is used by a component to access an EIS instance.
 * <p>
 * J2SE Example:
 * <p>
 * <code>
 *      // login to server<br>
 *      loginContext.login(); 
 * <p>     
 *      //Gets the principal that contains the VistaLinkConnection<br>
 *      VistaKernelPrincipalImpl myPrincipal = VistaKernelPrincipalImpl.<br>
 *      			getKernelPrincipal(loginContext.getSubject());
 * <p>     
 *      //Get the VistaLinkConnection<br>
 *      VistaLinkConnection myConnection = myPrincipal.getAuthenticatedConnection();
 * <p>     
 *       //request  and response objects<br> 
 *      RpcRequest vReq = null; <br>
 *      RpcResponse vResp = null;
 * <p>     
 *      //The Rpc Context<br>
 *      String rpcContext = &quot;XOBV VISTALINK TESTER&quot;;
 * <p>     
 *      //The Rpc to call<br>
 *      String rpcName = &quot;XOBV TEST PING&quot;;
 * <p>     
 *       //Construct the request object<br>
 *      vReq = RpcRequestFactory.getRpcRequest(rpcContext, rpcName);
 * <p>     
 *      &lt;b&gt;  //Execute the Rpc and get the response<br> 
 *      vResp = myConnection.executeRPC(vReq);
 * <p>     
 *       //Work with the response ...
 * </code>
 * 
 */
public class VistaLinkConnectionImpl implements VistaLinkConnection {

	/**
	 * The logger used by this class
	 */
	private static final Logger logger = Logger.getLogger(VistaLinkConnection.class);

	/**
	 * The managed connection this VistaLinkConnection uses to interact with M
	 */
	private VistaLinkManagedConnection managedConnection;

	/**
	 * This constructor should not be called directly. Used by spi classes.
	 * 
	 * @param mc
	 */
	public VistaLinkConnectionImpl(VistaLinkManagedConnection mc) {
		managedConnection = mc;
	}

	/**
	 * Closes this connection handle. Informs the managed connection that this
	 * handle is closed
	 * 
	 * @throws ResourceException
	 */
	public void close() throws ResourceException {
		try {

			if (managedConnection != null) {
				// reset socket timeout to default
				managedConnection.setDefaultSocketTimeOut();
				managedConnection.closeHandle(this);
				managedConnection = null;
			}
		} catch (ResourceException e) {

			if (logger.isEnabledFor(Level.ERROR)) {
				String errMsg = (new StringBuffer()).append("Can not close connection handle.").append("\n\t").append(
						ExceptionUtils.getFullStackTrace(e)).toString();
				logger.error(errMsg);
			}
			throw e;
		}
	}

	/**
	 * Executes an interaction with M
	 * 
	 * @param requestVO
	 *            the request being made
	 * @param responseFactory
	 *            the factory which will construct the response
	 * @return VistaLinkResponseVO the response from M
	 * @throws VistaLinkFaultException
	 *             thrown if an error occurred on M while processing the request
	 * @throws FoundationsException
	 *             thrown if an internal adapter exception has occurred
	 */
	public VistaLinkResponseVO executeInteraction(VistaLinkRequestVO requestVO, VistaLinkResponseFactory responseFactory)
			throws VistaLinkFaultException, FoundationsException {
		try {
			return getManagedConnection().executeInteraction(requestVO, responseFactory);
		} catch (VistaLinkFaultException e) {
			// Do not want to log application level exceptions
			throw e;
		} catch (FoundationsException e) {

			if (logger.isEnabledFor(Level.ERROR)) {

				String errMsg = (new StringBuffer()).append("Can not execute interaction.").append("\n\t").append(
						ExceptionUtils.getFullStackTrace(e)).toString();

				logger.error(errMsg);
			}

			throw e;
		}
	}

	/**
	 * Executes an interaction with M using the RpcResponseFactory to construct
	 * a response.
	 * 
	 * @param request
	 *            The request being made
	 * @return RpcResponse the response that is returned
	 * @throws VistaLinkFaultException
	 *             thrown if an error occurred on M while processing the request
	 * @throws FoundationsException
	 *             thrown if an internal adapter exception has occurred
	 */
	public RpcResponse executeRPC(RpcRequest request) throws VistaLinkFaultException, FoundationsException {
		try {
			return getManagedConnection().executeRPC(request);
		} catch (VistaLinkFaultException e) {
			// Do not want to log application level exceptions
			throw e;
		} catch (FoundationsException e) {
			if (logger.isEnabledFor(Level.ERROR)) {

				String errMsg = (new StringBuffer()).append("Can not execute RPC.").append("\n\t").append(
						ExceptionUtils.getFullStackTrace(e)).toString();

				logger.error(errMsg);
			}

			throw e;
		}
	}

	/**
	 * Returns current connection time out value.
	 * 
	 * @return int time out value in milli-seconds
	 */
	public int getTimeOut() {
		return (int) managedConnection.getSocketTimeOut();
	}

	/**
	 * Use to set time out for read operations on connections
	 * 
	 * @param timeOut time out value to set in milli-seconds.
	 */
	public void setTimeOut(int timeOut) {
		managedConnection.setSocketTimeOut(timeOut);
	}

	/**
	 * Gets the meta-information on the underlying EIS instance via this
	 * connection
	 * 
	 * @return ConnectionMetaData the value object that contains the metadata
	 *         for this adapter
	 * @throws ResourceException
	 */
	public ConnectionMetaData getMetaData() throws ResourceException {
		try {
			return managedConnection.getConnectionMetaData();
		} catch (VistaLinkResourceException e) {

			if (logger.isEnabledFor(Level.ERROR)) {

				String errMsg = ExceptionUtils.getFullStackTrace(e);

				logger.error(errMsg);
			}
			throw e;
		}
	}

	/**
	 * Returns connection information about the host
	 * 
	 * @return VistaLinkServerInfo the value object that contains connection
	 *         information
	 */
	public VistaLinkServerInfo getConnectionInfo() {
		return new VistaLinkServerInfo(managedConnection.getHostAddr(), managedConnection.getHostPort());
	}

	/**
	 * <b>This method should not be called directly. Used by spi classes. </b>
	 * 
	 * @return VistaLinkManagedConnection the managed connection
	 */
	public VistaLinkManagedConnection getManagedConnection() throws FoundationsException {

		if (managedConnection == null) {

			throw new FoundationsException("The managed connection is null.");

		}
		return managedConnection;
	}

	/**
	 * <b>This method should not be called directly. Used by spi classes. </b>
	 * 
	 * @param mc
	 */
	public void setManagedConnection(VistaLinkManagedConnection mc) {
		managedConnection = mc;
	}

	/**
	 * Empty method. throws NotSupportedException
	 * 
	 * @see javax.resource.cci.Connection#createInteraction()
	 */
	public Interaction createInteraction() throws ResourceException {
		throw new NotSupportedException(
				"VistALink does not implement Iteraction and Record part of CCI interface.  VistaRequest interface is used instead.");
	}

	/**
	 * Empty method. throws NotSupportedException
	 * 
	 * @see javax.resource.cci.Connection#getLocalTransaction()
	 */
	public LocalTransaction getLocalTransaction() throws ResourceException {
		throw new NotSupportedException("VistALink does not support local transactions.");
	}

	/**
	 * Empty method. throws NotSupportedException
	 * 
	 * @see javax.resource.cci.Connection#getResultSetInfo()
	 */
	public ResultSetInfo getResultSetInfo() throws ResourceException {
		throw new NotSupportedException("VistALink does not support ResultSet functionality.");
	}

}