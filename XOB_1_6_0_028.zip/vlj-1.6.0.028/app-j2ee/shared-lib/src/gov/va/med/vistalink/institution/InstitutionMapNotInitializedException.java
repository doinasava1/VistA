package gov.va.med.vistalink.institution;

import gov.va.med.exception.FoundationsException;

/**
 * Represents an attempt to access some functionality of the 
 * InstitutionMapping instance when that instance has not been 
 * created.
 * 
 */
public class InstitutionMapNotInitializedException extends FoundationsException {

	/**
	 * Exception constructor.
	 * @va.exclude
	 */
	public InstitutionMapNotInitializedException()
	{
		super();
	}
	
	/**
	 * Exception constructor.
	 * @param message Exception message.
	 * @va.exclude
	 */
	public InstitutionMapNotInitializedException(String message) {
		super(message);
	}
	
	/**
	 * Exception constructor.
	 * @param nestedException A nested exception.
	 * @va.exclude
	 */
	public InstitutionMapNotInitializedException(Exception nestedException) {
		super(nestedException);
	}
	
	/**
	 * Exception constructor.
	 * @param message Exception message.
	 * @param nestedException A nested exception.
	 * @va.exclude
	 */
	public InstitutionMapNotInitializedException(String message, Exception nestedException) {
		super(message, nestedException);
	}
}
