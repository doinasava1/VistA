package gov.va.med.vistalink.security;

import gov.va.med.vistalink.security.m.SecurityRequestFactory;
import gov.va.med.vistalink.security.m.SecurityVO;
import gov.va.med.vistalink.security.m.SecurityVOChangeVc;
import gov.va.med.vistalink.security.m.SecurityVOLogon;
import gov.va.med.vistalink.security.m.SecurityVOSelectDivision;
import gov.va.med.vistalink.security.m.SecurityVOUserDemographics;
import gov.va.med.vistalink.security.m.VistaKernelPrincipal;
import gov.va.med.vistalink.security.m.SecurityVOSetupAndIntroText;

import java.io.IOException;
import java.util.Map;
import java.util.TreeMap;

import javax.security.auth.Subject;
import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.UnsupportedCallbackException;
import javax.security.auth.login.LoginException;
import javax.security.auth.spi.LoginModule;

import org.apache.log4j.Logger;

/**
 * A JAAS-compliant LoginModule to log users on to a Vista system. An application never needs to access the
 * VistaLoginModule class directly. Rather, as a JAAS login module, its methods are invoked indirectly by an application
 * through the JAAS login context class (<code>javax.security.auth.login.LoginContext</code>).
 * <p>
 * The key classes for invoking a login with this login module are:
 * <ul>
 * <li>a callback handler, either <code>CallbackHandlerSwing</code>, <code>CallbackHandlerSwingCCOW</code> or
 * <code>CallbackHandlerUnitTest</code>
 * <li>the login context (<code>javax.security.auth.login.LoginContext</code>)
 * <li>the Kernel principal returned after a successful login (<code>VistaKernelPrincipalImpl</code>)
 * </ul>
 * An example login:
 * <p>
 * <code>
 * String jaasCfgName = &quot;RpcSampleServer&quot;;
 * <p>
 * // create the callback handler<br>
 * CallbackHandlerSwing cbhSwing = new CallbackHandlerSwing(myFrame);
 * <p>
 * // create the LoginContext<br>
 * loginContext = new LoginContext(jaasCfgName, cbhSwing);
 * <p>
 * // login to server<br>
 * loginContext.login();
 * </code>
 * <p>
 * An example logout:
 * <p>
 * <code>
 * // logout of the server<br>
 * loginContext.logout();
 * </code>
 * 
 * @see CallbackHandlerSwing
 * @see CallbackHandlerUnitTest
 * @see VistaKernelPrincipal
 * @see VistaKernelPrincipalImpl
 */
public final class VistaLoginModule implements LoginModule {

	/**
	 * JAAS configuration key to store/retrieve server IP address. Use this key to pass in the value of this login
	 * option, from a JAAS configuration to the <code>VistaLoginModule</code>.
	 */
	public static final String SERVER_ADDRESS_KEY = "gov.va.med.vistalink.security.ServerAddressKey";

	/**
	 * JAAS configuration key to store/retrieve server IP address, in v1.0. For backwards compatibility.
	 */
	public static final String SERVER_ADDRESS_KEY_V1 = "gov.va.med.foundations.security.vistalink.ServerAddressKey";

	/**
	 * JAAS configuration key to store/retrieve server port. Use this key to pass in the value of this login option,
	 * from a JAAS configuration to the <code>VistaLoginModule</code>.
	 */
	public static final String SERVER_PORT_KEY = "gov.va.med.vistalink.security.ServerPortKey";

	/**
	 * JAAS configuration key to store/retrieve server port, in v1.0. For backwards compatiblity.
	 */
	public static final String SERVER_PORT_KEY_V1 = "gov.va.med.foundations.security.vistalink.ServerPortKey";

	/**
	 * JAAS configuration key to store/retrieve the mode for providing back-end Kernel login services. Valid values for
	 * the JAAS configuration:
	 * <ul>
	 * <li><i>client-server </i>: client/server mode (java client/M server)
	 * <li><i>wls </i>: J2EE n-tier mode with WebLogic server
	 * <li><i>mock </i>: mock back-end interface (can be used with unit testing)
	 * <li>(default if not specified) client/server mode
	 * </ul>
	 * Use this key to pass in the value of this login option, from a JAAS configuration to the
	 * <code>VistaLoginModule</code>.
	 */
	public static final String SERVER_SPI_KEY = "gov.va.med.vistalink.security.SPIKey";

	/**
	 * keep track of the JAAS subject passed in from the LoginContext
	 */
	private Subject subject;

	/**
	 * keep track of the principal created/returned by this loginmodule
	 */
	private VistaKernelPrincipalImpl userPrincipal;

	/**
	 * keep track of JAAS options passed in
	 */
	private Map options;

	/**
	 * keep track of JAAS callback handler passed in
	 */
	private CallbackHandler callbackHandler;

	/**
	 * keep track of JAAS shared state, to add or read
	 */
	private Map sharedState;

	/**
	 * Initialize Logger instance to be used by this class
	 */
	private static final Logger logger = Logger.getLogger(VistaLoginModule.class);

	/**
	 * global timeout value
	 */
	private int timeoutInSeconds = 0;

	/**
	 * keeps track of whether a Kernel CCOW token was used for login, rather than access/verify code
	 */
	private boolean ccowTokenUsedForLogin = false;

	/**
	 * keeps track of whether the CCOW is being used for this login
	 */
	private boolean ccowLoginModeEnabled = false;

	/**
	 * used to pass domain name to CCOW
	 */
	private String domainName = "";

	/**
	 * used to pass vpid to CCOW
	 */
	private String vpid = "";

	/**
	 * timeout value to use when we don't have a timeout value from M (i.e., kernel auto-logon)
	 */
	private static final int AUTOLOGON_TIMEOUT_VALUE = 200;

	/**
	 * number of times to retry login without encountering a 'known' error
	 */
	private static final int LOGIN_TRY_COUNT_LIMIT = 10;

	/**
	 * SPI types
	 */
	private static final int LOGIN_SPI_MODE_UNKNOWN = 0;

	private static final int LOGIN_SPI_MODE_CLIENT_SERVER = 1;

	private static final int LOGIN_SPI_MODE_MOCK = 2;

	private static final int LOGIN_SPI_MODE_FATKAAT = 3;

	private static final int LOGIN_SPI_MODE_UNITTEST = 4;

	/**
	 * @va.exclude
	 */
	public VistaLoginModule() {
	}

	/**
	 * keeps track of the Kernel SPI type used for back-end login services
	 */
	private int loginSPIMode;

	/**
	 * The instantiated back-end login service provider class
	 */
	private VistaLoginModuleSPI loginSPI;

	/**
	 * Should never be called by an application directly. Instead, this method is invoked behind the scenes by the proxy
	 * of the JAAS LoginContext.
	 * <p>
	 * Part of the JAAS interface for a login module; initializes the login module.
	 * 
	 * @param subject 
	 *            the subject to be authenticated.
	 * @param callbackHandler
	 *            a callback handler for communicating with the end user. The VistaLoginModule login module does not
	 *            make use of this.
	 * @param sharedState
	 *            state shared with other configuration login modules. Not used by the VistaLoginModule login module.
	 * @param options
	 *            This is where the configuration options passed to the LoginContext are then passed to the LoginModule.
	 * @va.exclude
	 */
	public void initialize(Subject subject, CallbackHandler callbackHandler, Map sharedState, Map options) {
		this.subject = subject;
		this.options = options;
		this.sharedState = sharedState;
		this.callbackHandler = callbackHandler;

		/*
		 * Instantiate the VistaLoginModuleSPI provider, and set the mode
		 */

		String loginSPIClassName = (String) this.options.get(SERVER_SPI_KEY);
		// default to client/server mode if key not present in JAAS options
		if ((loginSPIClassName == null) || (loginSPIClassName.equals(""))) {
			loginSPIClassName = "gov.va.med.vistalink.security.VistaLoginModuleSPIClientServer";
		}
		this.loginSPIMode = LOGIN_SPI_MODE_UNKNOWN;
		try {
			this.loginSPI = (VistaLoginModuleSPI) Class.forName(loginSPIClassName).newInstance();
			if (loginSPIClassName.equals("gov.va.med.vistalink.security.VistaLoginModuleSPIClientServer")) {
				this.loginSPIMode = LOGIN_SPI_MODE_CLIENT_SERVER;
			} else if (loginSPIClassName.equals("gov.va.med.vistalink.security.VistaLoginModuleSPIMock")) {
				this.loginSPIMode = LOGIN_SPI_MODE_MOCK;
			} else if (loginSPIClassName.equals("gov.va.med.authentication.kernel.fatkaat.VistaLoginModuleSPIFatKAAT")) {
				this.loginSPIMode = LOGIN_SPI_MODE_FATKAAT;
			} else if (loginSPIClassName.equals("gov.va.med.vistalink.security.VistaLoginModuleSPIUnitTest")) {
				this.loginSPIMode = LOGIN_SPI_MODE_FATKAAT;
			}
		} catch (ClassNotFoundException e) {
			logger.error("VistaLoginModuleSPI error: " + e.getMessage());
		} catch (InstantiationException e) {
			logger.error("VistaLoginModuleSPI error: " + e.getMessage());
		} catch (IllegalAccessException e) {
			logger.error("VistaLoginModuleSPI error: " + e.getMessage());
		}
	}

	/**
	 * Should never be called by an application directly. Instead, this method is invoked behind the scenes by the proxy
	 * of the JAAS LoginContext.
	 * <p>
	 * When an application invokes login() on the LoginContext, the LoginContext calls this method to initiate a login
	 * to a VistaLink M server. Once a successful login has occurred, the authenticated connection will be stored in the
	 * JAAS subject, in a VistaKernelPrincipal.
	 * 
	 * @return true if the authentication succeeded, or false if this LoginModule should be ignored.
	 * @throws VistaLoginModuleException 
	 *            a VistaLoginModuleException is thrown if the login for this module fails.
	 * @throws VistaLoginModuleLoginsDisabledException
	 *            thrown if logins are disabled
	 * @throws VistaLoginModuleNoJobSlotsAvailableException
	 *            thrown if no job slots are available
	 * @throws VistaLoginModuleNoPathToListenerException
	 *            thrown if the specified listener can't be reached
	 * @throws VistaLoginModuleTooManyInvalidAttemptsException
	 *            thrown if too many bad login attempts are made
	 * @throws VistaLoginModuleUserCancelledException
	 *             thrown if user cancels the login
	 * @throws VistaLoginModuleUserTimedOutException
	 *             thrown if user times out of the login
	 * @va.exclude
	 */
	public boolean login() throws VistaLoginModuleException, VistaLoginModuleLoginsDisabledException,
			VistaLoginModuleNoJobSlotsAvailableException, VistaLoginModuleNoPathToListenerException,
			VistaLoginModuleTooManyInvalidAttemptsException, VistaLoginModuleUserCancelledException,
			VistaLoginModuleUserTimedOutException {

		String exceptionMessage = "VistaLoginModule login method failed.";

		if (this.loginSPIMode == LOGIN_SPI_MODE_UNKNOWN) {
			String loginSPIMode = (String) this.options.get(SERVER_SPI_KEY);
			if (loginSPIMode == null) {
				loginSPIMode = " [null] ";
			}
			String errMessage = "Login SPI provider class '" + loginSPIMode + "' is unsupported.";
			logger.error(exceptionMessage);
			throw new VistaLoginModuleException(errMessage);
		}

		// get the connection factory
		try {

			loginSPI.initialize(options, sharedState);

		} catch (IOException e) {

			logoutConnectionBeforeLoginComplete();
			logger.error(exceptionMessage, e);
			throw new VistaLoginModuleException(exceptionMessage, e);

		} catch (UnsupportedCallbackException e) {

			logoutConnectionBeforeLoginComplete();
			logger.error(exceptionMessage, e);
			throw new VistaLoginModuleException(exceptionMessage, e);

		} catch (VistaLoginModuleException e) {

			/*
			 * this catch block prevents VistaLoginModuleExceptions and descendants from being caught in the 'catch-all'
			 * catch (Exception e) block where they would be re-wrapped inside another VistaLoginModuleException
			 */
			throw e;

		} catch (Exception e) {

			logoutConnectionBeforeLoginComplete();
			logger.error(exceptionMessage, e);
			throw new VistaLoginModuleException(exceptionMessage, e);

		}

		// Do the complete authentication/logon. All
		// non-VistaLoginModuleException exceptions thrown should be
		// caught/processed in lower level methods. Lower level method catches
		// that exception and throws a VistaLoginModuleException,
		// which is then passed through here up to LoginContext and the calling
		// app.
		performAllLogonSteps();

		return true;
	}

	/**
	 * Performs the complete set of steps to log on to the M system, including a/v code, division selection, and new
	 * verify code entry
	 * 
	 * @throws VistaLoginModuleException
	 *            a VistaLoginModuleException is thrown if the login for this module fails.
	 * @throws VistaLoginModuleTooManyInvalidAttemptsException
	 *            thrown if too many bad login attempts are made
	 * @throws VistaLoginModuleUserCancelledException
	 *            thrown if user cancels the login
	 * @throws VistaLoginModuleUserTimedOutException
	 *            thrown if user times out of the login
	 */
	private void performAllLogonSteps() throws VistaLoginModuleException,
			VistaLoginModuleTooManyInvalidAttemptsException, VistaLoginModuleUserCancelledException,
			VistaLoginModuleUserTimedOutException {

		String postSignInText = null;
		Callback[] calls = null;
		boolean enteredVerifyCodeWasNull = false;
		// tryCount is used by CVC dialog to enable/disable prompt for old v/c, and as login failure limit
		int tryCount = 0;

		// 1. M-side setup, get intro text
		SecurityVOSetupAndIntroText setupInfo = new SecurityVOSetupAndIntroText();

		/*
		 * initialize a logonResponseData object in case auto-signon is returned when setup/intro text is called
		 */
		SecurityVOLogon autoLogonResponseData = getIntroductoryTextAndSetupInfo(setupInfo);

		// 2. if Kernel auto-signon occured, logonResponseData will be populated
		if (autoLogonResponseData != null) {

			timeoutInSeconds = AUTOLOGON_TIMEOUT_VALUE;
			if (logger.isDebugEnabled()) {
				logger.debug("Result: " + autoLogonResponseData.getResultType());
			}
			// get post-sign-in text for later
			postSignInText = autoLogonResponseData.getPostSignInText();
			// if we need to change verify code or select a division, do it
			if (autoLogonResponseData.getResultType() == SecurityVO.RESULT_PARTIAL) {

				doSelectDivisionAndOrChangeVc(autoLogonResponseData, setupInfo.getLogonRetryCount(),
						enteredVerifyCodeWasNull);
			}

		} else {

			// 3. Kernel auto-signon did not occur, so, normal processing here.
			String exceptionMessage = "Error during login: ";

			// get the non-user-specific timeout to use at first
			timeoutInSeconds = setupInfo.getTimeout();

			try {

				/*
				 * 4. try to login do while true: means login will be repeated until an exception is thrown. when we
				 * exceed the max signons on the M side, an exception is thrown.
				 */

				do {
					tryCount++;
					// callback START (get access/verify codes)
					calls = new Callback[1];
					CallbackLogon avCbh = new CallbackLogon(setupInfo, timeoutInSeconds, tryCount);
					calls[0] = avCbh;
					callbackHandler.handle(calls);
					if (avCbh.getSelectedOption() == CallbackLogon.KEYPRESS_CANCEL) {
						logoutConnectionBeforeLoginComplete();
						throw new VistaLoginModuleUserCancelledException("User cancelled access/verify code sign on.");
					} else if (avCbh.getSelectedOption() == CallbackLogon.KEYPRESS_TIMEOUT) {
						logoutConnectionBeforeLoginComplete();
						throw new VistaLoginModuleUserTimedOutException(
								"User timed out during access/verify code sign on.");
					} else if (avCbh.getSelectedOption() != CallbackLogon.KEYPRESS_OK) {
						logoutConnectionBeforeLoginComplete();
						throw new VistaLoginModuleUserCancelledException(
								"Access/verify code sign on completed without user pressing OK.");
					}
					// callback END

					// get from the callback handler whether CCOW logins should
					// be attempted
					if (avCbh.getCcowLogonModeEnabled()) {
						this.ccowLoginModeEnabled = true;
					}

					// get login credentials -- either Kernel CCOW token or a/v
					// code
					if (avCbh.getToken().length() > 0) {
						this.ccowTokenUsedForLogin = true;
					} else {
						String accessCode = avCbh.getAccessCode();
						String verifyCode = avCbh.getVerifyCode();
						/*
						 * record if the entered verify code was null; might be needed later in CVC to decide whether to
						 * gray out the "Enter old verify code" dialog box
						 */
						if ((accessCode.indexOf(';') == -1) && (verifyCode.trim().length() == 0)) {
							enteredVerifyCodeWasNull = true;
						} else {
							enteredVerifyCodeWasNull = false;
						}
					}

					if (logger.isDebugEnabled()) {
						logger.debug("-> sending " + SecurityRequestFactory.MSG_ACTION_LOGON);
					}

					SecurityVOLogon logonResponseData = null;

					if (ccowTokenUsedForLogin) {
						logonResponseData = loginSPI.doKernelLogon(avCbh.getToken());
					} else {
						logonResponseData = loginSPI.doKernelLogon(avCbh.getAccessCode(), avCbh.getVerifyCode(), avCbh
								.getRequestCvc());
					}

					if (logger.isDebugEnabled()) {
						logger.debug("Result: " + logonResponseData.getResultType());
					}

					postSignInText = logonResponseData.getPostSignInText();
					// 5. need to change verify code or select a division?
					if (logonResponseData.getResultType() == SecurityVO.RESULT_PARTIAL) {

						doSelectDivisionAndOrChangeVc(logonResponseData, setupInfo.getLogonRetryCount(),
								enteredVerifyCodeWasNull);

						// if got here, change v/c and/or select division
						// actions were successful
						break;

					} else if (logonResponseData.getResultType() == SecurityVO.RESULT_SUCCESS) {
						// if got here, original signon was successful
						break;

					} else {
						// there was an error in the signon. Display error
						// message.

						String errorMessage = null;
						// if we're in CCOW mode, the token failed. Set CCOW
						// mode to false, clear token
						if (ccowTokenUsedForLogin) {

							ccowTokenUsedForLogin = false;
							avCbh.setToken("");
							errorMessage = "CCOW token for Single Signon expired or is not valid for this server.\nTrying interactive login next.";

						} else {
							errorMessage = logonResponseData.getResultMessage();
						}

						// Display error message.
						doCallbackConfirm(errorMessage, CallbackConfirm.ERROR_MESSAGE, "Login Error");
					}
				} while (tryCount < LOGIN_TRY_COUNT_LIMIT);

			} catch (UnsupportedCallbackException e) {

				// don't need to log here, it's already logged lower down
				logoutConnectionBeforeLoginComplete();
				throw new VistaLoginModuleException(exceptionMessage, e);

			} catch (IOException e) {

				logoutConnectionBeforeLoginComplete();
				logger.error(exceptionMessage, e);
				throw new VistaLoginModuleException(exceptionMessage, e);

			} catch (VistaLoginModuleException e) {
				/*
				 * this catch block prevents VistaLoginModuleExceptions and descendants from being caught in the
				 * 'catch-all' catch (Exception e) block where they would be re-wrapped inside another
				 * VistaLoginModuleException
				 */
				throw e;

			} catch (Exception e) {

				logoutConnectionBeforeLoginComplete();
				logger.error(exceptionMessage, e);
				throw new VistaLoginModuleException(exceptionMessage, e);
			}
		}

		/*
		 * If got here, login was successful; either by regular login or by Kernel auto-signon. So, do
		 * post-authentication/logon activities.
		 */

		// 6. display post-sign-in text if there are lines of text to display
		if ((postSignInText.length() > 0) && (!this.ccowTokenUsedForLogin)) {
			doCallbackConfirm(postSignInText, CallbackConfirm.POST_TEXT_MESSAGE, "Post-sign-in Text");
		}
		// 7. get user demographics
		getUserDemographicsAndBuildPrincipal();

		// 8. add authenticated connection to user principal (client/server mode)
		try {
			loginSPI.addSPISpecificInformationToPrincipal(userPrincipal);
		} catch (Exception e) {
			String exceptionMessage = "Logon error: Could not add SPI-specific information to user principal.";
			logoutConnectionBeforeLoginComplete();
			logger.error(exceptionMessage, e);
			throw new VistaLoginModuleException(exceptionMessage, e);
		}

	}

	/**
	 * Perform pre-authentication setup and get the introductory text and other server information from the M system. If
	 * Kernel auto-signon is triggered, however, the return type will be for a successful logon.
	 * 
	 * @param introTextAndServerInfo
	 *            object to return introductory text / server info in
	 * @return SecurityVOLogon If Kernel auto-signon is triggered, a logon response object is returned. Otherwise
	 *            (normal processing) null is returned.
	 * @throws VistaLoginModuleException
	 *            thrown if an error is encountered
	 */
	private SecurityVOLogon getIntroductoryTextAndSetupInfo(SecurityVOSetupAndIntroText introTextAndServerInfo)
			throws VistaLoginModuleException {

		SecurityVOLogon returnVal = null;
		String exceptionMessage = "Error doing M setup/introduction text retrieval: ";

		try {
			if (logger.isDebugEnabled()) {
				logger.debug("-> sending " + SecurityRequestFactory.MSG_ACTION_SETUP_AND_INTRO_TEXT);
			}

			Object responseDataObj = loginSPI.getSetupAndIntroTextInfo();

			if (responseDataObj instanceof SecurityVOSetupAndIntroText) {

				SecurityVOSetupAndIntroText myInfo = (SecurityVOSetupAndIntroText) responseDataObj;
				if (logger.isDebugEnabled()) {
					logger.debug("Result: " + myInfo.getResultType());
				}

				// SecurityVOSetupAndIntroText myInfo =
				// responseData.getSetupAndIntroTextInfo();

				// copy results into object instance specified in method
				// parameter
				introTextAndServerInfo.setDevice(myInfo.getDevice());
				introTextAndServerInfo.setIntroductoryText(myInfo.getIntroductoryText());
				introTextAndServerInfo.setServerName(myInfo.getServerName());
				introTextAndServerInfo.setUci(myInfo.getUci());
				introTextAndServerInfo.setVolume(myInfo.getVolume());
				introTextAndServerInfo.setLogonRetryCount(myInfo.getLogonRetryCount());
				introTextAndServerInfo.setTimeout(myInfo.getTimeout());

			} else if (responseDataObj instanceof SecurityVOLogon) {

				// return the logon response to the caller
				returnVal = (SecurityVOLogon) responseDataObj;

			} else {

				String errMessage = exceptionMessage + "; Unexpected response class for "
						+ SecurityRequestFactory.MSG_ACTION_SETUP_AND_INTRO_TEXT + " request: ";
				if (responseDataObj != null) {
					errMessage = errMessage + responseDataObj.getClass().getName();
				} else {
					errMessage = errMessage + "null";
				}

				logger.error(errMessage);
				logoutConnectionBeforeLoginComplete();
				throw new VistaLoginModuleException(errMessage);
			}

		} catch (IOException e) {

			logger.error(exceptionMessage, e);
			logoutConnectionBeforeLoginComplete();
			throw new VistaLoginModuleException(exceptionMessage, e);

		} catch (UnsupportedCallbackException e) {

			logger.error(exceptionMessage, e);
			logoutConnectionBeforeLoginComplete();
			throw new VistaLoginModuleException(exceptionMessage, e);

		} catch (VistaLoginModuleException e) {

			/*
			 * this catch block prevents VistaLoginModuleExceptions and descendants, thrown and already logged at lower
			 * levels, from being caught in the 'catch-all' catch (Exception e) block where they would be re-wrapped
			 * inside another VistaLoginModuleException.
			 */
			throw e;

		} catch (Exception e) {

			logger.error(exceptionMessage, e);
			logoutConnectionBeforeLoginComplete();
			throw new VistaLoginModuleException(exceptionMessage, e);
		}

		return returnVal;
	}

	/**
	 * Called by both the "auto-logon" and regular logon code to process a partially successful login (i.e., either the
	 * v/c needs to be changed or a division needs to be selected.)
	 * 
	 * @param responseData
	 *            the logon response returned from the logon attempt that was partially successful
	 * @param retryLogonCount #
	 *            of times to retry the login
	 * @throws VistaLoginModuleException
	 */
	private void doSelectDivisionAndOrChangeVc(SecurityVOLogon responseData, int retryLogonCount,
			boolean enteredVerifyCodeWasNull) throws VistaLoginModuleException {

		if (logger.isDebugEnabled()) {
			logger.debug("Need new Verify Code: " + responseData.getNeedNewVerifyCode() + " Need to select Divisions: "
					+ responseData.getNeedDivisionSelection());
		}

		// change verify code
		if (responseData.getNeedNewVerifyCode()) {
			doChangeVC(responseData.getResultMessage(), responseData.getCvcHelpText(), retryLogonCount,
					enteredVerifyCodeWasNull);

		} else if (responseData.getNeedDivisionSelection()) {
			// need to select a division
			doSelectDivision((TreeMap) responseData.getDivisionList(), retryLogonCount);
		} else {
			logoutConnectionBeforeLoginComplete();
			throw new VistaLoginModuleException(
					"Logon response was partial success, but M provided no reason for why login is only a partial success!");
		}
	}

	/**
	 * Changes the verify code.
	 * 
	 * @param changeVCMessage
	 *            text message from M explaining why CVC is needed
	 * @param cvcHelpText
	 *            text from M to display if help button is pressed on CVC dialog
	 * @param retryLogonCount 
	 *            number of times M says to retry logon
	 * @throws VistaLoginModuleException
	 *            a VistaLoginModuleException is thrown if the login for this module fails.
	 * @throws VistaLoginModuleTooManyInvalidAttemptsException
	 *            thrown if too many bad login attempts are made
	 * @throws VistaLoginModuleUserCancelledException
	 *            thrown if user cancels the login
	 * @throws VistaLoginModuleUserTimedOutException
	 *            thrown if user times out of the login
	 */
	private void doChangeVC(String changeVCMessage, String cvcHelpText, int retryLogonCount,
			boolean enteredVerifyCodeWasNull) throws VistaLoginModuleException,
			VistaLoginModuleTooManyInvalidAttemptsException, VistaLoginModuleUserCancelledException,
			VistaLoginModuleUserTimedOutException {

		String vcOld = "", vcNew = "", vcNewCheck = "";
		int tryCount = 0;
		String exceptionMessage = "Change verify code failed: ";

		try {
			do {
				// callback START (get old, new and check vc)
				Callback[] calls = new Callback[1];
				CallbackChangeVc changeVcCbh = new CallbackChangeVc(changeVCMessage, cvcHelpText, timeoutInSeconds,
						enteredVerifyCodeWasNull);
				calls[0] = changeVcCbh;
				callbackHandler.handle(calls);
				vcOld = changeVcCbh.getOldVerifyCode();
				vcNew = changeVcCbh.getNewVerifyCode();
				vcNewCheck = changeVcCbh.getNewVerifyCodeCheck();
				if (changeVcCbh.getSelectedOption() == CallbackChangeVc.KEYPRESS_CANCEL) {
					logoutConnectionBeforeLoginComplete();
					throw new VistaLoginModuleUserCancelledException("User cancelled changing of verify code.");
				} else if (changeVcCbh.getSelectedOption() == CallbackChangeVc.KEYPRESS_TIMEOUT) {
					logoutConnectionBeforeLoginComplete();
					throw new VistaLoginModuleUserTimedOutException("User changing of verify code timed out.");
				} else if (changeVcCbh.getSelectedOption() != CallbackChangeVc.KEYPRESS_OK) {
					logoutConnectionBeforeLoginComplete();
					throw new VistaLoginModuleUserCancelledException("User did not press OK when changing verify code.");
				}
				// callback END

				if (!vcNew.equals(vcNewCheck)) {
					// error if confirmation doesn't equal new vc -- this is
					// *not* checked by the M side call
					doCallbackConfirm("The confirmation code does not match.", CallbackConfirm.ERROR_MESSAGE,
							"Change Verify Code Error");
					tryCount++;
					if (tryCount >= retryLogonCount) {
						logoutConnectionBeforeLoginComplete();
						throw new VistaLoginModuleTooManyInvalidAttemptsException(
								"Change verify code failed due to invalid user entry.");
					}

				} else {

					if (logger.isDebugEnabled()) {
						logger.debug("-> sending " + SecurityRequestFactory.MSG_ACTION_UPDATE_VC);
					}

					SecurityVOChangeVc responseData = this.loginSPI.changeVerifyCode(vcOld.toUpperCase(), vcNew
							.toUpperCase(), vcNewCheck.toUpperCase());

					if (logger.isDebugEnabled()) {
						logger.debug("Result: " + responseData.getResultType());
					}

					// now check if need to select divisions after vc changed
					if (responseData.getResultType() == SecurityVO.RESULT_PARTIAL) {
						doCvcConfirm();
						// need to select a division
						if (responseData.getNeedDivisionSelection()) {

							if (logger.isDebugEnabled()) {
								logger.debug("Need to select divisions: " + responseData.getNeedDivisionSelection());
							}

							doSelectDivision((TreeMap) responseData.getDivisionList(), retryLogonCount);
						}
						// if we made it here, division selection was
						// successful, so break
						break;

					} else if (responseData.getResultType() == SecurityVO.RESULT_SUCCESS) {
						// if we had success, then break
						doCvcConfirm();
						break;

					} else {
						// display error
						StringBuffer sb = new StringBuffer("Change Verify Code failed:\n");
						sb.append(responseData.getResultMessage());
						doCallbackConfirm(sb.toString(), CallbackConfirm.ERROR_MESSAGE, "Change Verify Code Error");
						tryCount++;
						if (tryCount >= retryLogonCount) {
							logoutConnectionBeforeLoginComplete();
							throw new VistaLoginModuleTooManyInvalidAttemptsException(
									"Change verify code failed due to invalid user entry.");
						}
					}
				}
			} while (true);

		} catch (UnsupportedCallbackException e) {

			// don't need to log here, it's already logged lower down
			logoutConnectionBeforeLoginComplete();
			throw new VistaLoginModuleException(exceptionMessage, e);

		} catch (IOException e) {
			logoutConnectionBeforeLoginComplete();
			logger.error(exceptionMessage, e);
			throw new VistaLoginModuleException(exceptionMessage, e);

		} catch (VistaLoginModuleException e) {

			/*
			 * this catch block prevents VistaLoginModuleExceptions and descendants from being caught in the 'catch-all'
			 * catch (Exception e) block where they would be re-wrapped inside another VistaLoginModuleException
			 */
			throw e;

		} catch (Exception e) {

			logoutConnectionBeforeLoginComplete();
			logger.error(exceptionMessage, e);
			throw new VistaLoginModuleException(exceptionMessage, e);

		}
	}

	/**
	 * Selects a division.
	 * 
	 * @param divisionList
	 *            list of divisions to select from
	 * @param retryLogonCount
	 *            how many times to retry any particular dialog
	 * @throws VistaLoginModuleException
	 *            a VistaLoginModuleException is thrown if the login for this module fails.
	 * @throws VistaLoginModuleTooManyInvalidAttemptsException
	 *            thrown if too many bad login attempts are made
	 * @throws VistaLoginModuleUserCancelledException
	 *            thrown if user cancels the login
	 * @throws VistaLoginModuleUserTimedOutException
	 *            thrown if user times out of the login
	 */
	private void doSelectDivision(TreeMap divisionList, int retryLogonCount) throws VistaLoginModuleException,
			VistaLoginModuleTooManyInvalidAttemptsException, VistaLoginModuleUserCancelledException,
			VistaLoginModuleUserTimedOutException {

		// if logged on via CCOW token, DUZ(2) will be defined
		// when the token is used to logon, even if VALIDAV reports
		// that selecting a division is needed

		if (!this.ccowTokenUsedForLogin) {

			int tryCount = 0;
			String exceptionMessage = "Division selection failed: ";
			try {
				do {
					// callback START (select division)
					Callback[] calls = new Callback[1];
					CallbackSelectDivision divCbh = new CallbackSelectDivision(divisionList, timeoutInSeconds);
					calls[0] = divCbh;
					callbackHandler.handle(calls);
					String selectedDivision = divCbh.getSelectedDivisionIen();
					if (divCbh.getSelectedOption() == CallbackSelectDivision.KEYPRESS_CANCEL) {
						logoutConnectionBeforeLoginComplete();
						throw new VistaLoginModuleUserCancelledException("User cancelled division selection.");
					} else if (divCbh.getSelectedOption() == CallbackSelectDivision.KEYPRESS_TIMEOUT) {
						logoutConnectionBeforeLoginComplete();
						throw new VistaLoginModuleUserTimedOutException("User division selection timed out.");
					} else if (divCbh.getSelectedOption() != CallbackSelectDivision.KEYPRESS_OK) {
						logoutConnectionBeforeLoginComplete();
						throw new VistaLoginModuleUserCancelledException(
								"Select Division failed without user pressing OK.");
					}
					// callback END

					if (logger.isDebugEnabled()) {
						logger.debug("-> sending " + SecurityRequestFactory.MSG_ACTION_SELECT_DIVISION);
					}

					SecurityVOSelectDivision responseData = loginSPI.selectDivision(selectedDivision);

					if (logger.isDebugEnabled()) {
						logger.debug("Result: " + responseData.getResultType());
					}

					if (responseData.getResultType() == SecurityVO.RESULT_SUCCESS) {

						// we're successful, break out of loop.
						break;

					} else {
						// display error
						doCallbackConfirm(responseData.getResultMessage(), CallbackConfirm.ERROR_MESSAGE,
								"Select Division Error");
						// check retries
						tryCount++;
						if (tryCount >= retryLogonCount) {
							// logout to clear up the connection that has DUZ
							// set up on the other end
							logoutConnectionBeforeLoginComplete();
							throw new VistaLoginModuleException(
									"Division selection failed due to too many invalid user entries.");
						}
					}
				} while (true);

			} catch (UnsupportedCallbackException e) {

				// don't need to log here, it's already logged lower down
				logoutConnectionBeforeLoginComplete();
				throw new VistaLoginModuleException(exceptionMessage, e);

			} catch (IOException e) {

				logoutConnectionBeforeLoginComplete();
				logger.error(exceptionMessage, e);
				throw new VistaLoginModuleException(exceptionMessage, e);

			} catch (VistaLoginModuleException e) {

				/*
				 * this catch block prevents VistaLoginModuleExceptions and descendants from being caught in the
				 * 'catch-all' catch (Exception e) block where they would be re-wrapped inside another
				 * VistaLoginModuleException
				 */
				throw e;

			} catch (Exception e) {

				logoutConnectionBeforeLoginComplete();
				logger.error(exceptionMessage, e);
				throw new VistaLoginModuleException(exceptionMessage, e);

			}
		}
	}

	/**
	 * Standardizes the "change verify code" dialog confirmations
	 * 
	 * @throws VistaLoginModuleException
	 *            a VistaLoginModuleException is thrown if the login for this module fails.
	 * @throws VistaLoginModuleUserCancelledException
	 *            thrown if user cancels the login
	 * @throws VistaLoginModuleUserTimedOutException
	 *            thrown if user times out of the login
	 */
	private void doCvcConfirm() throws VistaLoginModuleException, VistaLoginModuleUserCancelledException,
			VistaLoginModuleUserTimedOutException {

		doCallbackConfirm("Change of Verify Code succeeded.", CallbackConfirm.INFORMATION_MESSAGE,
				"Change Verify Code Confirmation");
	}

	/**
	 * Calls the confirm dialog for any kind of confirmation.
	 * 
	 * @param messageText
	 *            the text of the message to display
	 * @param messageType
	 *            the type of message (see types in CallbackConfirm class)
	 * @param contextDescription
	 *            Describes the context of the dialog display. Used for window title (verbatim) and also pre-pended to
	 *            exception text if an exception is returned.
	 * @throws VistaLoginModuleException
	 *            a VistaLoginModuleException is thrown if the login for this module fails.
	 * @throws VistaLoginModuleUserCancelledException
	 *            thrown if user cancels the login
	 * @throws VistaLoginModuleUserTimedOutException
	 *            thrown if user times out of the login
	 */
	private void doCallbackConfirm(String messageText, int messageType, String contextDescription)
			throws VistaLoginModuleException, VistaLoginModuleUserCancelledException,
			VistaLoginModuleUserTimedOutException {

		String exceptionMessage = contextDescription + " error: ";
		try {
			Callback[] calls = new Callback[1];
			CallbackConfirm ccCbh = new CallbackConfirm(messageText, messageType, contextDescription, timeoutInSeconds);
			calls[0] = ccCbh;
			callbackHandler.handle(calls);
			if (ccCbh.getSelectedOption() == CallbackConfirm.KEYPRESS_CANCEL) {
				logoutConnectionBeforeLoginComplete();
				throw new VistaLoginModuleUserCancelledException(contextDescription + ": User cancelled.");
			} else if (ccCbh.getSelectedOption() == CallbackConfirm.KEYPRESS_TIMEOUT) {
				logoutConnectionBeforeLoginComplete();
				throw new VistaLoginModuleUserTimedOutException(contextDescription + ": User timed out.");
			} else if (ccCbh.getSelectedOption() != CallbackConfirm.KEYPRESS_OK) {
				logoutConnectionBeforeLoginComplete();
				throw new VistaLoginModuleUserCancelledException(contextDescription
						+ ": User did not press OK to close dialog.");
			}

		} catch (UnsupportedCallbackException e) {

			// don't need to log here, it's already logged lower down
			logoutConnectionBeforeLoginComplete();
			throw new VistaLoginModuleException(exceptionMessage, e);

		} catch (IOException e) {

			logoutConnectionBeforeLoginComplete();
			logger.error(exceptionMessage, e);
			throw new VistaLoginModuleException(exceptionMessage, e);
		}
	}

	/**
	 * Build a VistaKernelPrincipal that holds user demographics of the authenticated user
	 * 
	 * @throws VistaLoginModuleException
	 */
	private void getUserDemographicsAndBuildPrincipal() throws VistaLoginModuleException {

		String exceptionMessage = "User Demographic retrieval failure: ";
		if (logger.isDebugEnabled()) {
			logger.debug("-> sending " + SecurityRequestFactory.MSG_ACTION_USER_DEMOGRAPHICS);
		}
		SecurityVOUserDemographics responseData = null;

		try {

			responseData = this.loginSPI.getUserDemographicsData();

		} catch (VistaLoginModuleException e) {

			/*
			 * this catch block prevents VistaLoginModuleExceptions and descendants from being caught in the 'catch-all'
			 * catch (Exception e) block where they would be re-wrapped inside another VistaLoginModuleException
			 */
			throw e;

		} catch (Exception e) {

			logger.error(exceptionMessage, e);
			throw new VistaLoginModuleException(exceptionMessage, e);
		}

		if (logger.isDebugEnabled()) {
			logger.debug("Result: " + responseData.getResultType());
		}

		if (responseData.getResultType() == SecurityVO.RESULT_SUCCESS) {
			// store domain name, remove it
			this.domainName = (String) responseData.getUserDemographicsHashtable().get(
					VistaKernelPrincipal.KEY_DOMAIN_NAME);
			responseData.getUserDemographicsHashtable().remove(VistaKernelPrincipal.KEY_DOMAIN_NAME);
			// store vpid
			this.vpid = (String) responseData.getUserDemographicsHashtable().get(VistaKernelPrincipal.KEY_VPID);
			// create principal
			userPrincipal = new VistaKernelPrincipalImpl(responseData.getUserDemographicsHashtable());
		} else {
			logoutConnectionBeforeLoginComplete();
			throw new VistaLoginModuleException(exceptionMessage + responseData.getResultMessage());
		}
	}

	/**
	 * Should never be called by an application directly. Instead, this method is invoked behind the scenes by the proxy
	 * of the JAAS LoginContext.
	 * <p>
	 * Part of the JAAS interface for a login module. Since we don't have a two-phase login, this always returns true
	 * (and is irrelevant to the success or failure of a login).
	 * 
	 * @throws LoginException
	 *            this is never thrown by this implementation of commit().
	 * @return this implementation of commit() always returns true.
	 * @va.exclude
	 */
	public boolean commit() throws LoginException {
		// Now it's time to add the principal to the subject
		if (!subject.getPrincipals().contains(userPrincipal)) {
			subject.getPrincipals().add(userPrincipal);
		}

		// Rest of this method is a hook for doing CCOW-related commit actions
		// -- writing the user context.
		if ((!this.ccowTokenUsedForLogin) && (this.ccowLoginModeEnabled)) {

			StringBuffer errorSb = new StringBuffer("Warning -- could not create CCOW User Context during login.");
			errorSb.append("SSO (Single Sign On) may not be enabled for subsequent applications.");
			Callback[] calls = new Callback[1];
			String ccowSecurePasscode = null;
			String kernelCcowToken = null;

			// get ccow values needed
			try {
				ccowSecurePasscode = loginSPI.getSecureCcowPasscode();
				kernelCcowToken = loginSPI.getKernelCcowToken();
			} catch (Exception e) {
				try {
					errorSb.append(e.getMessage());
					doCallbackConfirm(errorSb.toString(), CallbackConfirm.INFORMATION_MESSAGE, "CCOW Warning");
				} catch (VistaLoginModuleException e1) {
					/*
					 * VistaLoginModuleUserCancelledException, VistaLoginModuleUserTimedOutException
					 * VistaLoginModuleException
					 */
					logoutConnectionBeforeLoginComplete();
					if (e instanceof VistaLoginModuleException) {
						throw (VistaLoginModuleException) e;
					} else {
						throw new VistaLoginModuleException(e);
					}
				}
			}

			if ((ccowSecurePasscode != null) || (kernelCcowToken != null)) {
				// now we have ccow values. So, do the commit call back to write
				// user context.
				CallbackCommit ccomCbh = new CallbackCommit(userPrincipal
						.getUserDemographicValue(VistaKernelPrincipal.KEY_NAME_NEWPERSON01), this.domainName,
						this.vpid, ccowSecurePasscode, kernelCcowToken);
				calls[0] = ccomCbh;
				try {
					callbackHandler.handle(calls);
				} catch (Exception e) {
					errorSb.append(e.getMessage());
					logger.error(errorSb.toString());
					try {
						doCallbackConfirm(errorSb.toString(), CallbackConfirm.INFORMATION_MESSAGE, "CCOW Warning");
					} catch (VistaLoginModuleException e1) {
						/*
						 * VistaLoginModuleUserCancelledException, VistaLoginModuleUserTimedOutException
						 * VistaLoginModuleException
						 */
						logoutConnectionBeforeLoginComplete();
						throw e1;
					}
				}

				// check results for errors
				if ((ccomCbh.wasCancelPressed()) || (ccomCbh.getErrorMessageToReport().length() > 1)) {
					if (ccomCbh.wasCancelPressed()) {
						logoutConnectionBeforeLoginComplete();
						throw new VistaLoginModuleUserCancelledException("User cancelled login.");
					} else if (ccomCbh.getErrorMessageToReport().length() > 1) {
						errorSb.append(ccomCbh.getErrorMessageToReport());
						logger.error(errorSb.toString());
						try {
							doCallbackConfirm(errorSb.toString(), CallbackConfirm.INFORMATION_MESSAGE, "CCOW Warning");
						} catch (VistaLoginModuleException e1) {
							/*
							 * VistaLoginModuleUserCancelledException, VistaLoginModuleUserTimedOutException
							 * VistaLoginModuleException
							 */
							logoutConnectionBeforeLoginComplete();
							throw e1;
						}
					}
				}
			}
		}
		return true;
	}

	/**
	 * Should never be called by an application directly. Instead, this method is invoked behind the scenes by the proxy
	 * of the JAAS LoginContext.
	 * <p>
	 * Part of the JAAS interface for a login module. This loginmodule's implementation of this method calls M to
	 * cleanly shut down the connection to M. If we were to support an environment with multiple login modules, and the
	 * login for one of them failed, this method would be called to do any cleanup to back out of a partial login, which
	 * in the case of VistaLink, means clean up/tear down the existing connection to M.
	 * 
	 * @return true if cleanup/logout on the M side succeeded
	 * @throws VistaLoginModuleException
	 *            thrown if logging out on the M side fails.
	 * @va.exclude
	 */
	public boolean abort() throws VistaLoginModuleException {

		if (userPrincipal != null) {

			if (userPrincipal.getAuthenticatedConnection() != null) {
				logout();
			}
		}
		// if logout() successful -- or no connection present -- return true
		return true;
	}

	/**
	 * Log out before an authenticated connection has been placed in the userPrincipal (clears up the M side, useful
	 * when we're about to throw an exception). Don't want to throw any errors here, because we're calling this method
	 * immediately BEFORE throwing a LoginException in most cases.
	 */
	private void logoutConnectionBeforeLoginComplete() {

		try {
			this.loginSPI.logout();
		} catch (VistaLoginModuleException e) {
			// swallow this exception
		} catch (Exception e) {
			// swallow this one too
		}
	}

	/**
	 * Should never be called by an application directly. Instead, this method is invoked behind the scenes by the proxy
	 * of the JAAS LoginContext.
	 * <p>
	 * For applications to call, to logout a user from an open connection/session to a VistaLink M server. Doing this
	 * drops the connection, freeing up resources on the M server.
	 * 
	 * @return true if the logout was successful
	 * @throws VistaLoginModuleException
	 *            thrown if the logout fails on the M side.
	 * @va.exclude
	 */
	public boolean logout() throws VistaLoginModuleException {

		if (userPrincipal != null) {
			if (userPrincipal.getAuthenticatedConnection() != null) {
				try {
					// logout request to update the M side
					this.loginSPI.logout();

				} catch (VistaLoginModuleException e) {

					/*
					 * this catch block prevents VistaLoginModuleExceptions and descendants from being caught in the
					 * 'catch-all' catch (Exception e) block where they would be re-wrapped inside another
					 * VistaLoginModuleException
					 */
					throw e;

				} catch (Exception e) {

					logger.error("Error logging out: ", e);
					throw new VistaLoginModuleException("Error logging out: ", e);
				}
			}
		}
		return true;
	}
}