package gov.va.med.vistalink.console;

/**
 * Thrown when attempting to execute IServerHelper functionality that requires that associated server to be running, and
 * it appears not to be.
 * 
 */
public class ServerHelperNotRunningException extends ServerHelperException {

	public ServerHelperNotRunningException() {
		super();
	}

	public ServerHelperNotRunningException(String message) {
		super(message);
	}

	public ServerHelperNotRunningException(Exception e) {
		super(e);
	}

	public ServerHelperNotRunningException(String message, Exception e) {
		super(message, e);
	}
}
