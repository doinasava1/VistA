/*
 * Created on Apr 4, 2005
 *
 */
package gov.va.med.crypto;


import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.Key;

import java.io.UnsupportedEncodingException;
import java.io.IOException;

import javax.crypto.KeyGenerator;
import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;


/**
 * Provides basic implementation for a base class of Cipher algorithms, key based.
 * To implement a particular algorithm/encoding, specify the algorithmName, encodingFormat in the overriding class.
 * To implement a different Key and Cipher getting logic, override corresponding protected methods.
 * 
 */


public class KeyEncrypter extends VistaLinkEncrypter {
  static final int UNINITIALIZED = -1;
  protected int ks = UNINITIALIZED;
  
  protected Key generateKey(){
    try{
      return getKeyGenerator().generateKey();
    }
    catch(NoSuchAlgorithmException e){
      handleException(e, "generateKey() - NoSuchAlgorithmException!"); 
      return null;
    }      
  }
  
  protected KeyGenerator getKeyGenerator() throws NoSuchAlgorithmException{
	KeyGenerator gen = null;
	gen = KeyGenerator.getInstance(algorithmName);
	if(ks != UNINITIALIZED)
		gen.init(ks);

	return gen;
  }
  
  protected void handleException(Exception e, String message){
    logger.error(message, e);   
  }
  
  protected Cipher getCipher(int opmode){
    try{
      Cipher result = Cipher.getInstance(algorithmName);
      result.init(opmode, getKey());
      return result;
    }
    catch (InvalidKeyException e){handleException(e, "getCipher() - InvalidKeyException!");}
    catch (NoSuchPaddingException e) {handleException(e, "getCipher() - NoSuchPaddingException!");}
    catch (NoSuchAlgorithmException e) {handleException(e, "getCipher() - NoSuchAlgorithmException!");}
    return null;        
  }
  
  public String encrypt(String s){
    try {
      byte[] encoded = s.getBytes(encodingFormat);
      byte[] encr = getCipher(Cipher.ENCRYPT_MODE).doFinal(encoded);
      return new sun.misc.BASE64Encoder().encode(encr);
    }
    catch (BadPaddingException e) {handleException(e, "encrypt() - BadPaddingException!");}
    catch (IllegalBlockSizeException e) {handleException(e, "encrypt() - IllegalBlockSizeException!");}
    catch (UnsupportedEncodingException e) {handleException(e, "encrypt() - UnsupportedEncodingException!");}
    return null;
  }
  
  public String decrypt(String s) {
    try {
        byte[] decoded = new sun.misc.BASE64Decoder().decodeBuffer(s);
        byte[] decr = getCipher(Cipher.DECRYPT_MODE).doFinal(decoded);
        return new String(decr, encodingFormat);
    } 
    catch (BadPaddingException e) {handleException(e, "decrypt() - BadPaddingException!");}
    catch (IllegalBlockSizeException e) {handleException(e, "decrypt() - IllegalBlockSizeException!");}
    catch (UnsupportedEncodingException e) {handleException(e, "decrypt() - UnsupportedEncodingException!");}
    catch (IOException e) {handleException(e, "decrypt() - IOException!");}
    return null;
  }
  
  public Key getKey(){
    if( key == null )
      key = generateKey();
    return key;
  }  
  
  public void setKey(Key key){
	  this.key = key;
  }
}

