package gov.va.med.vistalink.security.m;

import java.util.Map;

/**
 * Logon-related value object for "logon with access/verify code" results.
 * 
 */
public class SecurityVOLogon extends SecurityVO {

	private boolean needNewVerifyCode = false;
	private boolean needDivisionSelection = false;
	private Map divisionList;
	private String postSignInText = "";
	private String cvcHelpText = "";
	
	/**
	 * Constructor.
	 * @param resultType Success, Failure or Partial Success (types defined in parent class) 
	 * @param resultMessage optional explanatory description for the result, usually used for failure and partial success only
	 */
	public SecurityVOLogon(int resultType, String resultMessage) {
		super(resultType, resultMessage);
	}
	
	/**
	 * Returns whether a new verify code is needed, after a (partially) successful logon operation.
	 * @return boolean whether a new verify code is needed
	 */
	public boolean getNeedNewVerifyCode() {
		return needNewVerifyCode;
	}

	/**
	 * Sets whether a new verify code is needed, after a (partially) successful logon operation.
	 * @param needNewVerifyCode whether the user needs to change verify code.
	 */
	public void setNeedNewVerifyCode(boolean needNewVerifyCode) {
		this.needNewVerifyCode = needNewVerifyCode;
	}

	/**
	 * Returns a TreeMap of divisions (should only be populated if getNeedDivisionSelection() returns true.)
	 * @return TreeMap list of divisions, division/station number string as key, VistaInstitutionVO as object.
	 * @see VistaInstitutionVO
	 */
	public Map getDivisionList() {
		return divisionList;
	}

	/**
	 * Sets a TreeMap of divisions (should only be populated if getNeedDivisionSelection() returns true.)
	 * @param divisionList TreeMap list of divisions, division/station number string as key, VistaInstitutionVO as object.
	 * @see VistaInstitutionVO
	 */
	public void setDivisionList(Map divisionList) {
		this.divisionList = divisionList;
	}

	/**
	 * If there is post-sign-in text to return, it is returned here
	 * @return String post-sign-in text
	 */
	public String getPostSignInText() {
		return postSignInText;
	}

	/**
	 * If there is post-sign-in text to return, set it here.
	 * @param postSignInText post-sign-in text
	 */
	public void setPostSignInText(String postSignInText) {
		this.postSignInText = postSignInText;
	}

	/**
	 * Returns whether division selection is needed, after a (partially) successful logon operation.
	 * @return boolean true if needed, false if not
	 */
	public boolean getNeedDivisionSelection() {
		return needDivisionSelection;
	}

	/**
	 * Sets whether division selection is needed, after a (partially) successful logon operation.
	 * @param needDivisionSelection true if needed, false if not
	 */
	public void setNeedDivisionSelection(boolean needDivisionSelection) {
		this.needDivisionSelection = needDivisionSelection;
	}

	/**
	 * Help text to make available for the 'change verify code' dialog.
	 * @return String help text for changing the verify code.
	 */
	public String getCvcHelpText() {
		return cvcHelpText;
	}
	
	/**
	 * Help text to make available for the 'change verify code' dialog.
	 * @param cvcHelpText help text for changing the verify code.
	 */
	public void setCvcHelpText(String cvcHelpText) {
		this.cvcHelpText = cvcHelpText;
	}
}
