package gov.va.med.vistalink.institution;

import java.io.Serializable;

/**
 * Value object used internally for Institution Mapping utility. Each object represents the institution mapping for a
 * single station number, and contains the JNDI name mapped to the station#, as well as a set of managed connection
 * factory (MCF) handles that have registered
 * 
 * @va.exclude
 */
public class InstitutionMappingVO implements Serializable {

	protected String jndiName;
	protected long lastOneInMcfDistinguishedIdentifier;

	/**
	 * Constructor
	 * @param jndiName JNDI name for this mapping
	 * @param lastOneInMcfDistinguishedIdentifier distinguished identifier for the most recent 'last one in' connection
	 *            factory to hold a handle for this mapping
	 */
	protected InstitutionMappingVO(String jndiName, long lastOneInMcfDistinguishedIdentifier) {
		this.jndiName = jndiName;
		this.lastOneInMcfDistinguishedIdentifier = lastOneInMcfDistinguishedIdentifier;
	}

	/**
	 * JNDI name for this mapping.
	 * @return Returns the jndiName.
	 */
	public String getJndiName() {
		return jndiName;
	}

	/**
	 * @param jndiName The jndiName to set.
	 */
	protected void setJndiName(String jndiName) {
		this.jndiName = jndiName;
	}

	/**
	 * MCF distinguished identifier for last MCF to own this mapping.
	 * @return Returns the lastOneInMcfDistinguishedIdentifier.
	 */
	protected long getLastOneInMcfDistinguishedIdentifier() {
		return lastOneInMcfDistinguishedIdentifier;
	}

	/**
	 * @param lastOneInMcfDistinguishedIdentifier The lastOneInMcfDistinguishedIdentifier to set.
	 */
	protected void setLastOneInMcfDistinguishedIdentifier(long lastOneInMcfDistinguishedIdentifier) {
		this.lastOneInMcfDistinguishedIdentifier = lastOneInMcfDistinguishedIdentifier;
	}
}