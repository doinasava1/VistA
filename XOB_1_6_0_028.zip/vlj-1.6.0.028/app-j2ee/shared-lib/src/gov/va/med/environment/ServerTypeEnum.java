package gov.va.med.environment;

import java.util.HashMap;
import java.util.Map;

/**
 * An enumeration base for J2EE server types.
 * 
 */
abstract class ServerTypeEnum {

	private String keyValue = "";

	// HashMap static must be declared before the static variables
	private static Map hm = new HashMap();

	ServerTypeEnum(String keyValue) {
		this.keyValue = keyValue;
		hm.put(this.keyValue, this);
	}

	public String toString() {
		return keyValue;
	}

	static final Object getObject(String keyValue) {
		return hm.get(keyValue);
	}

}