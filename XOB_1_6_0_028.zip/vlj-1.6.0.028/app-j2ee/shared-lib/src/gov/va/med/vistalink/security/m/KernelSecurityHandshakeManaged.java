package gov.va.med.vistalink.security.m;

import gov.va.med.vistalink.adapter.record.VistaLinkFaultException;
import gov.va.med.vistalink.adapter.spi.VistaLinkManagedConnection;
import gov.va.med.crypto.VistaKernelHashCountLimitExceededException;
import gov.va.med.exception.FoundationsException;

import java.io.IOException;

import javax.resource.ResourceException;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;

/**
 * Manages logon-related security handshake with M/VistA. Used for J2EE connector proxy logins.
 * 
 */
public final class KernelSecurityHandshakeManaged {
	// Initialize Logger instance to be used by this class
	private static final Logger LOGGER = Logger.getLogger(KernelSecurityHandshakeManaged.class);

	private static final String TEXT_RESULT = "Result: ";
	private static final String TEXT_SENDING = "-> sending ";
	
	/**
	 * @param myConnection The <code>VistaLinkConnection</code> connection to use
	 * @param securityResponseFactory An already instantiated <code>SecurityResponseFactory</code>
	 * @param j2eeMode true if j2ee mode, false if not
	 * @param isClientProduction if checking for client-server production mismatch, pass the client's production setting
	 * @return SecurityDataSetupAndIntroTextResponse or SecurityDataLogonResponse
	 * @throws ParserConfigurationException
	 * @throws VistaLinkFaultException
	 * @throws FoundationsException
	 */
	public static SecurityResponse doSetupAndGetIntroText(VistaLinkManagedConnection myConnection,
			SecurityResponseFactory securityResponseFactory, boolean j2eeMode, Boolean isClientProduction,
			String primaryStation) throws ParserConfigurationException, VistaLinkFaultException, FoundationsException {

		SecurityRequest requestVO = SecurityRequestFactory.getAVSetupAndIntroTextRequest(j2eeMode, isClientProduction,
				primaryStation);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(TEXT_SENDING + SecurityRequestFactory.MSG_ACTION_SETUP_AND_INTRO_TEXT);
		}

		SecurityResponse responseData = (SecurityResponse) myConnection.executeInteraction(requestVO,
				securityResponseFactory);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(TEXT_RESULT + responseData.getResultType());
		}

		return responseData;
	}

	/**
	 * 
	 * @param myConnection The <code>VistaLinkConnection</code> connection to use
	 * @param securityResponseFactory An already instantiated <code>SecurityResponseFactory</code>
	 * @param accessCode access code to login with
	 * @param verifyCode verify code to login with
	 * @param requestCvc boolean -- true to request changing verify code, false to not do that
	 * @return SecurityDataLogonResponse
	 * @throws ParserConfigurationException
	 * @throws VistaKernelHashCountLimitExceededException
	 * @throws FoundationsException
	 */
	public static SecurityDataLogonResponse doAVLogon(VistaLinkManagedConnection myConnection,
			SecurityResponseFactory securityResponseFactory, String accessCode, String verifyCode, boolean requestCvc)
			throws ParserConfigurationException, VistaKernelHashCountLimitExceededException, FoundationsException {

		// do logon with access/verify code
		SecurityRequest requestVO = SecurityRequestFactory.getAVLogonRequest(accessCode, verifyCode, requestCvc);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(TEXT_SENDING + SecurityRequestFactory.MSG_ACTION_LOGON);
		}

		SecurityDataLogonResponse responseData = (SecurityDataLogonResponse) myConnection.executeInteraction(requestVO,
				securityResponseFactory);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(TEXT_RESULT + responseData.getResultType());
		}

		return responseData;
	}

	/**
	 * 
	 * @param myConnection The <code>VistaLinkConnection</code> connection to use
	 * @param securityResponseFactory An already instantiated <code>SecurityResponseFactory</code>
	 * @param token Kernel CCOW token to login with
	 * @return SecurityDataLogonResponse
	 * @throws ParserConfigurationException
	 * @throws VistaKernelHashCountLimitExceededException
	 * @throws FoundationsException
	 */
	public static SecurityDataLogonResponse doAVLogon(VistaLinkManagedConnection myConnection,
			SecurityResponseFactory securityResponseFactory, String token) throws ParserConfigurationException,
			VistaKernelHashCountLimitExceededException, FoundationsException {

		// do logon with access/verify code
		SecurityRequest requestVO = SecurityRequestFactory.getAVLogonRequest(token);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(TEXT_SENDING + SecurityRequestFactory.MSG_ACTION_LOGON);
		}

		SecurityDataLogonResponse responseData = (SecurityDataLogonResponse) myConnection.executeInteraction(requestVO,
				securityResponseFactory);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(TEXT_RESULT + responseData.getResultType());
		}

		return responseData;
	}

	/**
	 * 
	 * @param myConnection The <code>VistaLinkConnection</code> connection to use
	 * @param securityResponseFactory An already instantiated <code>SecurityResponseFactory</code>
	 * @param divisionIenToSelect IEN string of the division to select
	 * @return SecurityDataSelectDivisionResponse
	 * @throws ParserConfigurationException
	 * @throws VistaLinkFaultException
	 * @throws FoundationsException
	 */
	public static SecurityDataSelectDivisionResponse doSelectDivision(VistaLinkManagedConnection myConnection,
			SecurityResponseFactory securityResponseFactory, String divisionIenToSelect)
			throws ParserConfigurationException, VistaLinkFaultException, FoundationsException {

		SecurityRequest requestVO = SecurityRequestFactory.getAVLogonSelectDivisionRequest(divisionIenToSelect);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(TEXT_SENDING + SecurityRequestFactory.MSG_ACTION_SELECT_DIVISION);
		}

		SecurityDataSelectDivisionResponse responseData = (SecurityDataSelectDivisionResponse) myConnection
				.executeInteraction(requestVO, securityResponseFactory);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(TEXT_RESULT + responseData.getResultType());
		}

		return responseData;
	}

	/**
	 * 
	 * @param myConnection The <code>VistaLinkConnection</code> connection to use
	 * @param securityResponseFactory An already instantiated <code>SecurityResponseFactory</code>
	 * @param vcOld old verify code
	 * @param vcNew new verify code
	 * @param vcNewCheck "check" presumably duplicate string for new verify code
	 * @return SecurityDataChangeVcResponse
	 * @throws ParserConfigurationException
	 * @throws VistaLinkFaultException
	 * @throws FoundationsException
	 */
	public static SecurityDataChangeVcResponse doChangeVerifyCode(VistaLinkManagedConnection myConnection,
			SecurityResponseFactory securityResponseFactory, String vcOld, String vcNew, String vcNewCheck)
			throws ParserConfigurationException, VistaLinkFaultException, FoundationsException {

		SecurityRequest requestVO = SecurityRequestFactory.getAVUpdateVCRequest(vcOld.toUpperCase(), vcNew
				.toUpperCase(), vcNewCheck.toUpperCase());

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(TEXT_SENDING + SecurityRequestFactory.MSG_ACTION_UPDATE_VC);
		}

		SecurityDataChangeVcResponse responseData = (SecurityDataChangeVcResponse) myConnection.executeInteraction(
				requestVO, securityResponseFactory);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(TEXT_RESULT + responseData.getResultType());
		}

		return responseData;
	}

	/**
	 * 
	 * @param myConnection The <code>VistaLinkConnection</code> connection to use
	 * @param securityResponseFactory An already instantiated <code>SecurityResponseFactory</code>
	 * @return SecurityDataUserDemographicsResponse
	 * @throws ParserConfigurationException
	 * @throws VistaLinkFaultException
	 * @throws FoundationsException
	 */
	public static SecurityDataUserDemographicsResponse doGetUserDemographics(VistaLinkManagedConnection myConnection,
			SecurityResponseFactory securityResponseFactory) throws ParserConfigurationException,
			VistaLinkFaultException, FoundationsException {

		SecurityRequest requestVO = SecurityRequestFactory.getAVGetUserDemographicsRequest();

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(TEXT_SENDING + SecurityRequestFactory.MSG_ACTION_USER_DEMOGRAPHICS);
		}

		SecurityDataUserDemographicsResponse responseData = (SecurityDataUserDemographicsResponse) myConnection
				.executeInteraction(requestVO, securityResponseFactory);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(TEXT_RESULT + responseData.getResultType());
		}

		return responseData;
	}

	/**
	 * 
	 * @param myConnection The <code>VistaLinkConnection</code> connection to use
	 * @param securityResponseFactory An already instantiated <code>SecurityResponseFactory</code>
	 * @throws ParserConfigurationException
	 * @throws VistaLinkFaultException
	 * @throws FoundationsException
	 * @throws ResourceException
	 * @throws IOException
	 */
	public static SecurityDataLogoutResponse doLogout(VistaLinkManagedConnection myConnection,
			SecurityResponseFactory securityResponseFactory) throws ParserConfigurationException,
			VistaLinkFaultException, FoundationsException, ResourceException, IOException {

		SecurityRequest requestVO = SecurityRequestFactory.getAVLogoutRequest();

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(TEXT_SENDING + SecurityRequestFactory.MSG_ACTION_LOGOUT);
		}

		SecurityDataLogoutResponse responseData = (SecurityDataLogoutResponse) myConnection.executeInteraction(
				requestVO, securityResponseFactory);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(TEXT_RESULT + responseData.getResultType());
		}

		return responseData;
	}

}