package gov.va.med.vistalink.security;

import gov.va.med.vistalink.security.m.SecurityVO;
import gov.va.med.vistalink.security.m.SecurityVOChangeVc;
import gov.va.med.vistalink.security.m.SecurityVOLogon;
import gov.va.med.vistalink.security.m.SecurityVOSelectDivision;
import gov.va.med.vistalink.security.m.SecurityVOUserDemographics;
import gov.va.med.vistalink.security.m.VistaKernelPrincipal;
import gov.va.med.vistalink.security.m.SecurityVOSetupAndIntroText;

import java.util.Hashtable;
import java.util.Map;

/**
 * Mock implementation of teh <code>VistaLoginModuleSPI</code> interface, supports log in
 * without any back-end security provider at all. 
 * 
 * @see VistaLoginModuleSPI
 * @see VistaLoginModule
 */
class VistaLoginModuleSPIMock implements VistaLoginModuleSPI {

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.va.med.vistalink.security.VistaLoginModuleSPI#initialize(java.util.Map)
	 */
	public void initialize(Map jaasOptions, Map jaasSharedState) throws Exception {
		// no action needed yet
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.va.med.vistalink.security.VistaLoginModuleSPI#getSetupAndIntroTextInfo()
	 */
	public Object getSetupAndIntroTextInfo() throws Exception {
		/*
		 * SecurityVOSetupAndIntroText setupAndIntroTextInfo, SecurityResponse
		 * responseData
		 */
		SecurityVOSetupAndIntroText infoVO = new SecurityVOSetupAndIntroText(SecurityVO.RESULT_SUCCESS, "");
		infoVO.setDevice("x");
		infoVO.setIntroductoryText("yadda yadda hello\nyadda yadda hello\nyadda yadda hello\nyadda yadda hello\nyadda yadda hello\nyadda yadda hello\nyadda yadda hello\nyadda yadda hello\nyadda yadda hello\nyadda yadda hello\nyadda yadda hello\nyadda yadda hello\nyadda yadda hello\nyadda yadda hello\nyadda yadda hello\nyadda yadda hello\nyadda yadda hello\nyadda yadda hello\nyadda yadda hello\nyadda yadda hello\n");
		infoVO.setLogonRetryCount(5);
		infoVO.setPort(0);
		infoVO.setServerName("Server0");
		infoVO.setTimeout(150);
		infoVO.setUci("UCI0");
		infoVO.setVolume("Vol0");
		/*
		 * @param resultType type of result -- success, failure or
		 * partialsuccess. @param resultMessage string returned with result if
		 * partialsuccess or failure @param rawXml raw XML of the response
		 */
//		SecurityDataSetupAndIntroTextResponse myResponse = new SecurityDataSetupAndIntroTextResponse(infoVO,
//				new SecurityResponse(SecurityResponse.RESULT_SUCCESS, null, ""));
//		return myResponse;
		return infoVO;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.va.med.vistalink.security.VistaLoginModuleSPI#doKernelLogon(java.lang.String)
	 */
	public SecurityVOLogon doKernelLogon(String kernelCcowLogonToken) throws Exception {

		SecurityVOLogon myResponse = new SecurityVOLogon(SecurityVO.RESULT_SUCCESS,"");
		myResponse.setNeedDivisionSelection(false);
		myResponse.setNeedNewVerifyCode(false);
		myResponse.setPostSignInText("");
		return myResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.va.med.vistalink.security.VistaLoginModuleSPI#doKernelLogon(java.lang.String,
	 *      java.lang.String, boolean)
	 */
	public SecurityVOLogon doKernelLogon(String accessCode, String verifyCode, boolean requestCvc)
			throws Exception {

		SecurityVOLogon myResponse = new SecurityVOLogon(SecurityVO.RESULT_SUCCESS,"");
		myResponse.setNeedDivisionSelection(false);
		myResponse.setNeedNewVerifyCode(false);
		myResponse.setPostSignInText("");
		if (requestCvc) {
			myResponse.setNeedNewVerifyCode(true);
			myResponse.setResultType(SecurityVO.RESULT_PARTIAL);
		}
		return myResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.va.med.vistalink.security.VistaLoginModuleSPI#changeVerifyCode(java.lang.String,
	 *      java.lang.String, java.lang.String)
	 */
	public SecurityVOChangeVc changeVerifyCode(String oldVerifyCode, String newVerifyCode,
			String newVerifyCodeCheck) throws Exception {

		SecurityVOChangeVc myResponse = new SecurityVOChangeVc(SecurityVO.RESULT_SUCCESS, "");
		myResponse.setNeedDivisionSelection(false);
		return myResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.va.med.vistalink.security.VistaLoginModuleSPI#selectDivision(java.lang.String)
	 */
	public SecurityVOSelectDivision selectDivision(String selectedDivisionIen) throws Exception {
		/*
		 * SecurityResponse responseData
		 */
		SecurityVOSelectDivision myResponse = new SecurityVOSelectDivision(SecurityVO.RESULT_SUCCESS, "");
		return myResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.va.med.vistalink.security.VistaLoginModuleSPI#getUserDemographicsData()
	 */
	public SecurityVOUserDemographics getUserDemographicsData() throws Exception {

		Hashtable userDemographicsHashtable = new Hashtable();

		// name info
		userDemographicsHashtable.put(VistaKernelPrincipal.KEY_NAME_NEWPERSON01, "TestUser");
		userDemographicsHashtable.put(VistaKernelPrincipal.KEY_NAME_DISPLAY, "TestUser");
		userDemographicsHashtable.put(VistaKernelPrincipal.KEY_NAME_FAMILYLAST, "User");
		userDemographicsHashtable.put(VistaKernelPrincipal.KEY_NAME_GIVENFIRST, "Test");
		userDemographicsHashtable.put(VistaKernelPrincipal.KEY_NAME_MIDDLE, "");
		userDemographicsHashtable.put(VistaKernelPrincipal.KEY_NAME_PREFIX, "");
		userDemographicsHashtable.put(VistaKernelPrincipal.KEY_NAME_SUFFIX, "");
		userDemographicsHashtable.put(VistaKernelPrincipal.KEY_NAME_DEGREE, "");

		//userinfo node
		userDemographicsHashtable.put(VistaKernelPrincipal.KEY_DUZ, "1");
		userDemographicsHashtable.put(VistaKernelPrincipal.KEY_DTIME, "150");
		userDemographicsHashtable.put(VistaKernelPrincipal.KEY_TITLE, "Tester");
		userDemographicsHashtable.put(VistaKernelPrincipal.KEY_SERVICE_SECTION, "SQA");
		userDemographicsHashtable.put(VistaKernelPrincipal.KEY_LANGUAGE, "");
		userDemographicsHashtable.put(VistaKernelPrincipal.KEY_VPID, "");

		//divisioninfo node
		userDemographicsHashtable.put(VistaKernelPrincipal.KEY_DIVISION_IEN, "-1");
		userDemographicsHashtable.put(VistaKernelPrincipal.KEY_DIVISION_STATION_NAME, "Oakland");
		userDemographicsHashtable.put(VistaKernelPrincipal.KEY_DIVISION_STATION_NUMBER, "999ZZ");

		SecurityVOUserDemographics myResponse = new SecurityVOUserDemographics(SecurityVO.RESULT_SUCCESS, "");
		myResponse.setUserDemographicsHashtable(userDemographicsHashtable);
		return myResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.va.med.vistalink.security.VistaLoginModuleSPI#getSecureCcowPasscode()
	 */
	public String getSecureCcowPasscode() throws Exception {
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.va.med.vistalink.security.VistaLoginModuleSPI#getKernelCcowToken()
	 */
	public String getKernelCcowToken() throws Exception {
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.va.med.vistalink.security.VistaLoginModuleSPI#addSPISpecificInformationToPrincipal(gov.va.med.vistalink.security.VistaKernelPrincipalImpl)
	 */
	public void addSPISpecificInformationToPrincipal(VistaKernelPrincipalImpl principal) throws Exception {
		// do nothing -- no connection to add
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gov.va.med.vistalink.security.VistaLoginModuleSPI#logout()
	 */
	public void logout() throws Exception {
		// do nothing -- nothing to log out of.
	}

}