/*
 * Created on Apr 8, 2005
 *
 */
package gov.va.med.crypto;

/**
 * PassPhrase based encrypter, using DES algorithm and "UTF8" encoding.
 * 
 */

public class DESPassPhraseEncrypter extends PassPhraseEncrypter {
	DESPassPhraseEncrypter() {
		super();
		algorithmName = "PBEWithMD5AndDES";
		encodingFormat = "UTF8";
		passPhrase = "IpanemaGirl";
	}
}
