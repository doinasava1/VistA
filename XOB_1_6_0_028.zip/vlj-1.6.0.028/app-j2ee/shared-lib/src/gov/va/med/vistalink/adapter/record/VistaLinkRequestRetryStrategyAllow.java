package gov.va.med.vistalink.adapter.record;

import org.apache.log4j.Logger;

/**
 * Simple 'Allow' strategy implementation that indicates request should be re-executed
 * 
 */
public class VistaLinkRequestRetryStrategyAllow implements VistaLinkRequestRetryStrategy {
    /**
     * The logger used by this class
     */
    private static final Logger logger = Logger.getLogger(VistaLinkRequestRetryStrategyAllow.class);
	
	/* 
	 * Simple 'Allow' logic that indicates request should be re-executed
	 * 
	 * @see gov.va.med.vistalink.adapter.record.VistaLinkRequestRetryStrategy#execute(gov.va.med.vistalink.adapter.record.VistaLinkRequestVO)
	 */
	public boolean execute(VistaLinkRequestVO request){
        if (logger.isDebugEnabled()) {
            logger.debug("Executing 'Allow' retry strategy for request class = " + request.getClass());
        }
		return true;
	}
}
