package gov.va.med.vistalink.security.m;

import gov.va.med.vistalink.adapter.record.VistaLinkFaultException;

/**
 * Represents an authentication failure during a re-authentication attempt, in
 * which the credentials passed for re-authentication (DUZ, VPID, etc.) could
 * not be matched with an actual Kernel user.
 * 
 */
public class SecurityIdentityDeterminationFaultException extends SecurityFaultException {

	/**
	 * @param vistaLinkFaultException
	 *            Fault Exception
	 * @va.exclude
	 */
	public SecurityIdentityDeterminationFaultException(VistaLinkFaultException vistaLinkFaultException) {
		super(vistaLinkFaultException);
	}

}