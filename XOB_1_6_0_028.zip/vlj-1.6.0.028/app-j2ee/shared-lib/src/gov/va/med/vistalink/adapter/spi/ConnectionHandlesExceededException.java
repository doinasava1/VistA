package gov.va.med.vistalink.adapter.spi;

import gov.va.med.vistalink.adapter.cci.VistaLinkResourceException;

/**
 * This exception class is thrown when a VistaLinkManagedConnection object has
 * exceeded its maximum allowable connection handles.
 * 
 */
public class ConnectionHandlesExceededException extends VistaLinkResourceException {

	/**
	 * Constructor for ConnectionHandlesExceededException.
	 * 
	 * @param reason
	 *            Reason
	 * @va.exclude
	 */
	public ConnectionHandlesExceededException(String reason) {
		super(reason);
	}

	/**
	 * Constructor for ConnectionHandlesExceededException.
	 * 
	 * @param e
	 *            Exception
	 * @va.exclude
	 */
	public ConnectionHandlesExceededException(Exception e) {
		super(e);
	}

	/**
	 * Constructor for ConnectionHandlesExceededException.
	 * 
	 * @param reason
	 *            Reason
	 * @param errorCode
	 *            Error Code
	 * @va.exclude
	 */
	public ConnectionHandlesExceededException(String reason, String errorCode) {
		super(reason, errorCode);
	}

	/**
	 * Constructor for ConnectionHandlesExceededException.
	 * 
	 * @param reason
	 *            Reason
	 * @param errorCode
	 *            Error Code
	 * @param e
	 *            Exception
	 * @va.exclude
	 */
	public ConnectionHandlesExceededException(String reason, String errorCode, Exception e) {
		super(reason, errorCode, e);
	}

	/**
	 * Constructor for ConnectionHandlesExceededException.
	 * 
	 * @param reason
	 *            Reason
	 * @param e
	 *            Exception
	 * @va.exclude
	 */
	public ConnectionHandlesExceededException(String reason, Exception e) {
		super(reason, e);
	}

}