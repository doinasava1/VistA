package gov.va.med.vistalink.rpc;

/**
 * Represents a reference type object for an RPC parameter. Used mainly for
 * RpcRequest.setParams() call to represent a 'reference' type parameter.
 * <p>
 * J2SE Example:
 * <p>
 * <code>
 *   //request  and response objects<br> 
 *   RpcRequest vReq = null;<br> 
 *   RpcResponse vResp = null;
 * <p>    
 *   //The Rpc Context<br>
 *   String rpcContext = &quot;XOBV VISTALINK TESTER&quot;;
 * <p>    
 *   //The Rpc to call<br>
 *   String rpcName = &quot;XWB GET VARIABLE VALUE&quot;;
 * <p>    
 *    //Construct the request object<br>
 *   vReq = RpcRequestFactory.getRpcRequest(rpcContext, rpcName);
 * <p>    
 *   //clear the params 	<br>
 *   vReq.clearParams()
 * <p>    
 *   //Create an arraylist for the params<br>
 *   ArrayList params = new ArrayList();
 * <p>    
 *   //Clear the arraylist<br>
 *   params.clear();
 * <p>    
 *   //add a new VistaRpcReferenceType to the array list<br>
 *    params.add(new VistaRpcReferenceType(&quot;DTIME&quot;));<br>
 * <p>    
 *   //Add the araylist with the VistaRpcReferenceType to the request as a param<br>
 *   vReq. setParams(params);
 * <p>    
 *   //An alternate way of doing the above<br>
 *   vReq.getParams().setParam(1, &quot;ref&quot;, &quot;DT&quot;);
 * <p>    
 *   //Execute the Rpc and get the response<br>
 *   vResp = myConnection.executeRPC(vReq);
 * <p>    
 *   //Work with the response ...
 * </code>
 * 
 */
public class RpcReferenceType {
	/**
	 * Represnts the value associated with 'reference' type param
	 */
	private String value;

	/**
	 * Default constructor
	 */
	public RpcReferenceType() {
	}

	/**
	 * Constructs this instance with the specified value
	 * 
	 * @param value
	 *            Name of variable to be referenced, like DUZ
	 */
	public RpcReferenceType(String value) {
		this.value = value;
	}

	/**
	 * Returns name of the variable desired in the M server partition.
	 * 
	 * @return String
	 */
	public String getValue() {
		return value;
	}

	/**
	 * Sets the value to the name of the variable desired in the M server
	 * partition.
	 * 
	 * @param value
	 *            The value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * Returns name of the variable desired in the M server partition.
	 * 
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return value;
	}

}