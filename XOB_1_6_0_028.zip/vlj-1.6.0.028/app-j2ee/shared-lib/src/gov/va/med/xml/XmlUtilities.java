package gov.va.med.xml;

import gov.va.med.exception.ExceptionUtils;
import gov.va.med.exception.FoundationsException;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 * This class contains a number of static utility methods to help developers work with XML documents, nodes, attributes
 * and strings
 * 
 * @deprecated Need for XML utilities has been superceded by the many JRE-built-in and external XML frameworks
 */
public class XmlUtilities {

	/**
	 * Represents the default header used for all xml documents that communicate with an M server via VistALink. It is
	 * important to use this header as keeps the client and M server in sync.
	 * 
	 * Note that that as a String constant, this value is compiled into the calling class at compile time; it is not
	 * dynamically linked at runtime.
	 */
	public static final String XML_HEADER = "<?xml version=\"1.0\" encoding=\"utf-8\" ?>";

	/**
	 * The logger used bythis class
	 */
	private static final Logger logger = Logger.getLogger(XmlUtilities.class);

	/**
	 * The document builder factory used by this class to construct a DocumentBuilder
	 */
	private static DocumentBuilderFactory documentBuilderFactory = null;

	/**
	 * The transformer factory used by this class to construct a Transformer
	 */
	private static TransformerFactory transformerFactory = null;

	/**
	 * Static method to intialize TransformerFactory & DocumentBuilderFactory.
	 */
	static {
		documentBuilderFactory = DocumentBuilderFactory.newInstance();
		documentBuilderFactory.setNamespaceAware(true);
		transformerFactory = TransformerFactory.newInstance();
	}

	/**
	 * Private constructor to prevent instantiation of this class object.
	 */
	private XmlUtilities() {
		// empty constructor to prevent instantiation
	}

	/**
	 * Converts a DOM document to a string.
	 * 
	 * @param doc
	 * @return String
	 * @throws FoundationsException
	 * @deprecated Need for XML utilities has been superceded by the many JRE-built-in and external XML frameworks
	 */
	public static String convertXmlToStr(Document doc) throws FoundationsException {
		StringWriter sw = new StringWriter();
		try {
			threadTransformer.getTransformer().transform(new DOMSource(doc), new StreamResult(sw));
		} catch (TransformerException e) {
			String errStr = "Exception occured transforming DOM to String.";
			if (logger.isEnabledFor(Level.ERROR)) {
				logger.error((new StringBuffer()).append(errStr).append("\n\t").append(
						ExceptionUtils.getFullStackTrace(e)).toString());
			}
			throw new FoundationsException(errStr, e);
		}
		return sw.toString();
	}

	/**
	 * Returns the first node at the specified XPath location.
	 * <p>
	 * Example:
	 * <p>
	 * This example returns the Customer/Address node in the specified document object.
	 * <p>
	 * <code>
	 * Node address = XmlUtilities.getNode(&quot;/Customer/Address&quot;, custDoc);
	 * </code>
	 * 
	 * @param xpathStr XPath str
	 * @param node Node to search
	 * @return Node first node found
	 * @deprecated Need for XML utilities has been superceded by the many JRE-built-in and external XML frameworks
	 */
	public static Node getNode(String xpathStr, Node node) {
		
		XPath xpath = XPathFactory.newInstance().newXPath();
		try {

			NodeList nodeSet = (NodeList) xpath.evaluate(xpathStr, node, XPathConstants.NODESET);
			logger.debug((new StringBuffer()).append("XPath ").append(xpathStr).append(" returned  ").append(
					nodeSet.getLength()).append("nodes.").toString());
			if (nodeSet.getLength() == 0) {
				return null;
			} else {
				return (Node) nodeSet.item(0);
			}

		} catch (XPathExpressionException e) {

			logger.error((new StringBuffer()).append("Exception occured.").append("\n\t").append(
			ExceptionUtils.getFullStackTrace(e)).toString());
			return null;

		}
		// Old JAXEN-based version
		//
//		try {
//			XPath xpath = new DOMXPath(xpathStr);
//			// selectNodes was used instead of selectSingleNode because of these
//			// tests
//			// (http://dom4j.org/benchmarks/xpath/index.html).
//			// Eventually we will be using dom4j.
//			List list = xpath.selectNodes(node);
//			if (logger.isDebugEnabled()) {
//				logger.debug((new StringBuffer()).append("XPath ").append(xpathStr).append(" returned  ").append(
//						list.size()).append("nodes.").toString());
//			}
//			if (list.isEmpty()) {
//				return null;
//			} else {
//				return (Node) list.get(0);
//			}
//		} catch (JaxenException e) {
//			if (logger.isEnabledFor(Level.ERROR)) {
//				logger.error((new StringBuffer()).append("Exception occured.").append("\n\t").append(
//						ExceptionUtils.getFullStackTrace(e)).toString());
//			}
//			return null;
//		}
	}

	/**
	 * Returns the Attribute with the given attrName at node.
	 * <p>
	 * Example:
	 * <p>
	 * This example returns the 'state' attribute from the address node.
	 * <p>
	 * <code>
	 *         Attr state = getAttr(address,&quot;state&quot;)
	 * </code>
	 * 
	 * @param node Node to search
	 * @param attrName Name of the attribute to find
	 * @return Attr Attribute found
	 * @deprecated Need for XML utilities has been superceded by the many JRE-built-in and external XML frameworks
	 */
	public static Attr getAttr(Node node, String attrName) {
		NamedNodeMap attrs = node.getAttributes();
		return (Attr) attrs.getNamedItem(attrName);
	}

	/**
	 * Returns an XML DOM Document for the specified String.
	 * <p>
	 * Example:
	 * <p>
	 * This example creates a customer XML document for a serialized customer:
	 * <p>
	 * <code>
	 * Document cust = XmlUtilities.getDocumentForXmlString(custXmlString);
	 * </code>
	 * 
	 * @param xml serialized XML document
	 * @return Document XML document
	 * @throws FoundationsException
	 * @deprecated Need for XML utilities has been superceded by the many JRE-built-in and external XML frameworks
	 */
	public static Document getDocumentForXmlString(String xml) throws FoundationsException {
		return getDocumentForXmlInputSource(new InputSource(new StringReader(xml)));
	}

	/**
	 * Returns an XML DOM Document for the specified InputStream
	 * <p>
	 * Example:
	 * <p>
	 * This example creates a customer XML document from an input stream.
	 * <p>
	 * <code>
	 * Document cust = XmlUtilities.getDocumentForXmlInputStream(custStream);
	 * </code>
	 * 
	 * @param xml input stream to processed
	 * @return Document XML document
	 * @throws FoundationsException
	 * @deprecated Need for XML utilities has been superceded by the many JRE-built-in and external XML frameworks
	 */
	public static Document getDocumentForXmlInputStream(InputStream xml) throws FoundationsException {
		return getDocumentForXmlInputSource(new InputSource(xml));
	}

	/**
	 * Returns an XML DOM Document for the specified InputStream
	 * <p>
	 * Example:
	 * <p>
	 * This example creates a customer XML document from an input source.
	 * <p>
	 * <code>
	 * Document cust = getDocumentForXmlInputSource(custSource);
	 * </code>
	 * 
	 * @param xml input source to processed
	 * @return Document XML document
	 * @throws FoundationsException
	 * @deprecated Need for XML utilities has been superceded by the many JRE-built-in and external XML frameworks
	 */
	private static Document getDocumentForXmlInputSource(InputSource xml) throws FoundationsException {
		if (logger.isDebugEnabled()) {
			logger.debug((new StringBuffer()).append("Using DocumentBuilderFactory factory ").append(
					documentBuilderFactory).append("; and DocumentBuilder builder ").append(threadDocumentBuilder));
		}
		Document returnDoc = null;
		try {
			returnDoc = threadDocumentBuilder.getBuilder().parse(xml);

		} catch (SAXException e) {
			String errStr = "Can not parse xml into a Document - SAXException.";

			if (logger.isEnabledFor(Level.ERROR)) {
				logger.error((new StringBuffer()).append(errStr).append("\n\t").append(
						ExceptionUtils.getFullStackTrace(e)).toString());
			}
			throw new FoundationsException(errStr, e);
		} catch (IOException e) {
			String errStr = "Can not parse xml into a Document - IOException.";
			if (logger.isEnabledFor(Level.ERROR)) {
				logger.error((new StringBuffer()).append(errStr).append("\n\t").append(
						ExceptionUtils.getFullStackTrace(e)).toString());
			}
			throw new FoundationsException(errStr, e);
		}
		return returnDoc;

	}

	private static class ThreadLocalDocumentBuilder extends ThreadLocal {

		public DocumentBuilder getBuilder() throws FoundationsException {
			DocumentBuilder builder = (DocumentBuilder) this.get();
			if (builder == null) {
				throw new FoundationsException(
						"Can not get DocumentBuilder from DocumentBuilderFactory - check JAXP configuration/classpaths. See error log for details.");
			}
			return builder;
		}

		protected Object initialValue() {
			synchronized (documentBuilderFactory) {
				try {
					DocumentBuilder builder = documentBuilderFactory.newDocumentBuilder();
					// Log implementation of Document Builder class
					if (logger.isDebugEnabled()) {
						logger.debug("Using DocumentBuilder implementation: " + builder.getClass().getName());
					}
					return builder;
				} catch (ParserConfigurationException e) {
					logger
							.error((new StringBuffer())
									.append(
											"Can not get DocumentBuilder from DocumentBuilderFactory - check JAXP configuration/classpaths.")
									.append("\n\t").append(ExceptionUtils.getFullStackTrace(e)).toString());
					return null;
				}
			}
		}
	}

	private static ThreadLocalDocumentBuilder threadDocumentBuilder = new ThreadLocalDocumentBuilder();

	private static class ThreadLocalTransformer extends ThreadLocal {

		public Transformer getTransformer() throws FoundationsException {
			Transformer transformer = (Transformer) this.get();
			if (transformer == null) {
				throw new FoundationsException(
						"Exception occured trying to create Transformer. See error log for details.");
			}
			return transformer;
		}

		protected Object initialValue() {
			synchronized (transformerFactory) {
				try {
					Transformer transformer = transformerFactory.newTransformer();
					Properties oprops = new Properties();
					oprops.put(OutputKeys.METHOD, "xml");
					transformer.setOutputProperties(oprops);
					// Log implementation of DOM parser class
					if (logger.isDebugEnabled()) {
						logger.debug("Using Transformer implementation: " + transformer.getClass().getName());
					}
					return transformer;
				} catch (TransformerConfigurationException e) {
					logger.error((new StringBuffer()).append("Exception occured trying to create Transformer.").append(
							"\n\t").append(ExceptionUtils.getFullStackTrace(e)).toString());
					return null;
				}
			}
		}
	}

	private static ThreadLocalTransformer threadTransformer = new ThreadLocalTransformer();
}