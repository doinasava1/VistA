package gov.va.med.vistalink.security.m;

/**
 * Implements response-specific fields for an AV.SetupAndIntroText security message 
 * @see SecurityResponse
 * @see SecurityResponseFactory
 */
public final class SecurityDataSetupAndIntroTextResponse extends SecurityResponse {

	private SecurityVOSetupAndIntroText setupAndIntroTextInfo;
	/**
	 * @see gov.va.med.vistalink.security.m.SecuriytResponse#SecuriytResponse(int, String)
	 */
	SecurityDataSetupAndIntroTextResponse(
		SecurityVOSetupAndIntroText setupAndIntroTextInfo,
		SecurityResponse responseData) {

		super(responseData);
		this.setupAndIntroTextInfo = setupAndIntroTextInfo;
	}

	/**
	 * @return Value Object with setup and introductory text information
	 */
	public SecurityVOSetupAndIntroText getSetupAndIntroTextInfo() {
		return setupAndIntroTextInfo;
	}
}
