package gov.va.med.vistalink.security;

import gov.va.med.vistalink.security.m.SecurityVOSetupAndIntroText;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.FocusTraversalPolicy;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.UIManager;
import javax.swing.border.Border;

/**
 * Swing Dialog to collect user input for a "enter accessPasswordField and verifyPasswordField code" event
 * @see VistaLoginModule
 * @see CallbackHandlerSwing
 */
final class DialogLogon extends JDialog {

	// used by other logon dialogs too
	static final String DEFAULT_TITLE = "HealtheVet-VistA Sign-on";
	static final String SIGNON_STRING = "Sign-on";

	private static final String ACCESS_LABEL = "Access Code: ";
	private static final char ACCESS_MNEMONIC = KeyEvent.VK_A;
	private static final String ACCESS_TOOLTIP = "Enter your VistA access code";

	private static final String VERIFY_LABEL = "Verify Code: ";
	private static final char VERIFY_MNEMONIC = KeyEvent.VK_V;
	private static final String VERIFY_TOOLTIP = "Enter your VistA Verify code";

	private static final String OK_BUTTON_LABEL = "OK";
	private static final char OK_BUTTON_MNEMONIC = KeyEvent.VK_O;
	private static final String OK_BUTTON_TOOLTIP = "Submits your login request to the server";

	private static final String CANCEL_BUTTON_LABEL = "Cancel";
	private static final char CANCEL_BUTTON_MNEMONIC = KeyEvent.VK_C;
	private static final String CANCEL_BUTTON_TOOLTIP = "Cancels your login request";

	private static final String CVC_CHECKBOX_LABEL = "Change Verify Code";
	private static final char CVC_CHECKBOX_MNEMONIC = KeyEvent.VK_E;
	private static final String CVC_CHECKBOX_TOOLTIP = "Ask to change your verify code";

	// private static final String VA_LOGO = "images/VAlogo.gif";
	private static final String VA_LOGO = "images/HealtheVetVistaSmallBlueSm.gif";
	private static final String VA_LOGO_TOOLTIP = "HealtheVet-VistA logo";

	private static final String SERVER_LABEL = "Server: ";
	private static final String VOLUME_LABEL = "Volume: ";
	private static final String UCI_LABEL = "U C I: ";
	private static final String DEVICE_LABEL = "Device: ";

	private static final String SERVER_INFO_LABEL = "Server Information: ";
	private static final String SERVER_INFO_TOOLTIP = "Information about the M server in use for the current connection";
	private static final char SERVER_INFO_MNEMONIC = KeyEvent.VK_S;

	private static final String BUTTON_508_TEXT = "Section 508 Information";
	private static final String BUTTON_508_TOOLTIP = "Display Section 508 compliance information for this application";
	private static final int BUTTON_508_MNEMONIC = KeyEvent.VK_5;
	private static final String[] TEXT_508_DISCLAIMER =
		{
			"V A's Office of Information & Technology, Veteran Health Information Technology staff have made",
			"every effort during the design, development and testing of this login screen to ensure full",
			"accessibility to all users in compliance with Section 508 of the Rehabilitation Act of 1973, as",
			"amended. Please send any comments, questions or concerns regarding the accessibility of this",
			"login module to Section508 @ v a dot gov [Section508@va.gov]." };

	private static final String JTEXTAREA_TOOLTIP = "System Announcements";
	private static final String JTEXTAREA_LABEL = "System Announcements:";
	private static final char JTEXTAREA_MNEMONIC = KeyEvent.VK_N;

	private static final int CODE_FIELD_COLUMNS = 13;
	
	private JScrollPane introScrollPane;
	private JPasswordField accessPasswordField;
	private JPasswordField verifyPasswordField;
	private JLabel accessLabel;
	private JLabel verifyLabel;
	private JLabel introLabel;
	private JCheckBox cvcCheckBox;
	private JButton okButton;
	private JButton cancelButton;
	private JButton section508Button;
	private JTextArea introTextArea;
	private Border introFocusBorder;
	private Border introNoFocusBorder;
	private Border serverInfoFocusBorder;
	private Border serverInfoNoFocusBorder;
	private Frame parentFrame;
	private JLabel serverInfoLabel;
	private JTextField serverInfoTextField;

	private CallbackLogon callbackAV;

	/**
	 * Create a modal Swing dialog to get accessPasswordField and verifyPasswordField codes from the user
	 * @param parent parent frame
	 * @param callbackAV callback to retrieve information from and place result in
	 */
	static void showVistaAVSwingGetAV(Frame parent, CallbackLogon callbackAV) {

		DialogLogon dialog = new DialogLogon(parent, callbackAV);
		if ((parent != null) && (!"".equals(parent.getTitle()))) {
			dialog.setTitle(parent.getTitle() + ": " + DEFAULT_TITLE);
		} else {
			dialog.setTitle(DEFAULT_TITLE);
		}
		VistaLoginSwingUtilities.goldenMeanCenterDialog(parent, dialog);
		dialog.setVisible(true);
	}

	private DialogLogon(Frame parent, CallbackLogon callbackAV) {
		super(parent, DEFAULT_TITLE, true);
		this.callbackAV = callbackAV;
		this.parentFrame = parent;

		BoxLayout mainLayout = new BoxLayout(getContentPane(), BoxLayout.Y_AXIS);
		getContentPane().setLayout(mainLayout);

		createIntroPane();
		// create after infoPane since we're doing setLabelFor
		JPanel annLabelPanel = createIntroLabelPane();
		JPanel contentPane = createContentPane();

		getContentPane().add(annLabelPanel);
		getContentPane().add(introScrollPane);
		getContentPane().add(contentPane);
		// getContentPane().add(serverInfoPanel);

		getContentPane().setFocusCycleRoot(true);
		getContentPane().setFocusTraversalPolicy(new DialogLogonFocusTraversalPolicy());

		/* pack auto-sets frame size based on size of components contained */
		pack();
		// ensure that the current window size does not exceed the screen size
		Dimension screenSize = getToolkit().getScreenSize();
		if ((this.getSize().width > screenSize.width) || (this.getSize().height > screenSize.height)) {
			this.setSize(screenSize);
		}

		VistaLoginSwingUtilities.goldenMeanCenterDialog(parent, this);

		getAccessibleContext().setAccessibleDescription(
				"This dialog asks you to enter your access and verify codes to log into the computer system.");

		// set up event for timeout
		int timeout = 1000 * this.callbackAV.getTimeoutInSeconds();
		ActionListener taskPerformer = new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				doTimeout();
			}
		};
		new Timer(timeout, taskPerformer).start();
		accessPasswordField.requestFocusInWindow();
	}

	private JPanel createIntroLabelPane() {

		introLabel = new JLabel(JTEXTAREA_LABEL);
		introLabel.setDisplayedMnemonic(JTEXTAREA_MNEMONIC);
		introLabel.setToolTipText(JTEXTAREA_TOOLTIP);
		introLabel.setLabelFor(introTextArea);
		introLabel.setFocusable(true);
		introLabel.addFocusListener(new FocusListener() {
			public void focusGained(FocusEvent e) {
				introTextArea.requestFocusInWindow();
			}

			public void focusLost(FocusEvent e) {
			}
		});

		JPanel annPanel = new JPanel();
		FlowLayout myLayout = new FlowLayout();
		myLayout.setAlignment(FlowLayout.LEFT);
		annPanel.setLayout(myLayout);
		annPanel.add(introLabel);
		return annPanel;
	}

	private void createIntroPane() {

		// get border from current LaF
		Border defaultBorder = UIManager.getBorder("TextField.border");
		introFocusBorder =
			BorderFactory.createCompoundBorder(UIManager.getBorder("List.focusCellHighlightBorder"), defaultBorder);
		introNoFocusBorder =
			BorderFactory.createCompoundBorder(
				BorderFactory.createLineBorder(UIManager.getColor("control"), 1),
				defaultBorder);

		introTextArea = new JTextArea(callbackAV.getSetupAndIntroTextInfo().getIntroductoryText());
		introTextArea.setCaretPosition(0);
		introTextArea.setToolTipText(JTEXTAREA_TOOLTIP);
		introTextArea.setEditable(false);
		introTextArea.setMargin(new Insets(3, 3, 3, 3));
		introTextArea.setColumns(80);
		if (introTextArea.getLineCount() > 20) {
			introTextArea.setRows(20);
		}
		introTextArea.setFocusable(true);
		introTextArea.getAccessibleContext().setAccessibleName(JTEXTAREA_LABEL + callbackAV.getSetupAndIntroTextInfo().getIntroductoryText());
		introTextArea.addFocusListener(new FocusListener() {
			public void focusGained(FocusEvent e) {
				introScrollPane.setBorder(introFocusBorder);
			}

			public void focusLost(FocusEvent e) {
				introScrollPane.setBorder(introNoFocusBorder);
			}
		});

		Font currentFont = introTextArea.getFont();
		introTextArea.setFont(new Font("monospaced", currentFont.getStyle(), currentFont.getSize()));
		introScrollPane = new JScrollPane(introTextArea);
		introScrollPane.setBorder(introNoFocusBorder);

	}

	private JPanel createContentPane() {
		GridBagLayout gridbag = new GridBagLayout();

		// accessPasswordField password field
		this.accessPasswordField = new JPasswordField("", CODE_FIELD_COLUMNS);
		this.accessPasswordField.setToolTipText(ACCESS_TOOLTIP);

		// accessPasswordField label
		accessLabel = new JLabel(ACCESS_LABEL);
		accessLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		accessLabel.setFont(accessLabel.getFont().deriveFont(Font.BOLD));
		// need to leave focus enabled for mnemonic to work; appears to waste an extra tab in the traversal cycle though
		accessLabel.setToolTipText(ACCESS_TOOLTIP);
		accessLabel.setDisplayedMnemonic(ACCESS_MNEMONIC);
		accessLabel.setLabelFor(this.accessPasswordField);
		accessLabel.addFocusListener(new FocusListener() {
			public void focusLost(FocusEvent e) {
			}

			public void focusGained(FocusEvent e) {
				accessPasswordField.requestFocusInWindow();
			}
		});

		// verifyPasswordField password field
		verifyPasswordField = new JPasswordField("", CODE_FIELD_COLUMNS);
		verifyPasswordField.setToolTipText(VERIFY_TOOLTIP);

		// verifyPasswordField label
		verifyLabel = new JLabel(VERIFY_LABEL);
		verifyLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		verifyLabel.setFont(verifyLabel.getFont().deriveFont(Font.BOLD));
		verifyLabel.setToolTipText(VERIFY_TOOLTIP);
		verifyLabel.setDisplayedMnemonic(VERIFY_MNEMONIC);
		verifyLabel.setLabelFor(this.verifyPasswordField);
		verifyLabel.addFocusListener(new FocusListener() {
			public void focusLost(FocusEvent e) {
			}

			public void focusGained(FocusEvent e) {
				verifyPasswordField.requestFocusInWindow();
			}
		});

		// Set a minimum width for the access/verify code password fields based on font width
		Dimension minimumDimension =
			new Dimension(
				(accessPasswordField.getFontMetrics(accessPasswordField.getFont()).charWidth('a') * 8),
				accessPasswordField.getFontMetrics(accessPasswordField.getFont()).getHeight());
		accessPasswordField.setMinimumSize(minimumDimension);
		verifyPasswordField.setMinimumSize(minimumDimension);

		// panel
		JPanel p = new JPanel();
		p.setLayout(gridbag);

		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.NONE;
		c.insets = new Insets(5, 5, 5, 5);
		c.ipadx = c.ipady = 0;
		c.weightx = 0;

		c.gridx = c.gridy = 0;
		c.gridheight = 3;
		c.weightx = 10;
		p.add(createLogoLabel(), c);

		c.gridy = 3;
		c.gridheight = 1;
		c.gridwidth = 1;
		c.weightx = 2;
		p.add(create508Button(), c);

		c.gridheight = 1;
		c.gridwidth = 1;
		c.gridx = 1;
		c.gridy = 0;
		c.weightx = 4;
		p.add(accessLabel, c);

		c.weightx = 4;
		c.gridy = 1;
		p.add(verifyLabel, c);

		c.gridx = 2;
		c.gridy = 0;
		c.weightx = 4;
		c.ipadx = c.ipady = 3;
		p.add(accessPasswordField, c);

		c.gridy = 1;
		c.weightx = 4;
		c.ipadx = c.ipady = 3;
		p.add(verifyPasswordField, c);

		createOKButton();
		c.gridx = 3;
		c.gridy = 0;
		c.fill = GridBagConstraints.HORIZONTAL;
		c.ipadx = c.ipady = 3;
		c.weightx = 2;
		p.add(okButton, c);

		createCancelButton();
		c.gridy = 1;
		c.fill = GridBagConstraints.HORIZONTAL;
		c.ipadx = c.ipady = 3;
		c.weightx = 2;
		p.add(cancelButton, c);

		c.gridx = 2;
		c.gridy = 2;
		c.ipadx = c.ipady = 0;
		c.gridheight = 1;
		c.gridwidth = 2;
		c.weightx = 2;
		c.fill = GridBagConstraints.NONE;
		c.anchor = GridBagConstraints.NORTHWEST;
		p.add(createCvcPanel(), c);

		c.gridx = 0;
		c.gridy = 4;
		c.gridwidth = 4;
		c.weightx = 2;
		c.anchor = GridBagConstraints.CENTER;
		JPanel serverInfoPanel = createServerInfoPanel(this.callbackAV.getSetupAndIntroTextInfo());
		p.add(serverInfoPanel, c);

		return p;
	}

	private JComponent createCvcPanel() {
		JPanel myPanel = new JPanel();
		FlowLayout myLayout = new FlowLayout();
		myLayout.setAlignment(FlowLayout.LEFT);
		myPanel.setLayout(myLayout);

		this.cvcCheckBox = new JCheckBox(CVC_CHECKBOX_LABEL, false);
		this.cvcCheckBox.setMnemonic(CVC_CHECKBOX_MNEMONIC);
		this.cvcCheckBox.setToolTipText(CVC_CHECKBOX_TOOLTIP);
		this.cvcCheckBox.setBorder(BorderFactory.createEmptyBorder());
		this.cvcCheckBox.setOpaque(false);
		myPanel.add(this.cvcCheckBox);

		return myPanel;
	}

	private void createCancelButton() {
		cancelButton = new JButton(CANCEL_BUTTON_LABEL);
		cancelButton.setMnemonic(CANCEL_BUTTON_MNEMONIC);
		cancelButton.setToolTipText(CANCEL_BUTTON_TOOLTIP);
		cancelButton.setFont(cancelButton.getFont().deriveFont(Font.BOLD));
		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cancelActionPerformed();
			}
		});
	}

	private void createOKButton() {
		okButton = new JButton(OK_BUTTON_LABEL);
		okButton.setMnemonic(OK_BUTTON_MNEMONIC);
		okButton.setToolTipText(OK_BUTTON_TOOLTIP);
		okButton.setFont(okButton.getFont().deriveFont(Font.BOLD));
		this.getRootPane().setDefaultButton(okButton);

		// handle events for button presses
		okButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				okActionPerformed();
			}
		});
	}

	private JPanel createServerInfoPanel(SecurityVOSetupAndIntroText setupInfo) {

		// text
		StringBuffer sb = new StringBuffer(" ");
		sb.append(SERVER_LABEL);
		sb.append(setupInfo.getServerName());
		sb.append("; ");
		sb.append(VOLUME_LABEL);
		sb.append(setupInfo.getVolume());
		sb.append("; ");
		sb.append(UCI_LABEL);
		sb.append(setupInfo.getUci());
		sb.append("; ");
		sb.append(DEVICE_LABEL);
		sb.append(setupInfo.getDevice());

		// get border from current LaF
		Border defaultBorder = UIManager.getBorder("TextField.border");
		serverInfoFocusBorder =
			BorderFactory.createCompoundBorder(UIManager.getBorder("List.focusCellHighlightBorder"), defaultBorder);
		serverInfoNoFocusBorder =
			BorderFactory.createCompoundBorder(
				BorderFactory.createLineBorder(UIManager.getColor("control"), 1),
				defaultBorder);

		serverInfoTextField = new JTextField(sb.toString());
		serverInfoTextField.setToolTipText(SERVER_INFO_TOOLTIP);
		serverInfoTextField.setEditable(false);
		serverInfoTextField.setFocusable(true);
		serverInfoTextField.setMargin(new Insets(1, 4, 1, 4));
		// ensure a minimum width for this field.
		Dimension minimumDimension =
			new Dimension(
				(serverInfoTextField.getFontMetrics(serverInfoTextField.getFont()).charWidth('a') * sb.length()),
				serverInfoTextField.getFontMetrics(serverInfoTextField.getFont()).getHeight() + 4);
		serverInfoTextField.setMinimumSize(minimumDimension);

		serverInfoTextField.getAccessibleContext().setAccessibleName(SERVER_INFO_LABEL + sb.toString());
		serverInfoTextField.setBorder(serverInfoNoFocusBorder);
		serverInfoTextField.addFocusListener(new FocusListener() {
			public void focusGained(FocusEvent e) {
				serverInfoTextField.setBorder(serverInfoFocusBorder);
			}

			public void focusLost(FocusEvent e) {
				serverInfoTextField.setBorder(serverInfoNoFocusBorder);
			}
		});

		serverInfoLabel = new JLabel(SERVER_INFO_LABEL);
		serverInfoLabel.setToolTipText(SERVER_INFO_TOOLTIP);
		serverInfoLabel.setFocusable(true);
		serverInfoLabel.setDisplayedMnemonic(SERVER_INFO_MNEMONIC);
		serverInfoLabel.setLabelFor(serverInfoTextField);

		JPanel p = new JPanel();
		BoxLayout myBoxLayout = new BoxLayout(p, BoxLayout.X_AXIS);
		// FlowLayout myFlowLayout = new FlowLayout();
		// myFlowLayout.setAlignment(FlowLayout.LEFT);
		// p.setLayout(myFlowLayout);
		p.setLayout(myBoxLayout);
		p.add(serverInfoLabel);
		p.add(serverInfoTextField);
		return p;
	}

	private JLabel createLogoLabel() {
		ImageIcon vaIcon = new ImageIcon(getClass().getResource(VA_LOGO));
		vaIcon.setDescription(VA_LOGO_TOOLTIP);
		vaIcon.getAccessibleContext().setAccessibleName("VA Logo");
		vaIcon.getAccessibleContext().setAccessibleDescription("VA Logo");
		JLabel l = new JLabel(vaIcon);
		l.setFocusable(false);
		l.setToolTipText(VA_LOGO_TOOLTIP);
		return l;
	}

	private JButton create508Button() {
		section508Button = new JButton(BUTTON_508_TEXT);
		section508Button.setToolTipText(BUTTON_508_TOOLTIP);
		section508Button.setMnemonic(BUTTON_508_MNEMONIC);
		// handle events for button presses
		section508Button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StringBuffer sb = new StringBuffer();
				for (int i = 0; i < TEXT_508_DISCLAIMER.length; i++) {
					sb.append(TEXT_508_DISCLAIMER[i]);
					sb.append('\n');
				}
				int returnVal = DialogConfirm.showDialogConfirm(parentFrame, sb.toString(), SIGNON_STRING + " " + BUTTON_508_TEXT, DialogConfirm.MODE_INFORMATION_MESSAGE, callbackAV.getTimeoutInSeconds());
				if (returnVal == DialogConfirm.TIMEOUT_OPTION) {
					doTimeout();
				}
			}
		});
		return section508Button;
	}

	private void okActionPerformed() {
		this.callbackAV.setAccessCode(this.accessPasswordField.getPassword());
		this.callbackAV.setVerifyCode(this.verifyPasswordField.getPassword());
		this.callbackAV.setRequestCvc(this.cvcCheckBox.isSelected());
		this.callbackAV.setSelectedOption(CallbackLogon.KEYPRESS_OK);
		this.setVisible(false);
		this.dispose();
	}

	private void cancelActionPerformed() {
		this.callbackAV.setAccessCode(null);
		this.callbackAV.setVerifyCode(null);
		this.callbackAV.setSelectedOption(CallbackLogon.KEYPRESS_CANCEL);
		this.setVisible(false);
		this.dispose();
	}

	private void doTimeout() {
		this.callbackAV.setAccessCode(null);
		this.callbackAV.setVerifyCode(null);
		this.callbackAV.setSelectedOption(CallbackLogon.KEYPRESS_TIMEOUT);
		this.setVisible(false);
		this.dispose();
	}

	/**
	 * Provides a focus traversal policy for this dialog
	 */
	class DialogLogonFocusTraversalPolicy extends FocusTraversalPolicy {

		/**
		 * get the next component in the focus traversal
		 * @param focusCycleRoot the root of the focus cycle
		 * @param aComponent currently focused component
		 * @return returns the next component in the (forward) cycle
		 */
		public Component getComponentAfter(Container focusCycleRoot, Component aComponent) {

			if (aComponent.equals(accessPasswordField)) {
				return verifyPasswordField;
			} else if (aComponent.equals(verifyPasswordField)) {
				return okButton;
			} else if (aComponent.equals(okButton)) {
				return cancelButton;
			} else if (aComponent.equals(cancelButton)) {
				return cvcCheckBox;
			} else if (aComponent.equals(cvcCheckBox)) {
				return section508Button;
			} else if (aComponent.equals(section508Button)) {
				return serverInfoTextField;
			} else if (aComponent.equals(serverInfoTextField)) {
				return introTextArea;
			} else if (aComponent.equals(introTextArea)) {
				return accessPasswordField;

				/* now for components outside the normal focus cycle */

			} else if (aComponent.equals(accessLabel)) {
				return accessPasswordField;
			} else if (aComponent.equals(verifyLabel)) {
				return verifyPasswordField;
			} else if (aComponent.equals(introLabel)) {
				return introTextArea;
			}
			return accessPasswordField;
		}

		/**
		 * get the previous (reverse direction) component in the focus traversal cycle
		 * @param focusCycleRoot the root of the focus cycle
		 * @param aComponent currently focused component
		 * @return returns the next component in the (reverse) cycle
		 */
		public Component getComponentBefore(Container focusCycleRoot, Component aComponent) {

			if (aComponent.equals(introTextArea)) {
				return serverInfoTextField;
			} else if (aComponent.equals(serverInfoTextField)) {
				return section508Button;
			} else if (aComponent.equals(section508Button)) {
				return cvcCheckBox;
			} else if (aComponent.equals(cvcCheckBox)) {
				return cancelButton;
			} else if (aComponent.equals(cancelButton)) {
				return okButton;
			} else if (aComponent.equals(okButton)) {
				return verifyPasswordField;
			} else if (aComponent.equals(verifyPasswordField)) {
				return accessPasswordField;
			} else if (aComponent.equals(accessPasswordField)) {
				return introTextArea;

				/* now for components outside the normal focus cycle */

			} else if (aComponent.equals(accessLabel)) {
				return cvcCheckBox;
			} else if (aComponent.equals(verifyLabel)) {
				return accessPasswordField;
			} else if (aComponent.equals(introLabel)) {
				return serverInfoTextField;
			}
			return accessPasswordField;
		}

		/**
		 * gets the default component to focus on
		 * @param focusCycleRoot the root of the focus cycle
		 * @return the default component in the focus cycle
		 */
		public Component getDefaultComponent(Container focusCycleRoot) {
			return accessPasswordField;
		}

		/**
		 * gets the last component in the focus cycle
		 * @param focusCycleRoot the root of the focus cycle
		 * @return the last component in the focus cycle
		 */
		public Component getLastComponent(Container focusCycleRoot) {
			return introTextArea;
		}

		/**
		 * gets the first component in the focus cycle
		 * @param focusCycleRoot the root of the focus cycle
		 * @return the first component in the focus cycle
		 */
		public Component getFirstComponent(Container focusCycleRoot) {
			return accessPasswordField;
		}
	}
}
