package gov.va.med.vistalink.security.m;

import gov.va.med.vistalink.adapter.cci.VistaLinkConnection;
import gov.va.med.vistalink.adapter.record.VistaLinkFaultException;
import gov.va.med.vistalink.adapter.spi.VistaLinkConnectionImpl;
import gov.va.med.crypto.VistaKernelHashCountLimitExceededException;
import gov.va.med.exception.FoundationsException;

import java.io.IOException;

import javax.resource.ResourceException;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;

/**
 * Manages logon-related security handshake with M/VistA. Used for client/server logins.
 * 
 */
public abstract class KernelSecurityHandshake {

	// Initialize Logger instance to be used by this class
	private static final Logger LOGGER = Logger.getLogger(KernelSecurityHandshake.class);

	/**
	 * 
	 * @param myConnection
	 *            The <code>VistaLinkConnection</code> connection to use
	 * @param securityResponseFactory
	 *            An already instantiated <code>SecurityResponseFactory</code>
	 * @return SecurityDataSetupAndIntroTextResponse
	 * @throws ParserConfigurationException
	 * @throws VistaLinkFaultException
	 * @throws FoundationsException
	 */
	public static SecurityResponse doSetupAndGetIntroText(VistaLinkConnection myConnection,
			SecurityResponseFactory securityResponseFactory) throws ParserConfigurationException,
			VistaLinkFaultException, FoundationsException {

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("sending setup and intro text");
		}

		return KernelSecurityHandshakeManaged.doSetupAndGetIntroText(((VistaLinkConnectionImpl) myConnection)
				.getManagedConnection(), securityResponseFactory, false, null, "");
	}

	/**
	 * 
	 * @param myConnection
	 *            The <code>VistaLinkConnection</code> connection to use
	 * @param securityResponseFactory
	 *            An already instantiated <code>SecurityResponseFactory</code>
	 * @param accessCode
	 *            access code to login with
	 * @param verifyCode
	 *            verify code to login with
	 * @param requestCvc
	 *            boolean -- true to request changing verify code, false to not
	 *            do that
	 * @return SecurityDataLogonResponse
	 * @throws ParserConfigurationException
	 * @throws VistaKernelHashCountLimitExceededException
	 * @throws FoundationsException
	 */
	public static SecurityDataLogonResponse doAVLogon(VistaLinkConnection myConnection,
			SecurityResponseFactory securityResponseFactory, String accessCode, String verifyCode, boolean requestCvc)
			throws ParserConfigurationException, VistaKernelHashCountLimitExceededException, FoundationsException {

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("sending logon");
		}

		return KernelSecurityHandshakeManaged.doAVLogon(
				((VistaLinkConnectionImpl) myConnection).getManagedConnection(), securityResponseFactory, accessCode,
				verifyCode, requestCvc);
	}

	/**
	 * 
	 * @param myConnection
	 *            The <code>VistaLinkConnection</code> connection to use
	 * @param securityResponseFactory
	 *            An already instantiated <code>SecurityResponseFactory</code>
	 * @param token
	 *            Kernel CCOW token to login with
	 * @return SecurityDataLogonResponse
	 * @throws ParserConfigurationException
	 * @throws VistaKernelHashCountLimitExceededException
	 * @throws FoundationsException
	 */
	public static SecurityDataLogonResponse doAVLogon(VistaLinkConnection myConnection,
			SecurityResponseFactory securityResponseFactory, String token) throws ParserConfigurationException,
			VistaKernelHashCountLimitExceededException, FoundationsException {

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("sending logon");
		}

		return KernelSecurityHandshakeManaged.doAVLogon(
				((VistaLinkConnectionImpl) myConnection).getManagedConnection(), securityResponseFactory, token);

	}

	/**
	 * 
	 * @param myConnection
	 *            The <code>VistaLinkConnection</code> connection to use
	 * @param securityResponseFactory
	 *            An already instantiated <code>SecurityResponseFactory</code>
	 * @param divisionIenToSelect
	 *            IEN string of the division to select
	 * @return SecurityDataSelectDivisionResponse
	 * @throws ParserConfigurationException
	 * @throws VistaLinkFaultException
	 * @throws FoundationsException
	 */
	public static SecurityDataSelectDivisionResponse doSelectDivision(VistaLinkConnection myConnection,
			SecurityResponseFactory securityResponseFactory, String divisionIenToSelect)
			throws ParserConfigurationException, VistaLinkFaultException, FoundationsException {

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("sending select division");
		}

		return KernelSecurityHandshakeManaged.doSelectDivision(((VistaLinkConnectionImpl) myConnection)
				.getManagedConnection(), securityResponseFactory, divisionIenToSelect);
	}

	/**
	 * 
	 * @param myConnection
	 *            The <code>VistaLinkConnection</code> connection to use
	 * @param securityResponseFactory
	 *            An already instantiated <code>SecurityResponseFactory</code>
	 * @param vcOld
	 *            old verify code
	 * @param vcNew
	 *            new verify code
	 * @param vcNewCheck
	 *            "check" presumably duplicate string for new verify code
	 * @return SecurityDataChangeVcResponse
	 * @throws ParserConfigurationException
	 * @throws VistaLinkFaultException
	 * @throws FoundationsException
	 */
	public static SecurityDataChangeVcResponse doChangeVerifyCode(VistaLinkConnection myConnection,
			SecurityResponseFactory securityResponseFactory, String vcOld, String vcNew, String vcNewCheck)
			throws ParserConfigurationException, VistaLinkFaultException, FoundationsException {

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("sending change verify");
		}

		return KernelSecurityHandshakeManaged.doChangeVerifyCode(((VistaLinkConnectionImpl) myConnection)
				.getManagedConnection(), securityResponseFactory, vcOld, vcNew, vcNewCheck);
	}

	/**
	 * 
	 * @param myConnection
	 *            The <code>VistaLinkConnection</code> connection to use
	 * @param securityResponseFactory
	 *            An already instantiated <code>SecurityResponseFactory</code>
	 * @return SecurityDataUserDemographicsResponse
	 * @throws ParserConfigurationException
	 * @throws VistaLinkFaultException
	 * @throws FoundationsException
	 */
	public static SecurityDataUserDemographicsResponse doGetUserDemographics(VistaLinkConnection myConnection,
			SecurityResponseFactory securityResponseFactory) throws ParserConfigurationException,
			VistaLinkFaultException, FoundationsException {

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("sending get user demographics");
		}

		return KernelSecurityHandshakeManaged.doGetUserDemographics(((VistaLinkConnectionImpl) myConnection)
				.getManagedConnection(), securityResponseFactory);
	}

	/**
	 * 
	 * @param myConnection
	 *            The <code>VistaLinkConnection</code> connection to use
	 * @param securityResponseFactory
	 *            An already instantiated <code>SecurityResponseFactory</code>
	 * @throws ParserConfigurationException
	 * @throws VistaLinkFaultException
	 * @throws FoundationsException
	 * @throws ResourceException
	 * @throws IOException
	 */
	public static SecurityDataLogoutResponse doLogout(VistaLinkConnection myConnection,
			SecurityResponseFactory securityResponseFactory) throws ParserConfigurationException,
			VistaLinkFaultException, FoundationsException, ResourceException, IOException {

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("sending do logout");
		}

		return KernelSecurityHandshakeManaged.doLogout(((VistaLinkConnectionImpl) myConnection).getManagedConnection(),
				securityResponseFactory);
	}

}