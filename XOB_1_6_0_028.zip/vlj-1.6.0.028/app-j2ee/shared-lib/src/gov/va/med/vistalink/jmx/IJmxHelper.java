package gov.va.med.vistalink.jmx;

import javax.management.MBeanServer;

/**
 * Set of wrapper functions to help applications achieve vendor-neutrality for the non-vendor-neutral portions of JMX
 * not currently covered by the JMX specifications. Implementations must be thread-safe.
 * <p>
 */
public interface IJmxHelper {

	/**
	 * Return the JMX domain string to be used to register all HealtheVet MBeans under.
	 * 
	 * @return JMX domain string for HealtheVet MBeans.
	 */
	String getJmxDomainForHev();

	/**
	 * Return local server identifier ObjectName key/properties to use in ObjectNames when registering MBeans.
	 * 
	 * @return ObjectName key/properties identifying local server (without leading/trailing commas)
	 */
	String getServerObjectNamePropertiesForRegistration();

	/**
	 * 
	 * @return the JVM-local MBeanServer instance to register/unregister custom MBeans
	 * @throws JmxHelperException
	 */
	MBeanServer getLocalMBeanServer() throws JmxHelperException;

	/**
	 * 
	 * @return the JMX domain name under which platform-supplied MBeans should be registered. For internal use only; not
	 *         intended to be a public API.
	 */
	String getJmxDomainForPlatform();

	/**
	 * Returns an identifier for the (multi-)server set of server resources (for use with DESScopedEncrypter token
	 * encryption)
	 * 
	 * @return domain name for computing domain
	 * @throws JmxHelperException
	 */
	String getComputingDomainName() throws JmxHelperException;
}