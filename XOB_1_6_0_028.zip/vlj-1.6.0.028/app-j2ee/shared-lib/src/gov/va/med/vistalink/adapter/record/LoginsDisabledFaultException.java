package gov.va.med.vistalink.adapter.record;

/**
 * This exception represents the case where the M side has logins disabled; this
 * is when the site sets the parameter to not allow any logins.
 * 
 */
public class LoginsDisabledFaultException extends VistaLinkFaultException {

	/**
	 * Constructor for LoginsDisabledFaultException.
	 * 
	 * @param vistaLinkFaultException
	 * @va.exclude
	 */
	public LoginsDisabledFaultException(VistaLinkFaultException vistaLinkFaultException) {
		super(vistaLinkFaultException);
	}

}