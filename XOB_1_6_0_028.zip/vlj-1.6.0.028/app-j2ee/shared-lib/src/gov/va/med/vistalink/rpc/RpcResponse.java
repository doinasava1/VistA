package gov.va.med.vistalink.rpc;

import gov.va.med.vistalink.adapter.record.VistaLinkResponseVOImpl;
import gov.va.med.xml.XmlUtilities;
import gov.va.med.exception.ExceptionUtils;
import gov.va.med.exception.FoundationsException;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;

/**
 * Represents a data structure which holds the response value(s).
 * <p>
 * It is extremely important that any code which might create a new RpcResponse be encased in a try catch block so that
 * VistaLinkfaultException and FoundationsException can be caught.
 * <p>
 * J2SE Example:
 * <p>
 * <code>
 *       //request  and response objects <br>
 *      RpcRequest vReq = null; <br>
 *      RpcResponse vResp = null;
 * <p>   
 *      //The Rpc Context<br>
 *      String rpcContext = &quot;XOBV VISTALINK TESTER&quot;;
 * <p>   
 *      //The Rpc to call<br>
 *      String rpcName = &quot;XOBV TEST PING&quot;;
 * <p>   
 *       //Construct the request object<br>
 *      vReq = RpcRequestFactory.getRpcRequest(rpcContext, rpcName);
 * <p>   
 *      //Execute   the Rpc and get the response <br>
 *      vResp = myConnection.executeRPC(vReq);
 * <p>   
 *       //Display  the response <br>
 *      System.out.println(vResp.getRawResponse());
 * </code>
 * 
 */

public class RpcResponse extends VistaLinkResponseVOImpl {

	/**
	 * The logger used by this class
	 */
	private static final Logger logger = Logger.getLogger(RpcResponse.class);

	/**
	 * The message type used for this response
	 */
	protected static final String GOV_VA_MED_RPC_RESPONSE = "gov.va.med.foundations.rpc.response";

	/**
	 * The message type used to indicate RPC fault
	 */
	protected static final String GOV_VA_MED_RPC_FAULT = "gov.va.med.vistalink.rpc.fault";

	/**
	 * The message type used to indicate a system/foundations fault
	 */
	protected static final String GOV_VA_MED_FOUNDATIONS_FAULT = "gov.va.med.foundations.vistalink.system.fault";

	/**
	 * The message type used to indicate a security fault
	 */
	protected static final String GOV_VA_MED_FOUNDATIONS_SECURITY_FAULT = "gov.va.med.foundations.security.fault";

	/**
	 * Represents the string that idenitifies if a Foundations fault has occurred.
	 */
	// not used; saving as documentation
	// private static final String ERROR_MSG_GEN = XmlUtilities.XML_HEADER + "<VistaLink messageType=\""
	// + GOV_VA_MED_FOUNDATIONS_FAULT + "\" >";
	/**
	 * Represents the string that idenitifies if a RPC fault has occurred.
	 */
	// not used; saving as documentation
	// private static final String ERROR_MSG_RPC = XmlUtilities.XML_HEADER + "<VistaLink messageType=\""
	// + GOV_VA_MED_RPC_FAULT + "\" >";
	/**
	 * Represents the string that idenitifies if a Security fault has occurred.
	 */
	// not used; saving as documentation
	// private static final String ERROR_MSG_SEC = XmlUtilities.XML_HEADER + "<VistaLink messagetype=\""
	// + GOV_VA_MED_FOUNDATIONS_SECURITY_FAULT + "\" >";
	/**
	 * Represents the suffix portion of the xml response
	 */
	// not used; saving as documentation
	// private static final String SUFFIX = "</Response></VistaLink>";
	/**
	 * Represents the beginning of the CDATA section
	 */
	// not used; saving as documentation
	// private static final String CDATA_BEG = "<![CDATA[";
	/**
	 * Represents the end of the CDATA section with the SUFFIX
	 */
	// not used; saving as documentation
	// private static final String CDATA_END = "]]>" + SUFFIX;
	/**
	 * Identifies the results type
	 */
	private String resultsType;

	/**
	 * Represents the extracted CDATA
	 */
	private String cdataFromXml = null;

	/**
	 * Represents extracted CDATA as a DOM document
	 */
	private Document cdataDocument = null;

	/**
	 * Constructor RpcResponse.
	 * 
	 * @param rawXml
	 * @param filteredXml
	 * @param doc
	 * @param messageType
	 * @param cdataFromXml
	 * @param resultsType
	 */
	protected RpcResponse(String rawXml, String filteredXml, Document doc, String messageType, String cdataFromXml,
			String resultsType) {

		// call a superclass constructor
		super(rawXml, filteredXml, doc, messageType);

		// set RPC specific properties
		this.cdataFromXml = cdataFromXml;
		this.resultsType = resultsType;
	}

	/**
	 * Gets an XML Document format based on the contains of the results returned by the RPC.
	 * <p>
	 * Note: This XML document is created during the call to this method and not as part of the creation of the
	 * RpcResponse object.
	 * <p>
	 * If calling application wants to use this method, it should use generic xml DOM interfaces from org.w3c.dom.*
	 * package.
	 * <p>
	 * Alternatively if application wants to use this document in a specific XML parser implementation, parser should be
	 * able to create a specific Document implementation from org.w3c.dom.Document interface. In this case it might be
	 * better from performance standpiont to use getResults() and parse xml string directly.
	 * 
	 * @return org.w3c.dom.Document
	 * @throws RpcResponseTypeIsNotXmlException results type must be 'xml'
	 * @throws FoundationsException
	 */
	public Document getResultsDocument() throws RpcResponseTypeIsNotXmlException, FoundationsException {
		try {
			if (this.resultsType.equals("xml")) {
				if (cdataDocument == null) {
					cdataDocument = XmlUtilities.getDocumentForXmlString(getResults());
				}
				return cdataDocument;
			} else {
				throw new RpcResponseTypeIsNotXmlException("Illegal method call. Results type is not 'xml'.");
			}
		} catch (FoundationsException e) {

			if (logger.isEnabledFor(Level.ERROR)) {
				logger.error((new StringBuffer()).append("Can not get results Document.").append("\n\t").append(
						ExceptionUtils.getFullStackTrace(e)).toString());
			}
			throw e;
		}
	}

	/**
	 * Gets the results string for the returned data in this response.
	 * 
	 * @return String
	 */
	public String getResults() {
		return cdataFromXml;
	}

	/**
	 * Gets the return type of the results sent back from the M VistAServer. At the present time (04/2002) the possible
	 * types are 'string' or 'array'.
	 * 
	 * @return String
	 */
	public String getResultsType() {
		return resultsType;
	}

	/**
	 * Sets the resultsType.
	 * 
	 * @param resultsType The resultsType to set
	 * @va.exclude
	 */
	public void setResultsType(String resultsType) {
		this.resultsType = resultsType;
	}

}