package gov.va.med.exception;

import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;

/**
 * Exposes utility methods for handling exceptions
 * 
 * @deprecated Superceded by JDK 1.4+ exception functionality.
 */
public class ExceptionUtils {

	/**
	 * Private constructor to prevent instantiation of this class objects.
	 */
	private ExceptionUtils() {
		//empty constructor to prevent instantiation
	}

	/**
	 * Gets the full stack trace as a string.
	 * 
	 * @param e
	 * @return String
	 * @deprecated Superceded by JDK 1.4+ exception functionality.
	 */
	public static String getFullStackTrace(Throwable e) {

		// no identical function in JDK 1.4 -- getStackTrace returns StackTraceElement[] not String
		// however commons.lang.exception.ExceptionUtils has identical method

		ByteArrayOutputStream byteOutStr = new ByteArrayOutputStream();
		PrintWriter writer = new PrintWriter(byteOutStr);
		e.printStackTrace(writer);
		writer.flush();
		writer.close();
		return new String(byteOutStr.toByteArray());
	}

	/**
	 * Gets the nested exception if exception is an instance of the exceptionClass or if any nested exception is an
	 * instance of the type exceptionClass.
	 * <p>
	 * If desired instance of exceptionClass is not found in the nested exception stack then null is returned.
	 * <p>
	 * Can be used to unwind nested exception stack.
	 * 
	 * @param e
	 * @param exceptionClass
	 * @return Throwable
	 * @deprecated Superceded by JDK 1.4+ exception functionality.
	 */
	public static Throwable getNestedExceptionByClass(Throwable e, Class exceptionClass) {

		// no similar function in JDK 1.4
		// however equivalent functionality could be obtained using commons.lang.exception's indexOfThrowable()
		// combined with getThrowables().

		// If this is the one we are looking for, just return it
		if (exceptionClass.isInstance(e)) {
			return e;
		}
		// recurse through nested exceptions
		Throwable nestedException = e.getCause();
		if (nestedException != null) {
			return ExceptionUtils.getNestedExceptionByClass(nestedException, exceptionClass);
		}
		return null;
	}

}