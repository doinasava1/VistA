package gov.va.med.vistalink.adapter.spi;


import gov.va.med.exception.ExceptionUtils;
import gov.va.med.exception.FoundationsException;
import gov.va.med.vistalink.adapter.record.VistaLinkRequestRetryStrategyAllow;
import gov.va.med.vistalink.adapter.record.VistaLinkRequestVOImpl;
import gov.va.med.xml.XmlUtilities;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.w3c.dom.Attr;
import org.w3c.dom.Node;

/**
 * This class represents a system information request.
 * 
 */
public class VistaLinkSystemInfoRequest extends VistaLinkRequestVOImpl {

	/**
	 * The logger used for this class
	 */
	private static final Logger logger =
		Logger.getLogger(VistaLinkSystemInfoRequest.class);

	/**
	 * The xml request used for system info request
	 */
	private static final String INITSYSTEMINFO_REQUEST =
		"<?xml version='1.0' encoding='utf-8' ?><VistaLink messageType='gov.va.med.foundations.vistalink.system.request' version='" + VistaLinkManagedConnectionFactory.ADAPTER_VERSION + "' mode='singleton' xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' xsi:noNamespaceSchemaLocation='vlSimpleRequest.xsd'><Request type='systemInfo' environment=''></Request></VistaLink>";


	/**
	 * Constructor for VistaLinkInitSocketRequest.
	 * @param adapterEnvironment
	 */

	public VistaLinkSystemInfoRequest(EMAdapterEnvironment adapterEnvironment) throws FoundationsException {
		super();
		try {
			
			this.requestDoc =
				XmlUtilities.getDocumentForXmlString(INITSYSTEMINFO_REQUEST);
			
			
			Node reqNode =
				XmlUtilities.getNode("/VistaLink/Request", this.requestDoc);

			Attr reqAdapterEnvironment = 
					XmlUtilities.getAttr(reqNode, "environment");
			if (adapterEnvironment != null) {
				reqAdapterEnvironment.setValue(adapterEnvironment.toString());
			}else{
				throw new FoundationsException("The adapter Environment is specified as null.");				
			}
			
			this.retryStrategy = new VistaLinkRequestRetryStrategyAllow();
			
		} catch (FoundationsException e) {

			if(logger.isEnabledFor(Level.ERROR)){
				
				String errMsg = (new StringBuffer())
					.append(
					"Could not construct xml document")
					.append("\n\t")
					.append(ExceptionUtils
							.getFullStackTrace(e))
					.toString();
						
				logger.error(errMsg);
			}
			throw e;
		}
	}

}
