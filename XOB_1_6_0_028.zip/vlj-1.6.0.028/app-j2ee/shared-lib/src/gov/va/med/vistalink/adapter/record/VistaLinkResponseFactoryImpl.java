package gov.va.med.vistalink.adapter.record;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import gov.va.med.vistalink.adapter.spi.VistaLinkManagedConnectionFactory;
import gov.va.med.xml.XmlUtilities;
import gov.va.med.exception.ExceptionUtils;
import gov.va.med.exception.FoundationsException;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

/**
 * Base response factory implementation. Performs system level response parsing tasks. Allows subclasses to plugin more
 * specific parsing implementations.
 * 
 */
public class VistaLinkResponseFactoryImpl implements VistaLinkResponseFactory {

	/**
	 * The logger used by this class
	 */
	private static final Logger logger = Logger.getLogger(VistaLinkResponseFactoryImpl.class);

	// constants used to extract results string from returned XML stream

	/**
	 * Fault message type name.
	 */
	protected static final String GOV_VA_MED_FOUNDATIONS_FAULT = "gov.va.med.foundations.vistalink.system.fault";

	/**
	 * Defines the message type for a security errors response
	 */
	protected static final String ERROR_MSG_GEN = XmlUtilities.XML_HEADER + "<VistaLink messageType=\""
			+ GOV_VA_MED_FOUNDATIONS_FAULT;

	/**
	 * Response message suffix (i.e., the last two XML tags).
	 */
	protected static final String SUFFIX = "</Response></VistaLink>";

	/**
	 * Response message root element name.
	 */
	protected static final String VISTALINK_ROOT_ELEMENT = "VistaLink";

	/**
	 * Constructor for VistaLinkResponseFactoryImpl.
	 */
	public VistaLinkResponseFactoryImpl() {
		super();
	}

	/**
	 * Called by the managedConnection to parse the response String and return VistaLinkResponseVO implementation.
	 * 
	 * @see gov.va.med.vistalink.adapter.record.VistaLinkResponseFactory#handleResponse(java.lang.String,
	 *      gov.va.med.vistalink.adapter.record.VistaLinkRequestVO)
	 */
	public VistaLinkResponseVO handleResponse(String response, VistaLinkRequestVO requestVO)
			throws FoundationsException {

		try {
			return parseMessageHeader(response, requestVO);
		} catch (VistaLinkFaultException e) {
			// do not log these as this application level exception
			throw e;
		} catch (FoundationsException e) {

			if (logger.isEnabledFor(Level.ERROR)) {

				String errMsg = (new StringBuffer()).append("Exception occured parsing response.").append("\n\t")
						.append(ExceptionUtils.getFullStackTrace(e)).toString();

				logger.error(errMsg);
			}
			throw e;
		}
	}

	/**
	 * Parses message header and performs other common response parsing tasks. Can not be subclassed.
	 * <p>
	 * This method delegates more specific parsing step calls to other methods of this class.
	 * 
	 * @param rawXml
	 * @param requestVO
	 * @return VistaLinkResponseVO
	 * @throws FoundationsException
	 */
	private VistaLinkResponseVO parseMessageHeader(String rawXml, VistaLinkRequestVO requestVO)
			throws VistaLinkFaultException, FoundationsException {

		// has a fault been returned, allow subclasses to indicate their own
		// fault types
		boolean isFault = doesResponseIndicateFaultCommon(rawXml) || doesResponseIndicateFault(rawXml);

		VistaLinkResponseVO resp = null;
		Document doc = null;

		// allow subclasses to perform addional XML String filtering,
		// such as removing CDATA before parsing the XML String into XML
		// Document
		String filteredXml = filterResponseXmlString(rawXml, isFault);

		// parse XML String into the XML Document
		doc = XmlUtilities.getDocumentForXmlString(filteredXml);

		// Check if the root element name is correct
		if (!doc.getDocumentElement().getNodeName().equals(VISTALINK_ROOT_ELEMENT)) {
			throw new FoundationsException("Root element of response is not VistaLink.");
		}

		String version = ((Attr) (doc.getDocumentElement().getAttributes()).getNamedItem("version")).getValue();

		// Ensure compatibility with VL 1.5, 1.6 M servers. Don't communicate with VL 1.0 M servers.
		// TODO: will need to update if new version released post-1.6. BETTER MECHANISM needed for keeping track of
		// COMPATIBLE M-SIDE REMOTE VL VERSIONS?
		if ((!version.equals(VistaLinkManagedConnectionFactory.ADAPTER_VERSION)) && (!version.equals("1.5"))) {
			throw new FoundationsException((new StringBuffer()).append("The response version [").append(version)
					.append("] is incompatible with this version of the adapter [").append(
							VistaLinkManagedConnectionFactory.ADAPTER_VERSION).append("]").toString());
		}

		// Get messageType
		String messageType = ((Attr) (doc.getDocumentElement().getAttributes()).getNamedItem("messageType")).getValue();

		if (isFault) {
			// if fault, handle it
			handleFault(doc, messageType);
		} else {
			// if no fault, parse message body, create response object
			resp = parseMessageBody(rawXml, filteredXml, doc, messageType, requestVO);
		}

		return resp;
	}

	/**
	 * Private and can not be overrided.
	 * 
	 * @param rawXml
	 * @return boolean Returns true if response indicates common fault condition.
	 */
	private boolean doesResponseIndicateFaultCommon(String rawXml) {
		return rawXml.startsWith(ERROR_MSG_GEN);
	}

	/**
	 * Should be overriden by the child classes to discover additional fault indication.
	 * 
	 * @param rawXml
	 * @return boolean Returns true if response indicates specific fault condition.
	 */
	protected boolean doesResponseIndicateFault(String rawXml) {
		return false;
	}

	/**
	 * Allows child classes to implement their own response XML filtering before any other work is done on the response
	 * String (e.g., removing CDATA from the response XML.)
	 * 
	 * @param rawXml
	 * @return String
	 */
	protected String filterResponseXmlString(String rawXml, boolean isFault) {
		return rawXml;
	}

	/**
	 * Parses message body. Child classes need to implement this method to be able to create their specific response
	 * objects.
	 * 
	 * @param filteredXml
	 * @param doc
	 * @param messageType
	 * @param requestVO
	 * @return VistaLinkResponseVO
	 * @throws FoundationsException
	 */
	protected VistaLinkResponseVO parseMessageBody(String rawXml, String filteredXml, Document doc, String messageType,
			VistaLinkRequestVO requestVO) throws FoundationsException {

		return new VistaLinkResponseVOImpl(rawXml, filteredXml, doc, messageType);

	}

	/**
	 * <ol>
	 * <li>Initiates VLJ Fault handling.</li>
	 * <li>Parses Fault message and stores fault data in the VistaLinkFaultException.</li>
	 * <li>Calls handleAndDelegateSpecificFault to perform more specific fault handling tasks.</li>
	 * </ol>
	 * Handles generic VLJ faults.
	 * 
	 * @param xdoc
	 * @param messageType
	 * @throws VistaLinkFaultException
	 * @throws FoundationsException
	 */
	protected final void handleFault(Document xdoc, String messageType) throws VistaLinkFaultException,
			FoundationsException {

		String faultCode = "";
		String faultString = "";
		String faultActor = "";
		String errorCode = "";
		String errorType = "";
		String errorMessage = "";

		try {
			XPath xpath = XPathFactory.newInstance().newXPath();
			NodeList faultCodeNodeList = (NodeList) xpath.evaluate("VistaLink/Fault/FaultCode/text()", xdoc, XPathConstants.NODESET);
			Node faultCodeNode = (faultCodeNodeList.getLength() > 0) ? faultCodeNodeList.item(0) : null; 

			// JAXEN-based parsing, now replaced by J2SE built-in XPath
//			XPath xpath = new DOMXPath("VistaLink/Fault/FaultCode/text()");
//			Node faultCodeNode = (Node) xpath.selectSingleNode(xdoc);
			if (faultCodeNode != null) {
				if (faultCodeNode.getNodeType() == Node.TEXT_NODE) {
					faultCode = ((Text) faultCodeNode).getData();
				}
			}

			xpath = XPathFactory.newInstance().newXPath();
			NodeList faultStringNodeList = (NodeList) xpath.evaluate("VistaLink/Fault/FaultString/text()", xdoc, XPathConstants.NODESET);
			Node faultStringNode = (faultStringNodeList.getLength() > 0) ? faultStringNodeList.item(0) : null; 
			// JAXEN-based parsing, now replaced by J2SE built-in XPath
//			xpath = new DOMXPath("VistaLink/Fault/FaultString/text()");
//			Node faultStringNode = (Node) xpath.selectSingleNode(xdoc);
			if (faultStringNode != null) {
				if (faultStringNode.getNodeType() == Node.TEXT_NODE) {
					faultString = ((Text) faultStringNode).getData();
				}
			}

			xpath = XPathFactory.newInstance().newXPath();
			NodeList faultActorNodeList = (NodeList) xpath.evaluate("VistaLink/Fault/FaultActor/text()", xdoc, XPathConstants.NODESET);
			Node faultActorNode = (faultActorNodeList.getLength() > 0) ? faultActorNodeList.item(0) : null; 
			// JAXEN-based parsing, now replaced by J2SE built-in XPath
//			xpath = new DOMXPath("VistaLink/Fault/FaultActor/text()");
//			Node faultActorNode = (Node) xpath.selectSingleNode(xdoc);
			if (faultActorNode != null) {
				if (faultActorNode.getNodeType() == Node.TEXT_NODE) {
					faultActor = ((Text) faultActorNode).getData();
				}
			}

			xpath = XPathFactory.newInstance().newXPath();
			NodeList errorNodeList = (NodeList) xpath.evaluate("/VistaLink/Fault/Detail/Error/.", xdoc, XPathConstants.NODESET);
			Node errorNode = (errorNodeList.getLength() > 0) ? errorNodeList.item(0) : null; 
			// JAXEN-based parsing, now replaced by J2SE built-in XPath
//			xpath = new DOMXPath("/VistaLink/Fault/Detail/Error/.");
//			Node errorNode = (Node) xpath.selectSingleNode(xdoc);
			errorCode = ((Attr) (errorNode.getAttributes()).getNamedItem("code")).getValue();

			Attr errorTypeAttr = (Attr) errorNode.getAttributes().getNamedItem("type");
			if (errorTypeAttr != null) {
				errorType = errorTypeAttr.getValue();
			}

			xpath = XPathFactory.newInstance().newXPath();
			NodeList msgNodeList = (NodeList) xpath.evaluate("/VistaLink/Fault/Detail/Error/Message/text()", xdoc, XPathConstants.NODESET);
			Node msgNode = (msgNodeList.getLength() > 0) ? msgNodeList.item(0) : null; 
			// JAXEN-based parsing, now replaced by J2SE built-in XPath
//			xpath = new DOMXPath("/VistaLink/Fault/Detail/Error/Message/text()");
//			Node msgNode = (Node) xpath.selectSingleNode(xdoc);
			if (msgNode != null) {
				errorMessage = msgNode.getNodeValue();
			}

			// Create new VistaLinkFaultException using info we just collected.
			// VistaLinkFaultException creates exception representation message.
			VistaLinkFaultException faultException = new VistaLinkFaultException(errorCode, errorMessage, errorType,
					faultActor, faultCode, faultString);

			//
			// If fault parsing structure above is GENERIC
			// for all of the VistaLink - an assumption for now,
			// then we should only need to
			// perform additional call below to allow subclasses
			// to perform it's part of exception handling
			// and be able to return it's own VistaLinkFaultException subclass
			// implementation.
			//

			// Allow subclasses to provide their own fault exception
			// implementation
			VistaLinkFaultException specificFaultException = handleAndDelegateSpecificFault(xdoc, messageType,
					faultException);

			// we could just throw an exception in handleSpecificFault()
			// but it is easier to read the code this way
			throw specificFaultException;

		} catch (XPathExpressionException e) {
			throw new FoundationsException("Exception parsing XML.", e);
		}

	}

	/**
	 * Private method that analizes fault and returns more specific VLJ exception.
	 * <p>
	 * If more specific fault exception is not faund, delegates fault processing to the subclasses by calling protected
	 * handleSpecificFault() method that subclasses can override.
	 * 
	 * @param xdoc
	 * @param messageType
	 * @param faultException
	 * @return VistaLinkFaultException
	 * @throws VistaLinkFaultException
	 * @throws FoundationsException
	 */
	private VistaLinkFaultException handleAndDelegateSpecificFault(Document xdoc, String messageType,
			VistaLinkFaultException faultException) throws VistaLinkFaultException, FoundationsException {

		if ("181003".equals(faultException.getErrorCode())) {
			return new NoJobSlotsAvailableFaultException(faultException);
		} else if ("181004".endsWith(faultException.getErrorCode())) {
			return new LoginsDisabledFaultException(faultException);
		} else {
			// if non of the above, perform delegation so that
			// child classes can do their part of work and be able
			// to provide more specific faul exception
			VistaLinkFaultException returnFaultException = handleSpecificFault(xdoc, messageType, faultException);
			if (returnFaultException == null) {
				returnFaultException = faultException;
			}
			return returnFaultException;
		}
	}

	/**
	 * This method can be overriden by the subclasses to perform additional fault handling and return a subclass of
	 * VistaLinkFaultException.
	 * <p>
	 * Implementation in this class returns faultException that is passed into the class.
	 * <p>
	 * Overriden method can either return a:
	 * <ul>
	 * <li>More specific VistaLinkFaultException implementation.</li>
	 * <li>The same faultException that is passed into the method.</li>
	 * <li>null. Will have the same result as returning the same faultException that is passed into the method.</li>
	 * </ul>
	 * 
	 * @param xdoc
	 * @param messageType
	 * @param faultException
	 * @return VistaLinkFaultException
	 * @throws VistaLinkFaultException
	 * @throws FoundationsException
	 */
	protected VistaLinkFaultException handleSpecificFault(Document xdoc, String messageType,
			VistaLinkFaultException faultException) throws VistaLinkFaultException, FoundationsException {

		return null;
	}

}