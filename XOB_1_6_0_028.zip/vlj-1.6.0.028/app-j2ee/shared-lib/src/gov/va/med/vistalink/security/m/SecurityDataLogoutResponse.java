package gov.va.med.vistalink.security.m;

/**
 * Implements response-specific fields for an AV.Logout security message 
 * @see SecurityResponse
 * @see SecurityResponseFactory
 */
public final class SecurityDataLogoutResponse extends SecurityResponse {

	/**
	 * 
	 * @see gov.va.med.vistalink.security.m.SecuriytResponse#SecuriytResponse(int, String)
	 */
	SecurityDataLogoutResponse(SecurityResponse responseData) {
		super(responseData);
	}

}
