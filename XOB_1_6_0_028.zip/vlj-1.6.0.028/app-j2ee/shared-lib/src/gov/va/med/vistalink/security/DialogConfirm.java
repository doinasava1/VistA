package gov.va.med.vistalink.security;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.FocusTraversalPolicy;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.Timer;
import javax.swing.UIManager;
import javax.swing.border.Border;

/**
 * Swing Dialog to display an error, informational message, help, or post-sign-in text to user,
 * and collect their response (OK or CANCEL, depending on type of message).
 * @see VistaLoginModule
 * @see CallbackHandlerSwing
 */
public final class DialogConfirm extends JDialog {

	/**
	 * For error message confirmations (error icon; OK and CANCEL buttons)
	 * 
	 */
	public static final int MODE_ERROR_MESSAGE = 0;

	/**
	 * For "success" message confirmations (success icon; OK button)
	 */
	public static final int MODE_INFORMATION_MESSAGE = 1;

	/**
	 * For help message confirmations (information icon; OK button)
	 */
	public static final int MODE_HELP_MESSAGE = 2;

	/**
	 * return value if user pressed OK to close dialog
	 */
	public static final int OK_OPTION = 10;
	/**
	 * return value if user pressed CANCEL to close dialog
	 */
	public static final int CANCEL_OPTION = 11;
	/**
	 * return value if user timed out to close dialog
	 */
	public static final int TIMEOUT_OPTION = 12;

	private static final String OK_BUTTON_LABEL = "OK";
	private static final char OK_BUTTON_MNEMONIC = KeyEvent.VK_O;
	private static final String OK_BUTTON_TOOLTIP = "Sends OK confirmation";

	private static final String MESSAGE_AREA_TOOLTIP = "Message displayed by this dialog.";

	private static final String CANCEL_BUTTON_LABEL = "Cancel";
	private static final char CANCEL_BUTTON_MNEMONIC = KeyEvent.VK_C;
	private static final String CANCEL_BUTTON_TOOLTIP = "Sends cancel request";

	private static final String ERROR_LABEL = "Error:";
	private static final char ERROR_MNEMONIC = KeyEvent.VK_E;
	private static final String ERROR_LOGO = "images/error.gif";
	private static final String ERROR_LOGO_TOOLTIP = "Error logo";

	private static final String SUCCESS_LABEL = "Information:";
	private static final char SUCCESS_MNEMONIC = KeyEvent.VK_I;
	private static final String SUCCESS_LOGO = "images/yes1a.gif";
	private static final String SUCCESS_LOGO_TOOLTIP = "Informational logo";

	private static final String HELP_LABEL = "Help:";
	private static final char HELP_MNEMONIC = KeyEvent.VK_H;
	private static final String HELP_LOGO = "images/helpbook07.gif";
	private static final String HELP_LOGO_TOOLTIP = "Help logo";

	private String message;
	private int messageMode;
	private int returnVal;

	private Border focusBorder;
	private Border noFocusBorder;
	private JScrollPane messageScrollPane;
	private JButton okButton;
	private JButton cancelButton;
	private JLabel logoLabel;
	private JLabel messageTypeLabel;
	private JTextArea messageTextArea;

	/**
	 * Create a modal Swing dialog to present an error message to the user
	 * @param parent The parent window frame
	 * @param message The message to display
	 * @param windowTitle The title for the dialog window
	 * @param messageMode mode (determines what logo to display and whether to display a Cancel button)
	 * @param timeoutInSeconds the timeout value for the dialog
	 * @return what caused the dialog to close -- one of the OK_OPTION, CANCEL_OPTION or TIMEOUT_OPTION int values
	 *         provided by this class.
	 */
	public static int showDialogConfirm(
		Frame parent,
		String message,
		String windowTitle,
		int messageMode,
			int timeoutInSeconds) {

		String newWindowTitle = null;
		if ((parent != null) && (!"".equals(parent.getTitle()))) {
			newWindowTitle = parent.getTitle() + ": " + windowTitle;
		} else {
			newWindowTitle = DialogLogon.DEFAULT_TITLE + ": " + windowTitle;
		}

		DialogConfirm dialog = new DialogConfirm(parent, message, newWindowTitle, messageMode, timeoutInSeconds);
		dialog.setVisible(true);
		return dialog.returnVal;
	}

	private DialogConfirm(Frame parent, String message, String windowTitle, int messageMode, int timeoutInSeconds) {

		super(parent, windowTitle, true);

		this.message = message;
		this.messageMode = messageMode;

		createContentPane();
		pack();
		VistaLoginSwingUtilities.goldenMeanCenterDialog(parent, this);

		this.setFocusTraversalPolicy(new DialogConfirmFocusTraversalPolicy());
		this.getAccessibleContext().setAccessibleDescription(this.messageTextArea.getText());
		// set up event for timeout
		int timeout = -1;
		timeout = 1000 * (timeoutInSeconds);
		ActionListener taskPerformer = new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				doTimeout();
			}
		};
		new Timer(timeout, taskPerformer).start();
	}

	private void createContentPane() {

		JPanel logoPanel = createLogoPanel();
		createTextAreaComponents();
		JPanel buttonPanel = createButtonPanel();

		// set the accessible name of the OK button based on the dialog contents
		StringBuffer sb = new StringBuffer();
		sb.append(okButton.getText());
		sb.append(" button: ");
		sb.append(messageTypeLabel.getText());
		sb.append(messageTextArea.getText());
		okButton.getAccessibleContext().setAccessibleName(sb.toString());

		messageTypeLabel.setLabelFor(messageTextArea);
		messageTypeLabel.addFocusListener(new FocusListener() {
			public void focusGained(FocusEvent e) {
				messageTextArea.requestFocusInWindow();
			}

			public void focusLost(FocusEvent e) {
			}
		});

		Container contentPane = getContentPane();
		BorderLayout contentLayout = new BorderLayout();
		contentLayout.setHgap(5);
		contentLayout.setVgap(5);
		contentPane.setLayout(contentLayout);
		contentPane.add(logoPanel, BorderLayout.NORTH);
		contentPane.add(messageScrollPane, BorderLayout.CENTER);
		contentPane.add(buttonPanel, BorderLayout.SOUTH);
	}

	private void createTextAreaComponents() {

		// get border from current LaF
		Border defaultBorder = UIManager.getBorder("TextField.border");
		focusBorder =
			BorderFactory.createCompoundBorder(UIManager.getBorder("List.focusCellHighlightBorder"), defaultBorder);
		noFocusBorder =
			BorderFactory.createCompoundBorder(
				BorderFactory.createLineBorder(UIManager.getColor("control"), 1),
				defaultBorder);

		messageTextArea = new JTextArea(this.message);
		messageTextArea.setEditable(false);
		messageTextArea.setFocusable(true);
		messageTextArea.setCaretPosition(0);
		messageTextArea.setMargin(new Insets(5, 5, 5, 5));
		messageTextArea.setToolTipText(MESSAGE_AREA_TOOLTIP);
		messageTextArea.getAccessibleContext().setAccessibleName(MESSAGE_AREA_TOOLTIP);
		messageTextArea.addFocusListener(new FocusListener() {
			public void focusGained(FocusEvent e) {
				messageScrollPane.setBorder(focusBorder);
			}

			public void focusLost(FocusEvent e) {
				messageScrollPane.setBorder(noFocusBorder);
			}
		});

		// make it so message window isn't tiny
		if (messageTextArea.getLineCount() < 3) {
			messageTextArea.append("\n\n");
		}

		// create the scrollpane using the text
		messageScrollPane = new JScrollPane(messageTextArea);
		messageScrollPane.setBorder(noFocusBorder);
	}

	private JPanel createLogoPanel() {

		if (this.messageMode == MODE_ERROR_MESSAGE) {
			logoLabel = new JLabel(new ImageIcon(getClass().getResource(ERROR_LOGO)));
			logoLabel.setToolTipText(ERROR_LOGO_TOOLTIP);
			messageTypeLabel = new JLabel(ERROR_LABEL);
			messageTypeLabel.setDisplayedMnemonic(ERROR_MNEMONIC);
		} else if (this.messageMode == MODE_INFORMATION_MESSAGE) {
			logoLabel = new JLabel(new ImageIcon(getClass().getResource(SUCCESS_LOGO)));
			logoLabel.setToolTipText(SUCCESS_LOGO_TOOLTIP);
			messageTypeLabel = new JLabel(SUCCESS_LABEL);
			messageTypeLabel.setDisplayedMnemonic(SUCCESS_MNEMONIC);
		} else if (this.messageMode == MODE_HELP_MESSAGE) {
			logoLabel = new JLabel(new ImageIcon(getClass().getResource(HELP_LOGO)));
			logoLabel.setToolTipText(HELP_LOGO_TOOLTIP);
			messageTypeLabel = new JLabel(HELP_LABEL);
			messageTypeLabel.setDisplayedMnemonic(HELP_MNEMONIC);
		}
		logoLabel.setFocusable(false);

		messageTypeLabel.setFont(messageTypeLabel.getFont().deriveFont(Font.BOLD));

		JPanel logoPanel = new JPanel();
		FlowLayout logoLayout = new FlowLayout();
		logoLayout.setAlignment(FlowLayout.LEFT);
		logoPanel.setLayout(logoLayout);
		logoPanel.add(logoLabel);
		logoPanel.add(messageTypeLabel);

		return logoPanel;
	}

	private JPanel createButtonPanel() {
		JPanel p = new JPanel();
		FlowLayout myFlowLayout = new FlowLayout();
		myFlowLayout.setAlignment(FlowLayout.CENTER);
		myFlowLayout.setHgap(5);
		myFlowLayout.setVgap(5);
		p.setLayout(myFlowLayout);

		createOKButton();
		p.add(okButton);

		// if it's an error message, they can CANCEL. If information, can't cancel.
		if (this.messageMode == MODE_ERROR_MESSAGE) {
			createCancelButton();
			p.add(Box.createRigidArea(new Dimension(10, 0)));
			p.add(cancelButton);
		}
		return p;
	}

	private void createOKButton() {
		okButton = new JButton(OK_BUTTON_LABEL);
		okButton.setMnemonic(OK_BUTTON_MNEMONIC);
		okButton.setToolTipText(OK_BUTTON_TOOLTIP);
		okButton.setFont(okButton.getFont().deriveFont(Font.BOLD));
		this.getRootPane().setDefaultButton(okButton);
		okButton.setAlignmentX(RIGHT_ALIGNMENT);

		// handle events for button presses
		okButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				okActionPerformed();
			}
		});
	}

	private void createCancelButton() {
		cancelButton = new JButton(CANCEL_BUTTON_LABEL);
		cancelButton.setMnemonic(CANCEL_BUTTON_MNEMONIC);
		cancelButton.setToolTipText(CANCEL_BUTTON_TOOLTIP);
		cancelButton.setFont(cancelButton.getFont().deriveFont(Font.BOLD));
		cancelButton.setAlignmentX(RIGHT_ALIGNMENT);

		// handle events for button presses
		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cancelActionPerformed();
			}
		});
	}

	private void okActionPerformed() {
		this.returnVal = OK_OPTION;
		this.setVisible(false);
		this.dispose();

	}

	private void cancelActionPerformed() {
		this.returnVal = CANCEL_OPTION;
		this.setVisible(false);
		this.dispose();
	}

	private void doTimeout() {
		this.returnVal = TIMEOUT_OPTION;
		this.setVisible(false);
		this.dispose();
	}

	/**
	 * Provides a focus traversal policy for this dialog
	 */
	public class DialogConfirmFocusTraversalPolicy extends FocusTraversalPolicy {

		/**
		 * get the next component in the focus traversal
		 * @param focusCycleRoot the root of the focus cycle
		 * @param aComponent currently focused component
		 * @return returns the next component in the (forward) cycle
		 */
		public Component getComponentAfter(Container focusCycleRoot, Component aComponent) {

			if (aComponent.equals(messageTextArea)) {
				return okButton;
			} else if (aComponent.equals(okButton)) {
				if (cancelButton != null) {
					return cancelButton;
				} else {
					return messageTextArea;
				}
			} else if (aComponent.equals(cancelButton)) {
				return messageTextArea;
			}
			return okButton;
		}

		/**
		 * get the previous (reverse direction) component in the focus traversal cycle
		 * @param focusCycleRoot the root of the focus cycle
		 * @param aComponent currently focused component
		 * @return returns the next component in the (reverse) cycle
		 */
		public Component getComponentBefore(Container focusCycleRoot, Component aComponent) {

			if (aComponent.equals(cancelButton)) {
				return okButton;
			} else if (aComponent.equals(okButton)) {
				return messageTextArea;
			} else if (aComponent.equals(messageTextArea)) {
				if (cancelButton != null) {
					return cancelButton;
				} else {
					return okButton;
				}
			}
			return okButton;
		}

		/**
		 * gets the default component to focus on
		 * @param focusCycleRoot the root of the focus cycle
		 * @return the default component in the focus cycle
		 */
		public Component getDefaultComponent(Container focusCycleRoot) {
			return okButton;
		}

		/**
		 * gets the last component in the focus cycle
		 * @param focusCycleRoot the root of the focus cycle
		 * @return the last component in the focus cycle
		 */
		public Component getLastComponent(Container focusCycleRoot) {
			return cancelButton;
		}

		/**
		 * gets the first component in the focus cycle
		 * @param focusCycleRoot the root of the focus cycle
		 * @return the first component in the focus cycle
		 */
		public Component getFirstComponent(Container focusCycleRoot) {
			return okButton;
		}
	}

}