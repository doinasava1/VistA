package gov.va.med.vistalink.management;

import java.lang.ref.WeakReference;
import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import gov.va.med.environment.Environment;
import gov.va.med.environment.ServerType;
import gov.va.med.vistalink.adapter.cci.VistaLinkConnectionFactory;
import gov.va.med.vistalink.adapter.spi.VistaLinkSystemInfoVO;
import gov.va.med.vistalink.institution.InstitutionMapping;
import gov.va.med.vistalink.institution.InstitutionMappingFactory;
import gov.va.med.vistalink.institution.InstitutionMappingVO;

import javax.management.MBeanServer;
import javax.management.ObjectName;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.log4j.Logger;

/**
 * MBean implementation for the per-connection-factory VistALink management bean. Thread-safe.
 * 
 */
public class VistaLinkConnector implements VistaLinkConnectorMBean {

	private static final Logger logger = Logger.getLogger(VistaLinkConnector.class);
	
	// WEBLOGIC-specific MBean attributes
	private static final String WEBLOGIC_STATE_ATTR = "State";
	private static final String WEBLOGIC_EISTYPE_ATTR = "ConnectorEisType";
	private static final String WEBLOGIC_PARENT_ATTR = "Parent";
	private static final String WEBLOGIC_APPNAME_ATTR = "AppDeploymentMBean";
	private static final String WEBLOGIC_APPNAME_PROP = "Name";
	
	// use weak ref to hold CF just in case at some point container releases it after state change of some kind
	private WeakReference cfWr;
	private String jndiNameActual;
	private MBeanServer localMBeanServer;
	private ObjectName containerMBeanName;

	/**
	 * 
	 * @param jndiName
	 * @param containerMBeanName
	 * @param localMBeanServer
	 */
	public VistaLinkConnector(String jndiName, ObjectName containerMBeanName, MBeanServer localMBeanServer) {

		// sets in constructor ok for thread safety
		this.jndiNameActual = jndiName;
		this.containerMBeanName = containerMBeanName;
		this.localMBeanServer = localMBeanServer;

		// initialize weak ref to associated CF bound object in JNDI
		VistaLinkConnectionFactory cf = getCfWr();
		logger.debug("Tried to get CF reference in constructor, got: " + ((cf == null) ? "null" : cf.toString()));
	}

	/**
	 * Return the MBean type for this MBean
	 * 
	 * @return
	 */
	public static String getMBeanType() {
		return "VistaLinkConnector";
	}

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.management.VistaLinkConnectorMBean#getContainerMBeanName()
	 */
	public synchronized ObjectName getContainerMBeanName() {
		// synchronized instance variable access for thread safety
		return containerMBeanName;
	}

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.management.VistaLinkConnectorMBean#getCfgIpAddress()
	 */
	public String getCfgIpAddress() {
		VistaLinkConnectionFactory cf = getCfWr();
		if (cf != null) {
			return cf.getCfgIpAddress();
		} else {
			return null;
		}
	}

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.management.VistaLinkConnectorMBean#getCfgPort()
	 */
	public int getCfgPort() {
		VistaLinkConnectionFactory cf = getCfWr();
		if (cf != null) {
			return cf.getCfgPort();
		} else {
			return -1;
		}
	}

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.management.VistaLinkConnectorMBean#getCfgTimeout()
	 */
	public long getCfgTimeout() {
		VistaLinkConnectionFactory cf = getCfWr();
		if (cf != null) {
			return cf.getCfgTimeout();
		} else {
			return -1;
		}
	}

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.management.VistaLinkConnectorMBean#isCfgTimeoutAlwaysUseDefaultAsMin()
	 */
	public boolean isCfgTimeoutAlwaysUseDefaultAsMin() {
		VistaLinkConnectionFactory cf = getCfWr();
		if (cf != null) {
			return cf.isCfgTimeoutAlwaysUseDefaultAsMin();
		} else {
			return false;
		}
	}

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.management.VistaLinkConnectorMBean#getDistinguishedIdentifier()
	 */
	public long getDistinguishedIdentifier() {
		VistaLinkConnectionFactory cf = getCfWr();
		if (cf != null) {
			return cf.getDistinguishedIdentifier();
		} else {
			return -1L;
		}
	}

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.management.VistaLinkConnectorMBean#getHlthConnectionAuthFailureCount()
	 */
	public long getHlthConnectionAuthFailureCount() {
		VistaLinkConnectionFactory cf = getCfWr();
		if (cf != null) {
			return cf.getHlthConnectionAuthFailureCount();
		} else {
			return 0;
		}
	}

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.management.VistaLinkConnectorMBean#getHlthConnectionFailureCount()
	 */
	public long getHlthConnectionFailureCount() {
		VistaLinkConnectionFactory cf = getCfWr();
		if (cf != null) {
			return cf.getHlthConnectionFailureCount();
		} else {
			return 0;
		}
	}

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.management.VistaLinkConnectorMBean#getHlthDivisionMismatchCount()
	 */
	public long getHlthDivisionMismatchCount() {
		VistaLinkConnectionFactory cf = getCfWr();
		if (cf != null) {
			return cf.getHlthDivisionMismatchCount();
		} else {
			return 0;
		}
	}

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.management.VistaLinkConnectorMBean#getHlthIdentityFailureCount()
	 */
	public long getHlthIdentityFailureCount() {
		VistaLinkConnectionFactory cf = getCfWr();
		if (cf != null) {
			return cf.getHlthIdentityFailureCount();
		} else {
			return 0;
		}
	}

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.management.VistaLinkConnectorMBean#getHlthProductionMismatchCount()
	 */
	public long getHlthProductionMismatchCount() {
		VistaLinkConnectionFactory cf = getCfWr();
		if (cf != null) {
			return cf.getHlthProductionMismatchCount();
		} else {
			return 0;
		}
	}

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.management.VistaLinkConnectorMBean#getPerfCreateConnectionHandleAvgMillis()
	 */
	public double getPerfCreateConnectionHandleAvgMillis() {
		VistaLinkConnectionFactory cf = getCfWr();
		if (cf != null) {
			return cf.getPerfCreateConnectionHandleAvgMillis();
		} else {
			return 0;
		}
	}

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.management.VistaLinkConnectorMBean#getPerfMatchManagedConnectionAvgMillis()
	 */
	public double getPerfMatchManagedConnectionAvgMillis() {
		VistaLinkConnectionFactory cf = getCfWr();
		if (cf != null) {
			return cf.getPerfMatchManagedConnectionAvgMillis();
		} else {
			return 0;
		}
	}

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.management.VistaLinkConnectorMBean#getQueryMSystemMap()
	 */
	public Map getQueryMSystemMap() {
		VistaLinkConnectionFactory cf = getCfWr();
		if (cf != null) {
			return cf.queryMSystem().toMap();
		} else {
			return null;
		}
	}

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.management.VistaLinkConnectorMBean#getQueryMSystemReport()
	 */
	public String[] getQueryMSystemReport() {

		VistaLinkConnectionFactory cf = getCfWr();
		if (cf != null) {

			VistaLinkSystemInfoVO vo = cf.queryMSystem();
			StringBuffer sb = new StringBuffer();

			String errorMessage = vo.getErrorMessage();
			if ((errorMessage != null) && errorMessage.length() > 0) {

				sb.append("Remote M Error Message: " + vo.getErrorMessage());
				sb.append('\n');

			} else {

				sb.append("Remote VL Version: ").append(vo.getVistalinkVersion()).append('\n');
				sb.append("Remote VL Build: ").append(vo.getVistalinkBuild()).append('\n');
				sb.append("Remote VL Listener Timeout: ").append(vo.getAppServerTimeout()).append('\n');
				sb.append("Remote VL Reauthenticated Session Timeout: ").append(vo.getReAuthSessionTimeout()).append(
						'\n');
				sb.append("Remote VL Connector Proxy Username: ").append(vo.getCpName()).append('\n');
				sb.append("Remote UCI: ").append(vo.getUci()).append('\n');
				sb.append("Remote VOL: ").append(vo.getVol()).append('\n');
				sb.append("Remote BOX-VOLUME: ").append(vo.getBoxVolume()).append('\n');
				sb.append("Remote M Version: ").append(vo.getMumpsVersion()).append('\n');
				sb.append("Remote Operating System: ").append(vo.getOperatingSystem()).append('\n');
				sb.append("Remote Domain: ").append(vo.getDomainName()).append('\n');
				sb.append("Remote is Production?: ").append(vo.getVistaProduction()).append('\n');
				sb.append("Remote Kernel Default Institution: ").append(vo.getDefaultInstitution()).append('\n');
				sb.append("Introductory Text: ").append('\n');
				String[] introText = vo.getIntroText().split("<BR>");
				for (int i = 0; i < introText.length; i++) {
					sb.append(introText[i]).append('\n');
				}
			}
			return sb.toString().split("\n");
		} else {
			return null;
		}
	}

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.management.VistaLinkConnectorMBean#getQueryMappedInstitutions()
	 */
	public String[] getQueryMappedInstitutions() {
		String[] stationNumbers = null;

		// get Institution Mappings
		InstitutionMapping me = (InstitutionMapping) InstitutionMappingFactory.getInstitutionMapping();
		Map institutionMap = me.getMappingClone();
		// iterate through all stations, find any matching jndi names. We use the deployed JNDI name (rather
		// than the config JNDI name) to guarantee that we reflect how the mapping is actually working for applications
		// hitting this connector.
		TreeSet matchingStations = new TreeSet();
		Set keys = institutionMap.keySet();
		for (Iterator iter = keys.iterator(); iter.hasNext();) {
			String stationNumber = (String) iter.next();
			InstitutionMappingVO imVO = (InstitutionMappingVO) institutionMap.get(stationNumber);
			String mappingJndiName = imVO.getJndiName();
			if (mappingJndiName.equals(this.getJndiNameActual())) {
				matchingStations.add(stationNumber);
			}
		}
		// store any matched institutions
		if (matchingStations.size() > 0) {
			stationNumbers = new String[matchingStations.size()];
			int i = 0;
			for (Iterator iter = matchingStations.iterator(); iter.hasNext();) {
				stationNumbers[i] = (String) iter.next();
				i++;
			}
		}
		return stationNumbers;
	}

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.management.VistaLinkConnectorMBean#getEisType()
	 */
	public String getEisType() throws RemoteException {
		try {
			return (String) getLocalMBeanServer().getAttribute(getContainerMBeanName(), WEBLOGIC_EISTYPE_ATTR);
		} catch (Exception e) {
			logger.error("Failure retrieving EisType: ", e);
			throw new RemoteException(e.getClass().getName() + ": " + e.getMessage());
		}
	}

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.management.VistaLinkConnectorMBean#getJndiNameActual()
	 */
	public synchronized final String getJndiNameActual() {
		// synchronized instance variable access for thread safety
		return this.jndiNameActual;
	}

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.management.VistaLinkConnectorMBean#getJndiNameCustomProp()
	 */
	public String getJndiNameCustomProp() {
		VistaLinkConnectionFactory cf = getCfWr();
		if (cf != null) {
			return cf.getConnectorJndiName();
		} else {
			return null;
		}
	}

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.management.VistaLinkConnectorMBean#getDeploymentState()
	 */
	public String getDeploymentState() throws RemoteException {
		try {
			return (String) getLocalMBeanServer().getAttribute(getContainerMBeanName(), WEBLOGIC_STATE_ATTR);
		} catch (Exception e) {
			logger.error("Failure retrieving deployment state: ", e);
			throw new RemoteException(e.getClass().getName() + ": " + e.getMessage());
		}
	}

	/*
	 * (non-Javadoc)
	 * @see gov.va.med.vistalink.management.VistaLinkConnectorMBean#getVendorSpecificProperties()
	 */
	public Map getVendorSpecificProperties() throws RemoteException {
		HashMap returnVal = new HashMap();
		if (ServerType.WEBLOGIC.equals(Environment.getServerType())) {
			try {
				// ConnectorComponentRuntime MBEAN is WebLogic-specific
				ObjectName connectorComponentRuntimeOName = (ObjectName) getLocalMBeanServer().getAttribute(
						getContainerMBeanName(), WEBLOGIC_PARENT_ATTR);
				ObjectName appDeploymentMBeanOName = (ObjectName) getLocalMBeanServer().getAttribute(
						connectorComponentRuntimeOName, WEBLOGIC_APPNAME_ATTR);
				returnVal.put("WebLogic Application Name", appDeploymentMBeanOName.getKeyProperty(WEBLOGIC_APPNAME_PROP));
			} catch (Exception e) {
				logger.error("Failure retrieving WebLogic application name: ", e);
				throw new RemoteException(e.getClass().getName() + ": " + e.getMessage());
			}
		}
		return returnVal;
	}

	/**
	 * thread-safe access to connection factory weak reference. Attempts to populate the mbean's CF weak reference in
	 * case it is null (e.g., the associated resource adapter is newly deployed or updated, has not been started and
	 * therefore does not have a CF constructed yet.)
	 * @return
	 */
	private synchronized VistaLinkConnectionFactory getCfWr() {

		// TODO -- if deployment state is other than running, null out the CF reference delibrately?
		// this would prevent connections from being made when the connector is not "running"
		// e.g. after the connector has been "stopped" (even though WLS keeps the ref and
		// re-uses it if the connector is restarted rather than creating a new CF (as long as
		// it's only stopped, not undeployed).

		VistaLinkConnectionFactory returnVal = null;

		// check current weak ref first
		if (cfWr != null) {
			returnVal = (VistaLinkConnectionFactory) cfWr.get();
		}
		
		// try to get from JNDI if weak ref is null, or if current weak reference is holding null
		if (returnVal == null) {
			returnVal = getCF(this.getJndiNameActual());
			logger.debug("Tried to get CF reference for MBean, got: " + ((returnVal == null) ? "null" : returnVal.toString()));
			// update weak reference
			if (returnVal != null) {
				this.cfWr = new WeakReference(returnVal);
			}
		}
		return returnVal;
	}

	/**
	 * Helper method to retrieve connection factory based on a jndi name (e.g., just the same as if an application was
	 * doing it).
	 * 
	 * @param cfJndiName Name to use to retrieve connection factory.
	 * @return Connection factory, based on live jndi lookup.
	 */
	private VistaLinkConnectionFactory getCF(String cfJndiName) {

		VistaLinkConnectionFactory cf = null;
		try {
			InitialContext ctx = new InitialContext();
			cf = (VistaLinkConnectionFactory) ctx.lookup(cfJndiName);
		} catch (NamingException e) {
			// swallow
		}
		return cf;
	}

	/**
	 * synchronized instance variable access for thread safety
	 * @return
	 */
	private synchronized MBeanServer getLocalMBeanServer() {
		return localMBeanServer;
	}
}
