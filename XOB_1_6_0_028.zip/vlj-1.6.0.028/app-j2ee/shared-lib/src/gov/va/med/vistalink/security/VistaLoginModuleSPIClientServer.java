package gov.va.med.vistalink.security;

import java.io.IOException;
import java.net.ConnectException;
import java.util.Map;
import java.util.StringTokenizer;

import javax.resource.ResourceException;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;

import gov.va.med.crypto.VistaKernelHashCountLimitExceededException;
import gov.va.med.exception.ExceptionUtils;
import gov.va.med.exception.FoundationsException;
import gov.va.med.vistalink.adapter.cci.VistaLinkConnection;
import gov.va.med.vistalink.adapter.cci.VistaLinkConnectionFactory;
import gov.va.med.vistalink.adapter.cci.VistaLinkResourceException;
import gov.va.med.vistalink.adapter.record.LoginsDisabledFaultException;
import gov.va.med.vistalink.adapter.record.NoJobSlotsAvailableFaultException;
import gov.va.med.vistalink.adapter.record.VistaLinkFaultException;
import gov.va.med.vistalink.rpc.RpcRequest;
import gov.va.med.vistalink.rpc.RpcRequestFactory;
import gov.va.med.vistalink.rpc.RpcResponse;
import gov.va.med.vistalink.security.m.KernelSecurityHandshake;
import gov.va.med.vistalink.security.m.SecurityDataLogonResponse;
import gov.va.med.vistalink.security.m.SecurityDataLogoutResponse;
import gov.va.med.vistalink.security.m.SecurityDataSetupAndIntroTextResponse;
import gov.va.med.vistalink.security.m.SecurityFaultException;
import gov.va.med.vistalink.security.m.SecurityIPLockedFaultException;
import gov.va.med.vistalink.security.m.SecurityResponse;
import gov.va.med.vistalink.security.m.SecurityResponseFactory;
import gov.va.med.vistalink.security.m.SecurityTooManyInvalidLoginAttemptsFaultException;
import gov.va.med.vistalink.security.m.SecurityVO;
import gov.va.med.vistalink.security.m.SecurityVOChangeVc;
import gov.va.med.vistalink.security.m.SecurityVOLogon;
import gov.va.med.vistalink.security.m.SecurityVOSelectDivision;
import gov.va.med.vistalink.security.m.SecurityVOUserDemographics;
import gov.va.med.vistalink.security.m.SecurityVOSetupAndIntroText;

/**
 * A service provider that implements back-end services for Kernel/M-based logins. This service provider is for
 * client-server mode, where the client is a java rich client, and the server is an M server.
 * 
 * @see VistaLoginModuleSPI
 * @see VistaLoginModule
 */
class VistaLoginModuleSPIClientServer implements VistaLoginModuleSPI {

	private VistaLinkConnectionFactory myVCF;

	private VistaLinkConnection myConnection;

	private SecurityResponseFactory mySecurityResponseFactory;

	// Initialize Logger instance to be used by this class
	private static final Logger logger = Logger.getLogger(VistaLoginModuleSPIClientServer.class);

	/**
	 * Initializes a connection factory and connection, based on JAAS options.
	 * 
	 * @see gov.va.med.vistalink.security.VistaLoginModuleSPI#Initialize(gov.va.med.vistalink.adapter.cci.VistaLinkConnection,
	 *      java.lang.String, java.lang.Integer)
	 */
	public void initialize(Map jaasOptions, Map jaasSharedState) throws VistaLoginModuleException {

		myConnection = null;
		String serverAddress = "";
		int serverPort = -1;
		String exceptionMessage = "Could not create connection. ";

		// get the server IP and port from the JAAS setup
		try {
			serverAddress = (String) jaasOptions.get(VistaLoginModule.SERVER_ADDRESS_KEY);
			serverPort = Integer.parseInt((String) jaasOptions.get(VistaLoginModule.SERVER_PORT_KEY));
		} catch (NumberFormatException e) {

			// try backwards-compatible v1 keys
			try {

				serverAddress = (String) jaasOptions.get(VistaLoginModule.SERVER_ADDRESS_KEY_V1);
				serverPort = Integer.parseInt((String) jaasOptions.get(VistaLoginModule.SERVER_PORT_KEY_V1));

			} catch (NumberFormatException e1) {

				// swallow "v1.0" e1 exception, send up original exception for v15 key failure
				String errMsg = "Error converting port string to integer from the login configuration; port string was '"
						+ ((String) jaasOptions.get(VistaLoginModule.SERVER_PORT_KEY));
				logger.error(errMsg, e);
				throw new VistaLoginModuleException(errMsg, e);
			}
		}

		try {

			// get connection factory
			myVCF = VistaLinkConnectionFactory.getVistaLinkConnectionFactory(serverAddress, Integer.valueOf(serverPort));
			logger.debug("Ggetting J2SE connection.");
			myConnection = (VistaLinkConnection) myVCF.getConnection();
			logger.debug("VistaLoginModuleSPIClientServer's connection: " + myConnection);
			mySecurityResponseFactory = new SecurityResponseFactory();

		} catch (VistaLinkResourceException e) {

			logoutConnectionBeforeLoginComplete();
			if (ExceptionUtils.getNestedExceptionByClass(e, NoJobSlotsAvailableFaultException.class) != null) {
				throw new VistaLoginModuleNoJobSlotsAvailableException(exceptionMessage, e);
			} else if (ExceptionUtils.getNestedExceptionByClass(e, LoginsDisabledFaultException.class) != null) {
				throw new VistaLoginModuleLoginsDisabledException(exceptionMessage, e);
			} else if (ExceptionUtils.getNestedExceptionByClass(e, ConnectException.class) != null) {
				throw new VistaLoginModuleNoPathToListenerException(exceptionMessage, e);
			}
			throw new VistaLoginModuleException(exceptionMessage, e);

		} catch (ResourceException e) {

			logoutConnectionBeforeLoginComplete();
			logger.error(exceptionMessage, e);
			throw new VistaLoginModuleException(exceptionMessage, e);
		}

	}

	/**
	 * Makes client/server call to do setup and return introductory text.
	 * 
	 * @see gov.va.med.vistalink.security.VistaLoginModuleSPI#getSetupAndIntroTextInfo()
	 */
	public Object getSetupAndIntroTextInfo() throws VistaLoginModuleException {
		String exceptionMessage = "Error doing M setup/introduction text retrieval: ";
		try {
			SecurityResponse response = KernelSecurityHandshake.doSetupAndGetIntroText(myConnection,
					mySecurityResponseFactory);
			Object returnVal;
			if (response instanceof SecurityDataSetupAndIntroTextResponse) {
				returnVal = new SecurityVOSetupAndIntroText((SecurityDataSetupAndIntroTextResponse) response);
				// set the port here... not currently used anywhere though.
				((SecurityVOSetupAndIntroText) returnVal).setPort(myConnection.getConnectionInfo().getPort());
			} else if (response instanceof SecurityDataLogonResponse) {
				returnVal = ((SecurityDataLogonResponse) response).getSecurityVOLogon();
			} else {
				throw new VistaLoginModuleException("unexpected response type to setup/intro text request: '"
						+ response.getClass().getName() + "'.");

			}
			return returnVal;

		} catch (SecurityFaultException e) {
			// logged lower down
			logoutConnectionBeforeLoginComplete();
			String errMsg = "Security fault occured on the M system.";
			throw new VistaLoginModuleException(exceptionMessage + errMsg, e);
		} catch (VistaLinkFaultException e) {
			// logged lower down
			logoutConnectionBeforeLoginComplete();
			throw new VistaLoginModuleException(exceptionMessage, e);
		} catch (FoundationsException e) {
			// connector code already logged
			logoutConnectionBeforeLoginComplete();
			throw new VistaLoginModuleException(exceptionMessage, e);
		} catch (ParserConfigurationException e) {
			logoutConnectionBeforeLoginComplete();
			logger.error(exceptionMessage, e);
			throw new VistaLoginModuleException(exceptionMessage, e);
		}
	}

	/**
	 * Makes a client/server call to do a login.
	 * 
	 * @see gov.va.med.vistalink.security.VistaLoginModuleSPI#doLogon()
	 */
	public SecurityVOLogon doKernelLogon(String kernelCcowLogonToken) throws VistaLoginModuleException {

		return this.doKernelLogonInternal(null, null, kernelCcowLogonToken, false);
	}

	/**
	 * Makes a client/server call to do a login.
	 * 
	 * @see gov.va.med.vistalink.security.VistaLoginModuleSPI#doLogon()
	 */
	public SecurityVOLogon doKernelLogon(String accessCode, String verifyCode, boolean requestCvc)
			throws VistaLoginModuleException {

		return this.doKernelLogonInternal(accessCode, verifyCode, null, requestCvc);

	}

	private SecurityVOLogon doKernelLogonInternal(String accessCode, String verifyCode, String kernelCcowLogonToken,
			boolean requestCvc) throws VistaLoginModuleException {
		String exceptionMessage = "Error during login: ";
		try {
			if (accessCode == null) {
				// if access code null, must be a CCOW login
				return (KernelSecurityHandshake
						.doAVLogon(myConnection, mySecurityResponseFactory, kernelCcowLogonToken)).getSecurityVOLogon();
			} else {
				// do a regular login with a/v codes
				return (KernelSecurityHandshake.doAVLogon(myConnection, mySecurityResponseFactory, accessCode,
						verifyCode, requestCvc)).getSecurityVOLogon();
			}
		} catch (VistaKernelHashCountLimitExceededException e) {

			logoutConnectionBeforeLoginComplete();
			logger.error(exceptionMessage, e);
			throw new VistaLoginModuleException(exceptionMessage, e);

		} catch (SecurityTooManyInvalidLoginAttemptsFaultException e) {

			// logged by a lower level already
			logoutConnectionBeforeLoginComplete();
			String errMsg = "Login failed due to too many invalid login attempts.";
			throw new VistaLoginModuleTooManyInvalidAttemptsException(exceptionMessage + errMsg);

		} catch (SecurityIPLockedFaultException e) {

			// logged by a lower level already
			logoutConnectionBeforeLoginComplete();
			String errMsg = "Login failed and IP locked due to too many invalid login attempts.";
			throw new VistaLoginModuleIPLockedException(exceptionMessage + errMsg);

		} catch (SecurityFaultException e) {

			// logged by a lower level already
			logoutConnectionBeforeLoginComplete();
			String errMsg = "Security fault occured on the M system.";
			throw new VistaLoginModuleException(exceptionMessage + errMsg, e);

		} catch (VistaLinkFaultException e) {

			// logged by a lower level already
			logoutConnectionBeforeLoginComplete();
			throw new VistaLoginModuleException(exceptionMessage, e);

		} catch (FoundationsException e) {

			// connector code already logged
			logoutConnectionBeforeLoginComplete();
			throw new VistaLoginModuleException(exceptionMessage, e);

		} catch (ParserConfigurationException e) {
			logoutConnectionBeforeLoginComplete();
			logger.error(exceptionMessage, e);
			throw new VistaLoginModuleException(exceptionMessage, e);
		}
	}

	/**
	 * Makes a client/server call to change verify code.
	 * 
	 * @see gov.va.med.vistalink.security.VistaLoginModuleSPI#doChangeVerifyCode()
	 */
	public SecurityVOChangeVc changeVerifyCode(String oldVerifyCode, String newVerifyCode, String newVerifyCodeCheck)
			throws VistaLoginModuleException {

		String exceptionMessage = "Change verify code failed: ";

		try {
			return (KernelSecurityHandshake.doChangeVerifyCode(myConnection, mySecurityResponseFactory, oldVerifyCode
					.toUpperCase(), newVerifyCode.toUpperCase(), newVerifyCodeCheck.toUpperCase()))
					.getSecurityVOChangeVc();
		} catch (VistaLinkFaultException e) {
			logoutConnectionBeforeLoginComplete();
			// logged lower down
			throw new VistaLoginModuleException(exceptionMessage, e);
		} catch (ParserConfigurationException e) {
			logoutConnectionBeforeLoginComplete();
			logger.error(exceptionMessage, e);
			throw new VistaLoginModuleException(exceptionMessage, e);
		} catch (FoundationsException e) {
			logoutConnectionBeforeLoginComplete();
			// logged lower down
			throw new VistaLoginModuleException(exceptionMessage, e);
		}

	}

	/**
	 * Makes a client/server call to select division.
	 * 
	 * @see gov.va.med.vistalink.security.VistaLoginModuleSPI#doSelectDivision()
	 */
	public SecurityVOSelectDivision selectDivision(String selectedDivisionIen) throws VistaLoginModuleException {

		String exceptionMessage = "Select Division failed: ";

		try {
			return (KernelSecurityHandshake.doSelectDivision(myConnection, mySecurityResponseFactory,
					selectedDivisionIen)).getSecurityVOSelectDivision();
		} catch (VistaLinkFaultException e) {
			logoutConnectionBeforeLoginComplete();
			// logged lower down
			throw new VistaLoginModuleException(exceptionMessage, e);
		} catch (ParserConfigurationException e) {
			logoutConnectionBeforeLoginComplete();
			logger.error(exceptionMessage, e);
			throw new VistaLoginModuleException(exceptionMessage, e);
		} catch (FoundationsException e) {
			logoutConnectionBeforeLoginComplete();
			// logged lower down
			throw new VistaLoginModuleException(exceptionMessage, e);
		}
	}

	/**
	 * Makes a client/server call get user demographics.
	 * 
	 * @see gov.va.med.vistalink.security.VistaLoginModuleSPI#getUserDemographicsData()
	 */
	public SecurityVOUserDemographics getUserDemographicsData() throws VistaLoginModuleException {

		String exceptionMessage = "User Demographic retrieval failure: ";

		try {
			return (KernelSecurityHandshake.doGetUserDemographics(myConnection, mySecurityResponseFactory))
					.getSecurityVOUserDemographics();
		} catch (VistaLinkFaultException e) {
			logoutConnectionBeforeLoginComplete();
			// logged lower down
			throw new VistaLoginModuleException(exceptionMessage, e);
		} catch (ParserConfigurationException e) {
			logoutConnectionBeforeLoginComplete();
			logger.error(exceptionMessage, e);
			throw new VistaLoginModuleException(exceptionMessage, e);
		} catch (FoundationsException e) {
			logoutConnectionBeforeLoginComplete();
			// logged lower down
			throw new VistaLoginModuleException(exceptionMessage, e);
		}
	}

	/**
	 * Makes a client/server call to get a Kernel CCOW login token.
	 * 
	 * @see gov.va.med.vistalink.security.VistaLoginModuleSPI#getKernelCcowToken()
	 */
	public String getKernelCcowToken() throws VistaLoginModuleException {

		// don't need to kill the connection if this fails... login can
		// continue.
		String exceptionMessage = "Failed to retrieve Kernel CCOW token. ";
		if (myConnection == null) {
			throw new VistaLoginModuleException(exceptionMessage + "Connection is null.");
		} else {
			try {
				RpcRequest vReq = RpcRequestFactory.getRpcRequest("XUS SIGNON", "XUS GET CCOW TOKEN");
				// because we encode the RPC context, better to do this using
				// sink than as XML
				vReq.setUseProprietaryMessageFormat(true);
				RpcResponse vResp = myConnection.executeRPC(vReq);
				return vResp.getResults();
			} catch (VistaLinkFaultException e) {
				// logged lower down
				throw new VistaLoginModuleException(exceptionMessage, e);
			} catch (FoundationsException e) {
				// logged lower down
				throw new VistaLoginModuleException(exceptionMessage, e);
			}
		}

	}

	/**
	 * Makes a client/server call to get the CCOW passcode for the login module.
	 * 
	 * @see gov.va.med.vistalink.security.VistaLoginModuleSPI#getSecureCcowPasscode()
	 */
	public String getSecureCcowPasscode() throws VistaLoginModuleException {

		// don't need to kill the connection if this fails... login can
		// continue.

		logger.debug("in getSecureCcowPasscode.");
		String returnVal = "";
		String exceptionString = "Failed to retrieve CCOW passcode. ";
		if (myConnection == null) {
			throw new VistaLoginModuleException(exceptionString + "Connection is null.");
		} else {
			try {
				RpcRequest vReq = RpcRequestFactory.getRpcRequest("XUS SIGNON", "XUS CCOW VAULT PARAM");
				// because we encode the RPC context, better to do this using
				// sink than as XML
				vReq.setUseProprietaryMessageFormat(true);
				RpcResponse vResp = myConnection.executeRPC(vReq);
				StringTokenizer st = new StringTokenizer(vResp.getResults(), "\n");
				if (st.countTokens() == 2) {
					returnVal = st.nextToken() + st.nextToken();
				} else {
					// else return "", and writing user context will fail.
					logger.warn("Attempted to get a secure CCOW passcode from M, was not able to correctly retrieve.");
				}
			} catch (VistaLinkFaultException e) {
				// logged lower down
				throw new VistaLoginModuleException(exceptionString, e);
			} catch (FoundationsException e) {
				// logged lower down
				throw new VistaLoginModuleException(exceptionString, e);
			}
		}
		return returnVal;
	}

	/**
	 * Adds client/server specific information to the JAAS principal, namely, adding the client/server connection to the
	 * principal.
	 * 
	 * @see gov.va.med.vistalink.security.VistaLoginModuleSPI#commit()
	 */
	public void addSPISpecificInformationToPrincipal(VistaKernelPrincipalImpl principal) {
		principal.setAuthenticatedConnection(this.myConnection);
	}

	/**
	 * Performs client/server logout.
	 * 
	 * @see gov.va.med.vistalink.security.VistaLoginModuleSPI#logout()
	 */
	public void logout() throws VistaLoginModuleException {

		String exceptionMessage = "Error while logging out: ";
		try {

			SecurityDataLogoutResponse responseData = null;
			if ((myConnection != null) && (mySecurityResponseFactory != null)) {
				responseData = KernelSecurityHandshake.doLogout(myConnection, mySecurityResponseFactory);
				logger.debug("Result: " + responseData.getResultType());
				if (responseData.getResultType() != SecurityVO.RESULT_SUCCESS) {
					logger.error("Logout failure: " + responseData.getResultMessage());
				}
			}

		} catch (VistaLinkFaultException e) {

			logger.error(exceptionMessage, e);
			throw new VistaLoginModuleException(exceptionMessage, e);

		} catch (ParserConfigurationException e) {

			logger.error(exceptionMessage, e);
			throw new VistaLoginModuleException(exceptionMessage, e);

		} catch (FoundationsException e) {

			logger.error(exceptionMessage, e);
			throw new VistaLoginModuleException(exceptionMessage, e);

		} catch (ResourceException e) {

			logger.error(exceptionMessage, e);
			throw new VistaLoginModuleException(exceptionMessage, e);

		} catch (IOException e) {

			logger.error(exceptionMessage, e);
			throw new VistaLoginModuleException(exceptionMessage, e);

		} finally {

			// close/dispose the connection 
			if (myConnection != null) {
				try {
					myConnection.close();
				} catch (ResourceException err) {
					// other than logging, swallow this exception
					logger.error(exceptionMessage, err);
				} finally {
					myConnection = null;
				}
			}
			myVCF = null;
		}
	}

	/**
	 * Log out before an authenticated connection has been placed in the userPrincipal (clears up the M side, useful
	 * when we're about to throw an exception). Don't want to throw any errors here, because we're calling this method
	 * immediately BEFORE throwing a LoginException in most cases.
	 *  
	 */
	private void logoutConnectionBeforeLoginComplete() {

		try {
			logout();
		} catch (VistaLoginModuleException e) {
			// swallow this exception
		}
	}
}