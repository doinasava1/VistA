package gov.va.med.environment;

import org.apache.log4j.Logger;

/**
 * Environment settings for J2EE server use.
 * 
 */
public class Environment {

	private static final String WEBLOGIC_CLASSLOADER_PACKAGE = "weblogic.utils.classloaders";
	private static final int WEBLOGIC_CLASSLOADER_PACKAGE_LENGTH = WEBLOGIC_CLASSLOADER_PACKAGE.length();
	static final Logger logger = Logger.getLogger(Environment.class);

	/**
	 * private constructor to prevent instantiation
	 * 
	 */
	private Environment() {
		// empty private constructor
	}

	/**
	 * Returns whether the administrator has configured the J2EE server to be "production" in a VA-medical-center sense,
	 * i.e., is this system operating on production VA data. The source of the setting is the
	 * gov.va.med.environment.production JVM argument passed to the J2EE server upon startup. A setting of true
	 * desginates the server as a production server; any other value (including not passing the JVM argument at all)
	 * marks the server as not a VA production server.
	 * @return true if the server is a VA production server, false if not
	 */
	public static boolean isProduction() {

		return Boolean.getBoolean("gov.va.med.environment.production");
	}

	/**
	 * Returns the J2EE server type. The source of the setting is the gov.va.med.environment.servertype JVM argument
	 * passed to the J2EE server upon startup. If JVM arg missing, looks for WebLogic-specific classloader classes to
	 * determine if server type is WebLogic. Defaults to return UNKNOWN if the JVM argument is not present.
	 * 
	 * @return ServerType: JBOSS | ORACLE | SUN_RI_13 | UNKNOWN | WEBLOGIC | JAVASE | WEBSPHERE
	 */
	public static ServerType getServerType() {

		ServerType returnVal = null;
		String serverProperty = System.getProperty("gov.va.med.environment.servertype");

		if (serverProperty != null) {
			// 1. use JVM arg value if defined
			returnVal = ServerType.getServerTypeObject(serverProperty.toLowerCase());
			if (returnVal != null) {
				logger.debug("used JVM arg for server type");
			}
		} else if (isWebLogicClassLoaderHierarchy(Environment.class.getClassLoader())) {
			// 2. check classloader to see if appear to be in WebLogic JVM
			returnVal = ServerType.WEBLOGIC;
			logger.debug("used server auto-detection for server type");
		}

		// if failed to resolve, return unknown so don't return null
		if (returnVal == null) {
			returnVal = ServerType.UNKNOWN;
			logger.debug("no JVM arg value, and auto-detection failed; could not determine server type.");
		}
		return returnVal;
	}

	/**
	 * recurse though classloader hierarchy looking for one beginning with weblogic-specific package name
	 * 
	 * @param classLoader classloader associated with this environment
	 * @return true classloader hierarchy is from a weblogic server
	 */
	private static boolean isWebLogicClassLoaderHierarchy(ClassLoader classLoader) {
		boolean returnVal = false;
		if (classLoader != null) {
			String className = classLoader.getClass().getName();
			logger.debug("found class name in classloader hierarchy: " + className);
			if ((className.length() > WEBLOGIC_CLASSLOADER_PACKAGE.length())
					&& (WEBLOGIC_CLASSLOADER_PACKAGE
							.equals(className.substring(0, WEBLOGIC_CLASSLOADER_PACKAGE_LENGTH)))) {
				returnVal = true;
			} else {
				returnVal = isWebLogicClassLoaderHierarchy(classLoader.getParent());
			}
		}
		return returnVal;
	}

}