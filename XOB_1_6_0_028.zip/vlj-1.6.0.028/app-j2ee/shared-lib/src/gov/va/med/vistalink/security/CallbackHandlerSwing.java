package gov.va.med.vistalink.security;

import java.awt.Frame;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.UnsupportedCallbackException;

import org.apache.log4j.Logger;

/**
 * Implements the JAAS CallbackHandler interface. Use with the <code>VistaLoginModule</code> to invoke a Swing-based
 * interactive logon. Input values (access code, verify code, division selection, and other "user input") is collected
 * via a set of GUI dialogs when this callback handler is used.
 * <ol>
 * <li>Create an instance of CallbackHandlerSwing. No parameters are needed.
 * <li>Create the JAAS <code>LoginContext</code> instance, passing the instance of the callback handler as one of the
 * parameters.
 * <li>Invoke the JAAS login context's <code>login</code> method. The callback handler will invoke Swing dialogs to
 * collect user input wherever required for login.
 * </ol>
 * For example:
 * <p>
 * <code>
 * String cfgName = &quot;RpcSampleServer&quot;;
 * <p>
 * // create the callback handler<br>
 * CallbackHandlerSwing cbhSwing = new CallbackHandlerSwing(myFrame);
 * <p>
 * // create the LoginContext<br>
 * loginContext = new LoginContext(cfgName, cbhSwing);
 * <p>
 * // login to server<br>
 * loginContext.login();
 * </code>
 * 
 * @see VistaLoginModule
 */
public class CallbackHandlerSwing extends CallbackHandlerBase {

	private static final Logger logger = Logger.getLogger(CallbackHandlerSwing.class);

	private Frame windowParent;

	/**
	 * Instantiates a JAAS callback handler for Swing applications.
	 * 
	 * @param windowParent
	 *            Allows login dialogs to be centered over a parent frame (a top-level window with a title and border).
	 *            If null is passed, login dialogs are centered based on the screen itself.
	 */
	public CallbackHandlerSwing(Frame windowParent) {
		super();
		this.windowParent = windowParent;
	}

	/**
	 * Does the change verify code callback
	 * 
	 * @param cvcCallback
	 *            change verify code callback
	 */
	void doCallbackChangeVc(CallbackChangeVc cvcCallback) {
		logger.debug("starting CallbackChangeVc");
		DialogChangeVc.showVistaAVSwingChangeVC(windowParent, cvcCallback);
	}

	/**
	 * Does the confirm callback
	 * 
	 * @param confirmCallback confirm callback
	 */
	void doCallbackConfirm(CallbackConfirm confirmCallback) {
		// need to do more work here because DialogConfirm is designed for
		// generic use, not just use with a callback handler

		logger.debug("starting CallbackConfirm");
		int returnVal = -1;
		if (confirmCallback.getMessageMode() == CallbackConfirm.INFORMATION_MESSAGE) {
			returnVal = DialogConfirm.showDialogConfirm(windowParent, confirmCallback.getDisplayMessage(),
					confirmCallback.getWindowTitle(), DialogConfirm.MODE_INFORMATION_MESSAGE, confirmCallback
							.getTimeoutInSeconds());
		} else if (confirmCallback.getMessageMode() == CallbackConfirm.HELP_MESSAGE) {
			returnVal = DialogConfirm.showDialogConfirm(windowParent, confirmCallback.getDisplayMessage(),
					confirmCallback.getWindowTitle(), DialogConfirm.MODE_HELP_MESSAGE, confirmCallback
							.getTimeoutInSeconds());
		} else if (confirmCallback.getMessageMode() == CallbackConfirm.ERROR_MESSAGE) {
			returnVal = DialogConfirm.showDialogConfirm(windowParent, confirmCallback.getDisplayMessage(),
					confirmCallback.getWindowTitle(), DialogConfirm.MODE_ERROR_MESSAGE, confirmCallback
							.getTimeoutInSeconds());
		} else if (confirmCallback.getMessageMode() == CallbackConfirm.POST_TEXT_MESSAGE) {
			returnVal = DialogConfirm.showDialogConfirm(windowParent, confirmCallback.getDisplayMessage(),
					confirmCallback.getWindowTitle(), DialogConfirm.MODE_INFORMATION_MESSAGE, confirmCallback
							.getTimeoutInSeconds());
		}
		switch (returnVal) {
		case DialogConfirm.OK_OPTION:
			confirmCallback.setSelectedOption(CallbackConfirm.KEYPRESS_OK);
			break;
		case DialogConfirm.CANCEL_OPTION:
			confirmCallback.setSelectedOption(CallbackConfirm.KEYPRESS_CANCEL);
			break;
		case DialogConfirm.TIMEOUT_OPTION:
			confirmCallback.setSelectedOption(CallbackConfirm.KEYPRESS_TIMEOUT);
			break;
		default:
			confirmCallback.setSelectedOption(CallbackConfirm.KEYPRESS_TIMEOUT);
			break;
		}
	}

	/**
	 * Does the logon callback
	 * 
	 * @param logonCallback
	 */
	void doCallbackLogon(CallbackLogon logonCallback) {
		logger.debug("starting CallbackLogon");
		DialogLogon.showVistaAVSwingGetAV(windowParent, logonCallback);
	}

	/**
	 * Does the select division callback
	 * 
	 * @param divisionCallback
	 */
	void doCallbackSelectDivision(CallbackSelectDivision divisionCallback) {
		logger.debug("starting CallbackSelectDivision");
		DialogSelectDivision.showVistaAVSwingSelectDivision(windowParent, divisionCallback);
	}

	/**
	 * Does the commit callback
	 * 
	 * @param commitCallback
	 */
	void doCallbackCommit(CallbackCommit commitCallback) {
		logger.debug("starting CallbackCommit");
		// do nothing
	}

	/**
	 * processes unsupported callbacks
	 * 
	 * @param callback
	 *            the unsupported callback
	 * @throws UnsupportedCallbackException
	 *             thrown as part of the processing of an unsupported callback
	 */
	void doUnsupportedCallback(Callback callback) throws UnsupportedCallbackException {
		String errMsg = "Unsupported callback: '" + callback.getClass() + "'";
		UnsupportedCallbackException e = new UnsupportedCallbackException(callback, errMsg);
		logger.error(errMsg, e);
		throw e;
	}

	/**
	 * for child classes to access this value
	 * 
	 * @return windowParent
	 */
	Frame getWindowParent() {
		return this.windowParent;
	}

}