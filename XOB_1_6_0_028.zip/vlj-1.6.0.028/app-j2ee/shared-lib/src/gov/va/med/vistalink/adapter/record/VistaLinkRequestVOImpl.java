package gov.va.med.vistalink.adapter.record;

import gov.va.med.exception.ExceptionUtils;
import gov.va.med.exception.FoundationsException;
import gov.va.med.xml.XmlUtilities;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;

/**
 * Base request implementation.
 * Applications usually use a specific subclass of this implementation. 
 * 
 */
public class VistaLinkRequestVOImpl implements VistaLinkRequestVO {

	/**
	* The logger used by this class
	*/
	private static final Logger logger =
		Logger.getLogger(VistaLinkRequestVOImpl.class);

	/**
	 * The rate at which the heart beat will be scheduled (milliseconds).
	 * <p>
	 * A timeout value of 0 (zero) indicates that no specific time out for the request
	 * has been specified. The time out value associated with the socket will be used
	 * during socket read operations.
	 */
	private int timeOut = 0;

	/**
	 * Request data DOM document (i.e., original data).
	 */
	protected Document requestDoc = null;

	/**
	 * Request data as XML String. Computed once per object lifecycle
	 */
	protected String xmlString = null;

	/**
	 * Retry strategy if socket exception occurs during VistaLinkManagedConnection.executeInteraction()
	 */
	protected VistaLinkRequestRetryStrategy retryStrategy = new VistaLinkRequestRetryStrategyAllow();
	
	/**
	 * Constructor for VistaLinkRequestVOImpl.
	 * 
	 * @see java.lang.Object#Object()
	 * @va.exclude
	 */
	public VistaLinkRequestVOImpl() {
		this.requestDoc = null;
	}

	/**
	 * Constructor for VistaLinkRequestVOImpl.
	 * 
	 * @param requestDoc
	 * @va.exclude
	 */
	public VistaLinkRequestVOImpl(Document requestDoc) {
		this.requestDoc = requestDoc;
	}

	/*
	 *  (non-Javadoc)
	 * @see gov.va.med.vistalink.adapter.record.VistaLinkRequestVO#getRequestString()
	 * @va.exclude
	 */
	public String getRequestString() throws FoundationsException {
		if (requestDoc == null) {
			String errStr =
				"Can not return request String as requestDoc == null. Make sure to initialize Request appropriately.";
			FoundationsException e = new FoundationsException(errStr);

			if (logger.isEnabledFor(Level.ERROR)) {

				String errMsg = ExceptionUtils.getFullStackTrace(e);

				logger.error(errMsg);
	 		}

			throw e;
		}
		try {
			xmlString = XmlUtilities.convertXmlToStr(requestDoc);
		} catch (FoundationsException e) {

			if (logger.isEnabledFor(Level.ERROR)) {

				String errMsg =
					(new StringBuffer())
						.append("Converting requestDoc to XML String failed.")
						.append("\n\t")
						.append(ExceptionUtils.getFullStackTrace(e))
						.toString();

				logger.error(errMsg);
			}

			throw e;
		}
		return xmlString;
	}

	/*
	 *  (non-Javadoc)
	 * @see gov.va.med.vistalink.adapter.record.VistaLinkRequestVO#getTimeOut()
	 */
	public int getTimeOut() {
		return timeOut;
	}

	/*
	 *  (non-Javadoc)
	 * @see gov.va.med.vistalink.adapter.record.VistaLinkRequestVO#setTimeOut(int)
	 */
	public void setTimeOut(int timeOut) {
		this.timeOut = timeOut;
	}
	
	/* Returns current retry strategy instance reference 
	 * @see gov.va.med.vistalink.adapter.record.VistaLinkRequestVO#getRetryStrategy()
	 */
	public VistaLinkRequestRetryStrategy getRetryStrategy() {
		return retryStrategy;
	}
	
	/* 
	 * Sets retry strategy for request
	 * @see gov.va.med.vistalink.adapter.record.VistaLinkRequestVO#setRetryStrategy(gov.va.med.vistalink.adapter.record.VistaLinkRequestRetryStrategy)
	 */
	public void setRetryStrategy(VistaLinkRequestRetryStrategy retryStrategy) {
		if (retryStrategy != null) {
			this.retryStrategy = retryStrategy;			
		}
	}

}
