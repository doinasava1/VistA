package gov.va.med.exception;

/**
 * Represents the interface that all Foundations exceptions implement.
 * Implementing this interface allows ExceptionUtils to work with
 * the exception. 
 * 
 */
public interface FoundationsExceptionInterface {

	/**
	 * Return full stack trace. Full stack trace will include all nested exception
	 * messages and the full stack trace for the root exception.
	 * 
	 * @return full stack trace String
	 * @deprecated Use Throwable.getStackTrace() instead.
	 */
	String getFullStackTrace();
	
	/**
	 * Return nested exception that is wrapped within this exception.
	 * @return nested exception
	 * @deprecated Use Throwable.getCause() instead.
	 */
	Throwable getNestedException();

}
