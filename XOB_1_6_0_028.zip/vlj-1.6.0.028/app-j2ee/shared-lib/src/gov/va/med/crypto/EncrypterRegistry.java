/*
 * Created on Apr 11, 2005
 *
 */
package gov.va.med.crypto;

import java.util.Hashtable;

/**
 * Access wrapper class, used to hold singleton instances of VistALinkEncrypter implementations.
 * 
 */

public class EncrypterRegistry {
	private static Hashtable _reg = new Hashtable();

	static {

		DESKeyEncrypter dke = new DESKeyEncrypter();
		_reg.put(dke.getClass(), dke);
		DESPassPhraseEncrypter dppe = new DESPassPhraseEncrypter();
		_reg.put(dppe.getClass(), dppe);
		// change to lazy initialization so that these classes work in J2SE too -- commented out following:
		// DESScopedEncrypter dse = new DESScopedEncrypter();
		// _reg.put(dse.getClass(), dse);
	}

	private EncrypterRegistry() {
		// ...
	}

	public static VistaLinkEncrypter getInstance(Class c) {
		if (c.equals(DESScopedEncrypter.class)) {
			// don't create this one if don't need to -- use lazy initialization instead (requires app server
			// environment to successfully create)
			synchronized (DESKeyEncrypter.class) {
				if (null == _reg.get(c)) {
					DESScopedEncrypter dse = new DESScopedEncrypter();
					_reg.put(dse.getClass(), dse);
				}
			}
		}
		VistaLinkEncrypter result = (VistaLinkEncrypter) (_reg.get(c));
		if (result == null)
			throw new IllegalArgumentException("Unable to get class: " + c);
		return result;
	}

}
