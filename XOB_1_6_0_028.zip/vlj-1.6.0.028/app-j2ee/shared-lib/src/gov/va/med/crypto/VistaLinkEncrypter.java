/*
 * Created on Apr 11, 2005
 *
 */
package gov.va.med.crypto;

import java.security.Key;

import org.apache.log4j.Logger;

/**
 * An abstract ancestor for all implementations of Encryption/Decryption (two-way) algorithms,
 * used in VistaLink.
 * 
 */
public abstract class VistaLinkEncrypter{
  protected String algorithmName = "none";
  protected String encodingFormat = "none";
  protected Key key;
  protected static final Logger logger = Logger.getLogger(VistaLinkEncrypter.class);
  
  /**
   * Decrypts a string using the specified encoding algorithm and encoding.
   * @param s The String to encode. 
   * @return an encrypted and encoded (according to the specified encodingFormat)
   *         version of the input string.
   */
  public abstract String decrypt(String s);
  
  /**
   * Encrypts a string using the specified encoding algorithm and encoding.
   * @param s The String to encode. 
   * @return an encrypted and encoded (according to the specified encodingFormat)
   *         version of the input string.
   */
  public abstract String encrypt(String s);
  
  /**
   * Returns a Key instance, used for encryption/decryption process 
   * @return a Key instance.
   */ 
  public abstract Key getKey();
}
