package gov.va.med.vistalink.security.m;

import gov.va.med.vistalink.adapter.record.VistaLinkFaultException;

/**
 * This exception fault is returned from M, and signifies that there was a mismatch between the client
 * primary station (mapped to the connector) and the primary station of the M account the connector 
 * accessed (based on the value of the DEFAULT INSTITUTION field of the Kernel System Parameters file).
 */
public final class SecurityPrimaryStationMismatchException extends SecurityFaultException {

	/**
	 * Constructor
	 * @param vistaLinkFaultException the exception to copy into a new exception type
	 * @va.exclude
	 */
	public SecurityPrimaryStationMismatchException(VistaLinkFaultException vistaLinkFaultException) {
		super(vistaLinkFaultException);
	}

}
