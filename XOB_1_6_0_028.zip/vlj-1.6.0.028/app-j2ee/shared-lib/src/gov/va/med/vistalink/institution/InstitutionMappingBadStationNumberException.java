package gov.va.med.vistalink.institution;

/**
 * Represents a failure to create one or more institution mappings because
 * of one or more bad station#s on which the mapping was to be based.
 * 
 */
public class InstitutionMappingBadStationNumberException extends Exception {

	/**
	 * Exception constructor.
	 * @va.exclude
	 */
	public InstitutionMappingBadStationNumberException()
	{
		super();
	}
	
	/**
	 * Exception constructor.
	 * @param message Exception message.
	 * @va.exclude
	 */
	public InstitutionMappingBadStationNumberException(String message) {
		super(message);
	}
	
	/**
	 * Exception constructor.
	 * @param nestedException A nested exception.
	 * @va.exclude
	 */
	public InstitutionMappingBadStationNumberException(Exception nestedException) {
		super(nestedException);
	}
	
	/**
	 * Exception constructor.
	 * @param message Exception message.
	 * @param nestedException A nested exception.
	 * @va.exclude
	 */
	public InstitutionMappingBadStationNumberException(String message, Exception nestedException) {
		super(message, nestedException);
	}
}
