package gov.va.med.vistalink.adapter.cci;

import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

/**
 * This is the connection spec class for Application Proxy re-authentication
 * 
 */
public class VistaLinkAppProxyConnectionSpec extends VistaLinkConnectionSpecImpl {

	/**
	 * Value used to identify type as APPLICATION PROXY
	 */
	private static final String TYPE_APP_PROXY = "appproxy";

	/**
	 * Element name given to App Proxy type
	 */
	private static final String ELEMENT_APP_PROXY_NAME = "ApplicationProxyName";

	/**
	 * Name given to attribute representing APP PROXY NAME value
	 */
	private static final String ATTRIBUTE_VALUE = "value";

	/**
	 * The APP PROXY NAME value
	 */
	private String appProxyName;

	/**
	 * The logger used by this class
	 */
	private static final Logger logger = Logger.getLogger(VistaLinkAppProxyConnectionSpec.class);

	/**
	 * @va.exclude
	 */
	public VistaLinkAppProxyConnectionSpec() {
		super();
	}

	/**
	 * @param appProxyName
	 *            The Application Proxy Name identifier for the proxy user.
	 * @param division
	 *            The station number (e.g., "523", "523BZ", etc.) requested as
	 *            the division under which logon/actions should be conducted for
	 *            this user on the target Kernel/M system.
	 *            <p>
	 *            The division parameter for connection specs is mandatory. This
	 *            ensures that division requested for a connection on behalf of
	 *            an end-user matches the division actually accessed on the M
	 *            side of the connection.
	 *            <p>
	 *            The value to pass for the division parameter is the division
	 *            station number, e.g., "523", "523BZ", etc. This is the value
	 *            found in field 99 ('Station Number') of the corresponding
	 *            entry in the Institution File on the M system.
	 *            <p>
	 *            On the M side, if a user doesn't have one or more "divisions"
	 *            specified in the DIVISION (#200.02) multiple of their New
	 *            Person file entry, the division passed in with the connection
	 *            spec must be the station number of the division set into the
	 *            DEFAULT INSTITUTION (#217) field of the KERNEL SYSTEM
	 *            PARAMETERS (#8989.3) file entry for the site. This value is
	 *            set by Kernel into DUZ(2).
	 *            <p>
	 *            On the M side, if a user has one or more "divisions" specified
	 *            in the DIVISION (#200.02) multiple of their New Person file
	 *            entry, the division passed in with the connection spec must be
	 *            the station number for one of those divisions present in that
	 *            multiple. This value will be set by Kernel into DUZ(2).
	 */
	public VistaLinkAppProxyConnectionSpec(String division, String appProxyName) {
		super(division);
		this.appProxyName = appProxyName;
	}

	/**
	 * @return Application Proxy Name
	 */
	public String getAppProxyName() {
		return appProxyName;
	}

	/**
	 * Sets the Application Proxy Name
	 * 
	 * @param string
	 */
	public void setAppProxyName(String string) {
		appProxyName = string;
	}

	/**
	 * @return Security info
	 * @see gov.va.med.vistalink.adapter.cci.VistaLinkConnectionSpec#getProprietarySecurityInfo()
	 * @va.exclude
	 */
	public ArrayList getProprietarySecurityInfo() {
		ArrayList values = new ArrayList();
		values.add(appProxyName);
		return values;
	}

	/**
	 * Compares two objects to see if they are equal
	 * 
	 * @param obj
	 *            the object to compare
	 * @see gov.va.med.vistalink.adapter.cci.VistaLinkConnectionSpec#isConnSpecEqual(java.lang.Object)
	 * @va.exclude
	 * @deprecated Use equals() method.
	 */
	public boolean isConnSpecEqual(Object obj) {
		return equals(obj);
	}
	
	public boolean equals(Object obj) {
		
		if (obj instanceof VistaLinkAppProxyConnectionSpec) {
			VistaLinkAppProxyConnectionSpec connSpec = (VistaLinkAppProxyConnectionSpec) obj;
			if ((connSpec.getDivision().equals(this.getDivision())) && (connSpec.getAppProxyName().equals(this.getAppProxyName()))) {
				return true;
			}
		}
		return false;
	}

	public int hashCode() {
		// algorithm taken from "Effective Java" item #8.
		int HASHCODE_SEED = 17;
		int returnVal = HASHCODE_SEED;

		// division contribution to hashcode
		int divisionHashCode = this.getDivision().hashCode();
		returnVal = 37 * returnVal + divisionHashCode; 
		// proxy name contribution to hashcode
		int proxyNameHashCode = this.getAppProxyName().hashCode();
		returnVal = 37 * returnVal + proxyNameHashCode; 
		return returnVal;
	}

	/**
	 * creates the xml in the security node
	 * 
	 * @param requestDoc
	 *            the Document object that contains the nodes
	 * @param securityNode
	 *            the node to create the XML under
	 * @see gov.va.med.vistalink.adapter.cci.VistaLinkConnectionSpec#setAuthenticationNodes(org.w3c.dom.Document,
	 *      org.w3c.dom.Node)
	 * @va.exclude
	 */
	public void setAuthenticationNodes(Document requestDoc, Node securityNode) {
		if (logger.isDebugEnabled()) {
			logger.debug("setAuthenticationNodes -> Re Auth type is 'appProxyName'");
		}

		setSecurityDivisionAttr(securityNode);
		setSecurityTypeAttr(securityNode);

		Element elemAppProxy = requestDoc.createElement(ELEMENT_APP_PROXY_NAME);

		elemAppProxy.setAttribute(ATTRIBUTE_VALUE, this.getAppProxyName());

		securityNode.appendChild(elemAppProxy);

	}

	/**
	 * returns the security mechanism type.
	 * 
	 * @see gov.va.med.vistalink.adapter.cci.VistaLinkConnectionSpec#getSecurityType()
	 * @va.exclude
	 */

	public String getSecurityType() {
		return TYPE_APP_PROXY;
	}

}