package gov.va.med.vistalink.security;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.FocusTraversalPolicy;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.border.TitledBorder;

/**
 * Swing Dialog to collect user input for a "change verify code" event
 *
 * @see VistaLoginModule
 * @see CallbackHandlerSwing
 */
final class DialogChangeVc extends JDialog {

	private static final String DEFAULT_TITLE = "Change VistA Verify Code";

	private static final String PANEL_TITLE = "You need to enter a new verify code.";
	private static final String PANEL_ACCESSIBLE_DESCRIPTION = "This dialog is prompting you to change your verify code.";

	private static final String OLD_VERIFY_LABEL = "Old Verify Code: ";
	private static final char OLD_VERIFY_MNEMONIC = KeyEvent.VK_D;
	private static final String OLD_VERIFY_TOOLTIP = "Enter Current (Old) Verify Code";

	private static final String NEW_VERIFY_LABEL = "New Verify Code: ";
	private static final char NEW_VERIFY_MNEMONIC = KeyEvent.VK_N;
	private static final String NEW_VERIFY_TOOLTIP = "Enter New Verify Code";

	private static final String NEW_VERIFY_CHECK_LABEL = "Confirm New Verify Code: ";
	private static final char NEW_VERIFY_CHECK_MNEMONIC = KeyEvent.VK_F;
	private static final String NEW_VERIFY_CHECK_TOOLTIP = "Re-Enter New Verify Code";

	private static final String OK_BUTTON_LABEL = "OK";
	private static final char OK_BUTTON_MNEMONIC = 'O';
	private static final String OK_BUTTON_TOOLTIP = "Submits Request to Server to Change Verify Code";

	private static final String CANCEL_BUTTON_LABEL = "Cancel";
	private static final char CANCEL_BUTTON_MNEMONIC = 'C';
	private static final String CANCEL_BUTTON_TOOLTIP = "Cancels the Change Verify Code request";

	private static final String HELP_BUTTON_LABEL = "Help";
	private static final char HELP_BUTTON_MNEMONIC = 'H';
	private static final String HELP_BUTTON_TOOLTIP = "Get Help on Changing Verify Code";

	private static final int CODE_FIELD_COLUMNS = 13;

	private static final String HELP_MSG_1 = "Enter a new verify code and then confirm it.";

	private JPasswordField oldVerify;
	private JPasswordField newVerify;
	private JPasswordField newVerifyCheck;
	private JButton help;
	private JButton ok;
	private JButton cancel;
	private JLabel oldVerifyLabel;
	private JLabel newVerifyLabel;
	private JLabel newVerifyCheckLabel;
	private CallbackChangeVc cvcCbh;
	private Frame parentFrame;

	/**
	 * Create a modal Swing dialog to collect "change verify code" information from the user
	 * @param parent parent frame
	 * @param cvcCbh callback to retrieve information from and place result in
	 */
	static void showVistaAVSwingChangeVC(Frame parent, CallbackChangeVc cvcCbh) {

		DialogChangeVc dialog = new DialogChangeVc(parent, cvcCbh);
		if ((parent != null) && (!"".equals(parent.getTitle()))) {
			dialog.setTitle(parent.getTitle() + ": " + DialogLogon.SIGNON_STRING + " " + DEFAULT_TITLE);
		} else {
			dialog.setTitle(DialogLogon.DEFAULT_TITLE + ": " + DEFAULT_TITLE);
		}
		VistaLoginSwingUtilities.goldenMeanCenterDialog(parent, dialog);
		dialog.setVisible(true);
	}

	private DialogChangeVc(Frame parent, CallbackChangeVc cvcCbh) {
		super(parent, DEFAULT_TITLE, true);
		this.cvcCbh = cvcCbh;
		this.parentFrame = parent;

		Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());
		contentPane.add(createContentPane(), BorderLayout.CENTER);

		pack();
		VistaLoginSwingUtilities.goldenMeanCenterDialog(parent, this);

		getAccessibleContext().setAccessibleDescription(PANEL_ACCESSIBLE_DESCRIPTION);
		//set up event for timeout
		int timeout = 1000 * this.cvcCbh.getTimeoutInSeconds();
		ActionListener taskPerformer = new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				doTimeout();
			}
		};
		new Timer(timeout, taskPerformer).start();

		// disable oldVerify if the user logged on without entering a verify code
		// (meaning that their verify code had been deleted, so, no reason to prompt for it)
		if (cvcCbh.getEnteredVerifyCodeWasNull()) {
			oldVerify.setEditable(false);
			newVerify.requestFocusInWindow();
		} else {
			oldVerify.requestFocusInWindow();
		}
	}

	private JComponent createContentPane() {
		GridBagLayout gridbag = new GridBagLayout();

		JPanel p = new JPanel();
		p.setLayout(gridbag);

		createPasswordFields();
		createLabels();

		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.insets = new Insets(6, 6, 6, 6);
		c.ipadx = 3;
		c.ipady = 3;

		c.gridheight = 1;

		c.gridx = c.gridy = 0;
		c.gridwidth = 3;

		c.gridwidth = 1;
		c.gridx = 0;
		c.gridy = 1;
		p.add(oldVerifyLabel, c);

		c.gridy = 2;
		p.add(newVerifyLabel, c);

		c.gridy = 3;
		p.add(newVerifyCheckLabel, c);

		c.gridx = 1;
		c.gridy = 1;
		p.add(oldVerify, c);

		c.gridy = 2;
		p.add(newVerify, c);

		c.gridy = 3;
		p.add(newVerifyCheck, c);

		c.gridx = 2;
		c.gridy = 1;
		p.add(createOKButton(), c);

		c.gridy = 2;
		p.add(createCancelButton(), c);

		c.gridy = 3;
		p.add(createHelpButton(), c);

		p.setFocusCycleRoot(true);
		p.setFocusTraversalPolicy(new DialogChangeVcFocusTraversalPolicy());

		p.setBorder(new TitledBorder(PANEL_TITLE));

		return p;
	}

	private void createPasswordFields() {

		oldVerify = new JPasswordField("", CODE_FIELD_COLUMNS);
		oldVerify.setToolTipText(OLD_VERIFY_TOOLTIP);

		newVerify = new JPasswordField("", CODE_FIELD_COLUMNS);
		newVerify.setToolTipText(NEW_VERIFY_TOOLTIP);

		newVerifyCheck = new JPasswordField("", CODE_FIELD_COLUMNS);
		newVerifyCheck.setToolTipText(NEW_VERIFY_CHECK_TOOLTIP);

	}

	private void createLabels() {

		oldVerifyLabel = new JLabel(OLD_VERIFY_LABEL);
		oldVerifyLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		oldVerifyLabel.setFont(oldVerifyLabel.getFont().deriveFont(Font.BOLD));
		oldVerifyLabel.setDisplayedMnemonic(OLD_VERIFY_MNEMONIC);
		oldVerifyLabel.setToolTipText(OLD_VERIFY_TOOLTIP);
		oldVerifyLabel.setLabelFor(this.oldVerify);
		oldVerifyLabel.addFocusListener(new FocusListener() {
			public void focusLost(FocusEvent e) {
			}
			public void focusGained(FocusEvent e) {
				oldVerify.requestFocusInWindow();
			}
		});

		newVerifyLabel = new JLabel(NEW_VERIFY_LABEL);
		newVerifyLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		newVerifyLabel.setFont(newVerifyLabel.getFont().deriveFont(Font.BOLD));
		newVerifyLabel.setDisplayedMnemonic(NEW_VERIFY_MNEMONIC);
		newVerifyLabel.setToolTipText(NEW_VERIFY_TOOLTIP);
		newVerifyLabel.setLabelFor(this.newVerify);
		newVerifyLabel.addFocusListener(new FocusListener() {
			public void focusLost(FocusEvent e) {
			}
			public void focusGained(FocusEvent e) {
				newVerify.requestFocusInWindow();
			}
		});

		newVerifyCheckLabel = new JLabel(NEW_VERIFY_CHECK_LABEL);
		newVerifyCheckLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		newVerifyCheckLabel.setFont(newVerifyCheckLabel.getFont().deriveFont(Font.BOLD));
		newVerifyCheckLabel.setDisplayedMnemonic(NEW_VERIFY_CHECK_MNEMONIC);
		newVerifyCheckLabel.setToolTipText(NEW_VERIFY_CHECK_TOOLTIP);
		newVerifyCheckLabel.setLabelFor(this.newVerifyCheck);
		newVerifyCheckLabel.addFocusListener(new FocusListener() {
			public void focusLost(FocusEvent e) {
			}
			public void focusGained(FocusEvent e) {
				newVerifyCheck.requestFocusInWindow();
			}
		});

	}

	private JButton createCancelButton() {
		cancel = new JButton(CANCEL_BUTTON_LABEL);
		cancel.setMnemonic(CANCEL_BUTTON_MNEMONIC);
		cancel.setFont(cancel.getFont().deriveFont(Font.BOLD));
		cancel.setToolTipText(CANCEL_BUTTON_TOOLTIP);
		cancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cancelActionPerformed();
			}
		});

		return cancel;
	}

	private JButton createOKButton() {
		ok = new JButton(OK_BUTTON_LABEL);
		ok.setMnemonic(OK_BUTTON_MNEMONIC);
		ok.setFont(ok.getFont().deriveFont(Font.BOLD));
		ok.setToolTipText(OK_BUTTON_TOOLTIP);
		this.getRootPane().setDefaultButton(ok);

		// handle events for button presses
		ok.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				okActionPerformed();
			}
		});
		return ok;
	}

	private JButton createHelpButton() {
		help = new JButton(HELP_BUTTON_LABEL);
		help.setMnemonic(HELP_BUTTON_MNEMONIC);
		help.setFont(help.getFont().deriveFont(Font.BOLD));
		help.setToolTipText(HELP_BUTTON_TOOLTIP);

		// handle events for button presses
		help.addActionListener(new HelpButtonActionListener());
		return help;
	}

	private void okActionPerformed() {
		this.cvcCbh.setOldVerifyCode(this.oldVerify.getPassword());
		this.cvcCbh.setNewVerifyCode(this.newVerify.getPassword());
		this.cvcCbh.setNewVerifyCodeCheck(this.newVerifyCheck.getPassword());
		this.cvcCbh.setSelectedOption(CallbackChangeVc.KEYPRESS_OK);
		this.setVisible(false);
		this.dispose();
	}

	private void cancelActionPerformed() {
		this.cvcCbh.setOldVerifyCode(null);
		this.cvcCbh.setNewVerifyCode(null);
		this.cvcCbh.setNewVerifyCodeCheck(null);
		this.cvcCbh.setSelectedOption(CallbackChangeVc.KEYPRESS_CANCEL);
		this.setVisible(false);
		this.dispose();
	}

	private void doTimeout() {
		this.cvcCbh.setOldVerifyCode(null);
		this.cvcCbh.setNewVerifyCode(null);
		this.cvcCbh.setNewVerifyCodeCheck(null);
		this.cvcCbh.setSelectedOption(CallbackChangeVc.KEYPRESS_TIMEOUT);
		this.setVisible(false);
		this.dispose();
	}

	/**
	 * listener to launch the separate help dialog if help button is pressed
	 */
	class HelpButtonActionListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			StringBuffer sb = new StringBuffer(HELP_MSG_1);
			sb.append('\n');
			sb.append(cvcCbh.getCvcHelpText());
			int returnVal =
				DialogConfirm.showDialogConfirm(
					parentFrame,
					sb.toString(),
					DialogLogon.SIGNON_STRING + " Change Verify Code Help",
					DialogConfirm.MODE_HELP_MESSAGE,
					cvcCbh.getTimeoutInSeconds());
			if (returnVal == DialogConfirm.TIMEOUT_OPTION) {
				doTimeout();
			} else {
				oldVerify.requestFocusInWindow();
			}
		}
	}

	/**
	 * Provides a focus traversal policy for this dialog
	 */
	class DialogChangeVcFocusTraversalPolicy extends FocusTraversalPolicy {

		/**
		 * get the next component in the focus traversal
		 * @param focusCycleRoot the root of the focus cycle
		 * @param aComponent currently focused component
		 * @return returns the next component in the (forward) cycle
		 */
		public Component getComponentAfter(Container focusCycleRoot, Component aComponent) {

			if (aComponent.equals(oldVerify)) {
				return newVerify;
			} else if (aComponent.equals(newVerify)) {
				return newVerifyCheck;
			} else if (aComponent.equals(newVerifyCheck)) {
				return ok;
			} else if (aComponent.equals(ok)) {
				return cancel;
			} else if (aComponent.equals(cancel)) {
				return help;
			} else if (aComponent.equals(help)) {
				return oldVerify;

				/* Now for the "outside normal tab cycle" cases */

			} else if (aComponent.equals(oldVerifyLabel)) {
				return oldVerify;
			} else if (aComponent.equals(newVerifyLabel)) {
				return newVerify;
			} else if (aComponent.equals(newVerifyCheckLabel)) {
				return newVerifyCheck;
			}
			return oldVerify;
		}

		/**
		 * get the previous (reverse direction) component in the focus traversal cycle
		 * @param focusCycleRoot the root of the focus cycle
		 * @param aComponent currently focused component
		 * @return returns the next component in the (reverse) cycle
		 */
		public Component getComponentBefore(Container focusCycleRoot, Component aComponent) {

			if (aComponent.equals(help)) {
				return cancel;
			} else if (aComponent.equals(cancel)) {
				return ok;
			} else if (aComponent.equals(ok)) {
				return newVerifyCheck;
			} else if (aComponent.equals(newVerifyCheck)) {
				return newVerify;
			} else if (aComponent.equals(newVerify)) {
				return oldVerify;
			} else if (aComponent.equals(oldVerify)) {
				return help;

				/* Now for the "outside normal tab cycle" cases */

			} else if (aComponent.equals(newVerifyCheckLabel)) {
				return newVerify;
			} else if (aComponent.equals(newVerifyLabel)) {
				return oldVerify;
			} else if (aComponent.equals(oldVerifyLabel)) {
				return help;
			}
			return oldVerify;
		}

		/**
		 * gets the default component to focus on
		 * @param focusCycleRoot the root of the focus cycle
		 * @return the default component in the focus cycle
		 */
		public Component getDefaultComponent(Container focusCycleRoot) {
			return oldVerify;
		}
		
		/**
		 * gets the last component in the focus cycle
		 * @param focusCycleRoot the root of the focus cycle
		 * @return the last component in the focus cycle
		 */
		public Component getLastComponent(Container focusCycleRoot) {
			return help;
		}
		
		/**
		 * gets the first component in the focus cycle
		 * @param focusCycleRoot the root of the focus cycle
		 * @return the first component in the focus cycle
		 */
		public Component getFirstComponent(Container focusCycleRoot) {
			return oldVerify;
		}
	}
}