/*
 * Created on Jun 16, 2003
 *
 */
package gov.va.med.vistalink.adapter.spi;

import java.io.Serializable;

/**
 * 
 * Enumeration to identify the environment(J2SE/J2EE) that this adapter is
 * running in
 * 
 */
public class EMAdapterEnvironment implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1641425049939935561L;

	/**
	 * the integer value of the adapter environment state
	 */
	private final int adapterEnvironment;

	/**
	 * the string representation of the adapter environment state
	 */
	private final String adapterEnvironmentStringValue;

	/**
	 * Integer value that represents a J2SE adapter environment
	 */
	private static final int INT_J2SE = 1;

	/**
	 * Integer value that represents a J2EE adapter environment
	 */
	private static final int INT_J2EE = 2;

	/**
	 * String representation of a J2SE adapter environment
	 */
	private static final String STRING_J2SE = "J2SE";

	/**
	 * String representation of a J2EE adapter environment
	 */
	private static final String STRING_J2EE = "J2EE";

	/**
	 * represents a J2SE adapter environment
	 */
	public static final EMAdapterEnvironment J2SE = new EMAdapterEnvironment(INT_J2SE);

	/**
	 * represents a J2EE adapter environment
	 */
	public static final EMAdapterEnvironment J2EE = new EMAdapterEnvironment(INT_J2EE);

	/**
	 * private Constructor
	 * 
	 * @param adapterEnvironment -
	 *            the adapter environment
	 */
	private EMAdapterEnvironment(int adapterEnvironment) {
		this.adapterEnvironment = adapterEnvironment;

		String stringAdapterEnvironment = null;

		switch (adapterEnvironment) {
		case INT_J2SE:
			stringAdapterEnvironment = STRING_J2SE;
			break;
		case INT_J2EE:
			stringAdapterEnvironment = STRING_J2EE;
			break;
		default:
			stringAdapterEnvironment = null;
			break;
		}

		adapterEnvironmentStringValue = stringAdapterEnvironment;

	}

	/**
	 * Gets the integer value of the authentication state. Used internally for
	 * comparisons.
	 * 
	 * @return integer value
	 */
	private int getValue() {

		return adapterEnvironment;

	}

	/*
	 * (non-Javadoc) returns string representation of re-authentication state
	 * 
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return adapterEnvironmentStringValue;
	}

	/*
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object obj) {
		if (obj instanceof EMAdapterEnvironment) {
			return ((((EMAdapterEnvironment) obj).getValue()) == (this.getValue()));
		} else {
			return false;
		}
	}

	/**
	 * return hashcode
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		// algorithm taken from "Effective Java" item #8.
		int HASHCODE_SEED = 17;
		int returnVal = HASHCODE_SEED;

		// getValue contribution to hashcode
		int valueHashCode = getValue();
		returnVal = 37 * returnVal + valueHashCode; 

		return returnVal;
	}

}