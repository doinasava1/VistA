/*
 * Created on Nov 26, 2003
 *
 */
package gov.va.med.vistalink.adapter.spi;

/**
 * Enumeration class to enumerate adapter statuses.
 * 
 */
public class EMAdapterStatus {

	/**
	 * the integer value of the adapter status
	 */
	private final int adapterStatus;

	/**
	 * the string representation of the adapter status
	 */
	private final String adapterStatusStringValue;

	/**
	 * Integer value that represents a constructing status
	 */
	private static final int INT_CONSTRUCTING = 1;

	/**
	 * Integer value that represents a destructing status
	 */
	private static final int INT_DESTRUCTING = 2;

	/**
	 * Integer value that represents a cleanup status
	 */
	private static final int INT_CLEANUP = 3;

	/**
	 * Integer value that represents a Normal running status
	 */
	private static final int INT_RUNNING = 0;

	/**
	 * String value that represents a constructing status
	 */
	private static final String STRING_CONSTRUCTING = "constructing";

	/**
	 * String value that represents a destructing status
	 */
	private static final String STRING_DESTRUCTING = "destructing";

	/**
	 * String value that represents a cleanup status
	 */
	private static final String STRING_CLEANUP = "cleanup";

	/**
	 * String value that represents a Normal running status
	 */
	private static final String STRING_RUNNING = "running";

	/**
	 * represents a constructing state
	 */
	public static final EMAdapterStatus CONSTRUCTING = new EMAdapterStatus(INT_CONSTRUCTING);

	/**
	 * represents a destructing state
	 */
	public static final EMAdapterStatus DESTROYING = new EMAdapterStatus(INT_DESTRUCTING);

	/**
	 * represents a cleanup state
	 */
	public static final EMAdapterStatus CLEANUP = new EMAdapterStatus(INT_CLEANUP);

	/**
	 * represents a virgin state for re-authentication
	 */
	public static final EMAdapterStatus RUNNING = new EMAdapterStatus(INT_RUNNING);

	/**
	 * private Constructor
	 * 
	 * @param adapterStatus adapter status 
	 */
	private EMAdapterStatus(int adapterStatus) {
		this.adapterStatus = adapterStatus;

		String stringAdapterStatus = null;

		switch (adapterStatus) {
		case INT_CONSTRUCTING:
			stringAdapterStatus = STRING_CONSTRUCTING;
			break;
		case INT_DESTRUCTING:
			stringAdapterStatus = STRING_DESTRUCTING;
			break;
		case INT_CLEANUP:
			stringAdapterStatus = STRING_CLEANUP;
			break;
		case INT_RUNNING:
			stringAdapterStatus = STRING_RUNNING;
			break;
		default:
			stringAdapterStatus = null;
			break;
		}

		adapterStatusStringValue = stringAdapterStatus;

	}

	/**
	 * gets the integer value of the authentication state used internally for
	 * comparisons
	 * 
	 * @return integer value
	 */
	private int getValue() {

		return adapterStatus;

	}

	/*
	 * (non-Javadoc) returns string representation of re-authentication state
	 * 
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return adapterStatusStringValue;
	}

	/*
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object obj) {
		if (obj instanceof EMAdapterStatus) {
			return (boolean) ((((EMAdapterStatus) obj).getValue()) == (this.getValue()));
		} else {
			return false;
		}
	}

	/**
	 * return hashcode
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		// algorithm taken from "Effective Java" item #8.
		int HASHCODE_SEED = 17;
		int returnVal = HASHCODE_SEED;

		// getValue contribution to hashcode
		int valueHashCode = getValue();
		returnVal = 37 * returnVal + valueHashCode; 

		return returnVal;
	}

}