package gov.va.med.vistalink.adapter.record;

/**
 * Base strategy interface for determining if request should be re-executed
 * 
 */
public interface VistaLinkRequestRetryStrategy {

	/**
	 * Determines if it is ok to retry executing the request after it the failed to complete
	 * because of a socket error or other system type problem.
	 * 
	 * @param request VistaLinkRequestVO instance reference for the request
	 * @return boolean that indicates 1) true == attempt retry or 2) false == do not attempt retry 
	 */
	boolean execute(VistaLinkRequestVO request);
}
