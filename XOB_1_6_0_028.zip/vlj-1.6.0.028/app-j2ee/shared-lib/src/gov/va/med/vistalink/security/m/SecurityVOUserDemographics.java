package gov.va.med.vistalink.security.m;

import java.util.Hashtable;

/**
 * Logon-related value object to hold results of a 'get user demographics' call.
 * 
 */
public class SecurityVOUserDemographics extends SecurityVO {

	private Hashtable userDemographicsHashtable;

	/**
	 * Constructor.
	 * @param resultType Success, Failure or Partial Success (types defined in parent class) 
	 * @param resultMessage optional explanatory description for the result, usually used for failure and partial success only
	 */
	public SecurityVOUserDemographics(int resultType, String resultMessage) {
		super(resultType, resultMessage);
	}
	
	/**
	 * Returns a hash table ostensibly containing user demographics information. The user demographics
	 * information should be stored as Strings, using String keys provided in the VistaKernelPrincipal
	 * class.
	 * @return Hashtable populated with user demographics
	 * @see VistaKernelPrincipal
	 * @see gov.va.med.vistalink.security.VistaKernelPrincipalImpl
	 */
	public Hashtable getUserDemographicsHashtable() {
		//clone to avoid exposing internal implementation. 
		return (Hashtable) userDemographicsHashtable.clone();
	}
	
	/**
	 * Sets a hash table ostensibly containing user demographics information. The user demographics
	 * information should be stored as Strings, using String keys provided in the VistaKernelPrincipal
	 * class.
	 * @param userDemographicsHashtable Hashtable populated with user demographics
	 * @see VistaKernelPrincipal
	 * @see gov.va.med.vistalink.security.VistaKernelPrincipalImpl
	 */
	public void setUserDemographicsHashtable(Hashtable userDemographicsHashtable) {
		//clone to avoid exposing internal implementation. 
		this.userDemographicsHashtable = (Hashtable) userDemographicsHashtable.clone();
	}
}
