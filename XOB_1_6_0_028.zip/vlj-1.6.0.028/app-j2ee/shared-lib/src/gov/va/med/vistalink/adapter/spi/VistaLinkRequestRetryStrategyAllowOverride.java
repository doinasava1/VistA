package gov.va.med.vistalink.adapter.spi;

import gov.va.med.vistalink.adapter.record.VistaLinkRequestRetryStrategy;
import gov.va.med.vistalink.adapter.record.VistaLinkRequestVO;

import org.apache.log4j.Logger;

/**
 * Determines if the request should be retried based on the timeout value of the M listener.
 * 
 */
public class VistaLinkRequestRetryStrategyAllowOverride implements VistaLinkRequestRetryStrategy {
    /**
     * The logger used by this class
     */
    private static final Logger logger = Logger.getLogger(VistaLinkRequestRetryStrategyAllowOverride.class);

     private VistaLinkManagedConnection mc = null;

    protected VistaLinkRequestRetryStrategyAllowOverride(VistaLinkManagedConnection mc) {
        this.mc = mc;
    }

    /*
     * (non-Javadoc)
     * 
     * @see gov.va.med.vistalink.adapter.record.VistaLinkRequestRetryStrategy#execute(gov.va.med.vistalink.adapter.record.VistaLinkRequestVO)
     */
    public boolean execute(VistaLinkRequestVO request) {
         return automaticRequestRetry();
    }

    /**
     * Determines if the request should be retried based on the timeout value of the M listener.
     * If the time from the last successful interaction is more than the timeout value then a retry
     * should be attempted. The socket probably has timed out.
     * 
     * @return boolean indicator on whether retry should automatically be attempt
     */
    private boolean automaticRequestRetry() {
        long currentTime = System.currentTimeMillis();
        long lastExecuteTime = mc.getLastInteractionTimeMillis();
        long mTimeout = mc.getHeartBeatRate();
        if (logger.isDebugEnabled()) {
            logger.debug(new StringBuffer().append("\n\tRetry Current Time: \t").append(currentTime).append(
                    "\n\tLast Execution Time: \t").append(lastExecuteTime).append("\n\tDifference: \t").append(
                    currentTime - lastExecuteTime).append("\n\tThreshold: \t").append(mTimeout)
                    .toString());
        }
        if ((currentTime - lastExecuteTime) > mTimeout) {
            return true;
        }
        return false;
    }
}