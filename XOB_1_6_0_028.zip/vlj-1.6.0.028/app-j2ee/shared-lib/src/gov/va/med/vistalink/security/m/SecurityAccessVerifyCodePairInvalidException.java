package gov.va.med.vistalink.security.m;

import gov.va.med.vistalink.adapter.record.VistaLinkFaultException;

/**
 * Represents an authentication failure during an access/verify code-based re-authentication attempt, 
 * where either the access code, verify code (or both) authentication credentials are invalid.
 */
public class SecurityAccessVerifyCodePairInvalidException extends SecurityFaultException {

	/**
	 * @param vistaLinkFaultException
	 * @va.exclude
	 */
	public SecurityAccessVerifyCodePairInvalidException(VistaLinkFaultException vistaLinkFaultException) {
		super(vistaLinkFaultException);
	}

}
