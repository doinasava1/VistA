package gov.va.med.vistalink.management;

import java.rmi.RemoteException;
import java.util.Map;

import javax.management.ObjectName;

/**
 * 
 * MBean interface for the per-connection-factory VistALink management bean.
 * 
 */
public interface VistaLinkConnectorMBean {

	/**
	 * 
	 * @return system-specific ObjectName of connector's connector MBean linked to this VistALink MBean
	 */
	ObjectName getContainerMBeanName();

	/**
	 * 
	 * @return IP address from VistALink configuration file used for this connector
	 */
	String getCfgIpAddress();

	/**
	 * 
	 * @return port from VistALink configuration file used for this connector
	 */
	int getCfgPort();

	/**
	 * 
	 * @return timeout from VistALink configuration file used for this connector
	 */
	long getCfgTimeout();

	/**
	 * 
	 * @return whether a lower timeout can be set by applications than the configured timeout, from VistALink configuration file used for this connector
	 */
	boolean isCfgTimeoutAlwaysUseDefaultAsMin();

	/**
	 * 
	 * @return unique, internally managed distinguished identifier for the VistALink connector 
	 */
	long getDistinguishedIdentifier();

	/**
	 * 
	 * @return number of connector proxy authentication failures for this connector, since last system startup or deployment
	 */
	long getHlthConnectionAuthFailureCount();

	/**
	 * 
	 * @return number of TCP-level connection failures for this connector, since last system startup or deployment
	 */
	long getHlthConnectionFailureCount();

	/**
	 * 
	 * @return number of mismatches between connector primaryStation setting and target M system's primary station, since last system startup or deployment
	 */
	long getHlthDivisionMismatchCount();

	/**
	 * 
	 * @return number of re-authentication identification failures (failure to match requested DUZ, Application Proxy or VPID on M system), since last system startup or deployment
	 */
	long getHlthIdentityFailureCount();

	/**
	 * 
	 * @return number of mismatches between J2EE server's and M server's production setting, since last system startup or deployment
	 */
	long getHlthProductionMismatchCount();

	/**
	 * 
	 * @return The amount of time it takes for a VistaLink managed connection to create a new connection handle for the underlying physical connection represented by the ManagedConnection instance; this connection handle is used by the application code to refer to the underlying physical connection
	 */
	double getPerfCreateConnectionHandleAvgMillis();

	/**
	 * 
	 * @return The amount of time it takes for the VistaLink connection factory to either a) match a connection request with an existing connection in pool of managed connections, or b) determine that no such match exists
	 */
	double getPerfMatchManagedConnectionAvgMillis();

	/**
	 * 
	 * @return the EISType of the connector (for VistALink connectors, should always be 'VistA')
	 * @throws RemoteException thrown if unable returns this information (obtained from another MBean)
	 */
	String getEisType() throws RemoteException;

	/**
	 * 
	 * @return the JNDI name used to register the connector in the JNDI tree of the server
	 */
	String getJndiNameActual();

	/**
	 * 
	 * @return the value of the connectorJndiName custom ra.xml property 
	 */
	String getJndiNameCustomProp();

	/**
	 * 
	 * @return the current deployment state of the connector (platform-specific string)
	 * @throws RemoteException thrown if unable returns this information (obtained from another MBean) 
	 */
	String getDeploymentState() throws RemoteException;

	/**
	 * 
	 * @return a Map containing vendor-specific properties and values
	 * @throws RemoteException thrown if unable returns this information (obtained from other MBeans)
	 */
	Map getVendorSpecificProperties() throws RemoteException;

	/**
	 * 
	 * @return returns a Map containing a set of string keys and values obtained from calling the M system.
	 */
	Map getQueryMSystemMap();

	/**
	 * 
	 * @return a formatted string array report representing a set of properties and values obtained from calling the M system
	 */
	String[] getQueryMSystemReport();

	/**
	 * 
	 * @return a formatted string array listing the institutions currently mapped to this connector
	 */
	String[] getQueryMappedInstitutions();

}
