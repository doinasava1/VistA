package gov.va.med.vistalink.adapter.spi;

import gov.va.med.net.VistaSocketException;
import gov.va.med.net.VistaSocketTimeOutException;
import gov.va.med.vistalink.adapter.cci.VistaLinkConnection;
import gov.va.med.vistalink.adapter.cci.VistaLinkConnectionMetaData;
import gov.va.med.vistalink.adapter.cci.VistaLinkConnectionSpecImpl;
import gov.va.med.vistalink.adapter.cci.VistaLinkResourceException;
import gov.va.med.vistalink.adapter.heartbeat.HeartBeatInitializationFailedException;
import gov.va.med.vistalink.adapter.record.VistaLinkFaultException;
import gov.va.med.vistalink.adapter.record.VistaLinkRequestVO;
import gov.va.med.vistalink.adapter.record.VistaLinkResponseFactory;
import gov.va.med.vistalink.adapter.record.VistaLinkResponseFactoryImpl;
import gov.va.med.vistalink.adapter.record.VistaLinkResponseVO;
import gov.va.med.vistalink.rpc.RpcRequest;
import gov.va.med.vistalink.rpc.RpcResponse;
import gov.va.med.vistalink.rpc.RpcResponseFactory;
import gov.va.med.vistalink.security.m.KernelSecurityHandshakeManaged;
import gov.va.med.vistalink.security.m.SecurityDataLogonResponse;
import gov.va.med.vistalink.security.m.SecurityDivisionDeterminationFaultException;
import gov.va.med.vistalink.security.m.SecurityIdentityDeterminationFaultException;
import gov.va.med.vistalink.security.m.SecurityProductionMismatchException;
import gov.va.med.vistalink.security.m.SecurityResponseFactory;
import gov.va.med.vistalink.security.m.SecurityVO;
import gov.va.med.crypto.VistaKernelHashCountLimitExceededException;
import gov.va.med.environment.Environment;
import gov.va.med.exception.ExceptionUtils;
import gov.va.med.exception.FoundationsException;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.resource.NotSupportedException;
import javax.resource.ResourceException;
import javax.resource.cci.ConnectionMetaData;
import javax.resource.spi.ConnectionEvent;
import javax.resource.spi.ConnectionEventListener;
import javax.resource.spi.ConnectionRequestInfo;
import javax.resource.spi.LocalTransaction;
import javax.resource.spi.ManagedConnection;
import javax.resource.spi.ManagedConnectionMetaData;
import javax.security.auth.Subject;
import javax.transaction.xa.XAResource;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

/**
 * This class represents a managed connection to M
 * 
 */
public class VistaLinkManagedConnection implements ManagedConnection {
	/**
	 * constant value indicating that the managed connection can allocate unlimited connection handles
	 */
	private static final int UNLIMITED_CONNECTION_HANDLES = -1;

	/**
	 * constant error message indicating there are no more available connection handles
	 */
	private static final String EXCEPTION_CONNECTION_HANDLES_EXCEEDED = "There are no available connection handles.";

	/**
	 * The logger used by this class
	 */
	private static final Logger logger = Logger.getLogger(VistaLinkManagedConnection.class);

	/**
	 * The event notifier this class will use to notify event listeners of CONNECTION_CLOSED and
	 * CONNECTION_ERROR_OCCURRED events
	 */
	private VistaLinkConnectionEventNotifier connectionEventNotifer;

	/**
	 * The managed connection factory that constructed this managedConnection
	 */
	private VistaLinkManagedConnectionFactory managedConnectionFactory;

	/**
	 * The log writer specified by the Application server
	 */
	private PrintWriter logWriter;

	/**
	 * A set to contain all allocated connection handles
	 */
	private Set conSet;

	/**
	 * Cache the classes' hashcode
	 */
	private int hashCode;

	/**
	 * The raw socket connection to the host M Server
	 */
	private VistaSocketConnection socketCon;

	/**
	 * Indicates whether this managed connection is valid. Will be true if the socket has been created and the managed
	 * connection has been added to the HeartBeatManager Will be false if he socket failed to create, or a socket
	 * transfer failed, or the socket has been removed from the HeartBeatManager
	 */
	private boolean valid;

	private EMAdapterStatus adapterStatus;

	/**
	 * Indicates the last time an RPC was successfully executed
	 */
	private long lastTimeRpcExecutedMillis;

	/**
	 * Strategy that determines if retry should occur regardless of request strategy
	 */
	private VistaLinkRequestRetryStrategyAllowOverride allowOverrideStrategy = null;

	/**
	 * Indicates the last time an interaction with the host M Server was executed
	 */
	private long lastInteractionTimeMillis;

	/**
	 * The connection request info used by this class for re-authentication
	 */
	private VistaLinkConnectionRequestInfo connReqInfo = null;

	/**
	 * indicates the state of the re-authentication
	 */
	EMReAuthState reAuthState;

	private long distinguishedIdentifier;

	/**
	 * The rate at which the heart beat will be scheduled (in milliseconds)
	 */
	private long heartBeatRate = 0;

	/**
	 * constant value indicating M $JOB value not yet set
	 */
	private static final String INITIAL_M_JOB_VALUE = "[Not Set]";

	/**
	 * constant value indicating M $JOB value not yet set
	 */
	private static final String RESETTING_M_JOB_VALUE = "[Resetting...]";

	/**
	 * M $JOB value for connection or INITIAL_M_JOB_VALUE
	 */
	private String mJob = INITIAL_M_JOB_VALUE;

	/**
	 * The reauthentication session timeout in millis
	 */
	private long reAuthSessionTimeout;

	/**
	 * The time out value used (in milliseconds) when performing socket reads
	 */
	private long socketTimeOut = 5000;

	/**
	 * Constructs this instance of the managed connection. Creates a new raw socket connection with timeout. Adds this
	 * managed connection to the Heart beat timer. Sets the socketTimeout property.
	 * 
	 * @param mcf - the managed connection factory that created this managed connection
	 * @throws VistaLinkResourceException
	 */
	protected VistaLinkManagedConnection(VistaLinkManagedConnectionFactory mcf, long distinguishedIdentifier)
			throws VistaLinkResourceException {

		// set mcf, distinguished id, hashcode first
		setManagedConnectionFactory(mcf);
		this.distinguishedIdentifier = distinguishedIdentifier;
		setHashCode();

		setDefaultSocketTimeOut();
		if (logger.isDebugEnabled()) {
			String debugMsg = getLoggerFormattedString("Constructing");
			logger.debug(debugMsg);
		}
		conSet = Collections.synchronizedSet(new HashSet());
		this.allowOverrideStrategy = new VistaLinkRequestRetryStrategyAllowOverride(this);
		connectionEventNotifer = new VistaLinkConnectionEventNotifier();
		// get authenticated connection
		try {
			// createAuthenticatedConnection() is responsible for
			// creating, and authenticating the socket. if the authentication
			// process fails then this method also sends a close request to M
			createAuthenticatedConnection();
		} catch (VistaLinkResourceException e) {
			if (logger.isEnabledFor(Level.ERROR)) {
				/*
				 * Minimized error logging 9/27/07 Kyle
				 * exceptions will have full stack trace logged by createAuthenticatedConnection() depending on log4j config
				 * -- just clutters logs to put full stack trace in twice.
				 */
//				String errMsg = getLoggerFormattedStringWStackTrace(e);
//				logger.error(errMsg);
				logger.error(e.getMessage());
			}
			setValid(false);
			// These statements were added to ensure that a close request is
			// sent
			// to any connected non-null socket
			// More than likely the socket will be null and only the line
			// to determine is socketCon != null will be executed
			try {
				if (socketCon != null) {
					if (logger.isEnabledFor(Level.ERROR)) {
						String errorMsg = getLoggerFormattedString("Attempting to close socket that should already be closed, check implementation");
						logger.error(errorMsg);
					}
					socketCon.close();
				}
			} catch (VistaSocketException socex) {
				throw new VistaLinkResourceException("could not close managed connection, check the implementation",
						new VistaLinkResourceException(ExceptionUtils.getFullStackTrace(socex), e));
			} finally {
				socketCon = null;
			}
			throw e;
		}
		// add to timer task
		try {
			addToTimerTask();
		} catch (VistaLinkResourceException e1) {
			if (logger.isEnabledFor(Level.ERROR)) {
				String errMsg = getLoggerFormattedStringWStackTrace(e1);
				logger.error(errMsg);
			}
			try {
				destroy();
			} catch (ResourceException e2) {
				throw new VistaLinkResourceException("could not destroy managed connection",
						new VistaLinkResourceException(ExceptionUtils.getFullStackTrace(e2), e1));
			}
			throw e1;
		}
		// set states
		setReAuthState(EMReAuthState.VIRGIN);
		adapterStatus = EMAdapterStatus.RUNNING;
	}

	private void executeInitSocketInteraction() throws VistaLinkResourceException {
		try {
			if (logger.isDebugEnabled()) {
				logger.debug(getLoggerFormattedString("Executing Init Socket interaction"));
			}
			VistaLinkInitSocketRequest req = new VistaLinkInitSocketRequest(getAdapterEnvironment());
			VistaLinkInitSocketResponseFactory resFac = new VistaLinkInitSocketResponseFactory();
			VistaLinkInitSocketResponse resp = (VistaLinkInitSocketResponse) this.executeInteraction(req, resFac);
			setHeartBeatRate(resp.getHeartBeatRateMillis());
			setMJob(resp.getMJob());
			setReAuthSessionTimeout(resp.getReAuthSessionTimeout());
		} catch (VistaLinkFaultException e) {
			throw new VistaLinkResourceException("VistaLinkFaultException in executeInitSocketInteraction.", e);
		} catch (FoundationsException e) {
			throw new VistaLinkResourceException("FoundationsException in executeInitSocketInteraction.", e);
		}
	}

	/**
	 * This method is responsible for creating and authenticating the socket If authentication fails then this method
	 * will send a close request to M If any additional functionality is added that makes use if a valid socket, ie a
	 * socket that has passed construction, make sure to add cleanup code in the catch
	 * 
	 * @throws VistaLinkResourceException
	 */
	private void createAuthenticatedConnection() throws VistaLinkResourceException {
		adapterStatus = EMAdapterStatus.CONSTRUCTING;
		socketCon = null;
		
		try {
			socketCon = new VistaSocketConnection(getManagedConnectionFactory().getHostIpAddressResolvedWithException(), getHostPort(), this.toString());
		} catch (VistaLinkResourceException e) {
			Throwable e1 = e.getCause();
			if (e1 instanceof UnknownHostException) {
				managedConnectionFactory.incrementConnectionFailureCount();
			}
			throw e;
		} catch (VistaSocketException e) {
			String errStr = "Can not create VistaSocketConnection";

			/*
			 * Minimized error logging 9/27/07 Kyle
			 * exceptions will have full stack trace logged by VistaSocketConnection() depending on log4j config
			 * -- just clutters logs to put full stack trace in twice.
			 */
			if (logger.isEnabledFor(Level.ERROR)) {
//				String errMsg = getLoggerFormattedStringWStackTrace(errStr, e);
//				logger.error(errMsg);
				logger.error(e.getMessage());
			}
			logger.debug("about to increment connection failure count due to no path to listener.");
			// increment health monitoring
			if (getAdapterEnvironment() != null) {
				if (getAdapterEnvironment().equals(EMAdapterEnvironment.J2EE)) {
					managedConnectionFactory.incrementConnectionFailureCount();
				}
			}
			throw new VistaLinkResourceException(errStr, e);
		}
		setValid(true);
		try {
			// if any exceptions occur in the smaller try's
			// a close() will be sent to M in the big catch block
			try {
				if (getAdapterEnvironment() != null) {
					executeInitSocketInteraction();
					if (getAdapterEnvironment().equals(EMAdapterEnvironment.J2EE)) {
						performInitialAuthenticationSetup();
						performInitialAuthenticationLogon(getAccessCode(), getVerifyCode(), false);
					}
				} else {
					String errMsg = "The adapter environment is null, cannot determine if initial authentication is needed. ";
					if (logger.isEnabledFor(Level.ERROR)) {
						errMsg = getLoggerFormattedString(errMsg);
						logger.error(errMsg);
					}
					throw new VistaLinkResourceException(errMsg);
				}
			} catch (VistaLinkResourceException e) {

				// increment health monitoring
				if (getAdapterEnvironment() != null) {
					if (getAdapterEnvironment().equals(EMAdapterEnvironment.J2EE)) {
						// don't increment if it's a prod mismatch, already
						// incremented its own counter
						if ((e.getLinkedException() == null)
								|| (!(e.getLinkedException() instanceof SecurityProductionMismatchException))) {
							managedConnectionFactory.incrementConnectionAuthFailureCount();
						}
					}
				}
				
				/*
				 * Disabled error logging 9/27/07 Kyle
				 * exceptions will always be logged by performInitialAuthenticationSetup() or
				 * performInitialAuthenticationLogon() which are also in this class -- 
				 * just clutters logs to put full stack trace in twice.
				 */
				
//				if (logger.isEnabledFor(Level.ERROR)) {
//					String errMsg = getLoggerFormattedStringWStackTrace(e);
//					logger.error(errMsg);
//					logger.error(e.getMessage());
//				}
				throw e;
			}
		} catch (VistaLinkResourceException e) {
			// send close() because the connection is open and needs to be
			// closed
			try {
				if (socketCon != null) {
					socketCon.close();
				}
			} catch (VistaSocketException socex) {
				throw new VistaLinkResourceException("could not close managed connection",
						new VistaLinkResourceException(ExceptionUtils.getFullStackTrace(socex), e));
			} finally {
				socketCon = null;
			}
			throw e;
		}
		adapterStatus = EMAdapterStatus.RUNNING;
	}

	/**
	 * Executes the interaction to setup M for authentication
	 * 
	 * @throws VistaLinkResourceException
	 */
	private void performInitialAuthenticationSetup() throws VistaLinkResourceException {
		try {
			if (logger.isDebugEnabled()) {
				String debugMsg = getLoggerFormattedString("Setting up authentication");
				logger.debug(debugMsg);
			}
			
			KernelSecurityHandshakeManaged.doSetupAndGetIntroText(this, new SecurityResponseFactory(), true, Boolean
					.valueOf(Environment.isProduction()), managedConnectionFactory.getPrimaryStation());

		} catch (SecurityProductionMismatchException e) {
			// will be logged higher up
			// increment health monitoring
			if (getAdapterEnvironment() != null) {
				if (getAdapterEnvironment().equals(EMAdapterEnvironment.J2EE)) {
					managedConnectionFactory.incrementProductionMismatchCount();
				}
			}
			throw new VistaLinkResourceException("Can not perform setup", e);
		} catch (VistaLinkFaultException e) {
			String errStr = "Can not perform setup";
			if (logger.isEnabledFor(Level.ERROR)) {
				String errMsg = getLoggerFormattedStringWStackTrace(errStr, e);
				logger.error(errMsg);
			}
			throw new VistaLinkResourceException(errStr, e);
		} catch (ParserConfigurationException e) {
			String errStr = "Can not perform setup";
			if (logger.isEnabledFor(Level.ERROR)) {
				String errMsg = getLoggerFormattedStringWStackTrace(errStr, e);
				logger.error(errMsg);
			}
			throw new VistaLinkResourceException(errStr, e);
		} catch (FoundationsException e) {
			String errStr = "Can not perform setup";
			if (logger.isEnabledFor(Level.ERROR)) {
				String errMsg = getLoggerFormattedStringWStackTrace(errStr, e);
				logger.error(errMsg);
			}
			throw new VistaLinkResourceException(errStr, e);
		}
	}

	/**
	 * Executes the interaction to perform first phase authentication
	 * 
	 * @param accessCode
	 * @param verifyCode
	 * @param requestCvc
	 * @throws VistaLinkResourceException
	 */
	private void performInitialAuthenticationLogon(String accessCode, String verifyCode, boolean requestCvc)
			throws VistaLinkResourceException {
		try {
			if (logger.isDebugEnabled()) {
				String debugMsg = getLoggerFormattedString("executing first phase logon");
				logger.debug(debugMsg);
			}
			SecurityDataLogonResponse responseData = KernelSecurityHandshakeManaged.doAVLogon(this,
					new SecurityResponseFactory(), accessCode, verifyCode, requestCvc);
			// need to change verify code or select a division
			if (responseData.getResultType() == SecurityVO.RESULT_PARTIAL) {
				// change verify code
				if (responseData.getSecurityVOLogon().getNeedNewVerifyCode()) {
					String errStr = "Need new Verify Code: " + responseData.getSecurityVOLogon().getNeedNewVerifyCode()
							+ " Need to select Divisions: "
							+ responseData.getSecurityVOLogon().getNeedDivisionSelection();
					if (logger.isDebugEnabled()) {
						logger.debug(getLoggerFormattedString(errStr));
					}
					throw new VistaLinkResourceException(errStr);
				} else if (responseData.getSecurityVOLogon().getNeedDivisionSelection()) {
					// change verify code
					String errStr = "Need new Verify Code: " + responseData.getSecurityVOLogon().getNeedNewVerifyCode()
							+ " Need to select Divisions: "
							+ responseData.getSecurityVOLogon().getNeedDivisionSelection();
					if (logger.isDebugEnabled()) {
						logger.debug(getLoggerFormattedString(errStr));
					}
					throw new VistaLinkResourceException(errStr);
				} else {
					throw new VistaLinkResourceException(
							"Logon response was partial success, but M provided no reason for why login is only a partial success!");
				}
			} else if (responseData.getResultType() == SecurityVO.RESULT_SUCCESS) {
				// if got here, original signon was successful
				setReAuthState(EMReAuthState.NOTAUTHENTICATED);
				return;
			} else {
				throw new VistaLinkResourceException("Could not perform logon[]" + responseData.getResultMessage());
			}
		} catch (VistaKernelHashCountLimitExceededException e) {
			String errStr = "Could not perform Logon";
			if (logger.isEnabledFor(Level.ERROR)) {
				String errMsg = getLoggerFormattedStringWStackTrace(errStr, e);
				logger.error(errMsg);
			}
			throw new VistaLinkResourceException(errStr, e);
		} catch (ParserConfigurationException e) {
			String errStr = "Could not perform Logon";
			if (logger.isEnabledFor(Level.ERROR)) {
				String errMsg = getLoggerFormattedStringWStackTrace(errStr, e);
				logger.error(errMsg);
			}
			throw new VistaLinkResourceException(errStr, e);
		} catch (FoundationsException e) {
			String errStr = "Could not perform Logon";
			if (logger.isEnabledFor(Level.ERROR)) {
				String errMsg = getLoggerFormattedStringWStackTrace(errStr, e);
				logger.error(errMsg);
			}
			throw new VistaLinkResourceException(errStr, e);
		}
	}

	/**
	 * Performs VistA security logout and returns indicator on whether M/VistA server needs to have a 'close socket'
	 * request sent. (It is possible that that socket connection has been closed by the M/VistA server due to a time out
	 * condition. As a result, the M/VistA server would not require a security logout nor a close socket request.)
	 * 
	 * @return Boolean indicates whether the M/VistA server needs to have a 'Close Socket' request sent
	 * @throws VistaLinkResourceException
	 */
	private boolean performLogout() throws VistaLinkResourceException {
		try {
			if (logger.isDebugEnabled()) {
				String debugMsg = getLoggerFormattedString("Executing logout");
				logger.debug(debugMsg);
			}
			KernelSecurityHandshakeManaged.doLogout(this, new SecurityResponseFactory());
		} catch (VistaLinkSocketAlreadyClosedException e) {
			if (logger.isEnabledFor(Level.DEBUG)) {
				String loggerMsg = getLoggerFormattedString("This socket is already closed, no need to logout");
				logger.debug(loggerMsg);
			}
			return false;
		} catch (VistaLinkFaultException e) {
			String errStr = "Could not perform Logout";
			if (logger.isEnabledFor(Level.ERROR)) {
				String errMsg = getLoggerFormattedStringWStackTrace(errStr, e);
				logger.error(errMsg);
			}
			throw new VistaLinkResourceException(errStr, e);
		} catch (ParserConfigurationException e) {
			String errStr = "Could not perform Logout";
			if (logger.isEnabledFor(Level.ERROR)) {
				String errMsg = getLoggerFormattedStringWStackTrace(errStr, e);
				logger.error(errMsg);
			}
			throw new VistaLinkResourceException(errStr, e);
		} catch (FoundationsException e) {
			String errStr = "Could not perform Logout";
			if (logger.isEnabledFor(Level.ERROR)) {
				String errMsg = getLoggerFormattedStringWStackTrace(errStr, e);
				logger.error(errMsg);
			}
			throw new VistaLinkResourceException(errStr, e);
		} catch (ResourceException e) {
			String errStr = "Could not perform Logout";
			if (logger.isEnabledFor(Level.ERROR)) {
				String errMsg = getLoggerFormattedStringWStackTrace(errStr, e);
				logger.error(errMsg);
			}
			throw new VistaLinkResourceException(errStr, e);
		} catch (IOException e) {
			String errStr = "Could not perform Logout";
			if (logger.isEnabledFor(Level.ERROR)) {
				String errMsg = getLoggerFormattedStringWStackTrace(errStr, e);
				logger.error(errMsg);
			}
			throw new VistaLinkResourceException(errStr, e);
		}
		return true;
	}

	/**
	 * Adds a connection event listener to the event notifier for this managed connection
	 * 
	 * @param listener - the ConnectionEventListener to add
	 * @see javax.resource.spi.ManagedConnection#addConnectionEventListener(javax.resource.spi.ConnectionEventListener)
	 */
	public void addConnectionEventListener(ConnectionEventListener listener) {
		if (logger.isDebugEnabled()) {
			String debugMsg = getLoggerFormattedString("addConnectionEventListener");
			logger.debug(debugMsg);
		}
		connectionEventNotifer.addConnectorListener(listener);
	}

	/**
	 * Removes a connection event listener from the event notifier for this managed connection
	 * 
	 * @param listener - the ConnectionEventListener to remove
	 * @see javax.resource.spi.ManagedConnection#removeConnectionEventListener(javax.resource.spi.ConnectionEventListener)
	 */
	public void removeConnectionEventListener(ConnectionEventListener listener) {
		if (logger.isDebugEnabled()) {
			String debugMsg = getLoggerFormattedString("removeConnectionEventListener");
			logger.debug(debugMsg);
		}
		connectionEventNotifer.removeConnectorListener(listener);
	}

	/**
	 * Returns true if number of Connection Handles of this instance of the VistaLinkManagedCoonection is less than the
	 * Max number allotted
	 * 
	 * @return boolean
	 */
	protected boolean isConnectionHandleAvailable() {
		if (getMaxConnectionHandles() == UNLIMITED_CONNECTION_HANDLES) {
			return true;
		}
		if (conSet.size() < getMaxConnectionHandles()) {
			return true;
		}
		return false;
	}

	/**
	 * Adds a VistaLinkConnection object (handle) to conSet
	 * 
	 * @param con - the connection handle to add
	 * @throws ConnectionHandlesExceededException - thrown if maximum number of allowable VistaLinkConnection handles
	 *             has been reached
	 */
	private void addConHandle(VistaLinkConnection con) throws ConnectionHandlesExceededException {
		if (logger.isDebugEnabled()) {
			String debugMsg = getLoggerFormattedString("addConHandle");
			logger.debug(debugMsg);
		}
		if (isConnectionHandleAvailable()) {
			conSet.add(con);
		} else {
			String errStr = (new StringBuffer()).append(EXCEPTION_CONNECTION_HANDLES_EXCEEDED).append("[").append(
					getMaxConnectionHandles()).append("]").toString();
			throw new ConnectionHandlesExceededException(errStr);
		}
	}

	/**
	 * Removes the connection Handle from conSet
	 * 
	 * @param con - the connection handle to remove
	 */
	private synchronized void removeConHandle(VistaLinkConnection con) {
		if (logger.isDebugEnabled()) {
			String debugMsg = getLoggerFormattedString("removeConHandle");
			logger.debug(debugMsg);
		}
		conSet.remove(con);
	}

	/**
	 * Used by the container to change the association of an application-level connection handle with a
	 * ManagedConnection instance. The container should find the right ManagedConnection instance and call the
	 * associateConnection method.
	 * 
	 * @param connection Application-level connection handle
	 * @throws ResourceException
	 * @see javax.resource.spi.ManagedConnection#associateConnection(java.lang.Object)
	 */
	public void associateConnection(Object connection) throws ResourceException {
		try {
			if (logger.isDebugEnabled()) {
				String debugMsg = getLoggerFormattedString("associateConnection");
				logger.debug(debugMsg);
			}
			if (!(connection instanceof VistaLinkConnection)) {
				String errStr = "This connection is not of type VistaLinkConnection";
				throw new VistaLinkResourceException(errStr);
			}
			synchronized (this) {
				if (!isConnectionHandleAvailable()) {
					String errStr = (new StringBuffer()).append(EXCEPTION_CONNECTION_HANDLES_EXCEEDED).append("[")
							.append(getMaxConnectionHandles()).append("]").toString();
					throw new ConnectionHandlesExceededException(errStr);
				}
				VistaLinkConnectionImpl con = (VistaLinkConnectionImpl) connection;
				VistaLinkManagedConnection mc = null;
				try {
					mc = con.getManagedConnection();
				} catch (FoundationsException e) {
					if (logger.isEnabledFor(Level.ERROR)) {
						String errMsg = getLoggerFormattedStringWStackTrace(
								"The managed connection is null and cannot be disassociated, but the operation will continue",
								e);
						logger.error(errMsg);
					}
					mc = null;
				}
				if (mc != null) {
					mc.disassociateConnection(con);
				}
				con.setManagedConnection(this);
				addConHandle(con);
			}
		} catch (VistaLinkResourceException e) {
			if (logger.isEnabledFor(Level.ERROR)) {
				String errMsg = getLoggerFormattedStringWStackTrace("Error associating connection handle", e);
				logger.error(errMsg);
			}
			throw e;
		}
	}

	/**
	 * Disassociates this instance of VistaLinkManagedConnection from the VistaLinkConnection handle
	 * 
	 * @param con
	 */
	public void disassociateConnection(VistaLinkConnectionImpl con) {
		if (logger.isDebugEnabled()) {
			String debugMsg = getLoggerFormattedString("disassociate connection");
			logger.debug(debugMsg);
		}
		con.setManagedConnection(null);
		removeConHandle(con);
	}

	/**
	 * Application server calls this method to force any cleanup on the ManagedConnection instance. This method is
	 * usually called by the container after CONNECTION_CLOSED event is fired.
	 * <p>
	 * ManagedConnection should be cleaned-up to the initial state that is was before getConnection() was called on this
	 * object and be ready to be returned to the connection pool.
	 * 
	 * @see javax.resource.spi.ManagedConnection#cleanup()
	 */
	public void cleanup() throws ResourceException {
		if (logger.isDebugEnabled()) {
			String debugMsg = getLoggerFormattedString("Managed connection cleanup");
			logger.debug(debugMsg);
		}
		Iterator it = conSet.iterator();
		while (it.hasNext()) {
			VistaLinkConnectionImpl con = (VistaLinkConnectionImpl) it.next();
			removeConHandle(con);
			con.setManagedConnection(null);
		}
	}

	/**
	 * Destroys the physical socket connection to M. Application server calls this method either in case of shrinking
	 * the pool size or if exception occurs that is reported to the application server by firing an exception event.
	 * 
	 * @throws VistaLinkResourceException
	 * @see javax.resource.spi.ManagedConnection#destroy()
	 */
	public final synchronized void destroy() throws ResourceException {
		if (logger.isDebugEnabled()) {
			String debugMsg = getLoggerFormattedString("Destroying managed connection");
			logger.debug(debugMsg);
		}
		adapterStatus = EMAdapterStatus.DESTROYING;
		removeFromTimerTask();
		try {
			// Perform a security logout and obtain indicator on whether
			// M/VistA server needs to have a 'close socket' request sent.
			boolean sendCloseRequest = performLogout();
			socketCon.close(sendCloseRequest);
			if (logger.isDebugEnabled()) {
				String debugMsg = getLoggerFormattedString("Socket has been successfully closed");
				logger.debug(debugMsg);
			}
		} catch (VistaSocketException sockExc) {
			String errMsg = getLoggerFormattedStringWStackTrace("Can not close VistaSocketConnection.", sockExc);
			if (logger.isEnabledFor(Level.ERROR)) {
				logger.error(errMsg);
			}
			throw new VistaLinkResourceException(errMsg, sockExc);
		} catch (VistaLinkResourceException e) {
			if (logger.isEnabledFor(Level.ERROR)) {
				String errMsg = getLoggerFormattedStringWStackTrace("Can not perform destroy on managed connection", e);
				logger.error(errMsg);
			}
			throw e;
		} finally {
			setValid(false);
			socketCon = null;
			connReqInfo = null;
			setReAuthState(EMReAuthState.NOTAUTHENTICATED);
			managedConnectionFactory.removeMc(this);
		}
	}

	/**
	 * Closes the associated connection handle. Should not perform any cleanup on the managedConnection system
	 * resources.
	 * 
	 * @param con
	 */
	public void closeHandle(VistaLinkConnection con) throws ResourceException {
		if (logger.isDebugEnabled()) {
			String debugMsg = getLoggerFormattedString("Closing handle");
			logger.debug(debugMsg);
		}
		removeConHandle(con);
		ConnectionEvent event = new ConnectionEvent(this, ConnectionEvent.CONNECTION_CLOSED);
		event.setConnectionHandle(con);
		connectionEventNotifer.connectionClosed(event);
	}

	/**
	 * Creates a new connection handle for this ManagedConnection instance.
	 * 
	 * @param subject security context as JAAS subject
	 * @param connReqInfo ConnectionRequestInfo instance
	 * @return VistaLinkConnection Object instance representing the connection handle
	 * @throws VistaLinkResourceException
	 * @throws ConnectionHandlesExceededException thrown if there are no more allowable connection handles
	 * @see javax.resource.spi.ManagedConnection#getConnection(javax.security.auth.Subject,
	 *      javax.resource.spi.ConnectionRequestInfo)
	 */
	public Object getConnection(Subject subject, ConnectionRequestInfo connReqInfo)
			throws ConnectionHandlesExceededException, ResourceException {

		try {
			long beginTimeMillis = System.currentTimeMillis();
			VistaLinkConnection con = null;
			VistaLinkConnectionRequestInfo cri = null;

			String debugMsg;
			if (logger.isDebugEnabled()) {
				debugMsg = getLoggerFormattedString("Getting connection handle");
				logger.debug(debugMsg);
			}
			synchronized (this) {
				if (isConnectionHandleAvailable()) {
					if (logger.isDebugEnabled()) {
						debugMsg = getLoggerFormattedString("Connection handle available");
						logger.debug(debugMsg);
					}
					con = new VistaLinkConnectionImpl(this);
					cri = (VistaLinkConnectionRequestInfo) connReqInfo;

					/*
					 * IF NEED TO POPULATE DIVISION PROPERTY of a connection spec from the connector being used: Could
					 * check if cri.getConnectionSpec() instanceOf VistaLinkAppProxyConnectionSpec here. If so, check if
					 * division is null. If so, could use managedConnectionFactory.getPrimaryStation to get the primary
					 * station, and stuff it in. Current decision is, not needed because the application must have used
					 * some station # to retrieve the connector with, so the app should just send whatever station# down
					 * that it already has (presumably it's the primaryStation # if they don't have more specific
					 * information about lower-level divisions).
					 */

					if ((this.connReqInfo == null) || (!this.connReqInfo.equals(cri))) {
						setReAuthState(EMReAuthState.NOTAUTHENTICATED);
					} else if (idleTimeCheck()) {
						setReAuthState(EMReAuthState.NOTAUTHENTICATED);
					}
					if (logger.isDebugEnabled()) {
						logger.debug(getLoggerFormattedString("Connection re-authentication status: '"
								+ this.reAuthState.toString() + "'. cri = " + this.getConnReqInfoString()));
					}
					this.connReqInfo = cri;
					addConHandle(con);
					// save elapsed time
					long elapsedTimeMillis = System.currentTimeMillis() - beginTimeMillis;
					managedConnectionFactory.addCreateConnectionHandleTime(elapsedTimeMillis);
					if (logger.isInfoEnabled()) {
						logger.info(getLoggerFormattedString(new StringBuffer().append(
								"getConnection(...) processing time = ").append(elapsedTimeMillis).toString()));
					}
					return con;
				} else {
					String errStr = (new StringBuffer()).append(EXCEPTION_CONNECTION_HANDLES_EXCEEDED).append("[")
							.append(getMaxConnectionHandles()).append("]").toString();
					throw new ConnectionHandlesExceededException(errStr);
				} // isConnectionHandleAvailable()
			} // synchronized
		} catch (VistaLinkResourceException e) {
			if (logger.isEnabledFor(Level.ERROR)) {
				String errMsg = getLoggerFormattedStringWStackTrace("Error getting connection", e);
				logger.error(errMsg);
			}
			throw e;
		}
	}

	/**
	 * Determines if a re-authenticated managed connection has been idle too long
	 * 
	 * @return Returns boolean indicator whether or not managed connection should be re-authenticated again
	 */
	private boolean idleTimeCheck() {
		long currentTime = System.currentTimeMillis();
		if ((currentTime - getLastTimeRpcExecutedMillis()) > reAuthSessionTimeout) {
			if (logger.isDebugEnabled()) {
				logger.debug(getLoggerFormattedString(new StringBuffer().append(
						"Managed connection was idle too long. Re-authentication is required.\n\tCurrent Time: \t")
						.append(currentTime).append("\n\tLast RPC Execution Time: \t")
						.append(getLastTimeRpcExecutedMillis()).append("\n\tDifference: \t").append(
								currentTime - getLastTimeRpcExecutedMillis()).append("\n\tRefresh Rate: \t").append(
								reAuthSessionTimeout).toString()));
			} // logger
			return true;
		} // idle time check
		return false;
	}

	/**
	 * This method is not supported and will throw a NotSupportedException
	 * 
	 * @throws ResourceException
	 * @see javax.resource.spi.ManagedConnection#getLocalTransaction()
	 */
	public LocalTransaction getLocalTransaction() throws ResourceException {
		throw new NotSupportedException("Transaction Not Supported!");
	}

	/**
	 * Returns information about this managed connection
	 * 
	 * @throws ResourceException
	 * @see javax.resource.spi.ManagedConnection#getMetaData()
	 */
	public ManagedConnectionMetaData getMetaData() throws ResourceException {
		return new VistaLinkManagedConnectionMetaData(this);
	}

	/**
	 * Delegated from VistaLinkConnection class to return connection oriented metadata
	 * 
	 * @return ConnectionMetaData
	 * @throws ResourceException
	 */
	public ConnectionMetaData getConnectionMetaData() throws ResourceException {
		VistaLinkConnectionMetaData ret = new VistaLinkConnectionMetaData(this);
		return ret;
	}

	/**
	 * Returns distributed transaction resource, not supported
	 * 
	 * @see javax.resource.spi.ManagedConnection#getXAResource()
	 */
	public XAResource getXAResource() throws ResourceException {
		throw new NotSupportedException("Distributed Transaction Not Supported!");
	}

	/**
	 * @param mcf
	 */
	private void setManagedConnectionFactory(VistaLinkManagedConnectionFactory mcf) {
		managedConnectionFactory = mcf;
	}

	/**
	 * @return VistaLinkManagedConnectionFactory
	 */
	protected final VistaLinkManagedConnectionFactory getManagedConnectionFactory() {
		return managedConnectionFactory;
	}

	/**
	 * @see javax.resource.spi.ManagedConnection#setLogWriter(java.io.PrintWriter)
	 */
	public void setLogWriter(PrintWriter wr) throws ResourceException {
		logWriter = wr;
	}

	/**
	 * @see javax.resource.spi.ManagedConnection#getLogWriter()
	 */
	public PrintWriter getLogWriter() throws ResourceException {
		return logWriter;
	}

	/**
	 * Returns the maxConnectionHandles.
	 * 
	 * @return int
	 */
	public final int getMaxConnectionHandles() {
		return getManagedConnectionFactory().getMaxConnectionHandles();
	}

	/**
	 * Returns the hostAddr.
	 * 
	 * @return InetAddress
	 */
	public final InetAddress getHostAddr() {
		return getManagedConnectionFactory().getHostIpAddressResolved();
		// return hostAddr;
	}

	/**
	 * Returns the hostPort.
	 * 
	 * @return int
	 */
	public final int getHostPort() {
		return getManagedConnectionFactory().getHostPort();
	}

	private long getFactoryDistinguishedIdentifier() {
		return getManagedConnectionFactory().getDistinguishedIdentifier();
	}

	/**
	 * Executes an interaction with the RpcResponseFactory
	 * 
	 * @param request
	 * @return RpcResponse
	 * @throws VistaLinkFaultException
	 * @throws FoundationsException
	 */
	public RpcResponse executeRPC(RpcRequest request) throws VistaLinkFaultException, FoundationsException {
		VistaLinkConnectionSpecImpl connSpec = null;
		RpcResponse response = null;

		// initialize state before execution
		if (getAdapterEnvironment().equals(EMAdapterEnvironment.J2EE)) {
			synchronized (this) {
				connSpec = (VistaLinkConnectionSpecImpl) connReqInfo.getConnectionSpec();
			}
			if (connSpec == null) {
				throw new FoundationsException((new StringBuffer()).append("The adapter environment is [").append(
						getAdapterEnvironment().toString()).append("] and the connection spec is null.").toString());
			}
			if (logger.isDebugEnabled()) {
				StringBuffer debugMsg = new StringBuffer("About to execute RPC: '");
				debugMsg.append(request.getRpcName());
				debugMsg.append("', on connector configured with JNDI name: '");
				debugMsg.append(this.managedConnectionFactory.getConnectorJndiName());
				debugMsg.append("', primaryStation: '");
				debugMsg.append(this.managedConnectionFactory.getPrimaryStation());
				debugMsg.append("', reauthentication type: '");
				debugMsg.append(connSpec.getSecurityType());
				debugMsg.append("', conn spec division: '");
				debugMsg.append(connSpec.getDivision());
				debugMsg.append("'.");
				logger.debug(debugMsg.toString());
			}
		} else {
			connSpec = new VistaLinkJ2SEConnSpec();
			setReAuthState(EMReAuthState.AUTHENTICATED);
		}
		request.setReAuthenticateInfo(connSpec, reAuthState, getAdapterEnvironment());
		// execute the RPC interaction
		response = (RpcResponse) executeInteraction(request, new RpcResponseFactory());
		// post processing after successful execute interaction
		if (getAdapterEnvironment().equals(EMAdapterEnvironment.J2EE)) {
			setReAuthState(EMReAuthState.AUTHENTICATED);
			setLastTimeRpcExecutedMillis(System.currentTimeMillis());
			if (logger.isDebugEnabled()) {
				logger.debug("Completed execution of RPC: " + request.getRpcName());
			}
		}
		return response;
	}

	/**
	 * Executes an interaction with M and returns a response constructed by the specified response factory
	 * 
	 * @param requestVO
	 * @param responseFactory
	 * @return VistaLinkResponseVO
	 * @throws VistaLinkFaultException
	 * @throws FoundationsException
	 */
	public final VistaLinkResponseVO executeInteraction(VistaLinkRequestVO requestVO, VistaLinkResponseFactory responseFactory)
			throws VistaLinkFaultException, FoundationsException {
		VistaLinkResponseVO responseVO = null;
		// get request custom timeout if one defined
		long savedSocketTimeOut = socketTimeOut;
		if (requestVO.getTimeOut() > 0) {
			setSocketTimeOut(requestVO.getTimeOut());
		}
		if (logger.isDebugEnabled()) {
			String debugMsg = getLoggerFormattedString("Executing interaction");
			logger.debug(debugMsg);
		}
		try {
			String responseStr;
			try {
				// get response string and convert to response instance
				responseStr = getResponseFromSocket(requestVO.getRequestString());
				responseVO = responseFactory.handleResponse(responseStr, requestVO);
			} catch (VistaSocketTimeOutException stoe) {
				// attempt to establish a new authenticated connection but
				// method also throws or re-throws an exception
				restoreAuthenticatedConnection(stoe);
			} catch (VistaSocketException se) {
				if (doRetryStrategies(requestVO)) {
					// attempt to establish a new authenticated connection
					restoreAuthenticatedConnection(se);
					// perform retry process and convert to response instance
					responseStr = doRetry(requestVO);
					responseVO = responseFactory.handleResponse(responseStr, requestVO);
				} else {
					throw se;
				}
			} catch (SecurityDivisionDeterminationFaultException e) {
				// increment health monitoring
				if (getAdapterEnvironment() != null) {
					if (getAdapterEnvironment().equals(EMAdapterEnvironment.J2EE)) {
						managedConnectionFactory.incrementdivisionMismatchCount();
					}
				}
				throw e;
			} catch (SecurityIdentityDeterminationFaultException e) {
				// increment health monitoring
				if (getAdapterEnvironment() != null) {
					if (getAdapterEnvironment().equals(EMAdapterEnvironment.J2EE)) {
						managedConnectionFactory.incrementIdentityFailureCount();
					}
				}
				throw e;
			}
		} catch (VistaLinkSocketAlreadyClosedException e) {
			throw e;
		} catch (VistaLinkFaultException e) {
			throw e;
		} catch (VistaSocketTimeOutException e) {
			String msgStr = "Socket timeout has occurred";
			if (getAdapterEnvironment().equals(EMAdapterEnvironment.J2EE)) {
				if (logger.isEnabledFor(Level.DEBUG)) {
					String debugMsg = getLoggerFormattedStringWStackTrace(msgStr, e);
					logger.debug(debugMsg);
				}
			} else {
				// remove managed connection from heartbeat timer
				removeFromTimerTask();
				// notify app server of error with managed connection
				notifyErrorOccurred(e);
				if (logger.isEnabledFor(Level.ERROR)) {
					String errMsg = getLoggerFormattedStringWStackTrace(msgStr, e);
					logger.error(errMsg);
				}
			}
			throw new FoundationsException(msgStr, e);
		} catch (VistaSocketException e) {
			// remove managed connection from heartbeat timer
			removeFromTimerTask();
			// notify app server of error with managed connection
			notifyErrorOccurred(e);
			String errStr = "Exception occurred executing transfer, destroying connection";
			if (logger.isEnabledFor(Level.ERROR)) {
				String errMsg = getLoggerFormattedStringWStackTrace(errStr, e);
				logger.error(errMsg);
			}
			throw new FoundationsException(errStr, e);
		} catch (VistaLinkSocketClosedException e) {
			String errStr = "Error executing the interaction";
			if (logger.isEnabledFor(Level.ERROR)) {
				String errMsg = getLoggerFormattedStringWStackTrace(errStr, e);
				logger.error(errMsg);
			}
			throw new FoundationsException(errStr, e);
		} catch (FoundationsException e) {
			if (logger.isEnabledFor(Level.ERROR)) {
				String errMsg = getLoggerFormattedStringWStackTrace(
						"Can not send/receive data from socket (executeInteraction)", e);
				logger.error(errMsg);
			}
			throw e;
		} finally {
			// reset socket timeout back to connection time out value
			setSocketTimeOut(savedSocketTimeOut);
		}
		return responseVO;
	}

	/**
	 * Method determines if it is acceptable to retry executing the request after a socket exception has occur.
	 * 
	 * If it is determined that a retry attempt should not be performed, the VistaSocketException is rethrown.
	 * 
	 * @param requestVO VistaLinkRequestVO instance that will retried
	 * @return boolean true indicates it is ok to rerty
	 */
	private boolean doRetryStrategies(VistaLinkRequestVO requestVO) {
		String logMsg = "";
		/*
		 * If in j2se environment, return falseto cause re-throwing VistaSocketException
		 */
		if (getAdapterEnvironment().equals(EMAdapterEnvironment.J2SE)) {
			logMsg = "Request retry not attempted because the current environment is J2SE.";
			logger.debug(getLoggerFormattedString(logMsg));
			return false;
		}
		// execute allowOverrideStrategy and if automatic retry not allowed then
		// execute request retry strategy
		if (allowOverrideStrategy.execute(requestVO)) {
			logMsg = "Override retry strategy indicates a retry should automatically be attempted and there is no need to execute the request retry strategy";
			logger.debug(getLoggerFormattedString(logMsg));
		} else {
			logMsg = "Override retry strategy indicates request retry strategy should be executed";
			logger.debug(getLoggerFormattedString(logMsg));
			// execute request retry strategy
			if (!requestVO.getRetryStrategy().execute(requestVO)) {
				logMsg = "Request retry strategy indicates that an attempt to restore socket should not be performed.";
				logger.debug(getLoggerFormattedString(logMsg));
				return false;
			}
		}
		return true;
	}

	/**
	 * Method determines if it is acceptable to retry executing the request after a socket exception has occur.
	 * 
	 * If attempting to retry to acceptable, the request is executed again and a response string is returned if
	 * succesful. If the attempt is unsuccessful, an exception is thrown.
	 * 
	 * @param requestVO VistaLinkRequestVO instance that will retried
	 * @return string representing response
	 */
	private String doRetry(VistaLinkRequestVO requestVO) throws FoundationsException, VistaSocketTimeOutException,
			VistaLinkSocketClosedException, VistaSocketException {
		String responseStr = "";
		try {
			// prepare for retry
			doRetryPreparation(requestVO);
			// try to get response again
			responseStr = getResponseFromSocket(requestVO.getRequestString());
			logger.debug(getLoggerFormattedString("Retry restored socket and successfully executed request."));
		} catch (VistaSocketTimeOutException stoe) {
			restoreAuthenticatedConnection(stoe);
			throw stoe;
		}
		return responseStr;
	}

	/**
	 * Prepares the state of the managed conneciton and/or the request for the retry execution.
	 * 
	 * @param requestVO request instance that will retried
	 */
	private void doRetryPreparation(VistaLinkRequestVO requestVO) {
		// if RPC request must reset state to NOTAUTHENTICATED
		if (requestVO instanceof RpcRequest) {
			RpcRequest rpcRequst = (RpcRequest) requestVO;
			VistaLinkConnectionSpecImpl connSpec;
			synchronized (this) {
				connSpec = (VistaLinkConnectionSpecImpl) connReqInfo.getConnectionSpec();
			}
			setReAuthState(EMReAuthState.NOTAUTHENTICATED);
			rpcRequst.setReAuthenticateInfo(connSpec, reAuthState, getAdapterEnvironment());
			logger
					.debug(getLoggerFormattedString("Reset reauthentication information for retry and reauthentication on M/VistA server."));
		}
	}

	/**
	 * If possible and appropriate, attempts to restore an authentication socket connection to this managed connection
	 * after a socket time out has occurred.
	 * 
	 * @param stoe VistaSocketTimeOutException
	 * @throws VistaSocketException
	 */
	private void restoreAuthenticatedConnection(VistaSocketTimeOutException stoe) throws VistaSocketTimeOutException,
			VistaSocketException {
		setReAuthState(EMReAuthState.NOTAUTHENTICATED);
		if (logger.isEnabledFor(Level.DEBUG)) {
			logger.debug(getLoggerFormattedString(stoe.getMessage()));
		}
		// if c/s application then M partition is in an unreliable state and
		// and it is inappropriate to established a new socket connection.
		if (getAdapterEnvironment().equals(EMAdapterEnvironment.J2SE)) {
			throw stoe;
		}
		try {
			// socketCon.closeDontNotify();
			socketCon.close();
			socketCon = null;
			// if already trying to restore then re-throw exception
			if (this.adapterStatus.equals(EMAdapterStatus.CONSTRUCTING) && this.getMJob().equals(RESETTING_M_JOB_VALUE)) {
				logger
						.error(getLoggerFormattedString("restoreAuthenticatedConnection loop occurrred; exception re-thrown"));
				throw stoe;
			}
			setMJob(RESETTING_M_JOB_VALUE);
			createAuthenticatedConnection();
		} catch (VistaLinkResourceException re) {
			String errStr = "Error getting new authenticated socket connection after socket time out";
			re.setLinkedException(stoe);
			if (logger.isEnabledFor(Level.ERROR)) {
				String errMsg = getLoggerFormattedStringWStackTrace(errStr, re);
				logger.error(errMsg);
			}
			throw new VistaSocketException(errStr, re);
		}
		throw stoe;
	}

	/**
	 * If possible and appropriate, attempts to restore an authentication socket connection to this managed connection
	 * after a socket exception has occurred.
	 * <p>
	 * Also, if a new authenticated socket connection can not or should not be re-established, this method throws
	 * informative execptions and log debug information.
	 * 
	 * @param e VistaSocketException
	 * @throws VistaSocketException
	 * @throws FoundationsException
	 * @throws VistaLinkSocketAlreadyClosedException
	 * @throws VistaLinkSocketClosedException
	 */
	private void restoreAuthenticatedConnection(VistaSocketException e) throws VistaSocketException,
			FoundationsException, VistaLinkSocketAlreadyClosedException, VistaLinkSocketClosedException {
		setReAuthState(EMReAuthState.NOTAUTHENTICATED);
		// if c/s application then M partition is in an unreliable state and
		// and it is inappropriate to established a new soacket connection.
		if (getAdapterEnvironment().equals(EMAdapterEnvironment.J2SE)) {
			throw e;
		}

		if (logger.isDebugEnabled()) {
			logger.debug(getLoggerFormattedString("Exception[adapterStatus]" + adapterStatus.toString()));
		}

		if (adapterStatus.equals(EMAdapterStatus.CLEANUP)) {
			String errMsg = "M has most likely terminated this connection, no need to cleanup";
			if (logger.isDebugEnabled()) {
				String loggerMsg = getLoggerFormattedString(errMsg);
				logger.debug(loggerMsg);
			}
			throw new VistaLinkSocketAlreadyClosedException(errMsg, e);
		}

		if (adapterStatus.equals(EMAdapterStatus.DESTROYING)) {
			String errMsg = "M has most likely terminated this connection, no need to send logout";
			if (logger.isDebugEnabled()) {
				String loggerMsg = getLoggerFormattedString(errMsg);
				logger.debug(loggerMsg);
			}
			throw new VistaLinkSocketAlreadyClosedException(errMsg, e);
		}

		if (adapterStatus.equals(EMAdapterStatus.CONSTRUCTING)) {

			String errMsg = "This connection cannot be retried because construction has failed";
			if (logger.isEnabledFor(Level.ERROR)) {
				String loggerMsg = getLoggerFormattedStringWStackTrace(errMsg, e);
				logger.error(loggerMsg);
			}
			throw new VistaLinkSocketClosedException(errMsg, e);
		}

		if (logger.isDebugEnabled()) {
			String debugMsg = getLoggerFormattedStringWStackTrace(
					"Exception occurred executing transfer, now attempting 2nd pass", e);
			logger.debug(debugMsg);
		}
		socketCon.closeDontNotify();
		socketCon = null;
		try {
			setMJob(RESETTING_M_JOB_VALUE);
			createAuthenticatedConnection();
		} catch (VistaLinkResourceException e1) {
			String errStr = "Error getting new authenticated socket connection for 2nd pass attempt";
			e1.setLinkedException(e);
			if (logger.isEnabledFor(Level.ERROR)) {
				String errMsg = getLoggerFormattedStringWStackTrace(errStr, e1);
				logger.error(errMsg);
			}
			throw new VistaSocketException(errStr, e1);
		}
	}

	/**
	 * Executes an interaction and returns a response from the default response factory.
	 * 
	 * @param requestVO
	 * @return VistaLinkResponseVO
	 * @throws VistaLinkFaultException
	 * @throws FoundationsException
	 */
	public VistaLinkResponseVO executeSystemInteraction(VistaLinkRequestVO requestVO) throws VistaLinkFaultException,
			FoundationsException {
		return executeInteraction(requestVO, new VistaLinkResponseFactoryImpl());
	}

	protected VistaLinkSystemInfoResponse executeSystemInfoInteraction() throws FoundationsException {
		if (logger.isDebugEnabled()) {
			logger.debug(getLoggerFormattedString("Executing system info interaction"));
		}
		VistaLinkSystemInfoRequest req = new VistaLinkSystemInfoRequest(this.getAdapterEnvironment());
		VistaLinkSystemInfoResponseFactory resFactory = new VistaLinkSystemInfoResponseFactory();
		VistaLinkSystemInfoResponse resp = (VistaLinkSystemInfoResponse) this.executeInteraction(req, resFactory);
		return resp;
	}

	/**
	 * Executes a transfer with M.
	 * 
	 * @param request
	 * @return String
	 * @throws VistaSocketException
	 * @throws VistaLinkSocketClosedException
	 * @throws VistaLinkResourceException
	 */
	private synchronized String getResponseFromSocket(String request) throws VistaLinkSocketClosedException,
			VistaSocketException {
		if ((socketCon != null) && (isValid())) {
			if (logger.isDebugEnabled()) {
				String debugMsg = getLoggerFormattedString("Executing transfer with time out of " + socketTimeOut
						* VistaLinkManagedConnectionFactory.getSocketTimeOutMultipler());
				logger.debug(debugMsg);
			}
			try {
				socketCon.setTransferTimeOut(((int) socketTimeOut) * VistaLinkManagedConnectionFactory.getSocketTimeOutMultipler());
				String responseStr = socketCon.transfer(request);
				setLastInteractionTimeMillis(System.currentTimeMillis());
				return responseStr;
			} catch (VistaSocketException e) {
				throw e;
			}
		} else {
			removeFromTimerTask();
			VistaLinkSocketClosedException e = new VistaLinkSocketClosedException("This managed connection is closed. ");
			if (logger.isEnabledFor(Level.ERROR)) {
				String errMsg = getLoggerFormattedString("Error accessing socket");
				logger.error(errMsg, e);
			}
			throw e;
		}
	}

	/**
	 * Notifies event listeners(Application server) that an error has occurred on this managed connection instance.
	 */
	public final void notifyErrorOccurred(Exception e) {
		if (adapterStatus.equals(EMAdapterStatus.DESTROYING)) {
			if (logger.isDebugEnabled()) {
				String debugMsg = getLoggerFormattedString("Error occurred while destroying managed connection, will not notify event listeners as they are already notified");
				logger.debug(debugMsg);
			}
			return;
		}
		if (logger.isEnabledFor(Level.ERROR)) {
			String errMsg = getLoggerFormattedStringWStackTrace("Fatal Error has occurred, notifying event listeners",
					e);
			logger.error(errMsg);
		}
		ConnectionEvent event = new ConnectionEvent(this, ConnectionEvent.CONNECTION_ERROR_OCCURRED, e);
		connectionEventNotifer.connectionErrorOccurred(event);
	}

	/**
	 * Returns the socketCon for this managed connection
	 * 
	 * @return reference tot the current VistaSocketConnection for this managed connection
	 */
	protected VistaSocketConnection getSocketConnection() {
		return socketCon;
	}

	/**
	 * @return the current socket timeout for this managed connection
	 */
	// made it public for testing purposes 01052005 AM
	public long getSocketTimeOut() {
		return socketTimeOut;
	}

	/**
	 * Sets the socket timeout to the value of parameter.
	 * 
	 * @param socketTimeOut value of to set timeout in milliseconds
	 * @throws VistaSocketException
	 */
	// made it public for testing purposes 01052005 AM
	public final void setSocketTimeOut(long socketTimeOut) {
		if (getAdapterEnvironment().equals(EMAdapterEnvironment.J2EE)
				&& managedConnectionFactory.isAlwaysUseDefaultAsMin()) {
			this.socketTimeOut = socketTimeOut < managedConnectionFactory.getDefaultJ2EETimeOut() ? managedConnectionFactory
					.getDefaultJ2EETimeOut()
					: socketTimeOut;
		} else
			this.socketTimeOut = socketTimeOut;
	}

	/**
	 * sets the socket timeout from the value retrieved by the managed connection factory.
	 * 
	 * @throws VistaSocketException
	 */
	final void setDefaultSocketTimeOut() {
		socketTimeOut = managedConnectionFactory.getSocketTimeOut();
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	public final String toString() {
		String adapterEnvironmentString = "";
		if (getAdapterEnvironment() != null) {
			adapterEnvironmentString = getAdapterEnvironment().toString();
		}
		
		StringBuffer sb = new StringBuffer();
		sb.append(this.getClass().getName()).append("[]");
		InetAddress ia = getHostAddr();
		sb.append((ia != null) ? ia.getHostAddress() : "null host address").append("[]");
		sb.append(getHostPort()).append("[]").append(
				getMaxConnectionHandles()).append("[]").append(adapterEnvironmentString).append("[fdi]").append(
				getFactoryDistinguishedIdentifier()).append("[mdi]").append(distinguishedIdentifier);
		return sb.toString();
	}

	/**
	 * @return the operational environment for this managed connection (J2EE or J2SE)
	 */
	protected final EMAdapterEnvironment getAdapterEnvironment() {
		return getManagedConnectionFactory().getAdapterEnvironment();
	}

	/**
	 * Adds this managed connection to the Heartbeat Timer Task
	 * 
	 * @throws VistaLinkResourceException
	 */
	private void addToTimerTask() throws VistaLinkResourceException {
		try {
			this.getManagedConnectionFactory().getHeartBeatTimerManager()
					.addManagedConnection(this, getHeartBeatRate());
		} catch (HeartBeatInitializationFailedException e) {
			setValid(false);
			throw e;
		}
		if (logger.isDebugEnabled()) {
			String debugMsg = getLoggerFormattedString("Added managedconnection to Heartbeat TimerTask");
			logger.debug(debugMsg);
		}
	}

	/**
	 * Removes this managed connection from the Heartbeat Timer task.
	 */
	private void removeFromTimerTask() {
		this.getManagedConnectionFactory().getHeartBeatTimerManager().removeManagedConnection(this);
		if (logger.isDebugEnabled()) {
			String debugMsg = getLoggerFormattedString("removed managedconnection to Heartbeat TimerTask");
			logger.debug(debugMsg);
		}
	}

	/**
	 * @return
	 */
	/**
	 * @return long the last interaction time in milliseconds.
	 */
	public synchronized long getLastInteractionTimeMillis() {
		return lastInteractionTimeMillis;
	}

	/**
	 * Sets the last interaction time in milliseconds.
	 * 
	 * @param lastinteractiontimemillis
	 */
	public final synchronized void setLastInteractionTimeMillis(long lastinteractiontimemillis) {
		this.lastInteractionTimeMillis = lastinteractiontimemillis;
	}

	/**
	 * @return Returns the lastTimeRpcExecutedMillis.
	 */
	protected synchronized long getLastTimeRpcExecutedMillis() {
		return lastTimeRpcExecutedMillis;
	}

	/**
	 * 
	 * @param lastTimeRpcExecutedMillis
	 */
	private synchronized void setLastTimeRpcExecutedMillis(long lastTimeRpcExecutedMillis) {
		this.lastTimeRpcExecutedMillis = lastTimeRpcExecutedMillis;
	}

	/**
	 * Sets the heartBeatRate in milliseconds
	 * 
	 * @param heartBeatRate The heartBeatRate to be set (in milliseconds) for this managed connection
	 */
	private void setHeartBeatRate(long heartBeatRate) {
		this.heartBeatRate = heartBeatRate;
		if (logger.isDebugEnabled()) {
			String debugMsg = getLoggerFormattedString((new StringBuffer()).append("Heartbeat rate set successfully[]")
					.append(heartBeatRate).toString());
			logger.debug(debugMsg);
		}
	}

	/**
	 * 
	 * @return retrieves the heartbeat rate (in milliseconds) for this managed connection
	 */
	protected final long getHeartBeatRate() {
		return heartBeatRate;
	}

	/**
	 * @return Returns the M $JOB for connection
	 */
	protected final String getMJob() {
		return mJob;
	}

	/**
	 * @param mJob The M $JOB for the connection.
	 */
	protected final void setMJob(String mJob) {
		this.mJob = mJob;
		logger.debug(getLoggerFormattedString((new StringBuffer()).append("M $JOB set successfully[]").append(mJob)
				.toString()));
	}

	/**
	 * @return Returns the reAuthSessionTimeout.
	 */
	protected long getReAuthSessionTimeout() {
		return reAuthSessionTimeout;
	}

	/**
	 * @param reAuthSessionTimeout The reAuthSessionTimeout to set.
	 */
	protected final void setReAuthSessionTimeout(long reAuthSessionTimeout) {
		this.reAuthSessionTimeout = reAuthSessionTimeout;
	}

	/**
	 * @return boolean indicates whether this managed connection is a valid connection to an M server.
	 */
	public final synchronized boolean isValid() {
		return valid;
	}

	/**
	 * Sets the indicator on whether this managed connectioin is a valid connection to an M server.
	 * 
	 * @param valid
	 */
	public final synchronized void setValid(boolean valid) {
		this.valid = valid;
	}

	/**
	 * 
	 * @param log
	 * @return String
	 */
	private String getLoggerFormattedString(String log) {
		return (new StringBuffer()).append(this.toString()).append(" M $JOB=" + this.mJob).append("\n\t").append(log)
				.toString();
	}

	/**
	 * @param e
	 * @return String
	 */
	private String getLoggerFormattedStringWStackTrace(Throwable e) {
		return getLoggerFormattedString(ExceptionUtils.getFullStackTrace(e));
	}

	/**
	 * @param log
	 * @param e
	 * @return String
	 */
	private String getLoggerFormattedStringWStackTrace(String log, Throwable e) {
		return getLoggerFormattedString((new StringBuffer()).append(log).append("\n\t").append(
				ExceptionUtils.getFullStackTrace(e)).toString());
	}

	/**
	 * This implementation has changed for app server see hashCode->toString
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object obj) {
		if (obj instanceof VistaLinkManagedConnection) {
			return ((this.distinguishedIdentifier == ((VistaLinkManagedConnection) obj).distinguishedIdentifier) && (this.managedConnectionFactory
					.getDistinguishedIdentifier() == ((VistaLinkManagedConnection) obj).getManagedConnectionFactory()
					.getDistinguishedIdentifier()));
		} else {
			return false;
		}
	}

	/**
	 * Sets the cached hashcode for this object.
	 */
	private void setHashCode() {

		// algorithm taken from "Effective Java" item #8.

		int HASHCODE_SEED = 17;
		int returnVal = HASHCODE_SEED;

		// mcf distinguished id contribution to hashcode
		int mcfDistIdHashCode = (int) (this.managedConnectionFactory.getDistinguishedIdentifier() ^ (this.managedConnectionFactory
				.getDistinguishedIdentifier() >>> 32));
		returnVal = 37 * returnVal + mcfDistIdHashCode;
		// connection distinguished id contribution to hashcode
		int distIdHashCode = (int) (this.distinguishedIdentifier ^ (this.distinguishedIdentifier >>> 32));
		returnVal = 37 * returnVal + distIdHashCode;

		this.hashCode = returnVal;
	}

	/**
	 * return cached hashcode
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		return hashCode;
	}

	/**
	 * @return access code
	 */
	public final String getAccessCode() {
		return getManagedConnectionFactory().getAccessCode();
	}

	/**
	 * @return verify code
	 */
	public final String getVerifyCode() {
		return getManagedConnectionFactory().getVerifyCode();
	}

	/**
	 * @return request info object
	 */
	public synchronized VistaLinkConnectionRequestInfo getConnReqInfo() {
		return connReqInfo;
	}

	public String getConnReqInfoString() {
		VistaLinkConnectionRequestInfo info = getConnReqInfo();
		if (info == null) {
			return "Con Req Info is null";
		} else {
			return info.toString();
		}
	}

	/**
	 * @return Returns the reAuthState.
	 */
	protected EMReAuthState getReAuthState() {
		return reAuthState;
	}

	/**
	 * @param reAuthState The reAuthState to set.
	 */
	protected final void setReAuthState(EMReAuthState reAuthState) {
		this.reAuthState = reAuthState;
		// need to set last time RPC executed for idle time check
		if (this.reAuthState.equals(EMReAuthState.NOTAUTHENTICATED)) {
			setLastTimeRpcExecutedMillis(0);
		}
	}

	long getDistinguishedIdentifier() {
		return distinguishedIdentifier;
	}
}