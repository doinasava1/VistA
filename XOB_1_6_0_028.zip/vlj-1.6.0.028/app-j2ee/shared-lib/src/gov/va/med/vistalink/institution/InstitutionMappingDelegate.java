package gov.va.med.vistalink.institution;

import java.util.Set;

/**
 * Provides methods used by applications to query the institution mapping.
 * 
 */
public class InstitutionMappingDelegate {

	/**
	 * Private constructor to prevent instantiation of this class object.
	 */
	private InstitutionMappingDelegate() {
	}
	
	/**
	 * Returns the JNDI connector name (if found) for a division matching the station number passed in.
	 * <p>
	 * An example of retrieving the JNDI name for a connector is:
	 * <p>
	 * <code>
	 * String stationNumber = 500;
	 * String jndiConnectorName = null;<br>
	 * try {<br>
	 * 	jndiConnectorName = InstitutionMappingDelegate.getJndiConnectorNameForInstitution(stationNumber);<br>
	 * } catch (InstitutionMappingNotFoundException e) {<br>
	 * 	// take some action<br>
	 * } catch (InstitutionMapNotInitializedException e) {<br>
	 * 	// take some action<br>
	 * }
	 * </code>
	 * 
	 * @param stationNumber
	 *            institution station number for Vista Institution.
	 * @return Jndi Connector name, if a connector is found that is mapped to input station number. Use for a JNDI
	 *         lookup of actual VistaLink connector.
	 * @throws InstitutionMapNotInitializedException
	 *             thrown if the institution mapping has not been initialized
	 * @throws InstitutionMappingNotFoundException
	 *             thrown if no connector JNDI name has been mapped to input station number
	 */
	public static String getJndiConnectorNameForInstitution(String stationNumber)
			throws InstitutionMapNotInitializedException, InstitutionMappingNotFoundException {
		InstitutionMapping im = InstitutionMappingFactory.getInstitutionMapping();

		try {
			return im.getJndiConnectorNameForInstitution(stationNumber);
		} catch (InstitutionMappingBadStationNumberException e) {
			throw new InstitutionMappingNotFoundException("Invalid station number format: '" + stationNumber + "'.");
		}
	}

	/**
	 * Returns the set of station# strings for which adapters have been deployed on the current JVM, and for which
	 * institution mappings currently exist. The source of the station#s in the mapping is the primaryStation
	 * configuration attribute, for successfully deployed adapters.
	 * @return Set containing station# strings.
	 * @throws InstitutionMapNotInitializedException
	 */
	public static Set getVistaLinkMappedStationNumberSet() throws InstitutionMapNotInitializedException {

		Set returnVal = null;
		InstitutionMapping im = InstitutionMappingFactory.getInstitutionMapping();
		returnVal = im.getVistaLinkMappedStationNumberSet();
		return returnVal;
	}
}