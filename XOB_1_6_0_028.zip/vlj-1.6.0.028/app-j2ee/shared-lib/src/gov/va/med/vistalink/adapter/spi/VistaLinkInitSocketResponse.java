/*
 * Created on Oct 20, 2003
 *
 */
package gov.va.med.vistalink.adapter.spi;

import gov.va.med.vistalink.adapter.record.VistaLinkResponseVOImpl;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;

/**
 *
 */
public class VistaLinkInitSocketResponse extends VistaLinkResponseVOImpl {


	/**
	 * The logger used for this class
	 */
	private static final Logger logger =
		Logger.getLogger(VistaLinkInitSocketResponse.class);


	/**
	 * The rate the heart beat will scheduled at in millis
	 */
	private long heartBeatRateMillis;

	/**
	 * M partition's $JOB value
	 */
	private String mJob;

	/**
	 * The reauthentication session timeout in millis
	 */
	private long reAuthSessionTimeout;
	
	/**
	 * @param rawXml
	 * @param filteredXml
	 * @param doc
	 * @param messageType
	 */
	protected VistaLinkInitSocketResponse(
		String rawXml,
		String filteredXml,
		Document doc,
		String messageType, 
		long heartBeatRate,
		String mJob,
		long reAuthSessionTimeout) {

		super(rawXml, filteredXml, doc, messageType);

		setHeartBeatRateMillis(heartBeatRate);
		setMJob(mJob);
		setReAuthSessionTimeout(reAuthSessionTimeout);

		if(logger.isDebugEnabled()){

			logger.debug((new StringBuffer())
				.append(("initSocket response constructed"))
				.append("[]")
				.append(getHeartBeatRateMillis()).toString());

		}

	}

	/**
	 * Sets the heartBeatRateMillis.
	 * @param heartBeatRateMillis The heartBeatRateMillis to set
	 */
	private void setHeartBeatRateMillis(long heartBeatRateMillis) {
		this.heartBeatRateMillis = heartBeatRateMillis;
	}

	/**
	 * Returns the heartBeatRateMillis.
	 * @return long
	 */
	protected final long getHeartBeatRateMillis() {
		return heartBeatRateMillis;
	}

    /**
     * @return Returns the $JOB value
     */
	protected String getMJob() {
        return mJob;
    }
    
    /**
     * @param mJob value of $JOB for the M partition associated with the connection
     */
	protected final void setMJob(String mJob) {
        this.mJob = mJob;
    }
    /**
     * @return Returns the reAuthSessionTimeout.
     */
    protected long getReAuthSessionTimeout() {
        return reAuthSessionTimeout;
    }
    /**
     * @param reAuthSessionTimeout The reAuthSessionTimeout to set.
     */
    protected final void setReAuthSessionTimeout(long reAuthSessionTimeout) {
        this.reAuthSessionTimeout = reAuthSessionTimeout;
    }
}
