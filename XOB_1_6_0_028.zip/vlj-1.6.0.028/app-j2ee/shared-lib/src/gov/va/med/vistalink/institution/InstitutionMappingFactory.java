package gov.va.med.vistalink.institution;

import org.apache.log4j.Logger;

/**
 * Factory to create and access the mapping singleton object.
 * 
 */
public class InstitutionMappingFactory {

	private static final Logger logger = Logger.getLogger(InstitutionMappingFactory.class);
	private static Object syncObjSingleton = new Object();
	private static InstitutionMapping singleton = null;

	/**
	 * Private constructor to prevent instantiation of this class object.
	 */
	private InstitutionMappingFactory() {
	}
	
	/**
	 * Return (and if doesn't exist, create) institution mapping singleton instance. Access to
	 * this method are threadsafe.
	 * 
	 * @return InsitutionMapping singleton
	 * @va.exclude
	 */
	public static InstitutionMapping getInstitutionMapping() {
		InstitutionMapping returnVal = null;
		// synchronize creation of singleton
		synchronized (syncObjSingleton) {
			if (singleton == null) {
				logger.debug("Instance is null, so creating.");
				singleton = new InstitutionMapping();
				logger.debug("Instance created.");
			}
			returnVal = singleton;
		}
		return returnVal;
	}

}