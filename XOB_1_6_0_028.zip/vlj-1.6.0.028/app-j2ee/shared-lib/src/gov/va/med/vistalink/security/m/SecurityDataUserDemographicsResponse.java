package gov.va.med.vistalink.security.m;

import java.util.Hashtable;

/**
 * Implements response-specific fields for an AV.GetUserDemographics security message 
 * @see SecurityResponse
 * @see SecurityResponseFactory
 */
public final class SecurityDataUserDemographicsResponse extends SecurityResponse {

	private SecurityVOUserDemographics responseVO;

	/**
	 * 
	 * @see gov.va.med.vistalink.security.m.SecuriytResponse#SecuriytResponse(int, String)
	 */
	SecurityDataUserDemographicsResponse(
		Hashtable userDemographicsHashtable,
		SecurityResponse responseData) {

		super(responseData);
		responseVO = new SecurityVOUserDemographics(responseData.getResultType(), responseData.getResultMessage());
		responseVO.setUserDemographicsHashtable(userDemographicsHashtable);
	}

	/**
	 * returns a VO object populated with the demographics values returned from Vista
	 * @return SecurityVOUserDemographics VO which includes populated demographic values
	 */
	public SecurityVOUserDemographics getSecurityVOUserDemographics() {
		return this.responseVO;
	}
}
