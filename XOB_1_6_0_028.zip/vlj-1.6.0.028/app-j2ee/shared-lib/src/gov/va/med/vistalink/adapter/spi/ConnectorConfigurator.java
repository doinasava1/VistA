package gov.va.med.vistalink.adapter.spi;

import gov.va.med.vistalink.adapter.cci.VistaLinkResourceException;
import gov.va.med.vistalink.adapter.config.Connector;
import gov.va.med.vistalink.adapter.config.ConnectorsDocument;
import gov.va.med.crypto.DESPassPhraseEncrypter;
import gov.va.med.crypto.DESScopedEncrypter;
import gov.va.med.crypto.EncrypterRegistry;

import java.io.File;
import java.io.IOException;

import java.util.HashSet;

import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

import org.apache.log4j.Logger;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;

/**
 * XML configuration file worker.
 * 
 * NOTE: Not designed for thread safety.
 * 
 */
public class ConnectorConfigurator {

	private URL configUrl = null;
	private ConnectorsDocument configDocument;
	private static final Logger logger = Logger.getLogger(ConnectorConfigurator.class);
	private static final String CONFIG_FILE_PATH = "/gov.va.med.vistalink.connectorConfig.xml";

	/**
	 * Default constructor; filepath is the default Classpath location.
	 * 
	 */
	public ConnectorConfigurator() {
		this.configUrl = this.getClass().getResource(CONFIG_FILE_PATH);
	}

	public ConnectorConfigurator(URL url) {
		this.configUrl = url;
	}

	/**
	 * Use XMLBeans to read the config file contents into memory
	 * 
	 * @throws VistaLinkResourceException
	 */
	void readFile() throws VistaLinkResourceException {

		if (configUrl == null) {
			String error = "Missing configuration file path.";
			logger.error(error);
			throw new VistaLinkResourceException(error);
		}

		try {
			logger.debug("parsing XML doc from URL: " + configUrl);
			XmlObject xo = ConnectorsDocument.Factory.parse(configUrl);
			if (xo instanceof ConnectorsDocument) {
				HashSet errors = new HashSet();
				org.apache.xmlbeans.XmlOptions vOptions = new org.apache.xmlbeans.XmlOptions();
				vOptions.setErrorListener(errors);
				if (!xo.validate(vOptions))
					throw new VistaLinkResourceException("Not a valid Connectors document.\n" + errors.toString()
							+ "\n");
				configDocument = (ConnectorsDocument) xo;
			} else {
				throw new VistaLinkResourceException("Not a \"Connectors\" document");
			}

		} catch (XmlException e) {
			String error = "Problem parsing config file. ";
			logger.error(error, e);
			throw new VistaLinkResourceException(error, e);
		} catch (IOException e) {
			String error = "Problem opening config file.";
			logger.error(error, e);
			throw new VistaLinkResourceException(error, e);
		}
	}

	/**
	 * has this CC instance read the config file yet/loaded into memory?
	 * @return yes if file read
	 */
	boolean isFileRead() {
		return configDocument != null;
	}

	/**
	 * 
	 * @return external (String) form of config file URL
	 */
	public String getConfigUrlStr() {
		if (configUrl != null) {
			return this.configUrl.toExternalForm();
		}
		return null;
	}
	/**
	 * 
	 * @return array of connectors in the config file, from the in-memory array
	 * @throws VistaLinkResourceException
	 */
	public Connector[] getConnectorArray() throws VistaLinkResourceException {
		if (!isFileRead())
			readFile();
		return configDocument.getConnectors().getConnectorArray();
	}

	/**
	 * 
	 * @return number of entries in config file, in-memory array.
	 * @throws VistaLinkResourceException
	 */
	public int getConfigFileEntrySize() throws VistaLinkResourceException {

		if (!isFileRead())
			readFile();
		return configDocument.getConnectors().sizeOfConnectorArray();
	}

	/**
	 * get a named connector from in-memory connector array
	 * @param lName lookup key corresponding to jndiName attribute
	 * @return Connector object based on jdniName match
	 * @throws VistaLinkResourceException
	 */
	public Connector getConnectorByName(String lName) throws VistaLinkResourceException {
		if (!isFileRead())
			readFile();
		Connector result = null;
		Connector[] ls = getConnectorArray();
		for (int inx = 0; inx < ls.length; inx++) {
			result = ls[inx];
			if (result.getJndiName().equals(lName)) {
				break;
			}
			result = null;
		}
		return result;
	}

	/**
	 * Save the in-memory state of config file/connector array via XMLBeans to physical config file
	 * 
	 * @return true if file saved without error, false (or exception thrown) otherwise
	 * @throws VistaLinkResourceException
	 */
	public boolean save() throws VistaLinkResourceException {
		if (!isFileRead())
			readFile();
		boolean saveResult = false;
		HashSet errors = new HashSet();
		if (validateMemoryArr(errors)) {
			logger.debug("validateFile succeeded.");
			try {
				configDocument.save(new File(new URI(configUrl.toExternalForm())));
				saveResult = true;
				logger.debug("save config file succeeded.");
			} catch (IOException e) {
				logger.error("save config file failed: ", e);
				throw new VistaLinkResourceException("Error saving configuration file: " + e.getMessage());
			} catch (URISyntaxException e) {
				logger.error("save config file failed: ", e);
				throw new VistaLinkResourceException("Error saving configuration file: " + e.getMessage());
			}
		} else {
			logger.error("validateFile failed: " + errors.toString());
			throw new VistaLinkResourceException("Error validating configuration file: " + errors.toString());
		}
		return saveResult;
	}

	/**
	 * 
	 * @return # of entries in config file not encrypted, in the in-memory array.
	 * @throws VistaLinkResourceException
	 */
	public int getUnencryptedCount() throws VistaLinkResourceException {
		int count = 0;
		if (!isFileRead())
			readFile();
		Connector[] connectorArray = configDocument.getConnectors().getConnectorArray();
		for (int i = 0; i < connectorArray.length; i++) {
			if (!connectorArray[i].getEncrypted())
				count++;
		}
		return count;
	}

	/**
	 * Enrypt all entries in the config file not currently encrypted, in the in-memory array.
	 * 
	 * @return count of entries that were encrypted by this call
	 * @throws VistaLinkResourceException
	 */
	public int encryptAllUnencryptedEntries() throws VistaLinkResourceException {
		if (!isFileRead())
			readFile();
		Connector[] conns = getConnectorArray();
		int count = 0;
		for (int i = 0; i < conns.length; i++) {
			if (!conns[i].getEncrypted()) {
				updateEncryptionIfNeeded(conns[i]);
				count++;
			}
		}
		return count;
	}

	/**
	 * Change the encryption type, to scoped or not scoped.
	 * 
	 * @param isNewEncryptionTypeScoped whether the encryption to switch to is scoped or not scoped
	 * @return # of entries updated
	 * @throws VistaLinkResourceException
	 */
	public int changeEncryptionType(boolean isNewEncryptionTypeScoped) throws VistaLinkResourceException {
		int count = 0;
		if (!isFileRead())
			readFile();
		boolean currentEncryptionScoped = isEncryptionScoped();
		if (currentEncryptionScoped != isNewEncryptionTypeScoped) {
			Connector[] conns = getConnectorArray();
			for (int i = 0; i < conns.length; i++) {
				if (conns[i].getEncrypted()) {
					updateEncryption(conns[i], currentEncryptionScoped, isNewEncryptionTypeScoped);
					count++;
				}
			}
			configDocument.getConnectors().setEncryptionScoped(isNewEncryptionTypeScoped);
		}
		return count;
	}

	/**
	 * 
	 * @return global isEncryptionScoped value for config file, in-memory array.
	 * @throws VistaLinkResourceException
	 */
	public boolean isEncryptionScoped() throws VistaLinkResourceException {
		if (!isFileRead())
			readFile();
		return configDocument.getConnectors().getEncryptionScoped();
	}

	/**
	 * Encrypts an entry (both access/verify codes) if not currently encrypted, in the in-memory array.
	 * @param conn
	 */
	public boolean updateEncryptionIfNeeded(Connector conn) throws VistaLinkResourceException {
		if (!(conn.getEncrypted())) {
			updateEncryption(conn);
			return true;
		}
		return false;
	}

	/**
	 * Encrypts an entry (both access/verify codes), in the in-memory array.
	 * 
	 * @param conn
	 * @throws VistaLinkResourceException
	 */
	private void updateEncryption(Connector conn) throws VistaLinkResourceException {
		boolean currentScoping = isEncryptionScoped();
		updateEncryption(conn, currentScoping, currentScoping);
	}

	/**
	 * Encrypts an entry (both access/verify codes) with ability to decrypt via one encryption scheme, and encrypt via
	 * same or other scheme, in the in-memory array.
	 * 
	 * @param conn entry to encrypt
	 * @param isExistingEncryptionScoped encryption method to use to decrypt existing value
	 * @param isNewEncryptionScoped encryption method to use to encrypt replacement value
	 */
	private void updateEncryption(Connector conn, boolean isExistingEncryptionScoped, boolean isNewEncryptionScoped) {

		String accessCode = null;
		String verifyCode = null;

		// get current a/v codes
		if (conn.getEncrypted()) {
			accessCode = getDecryptedValue(conn.getAccessCode(), isExistingEncryptionScoped);
			verifyCode = getDecryptedValue(conn.getVerifyCode(), isExistingEncryptionScoped);
		} else {
			accessCode = conn.getAccessCode();
			verifyCode = conn.getVerifyCode();
		}

		// update with encrypted versions
		conn.setAccessCode(getEncryptedValue(accessCode, isNewEncryptionScoped));
		conn.setVerifyCode(getEncryptedValue(verifyCode, isNewEncryptionScoped));
		conn.setEncrypted(true);
		logger.debug("updated encryption for connector: '" + conn.getJndiName() + "'.");
	}

	/**
	 * sets encrypted access code, and (if entry not currently encrypted) encrypts verify code and marks entry
	 * encrypted, in the in-memory array.
	 * 
	 * @param conn
	 * @param accessCode
	 */
	public void setEncryptedAccessCode(Connector conn, String accessCode) throws VistaLinkResourceException {
		setEncryptedAccessCode(conn, accessCode, isEncryptionScoped());
	}

	private void setEncryptedAccessCode(Connector conn, String accessCode, boolean useScopedEncryption) {
		conn.setAccessCode(getEncryptedValue(accessCode, useScopedEncryption));
		// if entry is either not encrypted or not scoped, re-encrypt verify code
		if (!(conn.getEncrypted() /* && conn.getScoped() */)) {
			conn.setVerifyCode(getEncryptedValue(conn.getVerifyCode(), useScopedEncryption));
			conn.setEncrypted(true);
		}
	}

	/**
	 * Sets encrypted verify code, and (if entry not currently encrypted) encrypts access code and marks entry
	 * encrypted, in the in-memory array.
	 * 
	 * @param conn
	 * @param verifyCode
	 */
	public void setEncryptedVerifyCode(Connector conn, String verifyCode) throws VistaLinkResourceException {
		setEncryptedVerifyCode(conn, verifyCode, isEncryptionScoped());
	}

	private void setEncryptedVerifyCode(Connector conn, String verifyCode, boolean useScopedEncryption) {
		conn.setVerifyCode(getEncryptedValue(verifyCode, useScopedEncryption));
		// if entry is either not encrypted, re-encrypt access code
		if (!(conn.getEncrypted())) {
			conn.setAccessCode(getEncryptedValue(conn.getAccessCode(), useScopedEncryption));
			conn.setEncrypted(true);
		}
	}

	/**
	 * Add a connector to the in-memory array.
	 * 
	 * @param lName
	 * @return Empty, new connector object
	 * @throws VistaLinkResourceException
	 */
	public Connector addConnector(String lName) throws VistaLinkResourceException {
		if (!isFileRead())
			readFile();
		gov.va.med.vistalink.adapter.config.Connector result = null;
		if (getConnectorByName(lName) != null)
			throw new VistaLinkResourceException("Duplicate Connector Name!");
		result = configDocument.getConnectors().addNewConnector();
		result.setJndiName(lName);
		result.setAlwaysUseDefaultAsMin(true);
		return result;
	}
	
	/**
	 * Delete a connector from the in-memory array
	 * 
	 * @param lName
	 * @throws VistaLinkResourceException
	 */
	public void deleteConnector(String lName) throws VistaLinkResourceException {
		if (!isFileRead()) {
			readFile();
		}
		Connector[] la = getConnectorArray();
		for (int inx = 0; inx < la.length; inx++) {
			if (lName.equals(la[inx].getJndiName())) {
				configDocument.getConnectors().removeConnector(inx);
				logger.debug("just removed connector " + lName);
				save();
				break;
			}
		}
	}

	/**
	 * Call XMLBeans to validate the in-memory array.
	 * 
	 * @param errors
	 * @return false if file not read into memory or if fails validation, true otherwise.
	 */
	public boolean validateMemoryArr(java.util.Collection errors) throws VistaLinkResourceException {
		if (!isFileRead())
			readFile();
		boolean fileRead = isFileRead();
		logger.debug("in validateFile. isFileRead: " + fileRead);
		if (fileRead) {
			if (errors != null) {
				org.apache.xmlbeans.XmlOptions vOptions = new org.apache.xmlbeans.XmlOptions();
				vOptions.setErrorListener(errors);
				fileRead = configDocument.validate(vOptions);
				logger.debug("configDocument.validate(vOptions) result: " + fileRead);
			} else
				fileRead = configDocument.validate();
			logger.debug("configDocument.validate() result: " + fileRead);
		}
		return fileRead;
	}

	// private static String getXMLExceptionMessage(Collection errors) {
	// StringBuffer result = new StringBuffer();
	// for (Iterator i = errors.iterator(); i.hasNext();) {
	// XmlError error = (XmlError) i.next();
	//
	// result.append("\n");
	// result.append("Message: " + error.getMessage() + "\n");
	// result.append("Location of invalid XML: " + error.getCursorLocation().xmlText() + "\n");
	// }
	// return result.toString();
	// }

	/**
	 * Encrypt value using specified scheme.
	 * 
	 * @param original value to encrypt
	 * @param isScoped encryption scheme to use
	 * @return
	 */
	private String getEncryptedValue(String original, boolean isScoped) {
		if ((original != null) && (original.length() > 0)) {
			return EncrypterRegistry.getInstance(isScoped ? DESScopedEncrypter.class : DESPassPhraseEncrypter.class)
					.encrypt(original);
		} else {
			// encryption/decryption combo fails for empty strings
			return original;
		}
	}

	/**
	 * Decrypt value using specified scheme.
	 * 
	 * @param encrypted value to decrypt
	 * @param isScoped encryption scheme to use
	 * @return decrypted value
	 */
	public String getDecryptedValue(String encrypted, boolean isScoped) {
		if ((encrypted != null) && (encrypted.length() > 0)) {
			return EncrypterRegistry.getInstance(isScoped ? DESScopedEncrypter.class : DESPassPhraseEncrypter.class)
					.decrypt(encrypted);
		} else {
			// encryption/decryption combo fails for empty strings
			return encrypted;
		}
	}
}