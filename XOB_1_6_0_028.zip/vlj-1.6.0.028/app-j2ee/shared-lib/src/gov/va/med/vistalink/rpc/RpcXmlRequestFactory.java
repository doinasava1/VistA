package gov.va.med.vistalink.rpc;

import gov.va.med.exception.ExceptionUtils;
import gov.va.med.exception.FoundationsException;
import gov.va.med.vistalink.adapter.spi.VistaLinkManagedConnectionFactory;
import gov.va.med.xml.XmlUtilities;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

/**
 * Factory class to creates instances of RpcXmlRequest from an RpcRequest, used when in non-proprietary (XML)
 * communication mode.
 * 
 * <p>
 * J2SE Example:
 * <p>
 * <code>
 *    //request  and response objects <br>
 *   RpcRequest vReq = null; <br>
 *   RpcResponse vResp = null;
 * <p>   
 *   //The Rpc Context<br>
 *   String rpcContext = &quot;XOBV VISTALINK TESTER&quot;;
 * <p>   
 *   //The Rpc to call<br>
 *   String rpcName = &quot;XOBV TEST PING&quot;;
 * <p>   
 *   //Construct  the request object <br>
 *   vReq = RpcRequestFactory.getRpcRequest(rpcContext, rpcName);
 * <p>   
 *   //Execute the Rpc and get the response<br>
 *   vResp = myConnection.executeRPC(vReq);
 * <p>   
 *   //Work with the response ...
 * </code>
 * 
 */
class RpcXmlRequestFactory {

	/**
	 * the logger used by this class
	 */
	private static final Logger logger = Logger.getLogger(RpcXmlRequestFactory.class);

	/**
	 * Creates a RpcXmlRequest with a null RpcContext and RpcName
	 * 
	 * @return RpcXmlRequest
	 * @throws FoundationsException
	 */
	static RpcXmlRequest getRpcXmlRequest(RpcRequest rpcRequest) throws FoundationsException {
		try {
			RpcXmlRequest rpcXmlRequest = new RpcXmlRequest(XmlUtilities.getDocumentForXmlString(getBaseXml()));

			if (rpcRequest.getRpcName() != null) {
				rpcXmlRequest.setRpcName(rpcRequest.getRpcName());
			}
			if (rpcRequest.getRpcContext() != null) {
				rpcXmlRequest.setRpcContext(rpcRequest.getRpcContext());
			}
			if (rpcRequest.getRpcClientTimeOut() > 0) {
				rpcXmlRequest.setRpcClientTimeOut(rpcRequest.getRpcClientTimeOut());
			}
			rpcXmlRequest.setRpcVersion(rpcRequest.getRpcVersion());
			if (rpcRequest.getVlConnSpec() != null) {
				rpcXmlRequest.setReAuthenticateInfo(rpcRequest.getVlConnSpec());
			}
			buildParams(rpcRequest.getParams(), rpcXmlRequest.getParams());
			return rpcXmlRequest;
		} catch (FoundationsException e) {
			if (logger.isEnabledFor(Level.ERROR)) {
				logger.error((new StringBuffer()).append("Can not create RpcXmlRequest.").append("\n\t").append(
						ExceptionUtils.getFullStackTrace(e)).toString());
			}
			throw e;
		}
	}

	private static void buildParams(RpcRequestParams params, RpcXmlRequestParams xmlParams) {
		// get number of parameters
		int paramCount = params.getParams().size();
		// if no parameters exit
		if (paramCount == 0)
			return;
		// build parameters
		RpcRequestParam param = null;
		int posNumber = 0;
		String posString;
		for (int i = 0; i < paramCount; i++) {
			posNumber = i + 1;
			posString = String.valueOf(posNumber);
			if (params.getParams().containsKey(String.valueOf(posString))) {
				param = (RpcRequestParam) params.getParams().get(posString);
				xmlParams.setParam(posNumber, param.getType(), param.getValue());
			}
		}
	}

	/**
	 * Returns the base xml string used to construct a RpcRequest.
	 * 
	 * @return String
	 */
	private static String getBaseXml() {
		return XmlUtilities.XML_HEADER + "<VistaLink messageType='" + RpcXmlRequest.GOV_VA_MED_RPC_REQUEST + "'"
				+ " mode='singleton'" + " version='"
				+ VistaLinkManagedConnectionFactory.ADAPTER_VERSION
				+ "'"
				+ " xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance'"
				+ " xsi:noNamespaceSchemaLocation='rpcRequest.xsd'"
				// + " xmlns='http://med.va.gov/Foundations'"
				+ ">" + "  <RpcHandler version='" + RpcRequest.RPC_HANDLER_VERSION + "'/>"
				+ "  <Request rpcName='' rpcClientTimeOut='600' rpcVersion='0' >"
				+ "    <Security type='' state='virgin' division=''></Security>" + "    <RpcContext></RpcContext>"
				+ "    <Params></Params>" + "  </Request>" + "</VistaLink>";
	}
}
