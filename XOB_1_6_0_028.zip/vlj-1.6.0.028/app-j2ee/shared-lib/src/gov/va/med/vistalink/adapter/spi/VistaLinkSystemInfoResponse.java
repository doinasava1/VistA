package gov.va.med.vistalink.adapter.spi;

import gov.va.med.vistalink.adapter.record.VistaLinkResponseVOImpl;

import java.util.Map;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;

/**
 * This class represents the parsed response to a VistaLinkSystemInfoRequest.
 * 
 */
public class VistaLinkSystemInfoResponse extends VistaLinkResponseVOImpl {

	/**
	 * The logger used for this class
	 */
	private static final Logger logger = Logger.getLogger(VistaLinkSystemInfoResponse.class);

	/**
	 * The VistaLink system information valus object for a M/VistA server.
	 * 
	 * This value object is needed becuase it must be serializable to go across
	 * JVMs for the admin console addin.
	 */
	private VistaLinkSystemInfoVO systemInfoVO = null;

	/**
	 * @param rawXml
	 * @param filteredXml
	 * @param doc
	 * @param messageType
	 * @param systemInfoMap
	 */
	protected VistaLinkSystemInfoResponse(String rawXml, String filteredXml, Document doc, String messageType,
			Map systemInfoMap) {

		// update inherited impl
		super(rawXml, filteredXml, doc, messageType);

		// create serializable VO
		systemInfoVO = new VistaLinkSystemInfoVO(systemInfoMap);

		// log message for debugging
		if (logger.isDebugEnabled()) {
			logger.debug((new StringBuffer()).append(("system info response constructed")).append("[]"));
		}
	}

	protected VistaLinkSystemInfoVO getSystemInfoVO() {
		return systemInfoVO;
	}
}