/*
 * Created on May 18, 2005
 *
 */
package gov.va.med.vistalink.cache;

import gov.va.med.exception.FoundationsException;

/**
 * Represents a failure to retrieve a VistaLinkConnectionFactory instance based on 
 * jndiName passed, due to requested jndiName not being found in the existing context of 
 * jndiLookup interface.
 * 
 */


public class VistaLinkConnectionFactoryNotFoundException extends
                                                         FoundationsException{
  /**
   * Exception constructor.
   * @va.exclude
   */
  public VistaLinkConnectionFactoryNotFoundException()
  {
    super();
  }
  
  /**
   * Exception constructor.
   * @param message Exception message.
   * @va.exclude
   */
  public VistaLinkConnectionFactoryNotFoundException(String message) {
    super(message);
  }
  
  /**
   * Exception constructor.
   * @param nestedException A nested exception.
   * @va.exclude
   */
  public VistaLinkConnectionFactoryNotFoundException(Exception nestedException) {
    super(nestedException);
  }
  
  /**
   * Exception constructor.
   * @param message Exception message.
   * @param nestedException A nested exception.
   * @va.exclude
   */
  public VistaLinkConnectionFactoryNotFoundException(String message, Exception nestedException) {
    super(message, nestedException);
  }
}