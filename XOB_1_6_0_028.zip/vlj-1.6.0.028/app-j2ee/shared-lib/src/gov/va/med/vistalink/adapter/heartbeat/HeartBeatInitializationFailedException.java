package gov.va.med.vistalink.adapter.heartbeat;

/**
 * This exception class is thrown when the heart beat fails to make its first
 * interaction to retrieve the heartbeat rate from M.
 * 
 */
public class HeartBeatInitializationFailedException extends HeartBeatFailedException {

	/**
	 * Constructor for HeartBeatInitializationFailedException.
	 * 
	 * @param reason
	 *            Reason
	 * @va.exclude
	 */
	public HeartBeatInitializationFailedException(String reason) {
		super(reason);
	}

	/**
	 * Constructor for HeartBeatInitializationFailedException.
	 * 
	 * @param e
	 *            Exception
	 * @va.exclude
	 */
	public HeartBeatInitializationFailedException(Exception e) {
		super(e);
	}

	/**
	 * Constructor for HeartBeatInitializationFailedException.
	 * 
	 * @param reason
	 *            Reason
	 * @param errorCode
	 *            Error Code
	 * @va.exclude
	 */
	public HeartBeatInitializationFailedException(String reason, String errorCode) {
		super(reason, errorCode);
	}

	/**
	 * Constructor for HeartBeatInitializationFailedException.
	 * 
	 * @param reason
	 *            Reason
	 * @param errorCode
	 *            Error Code
	 * @param e
	 *            Exception
	 * @va.exclude
	 */
	public HeartBeatInitializationFailedException(String reason, String errorCode, Exception e) {
		super(reason, errorCode, e);
	}

	/**
	 * Constructor for HeartBeatInitializationFailedException.
	 * 
	 * @param reason
	 *            Reason
	 * @param e
	 *            Exception
	 * @va.exclude
	 */
	public HeartBeatInitializationFailedException(String reason, Exception e) {
		super(reason, e);
	}

}