package gov.va.med.vistalink.security;

import java.io.PrintStream;
import java.io.PrintWriter;

import gov.va.med.exception.ExceptionUtils;
import gov.va.med.exception.FoundationsExceptionInterface;

import javax.security.auth.login.LoginException;

/**
 * Represents a LoginException thrown by the LoginModule. The main difference from <code>LoginException</code> is
 * support in the constructor for including a nested exception.
 * 
 * When attempting a logon, you can trap for the more specific <code>VistaLoginModuleException</code>, in addition to
 * <code>LoginException</code>.
 * 
 */
public class VistaLoginModuleException extends LoginException implements FoundationsExceptionInterface {

	/**
	 * Constructor
	 * 
	 * @param msg
	 *            Exception message
	 * @see java.lang.Throwable#Throwable(String)
	 */
	VistaLoginModuleException(String msg) {
		super(msg);
	}

	/**
	 * Constructor
	 * 
	 * @param nestedException
	 *            exception to nest in new VistaLoginModuleException
	 */
	VistaLoginModuleException(Throwable nestedException) {
		super();
		initCause(nestedException);
	}

	/**
	 * Constructor
	 * 
	 * @param msg
	 *            String exception message
	 * @param nestedException
	 *            exception to nest in new VistaLoginModuleException
	 */
	VistaLoginModuleException(String msg, Throwable nestedException) {
		super(msg);
		initCause(nestedException);
	}

	/**
	 * Gets the nested exception
	 * 
	 * @see gov.va.med.exception.FoundationsExceptionInterface#getNestedException()
	 * @deprecated Use getCause() instead.
	 */
	public Throwable getNestedException() {
		return getCause();
	}

	/**
	 * Returns original message that was passed into the exception constructor. Does not perform message discovery from
	 * the nested exception. Only to be used by the descendants of this class.
	 * 
	 * @return String
	 */
	String getOriginalMessage() {
		return super.getMessage();
	}

	/**
	 * Returns the detail message, including nested messages from the nested exceptions.
	 * 
	 * @see java.lang.Throwable#getMessage()
	 */
	public String getMessage() {
		/*
		 * Note: jdk1.4 getMessage does *not* included nested messages from the nested exceptions, whereas this does.
		 * Guess we just leave this as-is, and it will behave as before for classes derived from FoundationsException.
		 */
		String retMessage = super.getMessage();
		if (retMessage == null) {
			retMessage = "";
		}

		// note that the original (pre-JDK-1.4) version of this call only went down one level.
		if (getCause() == null) {
			return retMessage;
		} else {
			return retMessage + "; \n\tRoot cause exception: \n\t" + getCause().toString();
		}
	}

	/**
	 * Prints the composite message and full embedded stack trace to the
	 * specified stream <code>ps</code>.
	 * 
	 * @see java.lang.Throwable#printStackTrace(java.io.PrintStream)
	 * @param ps
	 *            the print stream
	 */
	public void printStackTrace(PrintStream ps) {
		if (getNestedException() == null) {
			super.printStackTrace(ps);
		} else {
			ps.println(this);
			getNestedException().printStackTrace(ps);
		}
	}

	/**
	 * Prints the composite message and full embedded stack trace to the
	 * specified print writer <code>pw</code>
	 * 
	 * @see java.lang.Throwable#printStackTrace(java.io.PrintWriter)
	 * @param pw the print writer
	 * @deprecated unused method, not part of JAAS spec, left to help preserve compatibility with previous versions
	 * @va.exclude
	 */
	public void printStackTrace(PrintWriter pw) {
		if (getNestedException() == null) {
			super.printStackTrace(pw);
		} else {
			pw.println(this);
			getNestedException().printStackTrace(pw);
		}
	}

	/**
	 * Prints the composite message and full embedded stack trace to
	 * <code>System.err</code>.
	 * 
	 * @see java.lang.Throwable#printStackTrace()
	 * @deprecated unused method, not part of JAAS spec, left to help preserve compatibility with previous versions
	 * @va.exclude
	 */
	public void printStackTrace() {
		printStackTrace(System.err);
	}

	/**
	 * Returns the composite message and full embedded stack trace
	 * 
	 * @see gov.va.med.exception.FoundationsExceptionInterface#getFullStackTrace()
	 * @deprecated Use Throwable.getStackTrace() instead.
	 * @va.exclude
	 */
	public String getFullStackTrace() {
		// no identical substitute for this -- jdk 1.4 getStackTrace returns StackTraceElement[]
		return ExceptionUtils.getFullStackTrace(this);
	}

}