package gov.va.med.vistalink.samples;

import gov.va.med.exception.ExceptionUtils;
import gov.va.med.exception.FoundationsException;
import gov.va.med.vistalink.adapter.cci.VistaLinkAppProxyConnectionSpec;
import gov.va.med.vistalink.adapter.cci.VistaLinkConnection;
import gov.va.med.vistalink.adapter.cci.VistaLinkConnectionFactory;
import gov.va.med.vistalink.adapter.cci.VistaLinkConnectionSpec;
import gov.va.med.vistalink.adapter.cci.VistaLinkDuzConnectionSpec;
import gov.va.med.vistalink.adapter.cci.VistaLinkVpidConnectionSpec;
import gov.va.med.vistalink.adapter.record.VistaLinkFaultException;
import gov.va.med.vistalink.institution.InstitutionMappingDelegate;
import gov.va.med.vistalink.rpc.RpcRequest;
import gov.va.med.vistalink.rpc.RpcRequestFactory;
import gov.va.med.vistalink.rpc.RpcResponse;

import java.io.IOException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.resource.ResourceException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

/**
 * Controller servlet for MVC-architected sample web application.
 * <p>
 * Demonstrates how to use VistaLink in a J2EE environment to execute RPCs and retrieve data from M.
 * 
 * Note: This sample app is naive in a security sense, in terms of (not) checking whether user input conforms to
 * expectations.
 * 
 */
public class VistaLinkJ2EESample extends HttpServlet {

	private static final Logger logger = Logger.getLogger(VistaLinkJ2EESample.class);

	private static final String ACTION_RESULTS = "results";
	private static final String ACTION_APP_PROXY = "app-proxy";
	private static final String ACTION_VPID = "vpid";
	private static final String ACTION_DUZ = "duz";
	private static final String ACTION_LOGIN = "login";
	private static final String ACTION_PROCESS = "process";

	private static final String ACTION_RESULTS_PAGE = "/jsp/DisplayResults.jsp";
	private static final String ACTION_APP_PROXY_PAGE = "/jsp/AppProxyLogon.jsp";
	private static final String ACTION_VPID_PAGE = "/jsp/VpidLogon.jsp";
	private static final String ACTION_DUZ_PAGE = "/jsp/DuzLogon.jsp";
	private static final String ACTION_LOGIN_PAGE = "/jsp/LoginChoice.jsp";
	
	private static final String ATTR_DIVISION = "division";
	private static final String ATTR_DUZ = "duz";
	private static final String ATTR_VPID = "vpid";
	private static final String ATTR_APPPROXY = "appProxyName";
	private static final String ATTR_CONNECTOR = "connector";
	

	/**
	 * @va.exclude
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGetAndPost(request, response);
	}

	/**
	 * @va.exclude
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGetAndPost(request, response);
	}

	/**
	 * Method process boths GET and POST submissions
	 * @param request servlet request object
	 * @param response servlet response object
	 * @throws ServletException
	 * @throws IOException
	 */
	private void doGetAndPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException {

		logger.debug("in doGetAndPost");
		String action = request.getParameter("action");
		RequestDispatcher dispatcher = null;

		if (action != null) {
			if (ACTION_DUZ.equals(action)) {
				dispatcher = getServletContext().getRequestDispatcher(ACTION_DUZ_PAGE);
			} else if (ACTION_VPID.equals(action)) {
				dispatcher = getServletContext().getRequestDispatcher(ACTION_VPID_PAGE);
			} else if (ACTION_APP_PROXY.equals(action)) {
				dispatcher = getServletContext().getRequestDispatcher(ACTION_APP_PROXY_PAGE);
			} else if (ACTION_RESULTS.equals(action)) {
				dispatcher = getServletContext().getRequestDispatcher(ACTION_RESULTS_PAGE);
			} else if (ACTION_LOGIN.equals(action)) {
				dispatcher = getServletContext().getRequestDispatcher(ACTION_LOGIN_PAGE);
			} else if (ACTION_PROCESS.equals(action)) {
				// run RPCs, display results
				processRpc(request, response);
				return; // because dispatcher.forward() called in processRpc
			} else {
				// unknown action... default to login page
				dispatcher = getServletContext().getRequestDispatcher(ACTION_LOGIN_PAGE);
			}
		} else {
			// action is null... default to login page
			dispatcher = getServletContext().getRequestDispatcher(ACTION_LOGIN_PAGE);
		}
		dispatcher.forward(request, response);
	}

	/**
	 * Execute series of RPCs, store output in results StringBuffer.
	 * 
	 * @param request servlet request object
	 * @param response servlet response object
	 * @throws IOException
	 * @throws ServletException
	 */
	private void processRpc(HttpServletRequest request, HttpServletResponse response) throws IOException,
			ServletException {

		VistaLinkConnectionSpec connSpec = null;
		StringBuffer results = new StringBuffer();
		RequestDispatcher dispatcher = null;

		// collect form parameters
		String division = request.getParameter(ATTR_DIVISION);
		String duz = request.getParameter(ATTR_DUZ);
		String vpid = request.getParameter(ATTR_VPID);
		String appProxyName = request.getParameter(ATTR_APPPROXY);
		boolean connRefLookup = "lookup".equals(request.getParameter(ATTR_CONNECTOR));
		boolean connRefSelect = "select".equals(request.getParameter(ATTR_CONNECTOR));

		// create connection spec
		if (vpid != null) {
			connSpec = new VistaLinkVpidConnectionSpec(division, vpid);
			request.setAttribute(ATTR_DIVISION, division);
			request.setAttribute(ATTR_VPID, vpid);
		} else if (duz != null) {
			connSpec = new VistaLinkDuzConnectionSpec(division, duz);
			request.setAttribute(ATTR_DIVISION, division);
			request.setAttribute(ATTR_DUZ, duz);
		} else if (appProxyName != null) {
			connSpec = new VistaLinkAppProxyConnectionSpec(division, appProxyName);
			request.setAttribute(ATTR_DIVISION, division);
			request.setAttribute(ATTR_APPPROXY, appProxyName);
		} else {
			dispatcher = getServletContext().getRequestDispatcher(ACTION_LOGIN_PAGE);
			dispatcher.forward(request, response);
			return;
		}

		Context ic = null;
		String jndiName = "";
		VistaLinkConnectionFactory cf = null;
		VistaLinkConnection myConnection = null;
		RpcRequest vReq = null;
		RpcResponse vResp = null;
		String rpcName = "";
		// rpc success/failure indicator
		request.setAttribute("success", "false");

		if (connSpec != null) {

			try {
				ic = new InitialContext();
				if (connRefLookup) {
					jndiName = InstitutionMappingDelegate.getJndiConnectorNameForInstitution(division);
				} else if (connRefSelect) {
					jndiName = request.getParameter("connectorChoice");
				} else {
					// note, a resource-ref mapping is used to create the resource
					// reference used below
					jndiName = "java:comp/env/eis/vlj/testconnector";
				}
				request.setAttribute("jndiName", jndiName);
				cf = (VistaLinkConnectionFactory) ic.lookup(jndiName);
				myConnection = (VistaLinkConnection) cf.getConnection(connSpec);

				rpcName = "XOBV TEST PING";
				vReq = RpcRequestFactory.getRpcRequest();
				// set request timeout to twice connection's normal value
				vReq.setTimeOut(myConnection.getTimeOut() * 2);
				vReq.setUseProprietaryMessageFormat(true);
				vReq.setRpcContext("XOBV VISTALINK TESTER");
				vReq.setRpcName(rpcName);
				vResp = myConnection.executeRPC(vReq);
				results.append(rpcName).append(" Results: \n").append(vResp.getResults()).append('\n');

				rpcName = "XOBV TEST WORD PROCESSING";
				vReq.setRpcName(rpcName);
				vReq.clearParams();
				vResp = myConnection.executeRPC(vReq);
				results.append('\n').append(rpcName).append(" Results: \n").append(vResp.getResults()).append('\n');

				rpcName = "XOBV TEST STRING";
				vReq.setRpcName(rpcName);
				vReq.clearParams();
				vReq.getParams().setParam(1, "string", "This is a test string!");
				vResp = myConnection.executeRPC(vReq);
				results.append('\n').append(rpcName).append(" Results: \n").append(vResp.getResults()).append('\n');

				rpcName = "XOBV TEST GLOBAL NODE";
				vReq.setRpcName(rpcName);
				vReq.clearParams();
				vReq.getParams().setParam(1, "string", "Hello World");
				vResp = myConnection.executeRPC(vReq);
				results.append('\n').append(rpcName).append(" Results: \n").append(vResp.getResults()).append('\n');

				rpcName = "XOBV TEST RPC LIST";
				vReq.setRpcName(rpcName);
				vReq.clearParams();
				vReq.getParams().setParam(1, "string", "XOB");
				vResp = myConnection.executeRPC(vReq);
				results.append('\n').append(rpcName).append(" Results: \n").append(vResp.getResults());

				logger.debug("got results, length: '" + results.length() + "'");

				request.setAttribute("success", "true");

			} catch (VistaLinkFaultException e) {

				logger.error("Exception occurred executing " + rpcName + "\nException:", e);
				results.append("Exception occurred executing ").append(rpcName).append("\nException:").append(
						ExceptionUtils.getFullStackTrace(e));

			} catch (NamingException e) {

				logger.error("Exception occurred executing " + rpcName + "\nException:", e);
				results.append("Exception occurred:\n&nbsp;\n").append(e.getMessage()).append("\n&nbsp;\n").append(
						ExceptionUtils.getFullStackTrace(e));

			} catch (ResourceException e) {

				logger.error("Exception occurred executing " + rpcName + "\nException:", e);
				results.append("Exception occurred:\n&nbsp;\n").append(e.getMessage()).append("\n&nbsp;\n").append(
						ExceptionUtils.getFullStackTrace(e));

			} catch (FoundationsException e) {

				logger.error("Exception occurred executing " + rpcName + "\nException:", e);
				results.append("Exception occurred executing ").append(rpcName).append("\nException:").append(
						ExceptionUtils.getFullStackTrace(e));

			} finally {

				try {
					ic.close();
				} catch (NamingException e) {
					logger.error("Error closing context: ", e);
				}
				if (myConnection != null) {
					try {
						myConnection.close();
					} catch (ResourceException e) {
						logger.error("Error closing connection:", e);
					}
				}
			}
		}

		// display results
		request.setAttribute("results", results.toString());
		dispatcher = getServletContext().getRequestDispatcher(ACTION_RESULTS_PAGE);
		dispatcher.forward(request, response);
	}
}