package gov.va.med.vistalink.management.action;

import gov.va.med.vistalink.jmx.IJmxHelper;
import gov.va.med.vistalink.jmx.JmxHelperException;
import gov.va.med.vistalink.jmx.JmxHelperFactory;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.apache.struts.Globals;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionErrors;

/**
 * Base class for VistaLink console Struts pages, contains some common functionality.
 * 
 */
public class VistaLinkActionBase extends Action {

	static final Logger logger = Logger.getLogger(VistaLinkActionBase.class);
	static String domainName = "null";

	/**
	 * same as/keep in sync with definitionLabel in portlet's .book file. Used to generate portal-compatible label-for
	 * and styleId attributes (until Struts has an html:label tag) which the portal prefaces with the portlet
	 * definitionLabel.
	 */
	protected static String definitionLabel = null;
	static String STANDALONE_ENV_PROPERTY_NAME = "vistalinkj2m-standalone";
	static String INTEGRATED_DEFLABEL = "VistALinkJ2M";
	static String STANDALONE_DEFLABEL = "";
	
	static {
		// initialize DOMAIN name for header toolbar
		try {
			IJmxHelper jmxHelper = JmxHelperFactory.getJmxHelper();
			domainName = jmxHelper.getComputingDomainName();
		} catch (JmxHelperException e) {
			logger.error("Could not retrieve computing domain name: ", e);
		}

		// initialize definitionlabel for Form labelfor attributes
		try {
			Context ctx = new javax.naming.InitialContext();
			Context env = (Context) ctx.lookup("java:comp/env");
			boolean replaceLabel = Boolean.parseBoolean((String) env.lookup(STANDALONE_ENV_PROPERTY_NAME));
			definitionLabel = replaceLabel ? STANDALONE_DEFLABEL : INTEGRATED_DEFLABEL;
			
		} catch (NamingException e) {
			definitionLabel = INTEGRATED_DEFLABEL;
		}
		logger.debug("Set Definition Label for Edit Form to '" + definitionLabel + "'.");
	}

	private int sessionTimeoutTimerSeconds = -1; // holds timer value to set into page timer to fire session warning
	private int sessionTimeoutWarningMsgSeconds = -1; // holds # seconds to display to user in warning text
	private static final int SESSION_TIMEOUT_SECONDS_WARNING_INTERVAL = 240; // default before session times out

	static final byte ROLE_ADMIN = 1;
	static final byte ROLE_DEPLOYER = 2;
	static final byte ROLE_OPERATOR = 4;
	static final byte ROLE_MONITOR = 8;

	/**
	 * Default security privilege set for action classes
	 */
	static final byte DEPLOYER_OR_ADMIN_OR_OPERATOR = ROLE_OPERATOR | ROLE_ADMIN | ROLE_DEPLOYER;
	static final byte DEPLOYER_OR_ADMIN_OR_OPERATOR_OR_MONITOR = ROLE_OPERATOR | ROLE_ADMIN | ROLE_DEPLOYER
			| ROLE_MONITOR;

	/**
	 * Get 'Global' ActionErrors object for request, initialize it if necessary
	 * 
	 * @param request
	 * @return
	 */
	ActionErrors getGlobalActionErrors(HttpServletRequest request) {
		ActionErrors errors = (ActionErrors) request.getAttribute(Globals.ERROR_KEY);
		if (errors == null) {
			errors = new ActionErrors();
		}
		return errors;
	}

	/**
	 * Add page rendered to request in specific attribute.
	 * 
	 * @param request
	 */
	void addPageRenderedTime(HttpServletRequest request) {
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd h:mm:ss a");
		request.setAttribute("pageRenderedTime", sdf.format(new Date()));
		request.getUserPrincipal().getName();
		request.setAttribute("vlUserName", request.getUserPrincipal().getName());
		request.setAttribute("vlDomain", domainName);
	}

	/**
	 * synchronized method due to access to sessionTimeout instance variables
	 * 
	 * @param request
	 */
	synchronized void addSessionTimeoutWarning(HttpServletRequest request) {

		// retrieve Session timeout value, set sessionTimeout values based on that
		if (sessionTimeoutTimerSeconds < 0) {
			int sessionTimeout = request.getSession().getMaxInactiveInterval();
			if (sessionTimeout > 0) {
				if (sessionTimeout > SESSION_TIMEOUT_SECONDS_WARNING_INTERVAL) {
					sessionTimeoutTimerSeconds = sessionTimeout - SESSION_TIMEOUT_SECONDS_WARNING_INTERVAL;
					sessionTimeoutWarningMsgSeconds = SESSION_TIMEOUT_SECONDS_WARNING_INTERVAL;
				} else {
					sessionTimeoutTimerSeconds = sessionTimeout / 2;
					sessionTimeoutWarningMsgSeconds = sessionTimeoutTimerSeconds;
				}
			}
		}
		request.setAttribute("sessionTimeoutWarningTime", sessionTimeoutTimerSeconds);
		request.setAttribute("sessionTimeoutWarningIntervalMsg", "This administration console session will expire in "
				+ (sessionTimeoutWarningMsgSeconds / 60)
				+ " minutes unless you perform a console action AFTER clicking the OK button. Return to browser?");
	}

	/**
	 * Check if user is in one or more of a set of specified role(s). Unchecked SecurityException is thrown if problem
	 * found.
	 * 
	 * @param request needed to call isUserInRole
	 * @param acceptableRoleFlags pass in bit flags representing permissible roles to check if user has access against
	 */
	void checkIsUserInRole(HttpServletRequest request, byte acceptableRoleFlags) {

		boolean isInRole = false;
		if ((ROLE_ADMIN & acceptableRoleFlags) == ROLE_ADMIN) {
			isInRole = request.isUserInRole("Admin");
		}
		if (!isInRole) {
			if ((ROLE_DEPLOYER & acceptableRoleFlags) == ROLE_DEPLOYER) {
				isInRole = request.isUserInRole("Deployer");
			}
		}
		if (!isInRole) {
			if ((ROLE_OPERATOR & acceptableRoleFlags) == ROLE_OPERATOR) {
				isInRole = request.isUserInRole("Operator");
			}
		}
		if (!isInRole) {
			if ((ROLE_MONITOR & acceptableRoleFlags) == ROLE_MONITOR) {
				isInRole = request.isUserInRole("Monitor");
			}
		}
		if (!isInRole) {
			throw new SecurityException("User does not have sufficient privileges for this operation.");
		}
	}
}
