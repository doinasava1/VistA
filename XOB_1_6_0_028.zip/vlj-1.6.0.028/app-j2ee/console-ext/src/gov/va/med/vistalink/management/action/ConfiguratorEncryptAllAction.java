package gov.va.med.vistalink.management.action;

import gov.va.med.vistalink.adapter.spi.ConnectorConfigurator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.Globals;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.action.DynaActionForm;

/**
 * Action to encrypt all unencrypted entries in the configuration file.
 * 
 */
public class ConfiguratorEncryptAllAction extends VistaLinkActionBase {

	private static final Logger logger = Logger.getLogger(ConfiguratorEncryptAllAction.class);

	public ActionForward execute(ActionMapping mapping, ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {

		// security check
		try {
			checkIsUserInRole(request, DEPLOYER_OR_ADMIN_OR_OPERATOR);
		} catch (SecurityException e) {
			logger.warn("Access attempt without sufficient privileges" + e.getMessage());
			ActionErrors errors = getGlobalActionErrors(request);
			errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("configurator.nopriv", new Object[] { e.getMessage() }));
			request.setAttribute(Globals.ERROR_KEY, errors);
			return mapping.findForward("nopriv");
		}
		
		DynaActionForm form = (DynaActionForm) actionForm;
		String submitValue = form.getString("submitValue");

		if (isCancelled(request)) {
			logger.debug("request cancelled, forwarding to cancel");
			return mapping.findForward("cancel");
		} else if ("Yes, Encrypt All".equals(submitValue)) {
			ConnectorConfigurator cc = new ConnectorConfigurator();
			try {
				int count = cc.encryptAllUnencryptedEntries();
				cc.save();
				logger.debug("encrypted " + count + " entries.");
				request.setAttribute("isEncrypted", Boolean.TRUE); // to tell list page entries were encrypted
				request.setAttribute("encryptCount", Integer.valueOf(count)); // to tell how many
			} catch (Exception e) {
				logger.error("Error while encrypting unencrypted entries", e);
				ActionErrors errors = getGlobalActionErrors(request);
				errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("configurator.encryptionFailure",
						new Object[] { e.getMessage() }));
				request.setAttribute(Globals.ERROR_KEY, errors);
			}
			return mapping.findForward("success");
		} else {
			request.setAttribute("encryptForm", form);
			return mapping.findForward("prompt");
		}
	}
}
