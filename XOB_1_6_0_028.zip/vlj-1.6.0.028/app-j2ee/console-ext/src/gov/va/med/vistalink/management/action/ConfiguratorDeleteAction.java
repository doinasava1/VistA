package gov.va.med.vistalink.management.action;

import gov.va.med.vistalink.adapter.spi.ConnectorConfigurator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.Globals;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.action.DynaActionForm;

/**
 * Deletes a configuration entry.
 * 
 */
public class ConfiguratorDeleteAction extends VistaLinkActionBase {

	private static final Logger logger = Logger.getLogger(ConfiguratorDeleteAction.class);

	public ActionForward execute(ActionMapping mapping, ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {

		// security check
		try {
			checkIsUserInRole(request, DEPLOYER_OR_ADMIN_OR_OPERATOR);
		} catch (SecurityException e) {
			logger.warn("Access attempt without sufficient privileges" + e.getMessage());
			ActionErrors errors = getGlobalActionErrors(request);
			errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("configurator.nopriv", new Object[] { e.getMessage() }));
			request.setAttribute(Globals.ERROR_KEY, errors);
			return mapping.findForward("nopriv");
		}
		
		addPageRenderedTime(request);
		addSessionTimeoutWarning(request);
		DynaActionForm form = (DynaActionForm) actionForm;

		if (isCancelled(request)) {
			logger.debug("request cancelled, forwarding to cancel");
			return mapping.findForward("cancel");
		}

		String jndiName = form.getString("jndiName");
		ConnectorConfigurator cc = new ConnectorConfigurator();

		try {
			logger.debug("about to delete connector: '" + jndiName + "'.");
			cc.deleteConnector(jndiName);
			logger.debug("deleted connector '" + jndiName + "'.");
			request.setAttribute("isDeleted", Boolean.TRUE);
			request.setAttribute("jndiName", jndiName);
		} catch (Exception e) {
			logger.error("problem deleting connector '" + jndiName + "':", e);
			ActionErrors errors = getGlobalActionErrors(request);
			errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("configurator.generalError", new Object[] {
					"deleting entry", e.getMessage() }));
			request.setAttribute(Globals.ERROR_KEY, errors);
		}
		return mapping.findForward("success");
	}
}
