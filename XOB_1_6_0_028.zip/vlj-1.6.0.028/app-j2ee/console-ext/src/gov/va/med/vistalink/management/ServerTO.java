package gov.va.med.vistalink.management;

/**
 * Transfer object for console pages to pass state information about 'current server' between JSP pages and Struts
 * actions.
 * 
 */
public class ServerTO implements Comparable {

	private String serverName = "";
	private String serverConstructorAttributes = "";
	private boolean isAdminServer = false;

	public String getServerConstructorAttributes() {
		return serverConstructorAttributes;
	}

	public void setServerConstructorAttributes(String serverConstructorAttributes) {
		this.serverConstructorAttributes = serverConstructorAttributes;
	}

	public String getServerName() {
		return serverName;
	}

	public void setServerName(String serverName) {
		this.serverName = serverName;
	}

	public boolean isAdminServer() {
		return isAdminServer;
	}

	public void setAdminServer(boolean isAdminServer) {
		this.isAdminServer = isAdminServer;
	}

	public boolean equals(Object obj) {
		if (!(obj instanceof ServerTO)) {
			return false;
		}
		if (serverName.equals(((ServerTO) obj).getServerName())
				&& serverConstructorAttributes.equals(((ServerTO) obj).getServerConstructorAttributes())) {
			return true;
		}
		return false;
	}

	public int hashCode() {
		return 17 + (7 * serverName.length()) - (11 * serverConstructorAttributes.length());
	}

	public int compareTo(Object obj) {
		int returnVal = 1;
		if (obj instanceof ServerTO) {
			returnVal = serverName.toUpperCase().compareTo(((ServerTO) obj).getServerName().toUpperCase());
		}
		return returnVal;
	}
}
