package gov.va.med.vistalink.management.action;

import gov.va.med.vistalink.adapter.cci.VistaLinkResourceException;
import gov.va.med.vistalink.adapter.spi.ConnectorConfigurator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.Globals;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.action.DynaActionForm;

/**
 * Action to change the config file encryption type to either scoped or not scoped.
 * 
 */
public class ConfiguratorEncryptChangeTypeAction extends VistaLinkActionBase {

	private static final Logger logger = Logger.getLogger(ConfiguratorEncryptChangeTypeAction.class);

	public ActionForward execute(ActionMapping mapping, ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {

		// security check
		try {
			checkIsUserInRole(request, DEPLOYER_OR_ADMIN_OR_OPERATOR);
		} catch (SecurityException e) {
			logger.warn("Access attempt without sufficient privileges" + e.getMessage());
			ActionErrors errors = getGlobalActionErrors(request);
			errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("configurator.nopriv", new Object[] { e.getMessage() }));
			request.setAttribute(Globals.ERROR_KEY, errors);
			return mapping.findForward("nopriv");
		}
		
		DynaActionForm form = (DynaActionForm) actionForm;
		String submitValue = form.getString("submitValue");

		if (isCancelled(request)) {

			logger.debug("request cancelled, forwarding to cancel");
			return mapping.findForward("cancel");

		} else if ("Yes, Change Encryption Type".equals(submitValue)) {

			// 1. confirm current encryption setting = current setting user saw
			boolean viewedCurrentEncryptionScope = ((Boolean) form.get("isCurrentEncryptionScoped")).booleanValue();

			try {
				ConnectorConfigurator cc = new ConnectorConfigurator();
				boolean currentlyScoped = cc.isEncryptionScoped();
				if (currentlyScoped != viewedCurrentEncryptionScope) {
					ActionErrors errors = getGlobalActionErrors(request);
					errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("configurator.conflictingEdit"));
					request.setAttribute(Globals.ERROR_KEY, errors);
				} else {
					// change the encryption type to the opposit of the current type
					int count = cc.changeEncryptionType(!viewedCurrentEncryptionScope);
					cc.save();
					request.setAttribute("newEncryptType", (!viewedCurrentEncryptionScope) ? "scoped" : "not scoped");
					request.setAttribute("newEncryptCount", Integer.valueOf(count));
				}
				request.setAttribute("isEncryptionChanged", Boolean.TRUE); // to tell list page entries were encrypted

			} catch (Exception e) {
				logger.error("Error updating encryption in config file: ", e);
				ActionErrors errors = getGlobalActionErrors(request);
				errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("configurator.generalError", new Object[] {
						"Error updating encryption in config file: ", e.getMessage() }));
				request.setAttribute(Globals.ERROR_KEY, errors);
			}

			// 2. change
			return mapping.findForward("success");

		} else {

			// set up display values to prompt user to make a choice
			try {
				ConnectorConfigurator cc = new ConnectorConfigurator();
				boolean currentlyScoped = cc.isEncryptionScoped();
				form.set("isCurrentEncryptionScoped", Boolean.valueOf(currentlyScoped));
				request.setAttribute("currentlyScoped", Boolean.valueOf(currentlyScoped));
				request.setAttribute("currentlyNotScoped", Boolean.valueOf(!currentlyScoped));

			} catch (VistaLinkResourceException e) {

				logger.error("Could not retrieve encryption scope value from config file: ", e);
				ActionErrors errors = getGlobalActionErrors(request);
				errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("configurator.generalError", new Object[] {
						"Could not retrieve encryption scope value from config file:", e.getMessage() }));
				request.setAttribute(Globals.ERROR_KEY, errors);

			}

			request.setAttribute("encryptForm", form);
			return mapping.findForward("prompt");
		}
	}
}
