package gov.va.med.vistalink.management;

import com.bea.console.handles.Handle;

/**
 * Followed BEA console extension documentation instructions by creating this Handle class and passing in all form
 * beans. However, cannot find any effect the presence of this class actually imparts.
 * 
 */
public class ConsoleFormBeanHandle implements Handle {

	public String getDisplayName() {
		return "VistALink Console";
	}

	public String getObjectIdentifier() {
		return "VistaLinkConsolelId";
	}

	public String getObjectType() {
		return "VistaLinkConsoleObjectType";
	}

	public String getType() {
		return "VistaLinkConsoleType";
	}

	public boolean isInitialized() {
		return true;
	}

	public boolean isObjectType(String arg0) {
		return false;
	}

}
