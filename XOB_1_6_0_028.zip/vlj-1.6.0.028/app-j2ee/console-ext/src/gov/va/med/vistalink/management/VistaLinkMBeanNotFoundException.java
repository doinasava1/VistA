package gov.va.med.vistalink.management;

/**
 * Thrown when a VistaLink MBean needed to execute methods on a given server, is not found on that server. Typically
 * this would be because there are no VistaLink connectors deployed on the server.
 * 
 */
public class VistaLinkMBeanNotFoundException extends Exception {

}