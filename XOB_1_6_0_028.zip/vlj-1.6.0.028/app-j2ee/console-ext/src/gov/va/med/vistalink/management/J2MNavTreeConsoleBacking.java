package gov.va.med.vistalink.management;

import org.apache.log4j.Logger;

import com.bea.console.utils.NavTreeExtensionBacking;
import com.bea.console.utils.NavTreeExtensionEvent;
import com.bea.jsptools.tree.TreeNode;
import com.bea.netuix.servlets.controls.page.PageBackingContext;

/**
 * Adds the VistALink console to the WebLogic console navtree.
 * 
 */
public class J2MNavTreeConsoleBacking extends NavTreeExtensionBacking {

	private static final Logger logger = Logger.getLogger(J2MNavTreeConsoleBacking.class);

	public NavTreeExtensionEvent getTreeExtension(PageBackingContext ppCtx, String extensionUrl) {

		logger.debug("extensionUrl: " + extensionUrl + ", PageBackingContext DefinitionId: " + ppCtx.getDefinitionId()
				+ ", PageBackingContext DefinitionLabel: " + ppCtx.getDefinitionLabel());

		/*
		 * Construct parent node
		 */
		TreeNode parentNode = new TreeNode(ppCtx.getDefinitionLabel(), ppCtx.getTitle(), extensionUrl);

		NavTreeExtensionEvent evt = new NavTreeExtensionEvent(ppCtx.getDefinitionLabel(), extensionUrl, "/Environment",
				parentNode, NavTreeExtensionEvent.APPEND_ACTION);

		return evt;
	}
}
