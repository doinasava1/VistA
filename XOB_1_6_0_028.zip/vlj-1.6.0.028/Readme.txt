:: Department of Veterans Affairs
:: Office of Information & Technology (OI&T)
:: Veterans Health Information Technology (VHIT)
:: Common Services Portfolio
:: Product: VistALink (VL)

:: Connectivity Scope: J2EE to VistA/M
                       J2SE to VistA/M

:: Version: 1.6.0.028

=============================================
       CONTENTS
=============================================

   I. Build History/Lifecycle Map
  II. Introduction
 III. Zip Structure
  IV. Installation Instructions
   V. Known Issues and Limitations 
  VI. M Checksum Information


=============================================
   I.     Build History/Lifecycle Map
=============================================

Significant VistaLink release objects (JARs, EARs, WARs, etc.) have a build # in 
their filenames (e.g., in "vljSamples-1.6.0.001.jar", "001" is the build 
number). To determine what position in the development lifecycle a given 
VistALink build# represents, consult the following table.

      VistALink   VistALink
   v1.6 Build #   Lifecycle Position    Status
   ------------   --------------------  -------------------
            028   Release Candidate 4   current
            027   Release Candidate 3   (old)
            026   Release Candidate 2   (old)
            025   Release Candidate 1   (old)
            024   Dev Preview 2         (old)
            023   Dev Preview           (old)


=============================================
  II.     Introduction
=============================================

VistALink v1.6 addresses changes made to the J2EE Connectors specificiation in 
J2EE v1.4, as well changes made to WebLogic classes (e.g., its console extension 
mechanism). It provides a J2CA v1.5-compatible connector.

The pre-release version of VistALink v1.6 provided in *this* distribution is 
not supported, nor has it been through complete QA or other testing stages. It
is provided to help teams that otherwise cannot move forward with development 
based in WebLogic v9 or 10.

The previous version of VistALink (v1.5) was released in 6/06, and supports J2EE
v1.3 application servers (particularly WebLogic v. 8.1). It provides a J2CA 
v1.0-compatible connector.


=============================================
 III.     Zip Structure
=============================================

The directory structure of the distribution zip file is as follows:

   /vlj-1.6.0.xxx

        /app-j2ee               Application components for J2EE installation
            /configFile-j2ee    sample gov.va.med.vistalink.connectorConfig.xml configuration file
            /console-ext        Console plug-ins and standalone EAR version
            /Rar-Dev-Template   RAR for development systems
            /Rar-Prod-Template  RAR for production systems
            /sample             J2EE sample application
            /shared-lib         shared libraries for production systems
            
        /javadoc                javadoc for public java-side VistALink APIs
        /lib-deprecated         contains supporting jar no longer needed in most cases
        /log4j                  configuration file examples, VistALink logger spreadsheet
        /m                      KIDS distribution containing M side of VistALink
        /rpc-doc                extract of RPC Broker documentation on how to write RPCs
        /samples-J2SE           sample J2SE rich client applications


=============================================
  IV.   Installation Instructions
=============================================

 - See the Installation Guide draft document provided with this version for a 
   installation instructions.


=============================================
   V.     Known Issues and Limitations 
=============================================

 - In WebLogic v10.0, there is no link for the VistALink console extension in the
   WebLogic console navigation tree (left hand side of the console). 
   
   An alternate route to the VistALink console is to click on the top link of 
   the navigation tree, which is the domain name. On the right-hand page, one
   of the tabs is 'VistALink J2M'. 
   
 - In WebLogic v10.3, the console plug-in should not be used. In its place, a
   standalone web application version of the console is provided in an EAR file.


=============================================
  VI.    M Checksum Information 
=============================================
   
This location is where M routine checksums are documented for VistALink.

Routine    CHECK1^XTSUMBLD checksum
--------   ------------------------
Package: XOBU 1.6

XOBUENV   value = 95255801
XOBUM     value = 36328580
XOBUM1    value = 26724948
XOBUPOST  value = 715309
XOBUPRE   value = 3331902
XOBUZAP   value = 66617883
XOBUZAP0  value = 5948951
XOBUZAP1  value = 2296758


Package: XOBV 1.6

XOBVLIB   value = 29603500
XOBVLL    value = 20760795
XOBVLT    value = 32764303
XOBVPOST  value = 74051370
XOBVPRE   value = 568396
XOBVRH    value = 12957948
XOBVRM    value = 4502318
XOBVRMX   value = 3008010
XOBVRPC   value = 55791656
XOBVRPCI  value = 31578368
XOBVRPCX  value = 22239279
XOBVSKT   value = 19091287
XOBVSYSI  value = 53927220
XOBVTCP   value = 48106146
XOBVTCPL  value = 7619114
XOBVTLS   value = 4033073


Package: XOBS 1.6

XOBSCAV   value = 55844023
XOBSCAV1  value = 81688032
XOBSCAV2  value = 64619205
XOBSCI    value = 583719
XOBSRA    value = 61930744
XOBSRA1   value = 2720328
XOBSRAKJ  value = 10014384
